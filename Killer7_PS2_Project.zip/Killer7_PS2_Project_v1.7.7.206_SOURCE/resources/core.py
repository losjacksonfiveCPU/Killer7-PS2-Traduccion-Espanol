from __future__ import annotations
from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable, Optional
import hashlib, json, struct

SECTOR = 2048
SUPPORTED_SERIAL = 'SLUS_211.54'
EUR_SUPPORTED_SERIAL = 'SLES_533.66'


def identify_killer7_iso(iso) -> dict:
    """Identifica Killer7 por serial *o* por su estructura de archivos.

    Algunas herramientas/mods reescriben SYSTEM.CNF o dejan de conservar el
    serial de arranque aunque los datos del juego sigan siendo compatibles.
    Para abrir esas imágenes no exigimos un hash del dump original: si están
    presentes el ejecutable y el AFS característicos de una edición, la imagen
    se considera compatible. Las rutinas de escritura siguen validando tamaños,
    nombres de recursos y bytes concretos antes de modificar nada.
    """
    reported = iso.boot_serial()

    def has(parts):
        try:
            node = iso.find(parts)
            return int(getattr(node, 'size', 0)) > 0
        except Exception:
            return False

    # Un serial exacto tiene prioridad, pero también comprobamos la estructura
    # mínima para no clasificar como Killer7 una ISO distinta con SYSTEM.CNF
    # manipulado.
    eur_layout = has(['D_EU', 'DIR_E.AFS']) and has([EUR_SUPPORTED_SERIAL])
    usa_layout = has(['D_US', 'DIR.AFS']) and has([SUPPORTED_SERIAL])

    if reported == EUR_SUPPORTED_SERIAL and eur_layout:
        return {'edition': 'EUR', 'serial': EUR_SUPPORTED_SERIAL, 'reported_serial': reported, 'inferred': False}
    if reported == SUPPORTED_SERIAL and usa_layout:
        return {'edition': 'USA', 'serial': SUPPORTED_SERIAL, 'reported_serial': reported, 'inferred': False}
    if eur_layout:
        return {'edition': 'EUR', 'serial': EUR_SUPPORTED_SERIAL, 'reported_serial': reported, 'inferred': True}
    if usa_layout:
        return {'edition': 'USA', 'serial': SUPPORTED_SERIAL, 'reported_serial': reported, 'inferred': True}
    return {'edition': '', 'serial': reported, 'reported_serial': reported, 'inferred': False}


def is_compatible_eur_iso(iso) -> bool:
    return identify_killer7_iso(iso).get('edition') == 'EUR'


def is_compatible_usa_iso(iso) -> bool:
    return identify_killer7_iso(iso).get('edition') == 'USA'

TITLE_MENU_BLOCK_INDEX = 9000

# Límites estructurales confirmados en SLUS_211.54.
#
# JMB:
#   - escena = stInfo(76) + 16 * stJimaku(424) = 6860 bytes
#   - char_data ocupa 32 * s16 desde +0x08 hasta +0x47
#   - -2 termina el texto; por tanto el payload seguro es 31 códigos
# Evidencia de ejecutable: rutina ~0x002E4F30, bucle de 16 entradas
# (slti ...,0x10), stride 0x1A8 y stride de escena 0x1ACC.
JMB_UNITS_PER_SCENE = 16
JMB_RECORD_SIZE = 424
JMB_SCENE_SIZE = 6860
JMB_CODE_SLOTS = 32
JMB_MAX_CODES = JMB_CODE_SLOTS - 1

# Subtítulos *.da:
#   - registro = start/end (8 bytes) + 128 * s16 = 264 bytes
#   - -2 termina el texto; payload seguro = 127 códigos
# Evidencia de ejecutable: rutina JIMAKU ~0x002492B8, cálculo
# linea*264 y slti ...,0x80 para el bucle de códigos.
DA_RECORD_SIZE = 264
DA_CODE_SLOTS = 128
DA_MAX_CODES = DA_CODE_SLOTS - 1

# Texto ASCII/SJIS-directo verificado visualmente en SLUS_211.54.  Cada rango se
# escanea como secuencias imprimibles; los bytes no ASCII intercalados (iconos de
# botones, símbolos PS2, etc.) se conservan fuera de la unidad traducible.
# Claves internas del ELF: aparecen en las mismas zonas que el texto de UI, pero
# el MIPS las pasa a constructores/registro/carga de recursos, no al renderer de texto.
# Nunca deben traducirse aunque el escáner ASCII las encuentre.
DIRECT_INTERNAL_KEYS = {
    0x4B5FA8: 'Save',    # nombre interno del objeto de guardado
    0x4B5FF0: 'Option',  # nombre interno del objeto de opciones
    0x4B60E8: 'option',  # clave del recurso gráfico de la pantalla de opciones
}

# Cadenas visibles cortas o con '/' que el detector genérico de ASCII no inventaría
# de forma segura. Se añaden con IDs al final del bloque para no renumerar las
# unidades históricas del XLIFF.
DIRECT_FIXED_VISIBLE = {
    9010: [
        # sentence, offset, slot, source, target sugerido por el maestro
        (97, 0x4B56B0, 0x30, 'or reset/switch off the console.'),
        (98, 0x4B5700, 0x20, 'or reset/switch off console.'),
        (99, 0x4B5C20, 0x10, 'NO'),
    ],
    9011: [
        (24, 0x4B60C8, 0x08, 'ON'),
    ],
}

# Mensajes de Memory Card que son una sola C-string Shift-JIS. El extractor
# histórico partía la cadena alrededor de 81 A0 (□), rellenaba el primer tramo
# con espacios y esos espacios acababan dibujándose. El compilador recompone cada
# cadena lógica y rellena sólo al final.
DIRECT_SJIS_COMPOSITES = {
    0x4B51B0: {'end': 0x4B51E0, 'parts': (0x4B51B0, b'\x81\xA0', 0x4B51D6)},
    0x4B52A0: {'end': 0x4B52D0, 'parts': (0x4B52A0, b'\x81\xA0', 0x4B52BC)},
    0x4B5330: {'end': 0x4B5360, 'parts': (0x4B5330, b'\x81\xA0', b'2)')},
    0x4B53B0: {'end': 0x4B53D0, 'parts': (0x4B53B0, b'\x81\xA0', b'2)')},
    0x4B5420: {'end': 0x4B5440, 'parts': (0x4B5420, b'\x81\xA0', b'2)?')},
    0x4B5540: {'end': 0x4B5570, 'parts': (0x4B5540, b'\x81\xA0', 0x4B5557)},
    0x4B5620: {'end': 0x4B5650, 'parts': (0x4B5620, b'\x81\xA0', 0x4B5632)},
    0x4B5680: {'end': 0x4B56B0, 'parts': (0x4B5680, b'\x81\xA0', 0x4B5692)},
    0x4B5790: {'end': 0x4B57B0, 'parts': (0x4B5790, b'\x81\xA0', 0x4B57A2)},
    0x4B5850: {'end': 0x4B5870, 'parts': (0x4B5850, b'\x81\xA0', b'2) ?')},
    0x4B5A30: {'end': 0x4B5A50, 'parts': (0x4B5A30, b'\x81\xA0', 0x4B5A42)},
    0x4B5B30: {'end': 0x4B5B68, 'parts': (0x4B5B30, b'\x81\xA0', b'2)')},
}

DIRECT_ELF_GROUPS = [
    (8998, 'Objetos · anillos', [(0x46D4C0, 0x46D530)]),
    (9001, 'Interfaz · sangre', [(0x4A64C8, 0x4A6588)]),
    (9002, 'Interfaz · personajes y estado', [(0x4A9048, 0x4A91D0)]),
    (9003, 'Interfaz · habilidades', [(0x4AA7D0, 0x4AA8A0), (0x4AADB0, 0x4AB2A0)]),
    (9004, 'Blood Room', [(0x4AB420, 0x4AB900)]),
    (9005, 'Misiones', [(0x4ABA30, 0x4ABF98)]),
    (9006, 'Mapa', [(0x4ACBD0, 0x4ACEA0)]),
    (9007, 'Casa / coliseo', [(0x4AF1E0, 0x4AF260), (0x4AF2E0, 0x4AF2F0)]),
    (9008, 'Combate', [(0x4B0D18, 0x4B0D48), (0x4B0EA0, 0x4B0EB8), (0x4B11D8, 0x4B11E8)]),
    (9009, 'Guardado · capítulos', [(0x4B4F88, 0x4B5150)]),
    (9010, 'Memory Card / guardar / cargar', [(0x4B51B0, 0x4B5D90)]),
    (9011, 'Opciones y guardado', [(0x4B5EB8, 0x4B60F0)]),
    (9012, 'Combate · recarga', [(0x4A6C60, 0x4A6C68)]),
    # v1.7.6.6: etiqueta visible confirmada por la tabla bilingüe del Coliseo.
    # La fila final empareja New Stage con ﾆｭｰ ｽﾃｰｼﾞ en los mismos campos
    # donde las filas anteriores contienen Colosseum / ｺﾛｼｱﾑ.
    (9013, 'Casa / coliseo · nueva fase', [(0x4AF3C0, 0x4AF3D0)]),
]

# Tablas de nombres de zona al final de los módulos de escenario. Los límites
# excluyen nombres técnicos/eventos que aparecen inmediatamente después.
MODULE_TEXT_TABLES = [
    (9101, 'MODULES/BIN/S01M.BIN', 'Mapa · Zonas · escenario 1', 0x2DE38, 0x2E600),
    (9102, 'MODULES/BIN/S02M.BIN', 'Mapa · Zonas · escenario 2', 0x19CB0, 0x19F50),
    (9103, 'MODULES/BIN/S03M.BIN', 'Mapa · Zonas · escenario 3', 0x3C6E0, 0x3CD00),
    (9104, 'MODULES/BIN/S04M.BIN', 'Mapa · Zonas · escenario 4', 0x1A568, 0x1A980),
    (9105, 'MODULES/BIN/S05M.BIN', 'Mapa · Zonas · escenario 5', 0x29320, 0x29920),
    (9106, 'MODULES/BIN/S06M.BIN', 'Mapa · Zonas · escenario 6', 0x0F2F8, 0x0F3D0),
    (9107, 'MODULES/BIN/S07M.BIN', 'Mapa · Zonas · escenario 7', 0x1FEB8, 0x20250),
]

# Tablas K7P2 de nombres de ruta/localizador dentro de DIR.AFS.
# El ejecutable resuelve explícitamente las secciones NurbsPathName y
# WinLocatorName. v1.7.6.9 expone sólo los cuatro términos investigados para no
# convertir en localizables claves de gameplay no verificadas.
K7P2_SCENARIO_TERMS = {'Hallway', 'Parking', 'Iwazaru', 'Travis'}
K7P2_TABLE_NAMES = {'NurbsPathName', 'WinLocatorName'}


# Emparejamientos JMB/DIC que no siguen la regla de mismo nombre.
SPECIAL_JMB_DIC = {
    'end.jmb': 'GAL.dic',
    'Select.j': 'Select.r',
}

# Texto horneado dentro de texturas DIC. v1.7.6.5 añade un parche gráfico por
# regiones verificadas para estos 12 recursos. Siguen separados de JMB porque
# son píxeles 4bpp, no secuencias de glifos del motor de subtítulos.
GRAPHIC_TEXT_REFS = [
    (9201, 287, 'kanCel.dic', 'Gráfico · Angel', ['Angel', 'Complete']),
    (9202, 288, 'kanCur.dic', 'Gráfico · Encounter', ['Encounter', 'Complete']),
    (9203, 289, 'kanDmi.dic', 'Gráfico · Minor Image', ['Minor Image', 'Complete']),
    (9204, 290, 'kanEnd.dic', 'Gráfico · final', ['Complete']),
    (9205, 291, 'kanFuk.dic', 'Gráfico · Sunset I', ['Sunset', 'Part I', 'Complete']),
    (9206, 292, 'kanHtl.dic', 'Gráfico · Smile I', ['Smile', 'Part I', 'Complete']),
    (9207, 293, 'kanIsz.dic', 'Gráfico · Encounter II', ['Encounter', 'Part II', 'Complete']),
    (9208, 294, 'kanKak.dic', 'Gráfico · Sunset', ['Sunset', 'Complete']),
    (9209, 295, 'kanNY.dic', 'Gráfico · Alter Ego', ['Alter Ego', 'Complete']),
    (9210, 296, 'kanScl.dic', 'Gráfico · Smile', ['Smile', 'Complete']),
    (9211, 297, 'kanTxs.dic', 'Gráfico · Cloudman', ['Cloudman', 'Complete']),
    (9212, 1409, 'staff2.dic', 'Gráfico · epílogo', ['Shanghai, 100 years later']),
]

# Regiones verificadas visualmente para el recompilador gráfico v1.7.6.5.
# Cada entrada corresponde por orden a las unidades de GRAPHIC_TEXT_REFS.
# box = (x0, y0, x1, y1) dentro de la textura lineal ya deswizzled.
# polarity: 'light' = letras claras sobre fondo negro; 'dark' = letras oscuras sobre blanco.
# clear_box puede ser algo mayor que box para retirar sombras/duplicados del rótulo inglés.
GRAPHIC_PATCH_SPECS = {
    9201: [
        {'box': (38, 178, 425, 318), 'polarity': 'light', 'role': 'title'},
        {'box': (428, 252, 650, 310), 'polarity': 'light', 'role': 'small'},
    ],
    9202: [
        {'box': (32, 68, 456, 145), 'polarity': 'light', 'role': 'title', 'clear_box': (24, 60, 468, 154)},
        {'box': (405, 358, 640, 416), 'polarity': 'light', 'role': 'small'},
    ],
    9203: [
        {'box': (20, 118, 522, 220), 'polarity': 'light', 'role': 'title', 'clear_box': (16, 112, 528, 226)},
        {'box': (382, 378, 650, 442), 'polarity': 'light', 'role': 'small'},
    ],
    9204: [
        {'box': (0, 32, 210, 86), 'polarity': 'light', 'role': 'small'},
    ],
    9205: [
        {'box': (24, 36, 410, 174), 'polarity': 'light', 'role': 'title', 'clear_box': (20, 0, 420, 178)},
        {'box': (274, 180, 390, 250), 'polarity': 'light', 'role': 'small'},
        {'box': (286, 300, 512, 362), 'polarity': 'light', 'role': 'small'},
    ],
    9206: [
        {'box': (178, 18, 474, 142), 'polarity': 'light', 'role': 'title', 'clear_box': (176, 18, 478, 148)},
        {'box': (274, 255, 375, 304), 'polarity': 'light', 'role': 'small'},
        {'box': (244, 362, 425, 412), 'polarity': 'light', 'role': 'small'},
    ],
    9207: [
        {'box': (24, 76, 454, 156), 'polarity': 'light', 'role': 'title', 'clear_box': (24, 72, 460, 162)},
        {'box': (244, 176, 382, 236), 'polarity': 'light', 'role': 'small'},
        {'box': (318, 328, 592, 412), 'polarity': 'light', 'role': 'small'},
    ],
    9208: [
        {'box': (80, 45, 468, 140), 'polarity': 'light', 'role': 'title', 'clear_box': (78, 44, 472, 146)},
        {'box': (402, 308, 608, 365), 'polarity': 'light', 'role': 'small'},
    ],
    9209: [
        {'box': (28, 68, 360, 196), 'polarity': 'light', 'role': 'title'},
        {'box': (378, 382, 574, 440), 'polarity': 'light', 'role': 'small'},
    ],
    9210: [
        {'box': (24, 76, 320, 194), 'polarity': 'light', 'role': 'title', 'clear_box': (22, 74, 324, 198)},
        {'box': (298, 374, 482, 422), 'polarity': 'light', 'role': 'small'},
    ],
    9211: [
        {'box': (104, 94, 526, 220), 'polarity': 'light', 'role': 'title', 'clear_box': (100, 90, 532, 224)},
        {'box': (288, 390, 490, 444), 'polarity': 'light', 'role': 'small'},
    ],
    9212: [
        {'box': (200, 44, 820, 205), 'polarity': 'dark', 'role': 'epilogue', 'clear_box': (198, 42, 824, 208)},
    ],
}
TITLE_MENU_SPECS = [
    {'key': 'press_start', 'source': 'PRESS START BUTTON', 'offset': 0x4A6BC0, 'slot': 24},
    {'key': 'new_game', 'source': 'NEW GAME', 'offset': 0x4A6BF0, 'slot': 16},
    {'key': 'continue', 'source': 'CONTINUE', 'offset': 0x4A6C00, 'slot': 16},
    {'key': 'options', 'source': 'OPTIONS', 'offset': 0x4A6C10, 'slot': 16},
]


class K7Error(RuntimeError):
    pass


@dataclass
class IsoFile:
    path: str
    lba: int
    size: int
    is_dir: bool = False


@dataclass
class AfsEntry:
    index: int
    name: str
    offset: int
    size: int


@dataclass
class TextUnit:
    id: str
    afs_jmb_index: int
    afs_dic_index: int
    afs_name: str
    sentence: int
    jimaku: int
    wait: int
    disp_time: int
    codes: list[int]
    source: str = ''
    source_state: str = 'pending'
    source_candidate: str = ''
    source_provenance: str = ''
    source_confidence: Optional[float] = None
    max_codes: int = JMB_MAX_CODES
    binary_path: str = ''
    binary_offset: int = 0
    binary_slot: int = 0
    binary_pad: str = 'nul'

    @property
    def stable_id(self) -> str:
        return f'k7-{self.afs_jmb_index:04d}-{self.sentence:02d}-{self.jimaku:02d}'

    @property
    def code_signature(self) -> str:
        return ' '.join(f'{(c & 0xffff):04X}' for c in self.codes)

    @property
    def controls(self) -> list[int]:
        return [c & 0xffff for c in self.codes if c not in (-4, -3) and (c & 0xffff) >= 0xff00]

    @property
    def visible_code_count(self) -> int:
        return len(self.codes)



# Etiquetas contextuales v1.7.6.7. No alteran IDs, offsets ni datos binarios:
# sólo hacen que la GUI/XLIFF identifiquen cada contenedor por capítulo y función.
JAPANESE_EXCLUDED_DA = {
    '0073021.da', '0073030.da', '0073040.da', '0073041.da', '0073081.da',
    '0073082.da', '0074011.da', '0074031.da', '0075011.da', '0075020.da',
    '0100031.da', '0100032.da', '0100080.da', '0100131.da', '0121130.da',
}

DA_ROLE_OVERRIDES = {
    '0071010.da': 'Iwazaru · presentación',
    '0078010.da': 'Vinculum Gate · Soul Shells',
    '0078011.da': 'Vinculum Gate · Soul Shells',
    '0100020.da': 'Iwazaru',
    '0100030.da': 'Yoon-Hyun', '0100033.da': 'True Mask',
    '0100061.da': 'Yoon-Hyun · pista', '0100062.da': 'True Mask · solución',
    '0100070.da': 'Susie Sumner · Water Ring', '0100071.da': 'Susie Sumner',
    '0100100.da': 'Iwazaru · sushi',
    '0100151.da': 'Yoon-Hyun · pista', '0100152.da': 'True Mask · solución',
    '0110000.da': 'Travis Bell',
    '0110020.da': 'Travis Bell', '0110030.da': 'Travis Bell', '0110040.da': 'Travis Bell',
    '0110101.da': 'Yoon-Hyun · pista', '0110102.da': 'True Mask · solución',
    '0110111.da': 'Yoon-Hyun · pista', '0110112.da': 'True Mask · solución',
    '0110121.da': 'Yoon-Hyun · pista', '0110122.da': 'True Mask · solución',
    '0110131.da': 'Yoon-Hyun · pista', '0110132.da': 'True Mask · solución',
    '0110200.da': 'Iwazaru', '0110210.da': 'Iwazaru', '0110220.da': 'Iwazaru',
    '0110230.da': 'Iwazaru', '0110240.da': 'Iwazaru',
    '0110300.da': 'Kess Bloodysunday', '0110310.da': 'Kess Bloodysunday',
    '0110510.da': 'Travis Bell', '0116010.da': 'Travis Bell',
    '0112030.da': 'Susie Sumner', '0112031.da': 'Susie Sumner',
    '0201010.da': 'Travis Bell',
    '0201020.da': 'Susie Sumner', '0201021.da': 'Susie Sumner',
    '0201030.da': 'Travis Bell', '0201040.da': 'Travis Bell', '0201050.da': 'Travis Bell',
    '0201100.da': 'Iwazaru', '0201200.da': 'Julia Kisugi',
    '0201300.da': 'Cult Member', '0201310.da': 'Cult Member', '0201320.da': 'Cult Member',
    '0201330.da': 'Cult Member', '0201340.da': 'Cult Member', '0201350.da': 'Cult Member',
    '0201360.da': 'Cult Member',
    '0300100.da': 'Travis Bell', '0350010.da': 'Travis Bell · Ayame',
    '0400900.da': 'Curtis Blackburn',
    '0511210.da': 'Iwazaru',
    '0521010.da': 'Christopher Mills', '0521020.da': 'Christopher Mills',
    '0555000.da': 'Travis Bell · escuela',
}

MODULE_CONTEXT = {
    'S01M.BIN': 'Angel', 'S02M.BIN': 'Sunset', 'S03M.BIN': 'Cloudman',
    'S04M.BIN': 'Encounter', 'S05M.BIN': 'Alter Ego', 'S06M.BIN': 'Smile',
    'S07M.BIN': 'Lion',
}


def _da_chapter(name: str) -> str:
    stem = name.split('.', 1)[0]
    if stem.startswith('007'): return 'Angel'
    if stem.startswith('010'): return 'Sunset · Parte 1'
    if stem.startswith('011'): return 'Sunset · Parte 2'
    if stem.startswith('012'): return 'Sistema / tutoriales'
    if stem.startswith('020'): return 'Cloudman'
    if stem.startswith('030'): return 'Encounter · Parte 1'
    if stem.startswith('035'): return 'Encounter · Parte 2'
    if stem.startswith('040'): return 'Alter Ego'
    if stem.startswith('051'): return 'Smile · Parte 1'
    if stem == '0521010': return 'Smile · Parte 1'
    if stem.startswith('052') or stem.startswith('055'): return 'Smile · Parte 2'
    if stem.startswith('0901'): return 'Tutoriales · habilidades'
    if stem.startswith('0902'): return 'Archivo · Heaven Smile'
    return 'General'


def _da_role(block) -> str:
    if block.name in JAPANESE_EXCLUDED_DA:
        return 'Japonés · excluido'
    if block.name in DA_ROLE_OVERRIDES:
        return DA_ROLE_OVERRIDES[block.name]
    if block.name.startswith('0901'):
        return 'Iwazaru · sistema/habilidades'
    if block.name.startswith('0902'):
        return 'Iwazaru · bestiario'
    src = [u.source.strip() for u in block.units if u.source and u.source_state.lower() != 'pending']
    head = ' '.join(src[:4]).lower()
    if src and src[0].lower().startswith('master'):
        return 'Iwazaru'
    if 'i sell information' in head:
        return 'Yoon-Hyun'
    if 'loser' in head:
        return 'True Mask'
    if "smith. ('-')/" in head or "smith. ('-')" in head:
        return 'Susie Sumner'
    return 'diálogo / escena'


def _jmb_chapter(name: str) -> str:
    raw = name.rstrip('.')
    low = raw.lower()
    if low == 'end.jmb': return 'Final · recurso especial'
    if low == 'select.j': return 'Interfaz · selección / descifrado'
    if low == 'noise': return 'Sistema · efectos'
    if low == 'handso': return 'Angel · recurso Handso'
    if low == 'h_tit': return 'Interfaz · títulos'
    hmap = {'h_007':'Angel', 'h_010':'Sunset', 'h_020':'Cloudman', 'h_035':'Encounter', 'h_055':'Smile'}
    if low in hmap: return hmap[low]
    if low.startswith('p') and len(low) >= 4:
        code = low[1:4]
        return {'000':'Angel / prólogo','007':'Angel','011':'Sunset','020':'Cloudman','035':'Encounter','055':'Smile'}.get(code, 'Escena')
    if raw and raw[0].isdigit():
        return {'1':'Sunset','2':'Cloudman','3':'Encounter','4':'Alter Ego','5':'Smile','7':'Lion'}.get(raw[0], 'Escena')
    return 'Escena'


def block_context(block) -> str:
    if block.storage_kind == 'afs_da':
        return f'{_da_chapter(block.name)} · {_da_role(block)}'
    if block.storage_kind == 'afs_cinematic_da':
        return {
            'key': 'cinematic_da',
            'name': 'SUBTÍTULOS CINEMÁTICAS · DAR/DIC EUR',
            'limit': f'{DA_MAX_CODES} códigos por registro',
            'rule': (
                'DAR temporizado oculto en entradas AFS sin extensión. El visor EUR decodifica '
                'la rama francesa; sólo se inyectan líneas españolas marcadas como verificadas.'
            ),
        }
    if block.storage_kind == 'afs_pair':
        return _jmb_chapter(block.name)
    if block.storage_kind == 'elf_strings':
        return 'Interfaz · menú principal'
    if block.storage_kind == 'afs_graphic_ref':
        return block.name.replace('Gráfico · ', '')
    if block.storage_kind == 'afs_k7p2':
        scene = block.name.split(' ·', 1)[0]
        chapter = {
            '0': 'Angel', '1': 'Sunset', '2': 'Cloudman', '3': 'Encounter',
            '4': 'Alter Ego', '5': 'Smile', '7': 'Lion',
        }.get(scene[1:2] if scene.startswith('S') else '', 'Escenario')
        return f'{chapter} · {scene} · rutas/localizadores'
    if block.storage_kind == 'iso_ascii':
        base = block.storage_path.rsplit('/', 1)[-1]
        mod = MODULE_CONTEXT.get(base)
        return f'{mod} · {block.name}' if mod else block.name
    return block.name

@dataclass
class TextBlock:
    jmb_index: int
    dic_index: int
    name: str
    sentence_num: int
    char_num: int
    units: list[TextUnit] = field(default_factory=list)
    storage_kind: str = 'afs_pair'
    storage_path: str = ''

    @property
    def id(self) -> str:
        safe = ''.join(ch if ch.isalnum() else '_' for ch in self.name).strip('_') or 'unnamed'
        return f'K7_{self.jmb_index:04d}_{safe}'

    @property
    def context(self) -> str:
        return block_context(self)

    @property
    def label(self) -> str:
        clean = self.name.rstrip('.') or '(sin nombre)'
        if self.storage_kind == 'elf_strings':
            return f'MENÚ · {self.context} · {len(self.units)} textos'
        if self.storage_kind == 'iso_ascii':
            return f'DIRECTO · {self.context} · {len(self.units)} textos'
        if self.storage_kind == 'afs_graphic_ref':
            asset = self.units[0].afs_name if self.units else clean
            return f'GRÁFICO · {self.context} · {asset} · {len(self.units)} textos'
        if self.storage_kind == 'afs_k7p2':
            return f'ESCENARIO K7P2 · {self.context} · AFS {self.jmb_index:04d} · {len(self.units)} nombres'
        if self.storage_kind == 'afs_da':
            return f'SUBTÍTULOS · {self.context} · {clean} · {len(self.units)} líneas'
        return f'JMB · {self.context} · {clean} · AFS {self.jmb_index:04d} · {len(self.units)} textos'



def block_format_policy(block: TextBlock) -> dict[str, str]:
    """Política técnica de traducción derivada del formato/binario observado.

    Es deliberadamente conservadora: distingue lo que el motor parece permitir de
    lo que el recompilador de esta versión soporta de forma verificada.
    """
    if block.storage_kind == 'afs_da':
        return {
            'key': 'da',
            'name': 'SUBTÍTULO .da (DAR/DIC)',
            'limit': f'{DA_MAX_CODES} códigos por registro',
            'rule': (
                '128 s16 por registro (264 bytes con tiempos); -2 termina el texto. '
                'El número de registros se lee del DAT, pero esta versión conserva '
                'cantidad y tiempos originales. Atlas local 4bpp: todo target debe pasar preflight.'
            ),
        }
    if block.storage_kind == 'afs_pair':
        return {
            'key': 'jmb',
            'name': 'JMB + DIC',
            'limit': f'{JMB_MAX_CODES} códigos por unidad · {JMB_UNITS_PER_SCENE} unidades/escena',
            'rule': (
                'stJimaku mide 424 bytes y char_data ocupa 32 s16; la escena tiene '
                '16 registros fijos. No dividir ni añadir unidades. Conservar controles/flags '
                'y validar el atlas DIC.'
            ),
        }
    if block.storage_kind == 'elf_strings':
        return {
            'key': 'menu',
            'name': 'MENÚ PRINCIPAL · cadena del ejecutable',
            'limit': 'bytes ASCII del slot original',
            'rule': (
                'C-string renderizada con titlefont. Esta versión no relocaliza la cadena: '
                'ASCII estricto y tamaño de slot fijo.'
            ),
        }
    if block.storage_kind == 'iso_ascii':
        if (block.storage_path or '').startswith('MODULES/'):
            return {
                'key': 'module_direct',
                'name': 'DIRECTO · módulo MWo3',
                'limit': 'bytes ASCII del slot original',
                'rule': (
                    'Las cadenas de zona tienen punteros absolutos dentro del módulo, pero '
                    'la relocalización todavía no está habilitada. ASCII estricto y slot fijo.'
                ),
            }
        return {
            'key': 'slus_direct',
            'name': 'DIRECTO · SLUS_211.54',
            'limit': 'bytes ASCII del slot original',
            'rule': (
                'Hay cadenas por puntero y fragmentos unidos a controles/iconos; no son un '
                'formato uniformemente relocalizable. ASCII estricto, conservar ~ y slot fijo.'
            ),
        }
    if block.storage_kind == 'afs_k7p2':
        return {
            'key': 'k7p2_names',
            'name': 'ESCENARIO K7P2 · rutas/localizadores',
            'limit': 'ASCII · C-string en slot original',
            'rule': (
                'Sólo se edita el valor mostrado de NurbsPathName/WinLocatorName. '
                'La clave interna permanece intacta y la misma modificación se aplica '
                'a la copia K7P2 suelta y a su espejo dentro del DAR siguiente.'
            ),
        }
    if block.storage_kind == 'afs_graphic_ref':
        return {
            'key': 'graphic',
            'name': 'GRÁFICO · texto horneado en DIC',
            'limit': 'región fija dentro de la textura',
            'rule': (
                'Recompilador por regiones: conserva dimensiones, 4bpp, swizzle/layout GS y '
                'todos los bytes ajenos al payload gráfico. El target debe caber visualmente '
                'en la región verificada y el DIC final conservar exactamente su tamaño.'
            ),
        }
    return {'key': 'unknown', 'name': 'Formato desconocido', 'limit': '—',
            'rule': 'No traducir hasta identificar y verificar el formato.'}


class ISO9660:
    def __init__(self, path: str | Path):
        self.path = Path(path)
        self._fh = self.path.open('rb')
        self.root = self._read_root()

    def close(self):
        try:
            self._fh.close()
        except Exception:
            pass

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.close()

    def _read_root(self) -> IsoFile:
        self._fh.seek(16 * SECTOR)
        pvd = self._fh.read(SECTOR)
        if len(pvd) != SECTOR or pvd[1:6] != b'CD001':
            raise K7Error('La imagen no contiene un PVD ISO9660 válido.')
        return self._parse_record(pvd[156:], '/')

    @staticmethod
    def _parse_record(data: bytes, forced_name: Optional[str] = None) -> IsoFile:
        if not data or data[0] < 34:
            raise K7Error('Registro ISO9660 inválido.')
        nlen = data[32]
        raw_name = data[33:33+nlen]
        name = forced_name if forced_name is not None else raw_name.decode('ascii', 'replace')
        name = name.split(';', 1)[0]
        return IsoFile(name, struct.unpack_from('<I', data, 2)[0], struct.unpack_from('<I', data, 10)[0], bool(data[25] & 2))

    def list_dir(self, node: IsoFile) -> list[IsoFile]:
        if not node.is_dir:
            raise K7Error(f'{node.path} no es un directorio ISO9660.')
        self._fh.seek(node.lba * SECTOR)
        data = self._fh.read(node.size)
        out = []
        p = 0
        while p < len(data):
            ln = data[p]
            if ln == 0:
                p = ((p // SECTOR) + 1) * SECTOR
                continue
            rec = data[p:p+ln]
            if len(rec) < ln:
                break
            nlen = rec[32]
            name_raw = rec[33:33+nlen]
            if name_raw not in (b'\x00', b'\x01'):
                out.append(self._parse_record(rec))
            p += ln
        return out

    def find(self, parts: Iterable[str]) -> IsoFile:
        cur = self.root
        full = []
        for part in parts:
            wanted = part.upper().split(';', 1)[0]
            hit = next((x for x in self.list_dir(cur) if x.path.upper().split(';', 1)[0] == wanted), None)
            if hit is None:
                raise K7Error('No se encontró ' + '/'.join(full + [part]) + ' en la ISO.')
            full.append(part)
            hit.path = '/'.join(full)
            cur = hit
        return cur

    def read(self, node: IsoFile, rel_off: int = 0, size: Optional[int] = None) -> bytes:
        size = node.size - rel_off if size is None else min(size, node.size - rel_off)
        self._fh.seek(node.lba * SECTOR + rel_off)
        return self._fh.read(size)

    def boot_serial(self) -> str:
        try:
            txt = self.read(self.find(['SYSTEM.CNF'])).decode('ascii', 'ignore')
        except Exception:
            return ''
        import re
        m = re.search(r'(SLUS|SLES|SLPS|SCES|SCUS|SLPM)[_\- ]?(\d{3})[.\-]?(\d{2})', txt, re.I)
        return (m.group(1).upper() + '_' + m.group(2) + '.' + m.group(3)) if m else ''


class Killer7Project:
    def __init__(self, iso_path: str | Path, source_catalog: Optional[dict] = None):
        self.iso_path = Path(iso_path)
        self.iso = ISO9660(self.iso_path)
        ident = identify_killer7_iso(self.iso)
        if ident.get('edition') != 'USA':
            raise K7Error('La imagen no contiene la estructura compatible de Killer7 USA (D_US/DIR.AFS + SLUS_211.54).')
        self.reported_serial = ident.get('reported_serial', '')
        self.serial_inferred = bool(ident.get('inferred'))
        self.serial = SUPPORTED_SERIAL
        self.afs_node = self.iso.find(['D_US', 'DIR.AFS'])
        self.exe_node = self.iso.find([SUPPORTED_SERIAL])
        self.afs_base = self.afs_node.lba * SECTOR
        self.catalog = source_catalog or {}
        self.entries = self._read_afs_table()
        self.blocks = self._scan_blocks()
        self.da_blocks = self._scan_da_subtitles()
        self.ui_blocks = (
            self._scan_title_menu()
            + self._scan_direct_elf()
            + self._scan_module_texts()
            + self._scan_k7p2_scenario_labels()
            + self._scan_graphic_refs()
        )
        self._image_sha256: Optional[str] = None

    @property
    def all_blocks(self) -> list[TextBlock]:
        return self.blocks + self.da_blocks + self.ui_blocks

    def _scan_title_menu(self) -> list[TextBlock]:
        data = self.iso.read(self.exe_node)
        units = []
        for i, spec in enumerate(TITLE_MENU_SPECS):
            off, slot, source = int(spec['offset']), int(spec['slot']), str(spec['source'])
            raw = data[off:off+slot]
            actual = raw.split(b'\0', 1)[0].decode('ascii', 'replace')
            # Source XLIFF canónico = inglés del disco original. Si la ISO ya está
            # traducida, el editor puede seguir abriéndola; el compilador verificará
            # el slot real antes de aplicar un parche nuevo.
            candidate = '' if actual == source else actual
            units.append(TextUnit(
                f'{TITLE_MENU_BLOCK_INDEX:04d}-{i:02d}-00', TITLE_MENU_BLOCK_INDEX, -1,
                'SLUS_211.54:title-menu', i, 0, 0, 0, [ord(ch) for ch in source],
                source, 'verified', candidate, 'elf-ascii', 1.0, slot - 1,
            ))
        return [TextBlock(
            TITLE_MENU_BLOCK_INDEX, -1, 'Menú principal', len(units), 0, units,
            storage_kind='elf_strings', storage_path=SUPPORTED_SERIAL
        )]

    @staticmethod
    def _direct_string_ok(text: str) -> bool:
        if len(text) < 3 or not any(ch.isalpha() for ch in text):
            return False
        low = text.lower()
        if any(x in text for x in ('_', '%', '/', '\\')):
            return False
        if low.endswith(('.png', '.bin', '.ico', '.afs', '.hps')):
            return False
        # `all` se usaba como prefijo técnico, pero el SLES/SLUS contiene una
        # frase visible real del Blood Room: `all you need is Blood`. No volver a
        # descartarla por el filtro genérico.
        if low.startswith(('event', 'door', 'branch', 'curve', 'set')):
            return False
        if low.startswith('all') and low != 'all you need is blood':
            return False
        if low.endswith(('shape', 'joint', 'path')) or 'tex00' in low:
            return False
        if low.strip() in {'start', 'new stag'}:
            return False
        useful = sum(ch.isalpha() or ch.isspace() or ch in "'`.,!?():;\"-~#" for ch in text)
        return useful / max(1, len(text)) >= 0.80

    def _scan_ascii_ranges(self, node: IsoFile, block_index: int, label: str, ranges, path: str) -> TextBlock:
        data = self.iso.read(node)
        units: list[TextUnit] = []
        import re
        pat = re.compile(rb'[ -~]{3,}')
        seen = set()
        for start, stop in ranges:
            start = max(0, int(start)); stop = min(len(data), int(stop))
            for m in pat.finditer(data, start, stop):
                a, z = m.span()
                # No interpretar el segundo byte imprimible de un carácter Shift-JIS
                # como el inicio de una cadena ASCII (p.ej. 82 42 + "No memory...").
                if a > 0 and (0x81 <= data[a-1] <= 0x9F or 0xE0 <= data[a-1] <= 0xEF) and (0x40 <= data[a] <= 0xFC):
                    a += 1
                raw = data[a:z]
                if len(raw) < 3:
                    continue
                try:
                    text = raw.decode('ascii')
                except UnicodeDecodeError:
                    continue
                if not self._direct_string_ok(text):
                    continue
                key = (a, text)
                if key in seen:
                    continue
                seen.add(key)
                # Si termina en NUL podemos usar también el padding NUL contiguo; si
                # termina ante un byte de control sólo se sustituye el tramo ASCII y
                # las traducciones más cortas se rellenan con espacios.
                pad = 'space'
                slot = len(raw)
                if z < len(data) and data[z] == 0:
                    q = z + 1
                    while q < len(data) and data[q] == 0 and q - a < len(raw) + 65:
                        q += 1
                    slot = q - a
                    pad = 'nul'
                seq = len(units)
                units.append(TextUnit(
                    f'{block_index:04d}-{seq:03d}-00', block_index, -1, path,
                    seq, 0, 0, 0, [ord(ch) for ch in text],
                    text, 'verified', '', 'binary-ascii', 1.0,
                    slot if pad == 'space' else max(1, slot - 1),
                    path, a, slot, pad,
                ))
        return TextBlock(block_index, -1, label, 1, 0, units, 'iso_ascii', path)

    def _scan_direct_elf(self) -> list[TextBlock]:
        out = []
        for idx, label, ranges in DIRECT_ELF_GROUPS:
            block = self._scan_ascii_ranges(self.exe_node, idx, label, ranges, SUPPORTED_SERIAL)
            # Marcar las claves internas sin eliminarlas: así sus IDs históricos no
            # cambian, pero el editor deja claro que no son texto localizable y el
            # compilador las protege aunque un XLIFF antiguo tenga target español.
            for u in block.units:
                if u.binary_offset in DIRECT_INTERNAL_KEYS:
                    u.source_provenance = 'internal-key; no traducir'
            # Añadir cadenas visibles que el escáner genérico omite por ser muy
            # cortas (ON/NO) o contener '/'. Se usan sentences explícitos para no
            # renumerar las unidades existentes.
            existing_offsets = {u.binary_offset for u in block.units}
            for sentence, off, slot, source in DIRECT_FIXED_VISIBLE.get(idx, []):
                if off in existing_offsets:
                    continue
                actual = self.iso.read(self.exe_node, off, slot).split(b'\0', 1)[0]
                try:
                    actual_text = actual.decode('ascii')
                except UnicodeDecodeError:
                    continue
                if actual_text != source:
                    continue
                block.units.append(TextUnit(
                    f'{idx:04d}-{sentence:03d}-00', idx, -1, SUPPORTED_SERIAL,
                    sentence, 0, 0, 0, [ord(ch) for ch in source],
                    source, 'verified', '', 'binary-ascii-fixed', 1.0,
                    max(1, slot - 1), SUPPORTED_SERIAL, off, slot, 'nul',
                ))
            block.units.sort(key=lambda u: (u.binary_offset, u.sentence))
            if block.units:
                out.append(block)
        return out

    def _scan_module_texts(self) -> list[TextBlock]:
        out = []
        for idx, path, label, start, stop in MODULE_TEXT_TABLES:
            try:
                node = self.iso.find(path.split('/'))
            except K7Error:
                continue
            block = self._scan_ascii_ranges(node, idx, label, [(start, stop)], path)
            # Las tablas de zonas no contienen fragmentos concatenados con controles;
            # un espacio final aquí suele indicar identificador/fragmento técnico.
            block.units = [u for u in block.units if u.source == u.source.rstrip()]
            if block.units:
                out.append(block)
        return out

    @staticmethod
    def _k7p2_cstr(raw: bytes, offset: int) -> str | None:
        if not (0 <= int(offset) < len(raw)):
            return None
        end = raw.find(b'\0', int(offset))
        if end < 0:
            return None
        try:
            return raw[int(offset):end].decode('ascii')
        except UnicodeDecodeError:
            return None

    @classmethod
    def _parse_k7p2_name_tables(cls, raw: bytes) -> list[dict]:
        """Extrae pares clave->nombre de NurbsPathName/WinLocatorName.

        Layout observado en los recursos K7P2 de SLUS_211.54:
        - u32 section_count en +0x0C;
        - desde +0x20: pares (puntero_nombre_sección, puntero_tabla);
        - la tabla es una lista de punteros a registros de 2*u32 terminada en 0;
        - cada registro apunta a C-strings ASCII (clave interna, nombre mostrado).
        Los strings están alineados a 4 bytes; conservamos el slot original y no
        relocalizamos en esta revisión.
        """
        if len(raw) < 0x38 or raw[:4] != b'K7P2':
            return []
        try:
            section_count = struct.unpack_from('<I', raw, 0x0C)[0]
        except struct.error:
            return []
        if not (1 <= section_count <= 16) or 0x20 + section_count * 8 > len(raw):
            return []
        out: list[dict] = []
        for si in range(section_count):
            name_ptr, table_ptr = struct.unpack_from('<II', raw, 0x20 + si * 8)
            section = cls._k7p2_cstr(raw, name_ptr)
            if section not in K7P2_TABLE_NAMES:
                continue
            q = int(table_ptr)
            seen_pairs: set[int] = set()
            for _ in range(4096):
                if q + 4 > len(raw):
                    break
                pair_ptr = struct.unpack_from('<I', raw, q)[0]
                q += 4
                if pair_ptr == 0:
                    break
                if pair_ptr in seen_pairs or pair_ptr + 8 > len(raw):
                    break
                seen_pairs.add(pair_ptr)
                key_ptr, value_ptr = struct.unpack_from('<II', raw, pair_ptr)
                key = cls._k7p2_cstr(raw, key_ptr)
                value = cls._k7p2_cstr(raw, value_ptr)
                if key is None or value is None:
                    break
                # Cada C-string ocupa su longitud+NUL redondeada a 4 bytes.
                slot = (len(value.encode('ascii')) + 1 + 3) & ~3
                if value_ptr + slot > len(raw):
                    break
                out.append({
                    'section': section, 'key': key, 'value': value,
                    'pair_offset': int(pair_ptr), 'value_offset': int(value_ptr),
                    'slot': int(slot),
                })
        return out

    def _scan_k7p2_scenario_labels(self) -> list[TextBlock]:
        """Expone Hallway/Parking/Iwazaru/Travis de las tablas K7P2.

        La entrada K7P2 suelta está duplicada byte por byte en el DAR siguiente.
        El bloque guarda ese índice DAR en ``dic_index`` para que el compilador
        actualice ambas copias de forma atómica.
        """
        out: list[TextBlock] = []
        for entry in self.entries:
            raw = self.entry_bytes(entry.index)
            if not raw.startswith(b'K7P2'):
                continue
            rows = [r for r in self._parse_k7p2_name_tables(raw)
                    if r['value'] in K7P2_SCENARIO_TERMS]
            if not rows:
                continue
            dar_index = entry.index + 1
            if dar_index >= len(self.entries):
                continue
            dar_entry = self.entries[dar_index]
            dar_raw = self.entry_bytes(dar_index)
            if dar_entry.name != entry.name or not dar_raw.startswith(b'DAR\0') or dar_raw.find(raw) < 0:
                continue
            # Una misma C-string podría ser reutilizada por varias claves. Exponerla
            # una sola vez evita dos unidades escribiendo el mismo slot.
            unique = []
            seen_offsets = set()
            for row in rows:
                if row['value_offset'] in seen_offsets:
                    continue
                seen_offsets.add(row['value_offset'])
                unique.append(row)
            units: list[TextUnit] = []
            for seq, row in enumerate(unique):
                text = row['value']
                role = 'place-label' if text in ('Hallway', 'Parking') else 'proper-name'
                provenance = (
                    f"k7p2-{role}:{row['section']}; key={row['key']}; "
                    f"mirror_dar={dar_index:04d}"
                )
                units.append(TextUnit(
                    f'{entry.index:04d}-{seq:03d}-00', entry.index, dar_index,
                    entry.name, seq, 0, 0, 0, [ord(ch) for ch in text],
                    text, 'verified', '', provenance, 1.0,
                    max(1, int(row['slot']) - 1),
                    f'D_US/DIR.AFS#{entry.index:04d}', int(row['value_offset']),
                    int(row['slot']), 'nul',
                ))
            if units:
                out.append(TextBlock(
                    entry.index, dar_index, f'{entry.name} · rutas/localizadores K7P2',
                    1, 0, units, storage_kind='afs_k7p2',
                    storage_path=f'D_US/DIR.AFS#{entry.index:04d}:{entry.name}',
                ))
        return out

    @staticmethod
    def _parse_da_blob(raw: bytes) -> dict:
        """Parsea el subtipo DAR usado por los subtítulos 7-dígitos (*.da).

        El contenedor conserva dos hijos: una tabla de líneas/fParams y un DIC
        4bpp. No se acepta cualquier DAR: las comprobaciones estrictas evitan
        clasificar animaciones/otros recursos .da como subtítulos.
        """
        if len(raw) < 0x80 or raw[:4] != b'DAR\0':
            raise K7Error('Contenedor DAR de subtítulos inválido.')
        child_count = struct.unpack_from('<I', raw, 8)[0]
        if child_count != 2:
            raise K7Error(f'DAR de subtítulos con {child_count} hijos; se esperaban 2.')
        offsets = struct.unpack_from('<2I', raw, 0x10)
        sizes = struct.unpack_from('<2I', raw, 0x30)
        if offsets[0] != 0x80:
            raise K7Error(f'DAR de subtítulos: primer hijo en 0x{offsets[0]:X}, se esperaba 0x80.')
        if any(o < 0x80 or s <= 0 or o + s > len(raw) for o, s in zip(offsets, sizes)):
            raise K7Error('DAR de subtítulos con offsets/tamaños fuera del contenedor.')
        dat = raw[offsets[0]:offsets[0] + sizes[0]]
        dic = raw[offsets[1]:offsets[1] + sizes[1]]
        if len(dat) < 12:
            raise K7Error('Tabla DA de subtítulos demasiado corta.')
        line_count, glyph_count, record_offset, param_offset = struct.unpack_from('<HHII', dat, 0)
        # El ejecutable usa line_count desde el propio DAT; no existe evidencia
        # de un máximo de 64 líneas. La seguridad del parser se obtiene verificando
        # el layout/tamaño exactos, no imponiendo ese límite artificial.
        if line_count <= 0 or not (0 < glyph_count <= 256):
            raise K7Error('Cabecera de subtítulos DA fuera de rango.')
        if record_offset != 12 or param_offset != 12 + line_count * DA_RECORD_SIZE:
            raise K7Error('Layout de tabla DA no reconocido.')
        if param_offset + glyph_count * 8 != len(dat):
            raise K7Error('Tabla DA no termina exactamente tras los fParams.')
        if len(dic) < 0x120 or not dic.startswith(b'\x16\x00\x00\x00'):
            raise K7Error('Segundo hijo DA no es un DIC compatible.')
        try:
            name_len = struct.unpack_from('<I', dic, 0x40)[0]
            shift = name_len - 8
            width, height, bpp = struct.unpack_from('<III', dic, 0x78 + shift)
        except (struct.error, ValueError) as exc:
            raise K7Error('Cabecera DIC de subtítulos inválida.') from exc
        if width != 512 or height not in (32, 64, 128) or bpp != 4:
            raise K7Error(f'DIC de subtítulos inesperado: {width}x{height}, {bpp}bpp.')
        return {
            'raw': raw, 'child_offsets': offsets, 'child_sizes': sizes,
            'dat': dat, 'dic': dic, 'line_count': line_count,
            'glyph_count': glyph_count, 'record_offset': record_offset,
            'param_offset': param_offset, 'width': width, 'height': height,
            'bpp': bpp,
        }

    def da_parts(self, index: int) -> dict:
        return self._parse_da_blob(self.entry_bytes(index))

    def _scan_da_subtitles(self) -> list[TextBlock]:
        """Localiza los 7-dígitos .da que contienen subtítulos de gameplay."""
        import re
        out: list[TextBlock] = []
        for entry in self.entries:
            if not re.fullmatch(r'\d{7}\.da', entry.name or ''):
                continue
            try:
                meta = self.da_parts(entry.index)
            except K7Error:
                continue
            dat = meta['dat']
            units: list[TextUnit] = []
            for line in range(meta['line_count']):
                off = meta['record_offset'] + line * DA_RECORD_SIZE
                start, end = struct.unpack_from('<II', dat, off)
                codes = list(struct.unpack_from(f'<{DA_CODE_SLOTS}h', dat, off + 8))
                if -2 in codes:
                    codes = codes[:codes.index(-2)]
                elif -1 in codes:
                    codes = codes[:codes.index(-1)]
                if not codes:
                    continue
                uid = f'{entry.index:04d}-{line:02d}-00'
                cat = self._catalog_row(uid)
                conf = cat.get('confidence')
                try:
                    conf = float(conf) if conf is not None else None
                except Exception:
                    conf = None
                units.append(TextUnit(
                    uid, entry.index, entry.index, entry.name, line, 0,
                    int(start), int(end), codes,
                    str(cat.get('text', '')), str(cat.get('state', 'pending')),
                    str(cat.get('candidate', '')), str(cat.get('provenance', '')),
                    conf, DA_MAX_CODES,
                    f'D_US/DIR.AFS#{entry.index:04d}', 0, entry.size, 'da',
                ))
            if units:
                out.append(TextBlock(
                    entry.index, entry.index, entry.name,
                    meta['line_count'], meta['glyph_count'], units,
                    storage_kind='afs_da',
                    storage_path=f'D_US/DIR.AFS#{entry.index:04d}:{entry.name}',
                ))
        return out

    def _scan_graphic_refs(self) -> list[TextBlock]:
        out: list[TextBlock] = []
        for block_index, afs_index, afs_name, label, texts in GRAPHIC_TEXT_REFS:
            if not (0 <= afs_index < len(self.entries)):
                continue
            entry = self.entries[afs_index]
            if entry.name != afs_name:
                continue
            units = []
            for seq, text in enumerate(texts):
                units.append(TextUnit(
                    f'{block_index:04d}-{seq:03d}-00', block_index, afs_index, afs_name,
                    seq, 0, 0, 0, [ord(ch) for ch in text], text, 'verified', '',
                    'manual-visual-texture-review-v1.6', 1.0, max(31, len(text)),
                    f'D_US/DIR.AFS#{afs_index:04d}', 0, 0, 'graphic',
                ))
            out.append(TextBlock(
                block_index, afs_index, label, 1, 0, units,
                storage_kind='afs_graphic_ref', storage_path=f'D_US/DIR.AFS#{afs_index:04d}:{afs_name}'
            ))
        return out

    def iso_node(self, path: str) -> IsoFile:
        return self.iso.find([p for p in path.replace('\\', '/').split('/') if p])

    def close(self):
        self.iso.close()

    def image_sha256(self, chunk: int = 4 * 1024 * 1024) -> str:
        if self._image_sha256:
            return self._image_sha256
        h = hashlib.sha256()
        with self.iso_path.open('rb') as f:
            while True:
                b = f.read(chunk)
                if not b:
                    break
                h.update(b)
        self._image_sha256 = h.hexdigest()
        return self._image_sha256

    def manifest(self, with_hash: bool = True) -> dict:
        return {
            'format': 'killer7-ps2-xliff-project',
            'format_version': 2,
            'serial': self.serial,
            'image_name': self.iso_path.name,
            'image_size': self.iso_path.stat().st_size,
            'image_sha256': self.image_sha256() if with_hash else None,
            'afs_path': 'D_US/DIR.AFS',
            'afs_lba': self.afs_node.lba,
            'afs_size': self.afs_node.size,
            'block_count': len(self.all_blocks),
            'unit_count': sum(len(b.units) for b in self.all_blocks),
        }

    def _read_abs(self, absolute: int, size: int) -> bytes:
        self.iso._fh.seek(absolute)
        return self.iso._fh.read(size)

    def _read_afs_table(self) -> list[AfsEntry]:
        f = self.iso._fh
        b = self.afs_base
        f.seek(b)
        if f.read(4) != b'AFS\x00':
            raise K7Error('D_US/DIR.AFS no tiene firma AFS.')
        n = struct.unpack('<I', f.read(4))[0]
        raw = [struct.unpack('<II', f.read(8)) for _ in range(n)]
        name_off, name_sz = struct.unpack('<II', f.read(8))
        f.seek(b + name_off)
        nt = f.read(name_sz)
        names = []
        for i in range(n):
            row = nt[i*48:(i+1)*48]
            names.append(row[:32].split(b'\0', 1)[0].decode('latin1', 'replace'))
        return [AfsEntry(i, names[i], raw[i][0], raw[i][1]) for i in range(n)]

    def entry_bytes(self, idx: int) -> bytes:
        e = self.entries[idx]
        return self._read_abs(self.afs_base + e.offset, e.size)

    def entry_head(self, idx: int, size: int = 128) -> bytes:
        e = self.entries[idx]
        return self._read_abs(self.afs_base + e.offset, min(e.size, size))

    def _is_jmb(self, idx: int):
        e = self.entries[idx]
        h = self.entry_head(idx, 64)
        if len(h) < 20:
            return None
        try:
            sn, cn, so, co, to = struct.unpack_from('<hhIII', h, 0)
        except struct.error:
            return None
        # Layout PS2 encontrado en SLUS_211.54: metadata + sn*u32, después sn escenas
        # de 6860 bytes (stInfo 76 + 16 * stJimaku_JA 424), después fParams y textura.
        if 0 < sn < 100 and 0 < cn < 500 and so == 16 + 4*sn and co - so == JMB_SCENE_SIZE*sn and co <= to <= e.size:
            return sn, cn, so, co, to
        return None

    def _catalog_row(self, uid: str) -> dict:
        row = self.catalog.get(uid, {})
        if isinstance(row, str):
            return {'text': row, 'state': 'verified'}
        return row if isinstance(row, dict) else {}

    def _scan_blocks(self) -> list[TextBlock]:
        candidates = []
        for i in range(len(self.entries)):
            meta = self._is_jmb(i)
            if meta:
                candidates.append((i, meta))
        blocks = []
        for ji, meta in candidates:
            sn, cn, so, co, to = meta
            data = self.entry_bytes(ji)

            # Un mismo nombre puede contener varias ternas JMB/DAR/DIC consecutivas.
            # Elegir simplemente el DIC más cercano emparejaba el segundo JMB con
            # el atlas de la terna anterior. Usamos el tamaño real requerido por los
            # fParams y, en empate, la dirección observada en cada familia:
            #   Zan/paneles: JMB -> (DAR) -> DIC
            #   h_*:         DIC -> JMB
            extent_x = extent_y = 0
            if co + cn * 8 <= len(data):
                for pi in range(cn):
                    x, y, w, h = struct.unpack_from('<4H', data, co + pi*8)
                    extent_x = max(extent_x, x+w)
                    extent_y = max(extent_y, y+h)

            choices = []
            # En PAL/EUR hay familias DIC -> JMB -> DIC -> JMB (EN/FR/DE).
            # Si el recurso inmediatamente anterior ya es un DIC del mismo nombre,
            # pertenece al JMB actual; elegir el siguiente mezcla idiomas (p. ej.
            # JMB francés con atlas alemán en h_* y Handsom).
            prev_is_same_dic = False
            if ji > 0 and self.entries[ji - 1].name == self.entries[ji].name:
                prev_is_same_dic = self.entry_head(ji - 1, 4) == b'\x16\x00\x00\x00'
            prefer_before = self.entries[ji].name.startswith('h_') or prev_is_same_dic
            for d in range(1, 5):
                for di in (ji-d, ji+d):
                    if not (0 <= di < len(self.entries)) or self.entries[di].name != self.entries[ji].name:
                        continue
                    head = self.entry_head(di, 0x100)
                    if not head.startswith(b'\x16\x00\x00\x00') or len(head) < 0x84:
                        continue
                    try:
                        name_len = struct.unpack_from('<I', head, 0x40)[0]
                        shift = name_len - 8
                        dw, dh, dbpp = struct.unpack_from('<III', head, 0x78 + shift)
                    except (struct.error, ValueError):
                        continue
                    if dbpp != 4 or dw < extent_x or dh < extent_y:
                        continue
                    # Altura exacta del atlas respecto a los fParams es la señal más
                    # fuerte para distinguir variantes 32/64/128 del mismo nombre.
                    height_slack = dh - extent_y
                    wrong_direction = 0 if ((di < ji) == prefer_before) else 1
                    choices.append((height_slack, wrong_direction, d, di))
            # Excepciones verificadas: algunos recursos usan un atlas compartido
            # o un nombre diferente (Select.j -> Select.r, voiceXX -> voice.dic).
            special_name = SPECIAL_JMB_DIC.get(self.entries[ji].name)
            if special_name:
                special = next((e.index for e in self.entries if e.name == special_name), None)
                if special is not None:
                    choices = [(-1, 0, 0, special)]
            if not choices:
                continue
            di = min(choices)[3]
            units = []
            for s in range(sn):
                sb = so + s * JMB_SCENE_SIZE
                for j in range(JMB_UNITS_PER_SCENE):
                    o = sb + 76 + j * JMB_RECORD_SIZE
                    if o + 72 > len(data):
                        continue
                    wait, disp = struct.unpack_from('<ii', data, o)
                    codes = list(struct.unpack_from(f'<{JMB_CODE_SLOTS}h', data, o + 8))
                    if not codes or codes[0] == -1:
                        continue
                    if -2 in codes:
                        codes = codes[:codes.index(-2)]
                    if not codes:
                        continue
                    uid = f'{ji:04d}-{s:02d}-{j:02d}'
                    cat = self._catalog_row(uid)
                    conf = cat.get('confidence')
                    try:
                        conf = float(conf) if conf is not None else None
                    except Exception:
                        conf = None
                    units.append(TextUnit(
                        uid, ji, di, self.entries[ji].name, s, j, wait, disp, codes,
                        str(cat.get('text', '')),
                        str(cat.get('state', 'pending')),
                        str(cat.get('candidate', '')),
                        str(cat.get('provenance', '')),
                        conf,
                    ))
            blocks.append(TextBlock(ji, di, self.entries[ji].name, sn, cn, units))
        return blocks

    def block_by_id(self, block_id: str) -> TextBlock:
        for b in self.all_blocks:
            if b.id == block_id:
                return b
        raise KeyError(block_id)

    def unit_by_id(self, stable_id: str) -> TextUnit:
        for b in self.all_blocks:
            for u in b.units:
                if u.stable_id == stable_id:
                    return u
        raise KeyError(stable_id)

    @staticmethod
    def _dic_texture_info(raw: bytes, total_size: int | None = None) -> dict | None:
        """Reconoce una textura DIC 4bpp y su layout de transferencia GS.

        Se usa también por el escáner visual. La cabecera DIC no tiene una firma
        ASCII cómoda, así que se valida el layout observado: name_len, dimensiones,
        bpp=4 y que el payload calculado quepa en el recurso AFS.
        """
        if len(raw) < 0x120:
            return None
        try:
            name_len = struct.unpack_from('<I', raw, 0x40)[0]
            shift = int(name_len) - 8
            width_off = 0x78 + shift
            if shift < -8 or width_off < 0 or width_off + 12 > len(raw):
                return None
            width, height, bpp = struct.unpack_from('<III', raw, width_off)
        except struct.error:
            return None
        if bpp != 4 or not (1 <= width <= 4096 and 1 <= height <= 4096):
            return None
        # Los DIC 4bpp normales de Killer7 NO contienen un bitmap PSMT4
        # directamente swizzleado. El paquete GIF sube el IMAGE como PSMCT16
        # con TRXREG=(width/2,height/2) y el renderer lee la misma VRAM como
        # PSMT4 width x height. Además, el IMAGE GIFtag ocupa 16 bytes completos:
        # el payload empieza en 0x114+shift, no en 0x110+shift.
        payload_size = width * height // 2
        gs_ct16_alias = False
        rrw = rrh = nloop = 0
        try:
            trxreg = struct.unpack_from('<Q', raw, 0xE4 + shift)[0]
            rrw = int(trxreg & 0xFFF)
            rrh = int((trxreg >> 32) & 0xFFF)
            image_tag = struct.unpack_from('<Q', raw, 0x104 + shift)[0]
            nloop = int(image_tag & 0x7FFF)
            gs_ct16_alias = (
                (rrw, rrh) == (width // 2, height // 2)
                and nloop * 16 == payload_size
                and rrw * rrh * 2 == payload_size
            )
        except struct.error:
            pass
        pixel_off = (0x114 if gs_ct16_alias else 0x110) + shift
        limit = len(raw) if total_size is None else int(total_size)
        if pixel_off < 0 or pixel_off + payload_size > limit:
            return None
        return {
            'width': int(width), 'height': int(height), 'bpp': int(bpp),
            'pixel_offset': int(pixel_off), 'payload_size': int(payload_size),
            'gs_ct16_alias': bool(gs_ct16_alias),
            'rrw': int(rrw), 'rrh': int(rrh), 'nloop': int(nloop),
        }

    @classmethod
    def decode_dic_texture_preview(cls, dic: bytes):
        """Decodifica un DIC 4bpp para previsualización aplicando su CLUT RGBA.

        ``decode_dic_texture`` devuelve deliberadamente los índices 0..15 como
        luminancia porque el compilador necesita conservar/editarlos como índices.
        Para mostrar la textura al usuario eso no basta: muchos recursos (por
        ejemplo ``titleF.dic``) usan una CLUT distinta por textura y píxeles con
        alfa parcial. Mostrar el índice como gris produce trazos fantasma y texto
        aparentemente corrupto aunque el swizzle sea correcto.

        El paquete de CLUT observado en los DIC EUR comienza 0x50 bytes después
        del final del IMAGE principal y contiene 16 entradas RGBA32. El alfa del
        GS usa 0x80 como opacidad completa, por lo que se escala a 0..255.
        Si el paquete no está presente, se vuelve a la vista de índices.
        """
        from PIL import Image
        info = cls._dic_texture_info(dic)
        if not info:
            raise K7Error('El recurso no contiene una textura DIC 4bpp compatible.')
        width, height = info['width'], info['height']
        pixel_off, payload_size = info['pixel_offset'], info['payload_size']
        raw = dic[pixel_off:pixel_off + payload_size]
        if info.get('gs_ct16_alias'):
            rrw, rrh = int(info['rrw']), int(info['rrh'])
            dbw = max(1, rrw // 64)
            vram = bytearray(4 * 1024 * 1024)
            _da_write_ct16(vram, dbw, rrw, rrh, raw)
            px = _da_read_t4(vram, width, height)
        else:
            expanded = bytearray(width * height)
            for i, value in enumerate(raw):
                expanded[i*2] = value & 0x0F
                expanded[i*2+1] = (value >> 4) & 0x0F
            px = _unswizzle8(expanded, width, height)

        clut_off = pixel_off + payload_size + 0x50
        if clut_off + 16 * 4 > len(dic):
            im = Image.new('L', (width, height))
            im.putdata([value * 17 for value in px])
            return im
        palette = [tuple(dic[clut_off+i*4:clut_off+i*4+4]) for i in range(16)]
        # Rechaza datos que claramente no parecen una CLUT GS. Los DIC de Killer7
        # usan alfa 0..0x80; admitir un pequeño margen evita falsos negativos sin
        # interpretar trailers arbitrarios como colores.
        if any(len(c) != 4 or c[3] > 0x80 for c in palette):
            im = Image.new('L', (width, height))
            im.putdata([value * 17 for value in px])
            return im
        rgba = []
        for value in px:
            r, g, b, a = palette[value & 0x0F]
            rgba.append((r, g, b, min(255, int(a) * 2)))
        im = Image.new('RGBA', (width, height))
        im.putdata(rgba)
        return im

    @classmethod
    def decode_dic_texture(cls, dic: bytes):
        """Decodifica una textura DIC 4bpp según la transferencia real al GS."""
        from PIL import Image
        info = cls._dic_texture_info(dic)
        if not info:
            raise K7Error('El recurso no contiene una textura DIC 4bpp compatible.')
        width, height = info['width'], info['height']
        pixel_off, payload_size = info['pixel_offset'], info['payload_size']
        raw = dic[pixel_off:pixel_off + payload_size]
        if info.get('gs_ct16_alias'):
            rrw, rrh = int(info['rrw']), int(info['rrh'])
            dbw = rrw // 64
            vram = bytearray(4 * 1024 * 1024)
            _da_write_ct16(vram, dbw, rrw, rrh, raw)
            if _da_read_ct16(vram, dbw, rrw, rrh) != raw:
                raise K7Error('La transferencia GS PSMCT16 del DIC no hace round-trip.')
            px = _da_read_t4(vram, width, height)
        else:
            expanded = bytearray(width * height)
            for i, value in enumerate(raw):
                expanded[i*2] = value & 0x0F
                expanded[i*2+1] = (value >> 4) & 0x0F
            px = _unswizzle8(expanded, width, height)
        im = Image.new('L', (width, height))
        im.putdata([value * 17 for value in px])
        return im

    def scan_image_resources(self, include_subtitle_atlases: bool = False) -> list[dict]:
        """Inventaría texturas DIC de DIR.AFS para revisión visual.

        No usa OCR ni modifica la ISO. Por defecto omite los atlas internos de los
        subtítulos .da porque son fuentes de glifos, no imágenes de interfaz/escena.
        Se pueden incluir desde la ventana del escáner para tareas de investigación.
        """
        known_text = {int(row[1]) for row in GRAPHIC_TEXT_REFS}
        suspicious_tokens = (
            'font', 'title', 'menu', 'load', 'save', 'option', 'tutorial',
            'kan', 'mes', 'win', 'logo', 'staff', 'typ', 'map', 'ui',
        )
        out: list[dict] = []
        for entry in self.entries:
            head = self.entry_head(entry.index, 0x180)
            info = self._dic_texture_info(head, entry.size)
            if not info:
                continue
            lname = entry.name.lower()
            if entry.index in known_text:
                hint = 'Texto conocido'
            elif any(token in lname for token in suspicious_tokens):
                hint = 'Candidato por nombre'
            else:
                hint = 'Revisar'
            out.append({
                'id': f'afs:{entry.index:04d}',
                'kind': 'afs_dic',
                'afs_index': int(entry.index),
                'name': entry.name,
                'size': int(entry.size),
                'width': info['width'],
                'height': info['height'],
                'bpp': info['bpp'],
                'hint': hint,
                'path': f'D_US/DIR.AFS#{entry.index:04d}:{entry.name}',
            })

        if include_subtitle_atlases:
            seen = {item['afs_index'] for item in out if item['kind'] == 'afs_dic'}
            for block in self.da_blocks:
                if block.jmb_index in seen:
                    continue
                try:
                    meta = self.da_parts(block.jmb_index)
                except Exception:
                    continue
                out.append({
                    'id': f'da:{block.jmb_index:04d}',
                    'kind': 'da_atlas',
                    'afs_index': int(block.jmb_index),
                    'name': self.entries[block.jmb_index].name,
                    'size': len(meta['dic']),
                    'width': int(meta['width']),
                    'height': int(meta['height']),
                    'bpp': int(meta['bpp']),
                    'hint': 'Atlas de subtítulos',
                    'path': f'D_US/DIR.AFS#{block.jmb_index:04d}:{self.entries[block.jmb_index].name} / DIC interno',
                })

        out.sort(key=lambda row: (row['afs_index'], row['kind']))
        return out

    def decode_image_resource(self, resource: dict):
        kind = resource.get('kind')
        index = int(resource.get('afs_index', -1))
        if kind == 'afs_dic':
            return self.decode_dic_texture(self.entry_bytes(index))
        if kind == 'da_atlas':
            return decode_da_ps2_atlas(self.da_parts(index)['dic'])
        raise K7Error(f'Tipo de imagen no soportado: {kind!r}.')

    def decode_atlas(self, block: TextBlock):
        if block.storage_kind == 'afs_da':
            dic = self.da_parts(block.jmb_index)['dic']
            return decode_da_ps2_atlas(dic)
        return self.decode_dic_texture(self.entry_bytes(block.dic_index))

    def glyph_params(self, block: TextBlock):
        if block.storage_kind == 'afs_da':
            meta = self.da_parts(block.jmb_index)
            dat = meta['dat']
            return [struct.unpack_from('<4H', dat, meta['param_offset'] + k*8)
                    for k in range(meta['glyph_count'])]
        j = self.entry_bytes(block.jmb_index)
        _sn, cn, _so, co, _to = struct.unpack_from('<hhIII', j, 0)
        return [struct.unpack_from('<4H', j, co + k*8) for k in range(cn)]

    def render_unit(self, block: TextBlock, unit: TextUnit, scale: int = 2):
        from PIL import Image, ImageOps
        atlas = self.decode_atlas(block)
        params = self.glyph_params(block)
        pieces = []
        wtotal = 0
        h = max([p[3] for p in params] or [32])
        for code in unit.codes:
            if code in (-4, -3):
                pieces.append(('gap', 12))
                wtotal += 12
                continue
            u = code & 0xffff
            if u >= 0xff00:
                pieces.append(('gap', 18))
                wtotal += 18
                continue
            idx = (u & 0xfff) if ((u & 0x7000) or (u & 0x8000)) else code
            if 0 <= idx < len(params):
                x, y, w, gh = params[idx]
                if x + w <= atlas.width and y + gh <= atlas.height:
                    g = atlas.crop((x, y, x+w, y+gh))
                    pieces.append(('glyph', g))
                    wtotal += w + 1
                    continue
            pieces.append(('gap', 12))
            wtotal += 12
        out = Image.new('L', (max(1, wtotal), h), 0)
        x = 0
        for typ, val in pieces:
            if typ == 'glyph':
                out.paste(val, (x, 0))
                x += val.width + 1
            else:
                x += val
        bbox = out.getbbox()
        if bbox:
            out = out.crop((0, max(0, bbox[1]-2), out.width, min(out.height, bbox[3]+2)))
        out = ImageOps.autocontrast(out)
        if scale != 1:
            out = out.resize((out.width*scale, out.height*scale), Image.Resampling.NEAREST)
        return out



# --- PS2 GS helpers for 7-digit .da subtitle atlases -----------------------
# These DICs do not store a linear PSMT4 bitmap. Killer7 uploads the 16,384-byte
# IMAGE packet as a 256 x (H/2) PSMCT16 transfer and then samples the same GS
# memory as a 512 x H PSMT4 texture. Reproducing that aliasing is required both
# for a faithful preview and for safe in-place custom glyph edits.
_DA_BLOCK16 = [
    0,2,8,10, 1,3,9,11, 4,6,12,14, 5,7,13,15,
    16,18,24,26, 17,19,25,27, 20,22,28,30, 21,23,29,31,
]
_DA_COLUMN_WORD16 = [
    0,1,4,5,8,9,12,13, 0,1,4,5,8,9,12,13,
    2,3,6,7,10,11,14,15, 2,3,6,7,10,11,14,15,
]
_DA_COLUMN_HALF16 = [0]*8 + [1]*8 + [0]*8 + [1]*8
_DA_BLOCK4 = _DA_BLOCK16
_DA_COLUMN_WORD4 = [
    [
        0,1,4,5,8,9,12,13, 0,1,4,5,8,9,12,13, 0,1,4,5,8,9,12,13, 0,1,4,5,8,9,12,13,
        2,3,6,7,10,11,14,15, 2,3,6,7,10,11,14,15, 2,3,6,7,10,11,14,15, 2,3,6,7,10,11,14,15,
        8,9,12,13,0,1,4,5, 8,9,12,13,0,1,4,5, 8,9,12,13,0,1,4,5, 8,9,12,13,0,1,4,5,
        10,11,14,15,2,3,6,7, 10,11,14,15,2,3,6,7, 10,11,14,15,2,3,6,7, 10,11,14,15,2,3,6,7,
    ],
    [
        8,9,12,13,0,1,4,5, 8,9,12,13,0,1,4,5, 8,9,12,13,0,1,4,5, 8,9,12,13,0,1,4,5,
        10,11,14,15,2,3,6,7, 10,11,14,15,2,3,6,7, 10,11,14,15,2,3,6,7, 10,11,14,15,2,3,6,7,
        0,1,4,5,8,9,12,13, 0,1,4,5,8,9,12,13, 0,1,4,5,8,9,12,13, 0,1,4,5,8,9,12,13,
        2,3,6,7,10,11,14,15, 2,3,6,7,10,11,14,15, 2,3,6,7,10,11,14,15, 2,3,6,7,10,11,14,15,
    ],
]
_DA_COLUMN_BYTE4 = [
    0,0,0,0,0,0,0,0, 2,2,2,2,2,2,2,2, 4,4,4,4,4,4,4,4, 6,6,6,6,6,6,6,6,
    0,0,0,0,0,0,0,0, 2,2,2,2,2,2,2,2, 4,4,4,4,4,4,4,4, 6,6,6,6,6,6,6,6,
    1,1,1,1,1,1,1,1, 3,3,3,3,3,3,3,3, 5,5,5,5,5,5,5,5, 7,7,7,7,7,7,7,7,
    1,1,1,1,1,1,1,1, 3,3,3,3,3,3,3,3, 5,5,5,5,5,5,5,5, 7,7,7,7,7,7,7,7,
]

def _da_dic_layout(dic: bytes):
    if len(dic) < 0x120:
        raise K7Error('DIC DA demasiado corto.')
    name_len = struct.unpack_from('<I', dic, 0x40)[0]
    shift = name_len - 8
    width, height, bpp = struct.unpack_from('<III', dic, 0x78 + shift)
    if width != 512 or height not in (32,64,128) or bpp != 4:
        raise K7Error(f'DIC DA inesperado: {width}x{height}, {bpp}bpp.')
    # GIF A+D packet: TRXREG is the second write; it must request 256 x H/2.
    trxreg = struct.unpack_from('<Q', dic, 0xE4 + shift)[0]
    rrw = trxreg & 0xFFF
    rrh = (trxreg >> 32) & 0xFFF
    if (rrw, rrh) != (width//2, height//2):
        raise K7Error(f'TRXREG DA inesperado: {rrw}x{rrh}.')
    # IMAGE GIFtag is 16 bytes at 0x104; payload starts immediately at 0x114.
    image_tag = struct.unpack_from('<Q', dic, 0x104 + shift)[0]
    nloop = image_tag & 0x7FFF
    payload_size = width * height // 2
    if nloop * 16 != payload_size:
        raise K7Error(f'GIF IMAGE DA inconsistente: {nloop} QW != {payload_size} bytes.')
    pixel_off = 0x114 + shift
    if pixel_off + payload_size > len(dic):
        raise K7Error('Payload gráfico DA truncado.')
    return width, height, pixel_off, payload_size

def _da_write_ct16(vram: bytearray, dbw: int, rrw: int, rrh: int, data: bytes):
    if len(data) != rrw * rrh * 2:
        raise K7Error('Transferencia PSMCT16 DA con tamaño incorrecto.')
    p = 0
    for y in range(rrh):
        for x in range(rrw):
            page_x, page_y = x//64, y//64
            page = page_x + page_y * dbw
            px, py = x-page_x*64, y-page_y*64
            block_x, block_y = px//16, py//8
            block = _DA_BLOCK16[block_x + block_y*4]
            bx, by = px-block_x*16, py-block_y*8
            column = by//2
            cw = _DA_COLUMN_WORD16[bx + (by-column*2)*16]
            ch = _DA_COLUMN_HALF16[bx + (by-column*2)*16]
            addr = (page*2048 + block*64 + column*16 + cw)*4 + ch*2
            vram[addr:addr+2] = data[p:p+2]
            p += 2

def _da_read_ct16(vram: bytearray, dbw: int, rrw: int, rrh: int) -> bytes:
    out = bytearray(rrw*rrh*2); p = 0
    for y in range(rrh):
        for x in range(rrw):
            page_x, page_y = x//64, y//64
            page = page_x + page_y * dbw
            px, py = x-page_x*64, y-page_y*64
            block_x, block_y = px//16, py//8
            block = _DA_BLOCK16[block_x + block_y*4]
            bx, by = px-block_x*16, py-block_y*8
            column = by//2
            cw = _DA_COLUMN_WORD16[bx + (by-column*2)*16]
            ch = _DA_COLUMN_HALF16[bx + (by-column*2)*16]
            addr = (page*2048 + block*64 + column*16 + cw)*4 + ch*2
            out[p:p+2] = vram[addr:addr+2]
            p += 2
    return bytes(out)

def _da_t4_addr(tbw: int, x: int, y: int):
    dbw = tbw >> 1
    page_x, page_y = x//128, y//128
    page = page_x + page_y*dbw
    px, py = x-page_x*128, y-page_y*128
    block_x, block_y = px//32, py//16
    block = _DA_BLOCK4[block_x + block_y*4]
    bx, by = px-block_x*32, py-block_y*16
    column = by//4
    i = bx + (by-column*4)*32
    cw = _DA_COLUMN_WORD4[column & 1][i]
    cb = _DA_COLUMN_BYTE4[i]
    return (page*2048 + block*64 + column*16 + cw)*4 + (cb>>1), bool(cb & 1)

def _da_read_t4(vram: bytearray, width: int, height: int) -> bytearray:
    out = bytearray(width*height)
    tbw = width // 64
    for y in range(height):
        for x in range(width):
            addr, high = _da_t4_addr(tbw, x, y)
            b = vram[addr]
            out[y*width+x] = ((b >> 4) & 0xF) if high else (b & 0xF)
    return out

def _da_write_t4(vram: bytearray, width: int, x: int, y: int, value: int):
    addr, high = _da_t4_addr(width//64, x, y)
    b = vram[addr]
    if high:
        vram[addr] = (b & 0x0F) | ((value & 0xF) << 4)
    else:
        vram[addr] = (b & 0xF0) | (value & 0xF)

def decode_da_ps2_atlas(dic: bytes):
    from PIL import Image
    width, height, pixel_off, payload_size = _da_dic_layout(dic)
    payload = dic[pixel_off:pixel_off+payload_size]
    # The GS transfer is 256 x H/2 PSMCT16. DBW is 256/64 = 4.
    vram = bytearray(4*1024*1024)
    _da_write_ct16(vram, 4, width//2, height//2, payload)
    # Defensive round-trip of the raw upload itself.
    if _da_read_ct16(vram, 4, width//2, height//2) != payload:
        raise K7Error('La transferencia GS DA no hace round-trip exacto.')
    px = _da_read_t4(vram, width, height)
    im = Image.new('L', (width, height))
    im.putdata([v*17 for v in px])
    return im

def encode_da_ps2_atlas_into_dic(original_dic: bytes, atlas) -> bytes:
    """Edita sólo los píxeles lógicos que cambian y conserva el resto del DIC."""
    width, height, pixel_off, payload_size = _da_dic_layout(original_dic)
    if atlas.size != (width, height):
        raise K7Error(f'Atlas DA {atlas.size} != {(width,height)}.')
    payload = original_dic[pixel_off:pixel_off+payload_size]
    vram = bytearray(4*1024*1024)
    _da_write_ct16(vram, 4, width//2, height//2, payload)
    original_px = _da_read_t4(vram, width, height)
    target_px = bytearray(max(0,min(15,int(round(v/17.0)))) for v in atlas.convert('L').getdata())
    for i, (old, new) in enumerate(zip(original_px, target_px)):
        if old != new:
            _da_write_t4(vram, width, i % width, i // width, new)
    new_payload = _da_read_ct16(vram, 4, width//2, height//2)
    # Verify what will be seen through PSMT4 is exactly the requested atlas.
    check = bytearray(4*1024*1024)
    _da_write_ct16(check, 4, width//2, height//2, new_payload)
    if _da_read_t4(check, width, height) != target_px:
        raise K7Error('La recompilación GS DA no reproduce exactamente el atlas solicitado.')
    out = bytearray(original_dic)
    out[pixel_off:pixel_off+payload_size] = new_payload
    return bytes(out)

def _unswizzle8(buf: bytes | bytearray, width: int, height: int) -> bytearray:
    out = bytearray(width * height)
    for y in range(height):
        for x in range(width):
            block_location = (y & (~0xf)) * width + (x & (~0xf)) * 2
            swap_selector = (((y + 2) >> 2) & 1) * 4
            posY = (((y & (~3)) >> 1) + (y & 1)) & 7
            column_location = posY * width * 2 + ((x + swap_selector) & 7) * 4
            byte_num = ((y >> 1) & 1) + ((x >> 2) & 2)
            swizzleid = block_location + column_location + byte_num
            if swizzleid < len(buf):
                out[y*width+x] = buf[swizzleid]
    return out


def load_source_catalog(path: str | Path | None) -> dict:
    if not path:
        return {}
    p = Path(path)
    if not p.exists():
        return {}
    obj = json.loads(p.read_text(encoding='utf-8'))
    return obj.get('units', obj) if isinstance(obj, dict) else {}


def save_source_catalog(path: str | Path, catalog: dict, meta: Optional[dict] = None) -> None:
    obj = {'format': 'killer7-source-catalog', 'version': 13, 'units': catalog}
    if meta:
        obj['meta'] = meta
    Path(path).write_text(json.dumps(obj, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
