from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from collections import defaultdict
from copy import deepcopy
import hashlib
import json
import math
import re
import shutil
import struct
import tempfile
import zipfile
import xml.etree.ElementTree as ET

from PIL import Image, ImageDraw, ImageFont, ImageOps

from core import (
    Killer7Project, TextBlock, TextUnit, K7Error, _unswizzle8,
    _da_write_ct16, _da_read_ct16, _da_read_t4, _da_write_t4, _da_dic_layout,
    encode_da_ps2_atlas_into_dic, TITLE_MENU_SPECS, TITLE_MENU_BLOCK_INDEX,
    JMB_UNITS_PER_SCENE, JMB_RECORD_SIZE, JMB_SCENE_SIZE, JMB_CODE_SLOTS,
    JMB_MAX_CODES, DA_RECORD_SIZE, DA_CODE_SLOTS, DA_MAX_CODES, GRAPHIC_PATCH_SPECS,
    DIRECT_INTERNAL_KEYS, DIRECT_SJIS_COMPOSITES, ISO9660, identify_killer7_iso,
    is_compatible_eur_iso,
)
from platform_paths import editable_path, resource_path

from xliff_io import (
    CONTROL_RE, parse_project_xliff, validate_project_xliff,
    visible_target_length,
)

PATCH_FORMAT = 'killer7-ps2-xliff-patch'
PATCH_VERSION = 1

# Prueba experimental aislada del flujo estable. Las v1.7.7.3/4 demostraron que
# el renderer acepta reutilizar un código de option.dat, pero también revelaron que
# el decodificador DIC genérico NO refleja el layout real de esta fuente. option.dat
# sube 64x64 PSMCT16 al GS y esa misma memoria se lee como 128x128 PSMT4; el payload
# empieza en 0x114 (+shift). La v1.7.7.5 usa ese alias de memoria real del GS y sólo
# modifica los píxeles lógicos de la casilla "j", usada como marcador para É.
# El inyector estable permanece intacto y el XLIFF maestro conserva ESTEREO.
EXPERIMENTAL_STEREO_UNIT = 'k7-9011-22-00'
EXPERIMENTAL_STEREO_OFFSET = 0x4B60E0
EXPERIMENTAL_STEREO_PAYLOAD = b'ESTjREO\x00'
EXPERIMENTAL_OPTION_FONT_NAME = 'option.dat'
EXPERIMENTAL_OPTION_FONT_CODE = ord('j')  # j => É sólo en la fuente option experimental

DEFAULT_FONT_CANDIDATES = [
    '/usr/share/fonts/opentype/urw-base35/NimbusRoman-Regular.otf',
    '/usr/share/fonts/truetype/liberation/LiberationSerif-Regular.ttf',
    '/usr/share/fonts/truetype/dejavu/DejaVuSerif.ttf',
    'C:/Windows/Fonts/times.ttf',
    'C:/Windows/Fonts/timesnewroman.ttf',
    '/System/Library/Fonts/Times.ttc',
]
PENDING_PREFIX = '⟦SOURCE PENDING'
SPECIAL_PREFIX = '⟦SPECIAL RESOURCE'


@dataclass
class CompiledBlock:
    block: TextBlock
    jmb: bytes
    dic: bytes
    translated_units: list[str]
    added_glyphs: dict[str, int]
    params: list[tuple[int, int, int, int]]
    atlas: Image.Image
    fallback_chars: list[str]
    synthesized_chars: list[str]


@dataclass
class CompiledDA:
    block: TextBlock
    data: bytes
    translated_units: list[str]
    added_glyphs: dict[str, int]
    params: list[tuple[int, int, int, int]]
    atlas: Image.Image
    fallback_chars: list[str]
    synthesized_chars: list[str]


@dataclass
class CompiledGraphic:
    block: TextBlock
    data: bytes
    translated_units: list[str]
    atlas: Image.Image


@dataclass
class CompiledK7P2:
    block: TextBlock
    primary: bytes
    mirror_dar: bytes
    translated_units: list[str]
    mirror_offset: int


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _signed16(value: int) -> int:
    value &= 0xffff
    return value - 0x10000 if value >= 0x8000 else value


def _glyph_index(code: int) -> int | None:
    if code in (-4, -3):
        return None
    u = code & 0xffff
    if u >= 0xff00:
        return None
    if (u & 0x7000) or (u & 0x8000):
        return u & 0x0fff
    return code


def _text_tokens(text: str):
    """Devuelve una secuencia ('char', c) / ('control', FFxx)."""
    out = []
    p = 0
    for m in CONTROL_RE.finditer(text):
        out.extend(('char', c) for c in text[p:m.start()])
        out.append(('control', int(m.group(1), 16)))
        p = m.end()
    out.extend(('char', c) for c in text[p:])
    return out


def _source_pairs(unit: TextUnit, source_text: str):
    """Alinea source XLIFF con códigos originales y devuelve (glyph_index, char)."""
    toks = _text_tokens(source_text)
    pos = 0
    pairs = []
    for code in unit.codes:
        if code in (-4, -3):
            if pos >= len(toks) or toks[pos][0] != 'char' or toks[pos][1] not in (' ', '\u3000'):
                return None
            pos += 1
            continue
        u = code & 0xffff
        if u >= 0xff00:
            if pos >= len(toks) or toks[pos][0] != 'control' or toks[pos][1] != u:
                return None
            pos += 1
            continue
        if pos >= len(toks) or toks[pos][0] != 'char':
            return None
        pairs.append((_glyph_index(code), toks[pos][1]))
        pos += 1
    return pairs if pos == len(toks) else None


def _file_unit_map(parsed_file: dict) -> dict[str, dict]:
    return {u['id']: u for u in parsed_file['units']}


def _project_block_map(project: Killer7Project) -> dict[str, TextBlock]:
    return {b.id: b for b in project.all_blocks}


def _existing_char_map(block: TextBlock, parsed_file: dict) -> dict[str, int]:
    expected = {u.stable_id: u for u in block.units}
    mapping: dict[str, int] = {}
    conflicts: set[str] = set()
    for row in parsed_file['units']:
        source = row['source']
        if not source or source.startswith(PENDING_PREFIX) or source.startswith(SPECIAL_PREFIX):
            continue
        unit = expected.get(row['id'])
        if unit is None:
            continue
        pairs = _source_pairs(unit, source)
        if pairs is None:
            continue
        for idx, ch in pairs:
            if idx is None:
                continue
            old = mapping.get(ch)
            if old is None:
                mapping[ch] = idx
            elif old != idx:
                conflicts.add(ch)
    for ch in conflicts:
        mapping.pop(ch, None)
    return mapping


def _build_glyph_bank(project: Killer7Project, parsed: dict):
    """Banco global de glifos confirmados por source XLIFF; nunca usa OCR."""
    blocks = _project_block_map(project)
    bank: dict[str, list[tuple[int, Image.Image]]] = defaultdict(list)
    seen = set()
    for pf in parsed['files']:
        block = blocks.get(pf['file_id'])
        if block is None or block.storage_kind != 'afs_pair':
            continue
        unit_map = {u.stable_id: u for u in block.units}
        atlas = project.decode_atlas(block)
        params = project.glyph_params(block)
        for row in pf['units']:
            source = row['source']
            if not source or source.startswith(PENDING_PREFIX) or source.startswith(SPECIAL_PREFIX):
                continue
            unit = unit_map.get(row['id'])
            if unit is None:
                continue
            pairs = _source_pairs(unit, source)
            if pairs is None:
                continue
            for idx, ch in pairs:
                if idx is None or not (0 <= idx < len(params)):
                    continue
                x, y, w, h = params[idx]
                if x + w > atlas.width or y + h > atlas.height:
                    continue
                key = (ch, w, h, atlas.crop((x, y, x+w, y+h)).tobytes())
                digest = hashlib.sha1(repr(key[:3]).encode() + key[3]).hexdigest()
                if (ch, digest) in seen:
                    continue
                seen.add((ch, digest))
                bank[ch].append((block.jmb_index, atlas.crop((x, y, x+w, y+h)).copy()))
    return bank


def _build_da_glyph_bank(project: Killer7Project, parsed: dict):
    """Banco global de glifos originales de subtítulos .da.

    Se construye exclusivamente a partir de sources ingleses verificados del
    propio XLIFF. Así, una traducción puede reutilizar una letra que no aparezca
    en su .da concreto pero sí en otro subtítulo de Killer7, sin rasterizar una
    tipografía externa.
    """
    blocks = _project_block_map(project)
    bank: dict[str, list[tuple[int, Image.Image]]] = defaultdict(list)
    seen = set()
    for pf in parsed['files']:
        block = blocks.get(pf['file_id'])
        if block is None or block.storage_kind != 'afs_da':
            continue
        unit_map = {u.stable_id: u for u in block.units}
        atlas = project.decode_atlas(block)
        params = project.glyph_params(block)
        for row in pf['units']:
            source = row['source']
            if not source or source.startswith(PENDING_PREFIX) or source.startswith(SPECIAL_PREFIX):
                continue
            unit = unit_map.get(row['id'])
            if unit is None:
                continue
            pairs = _source_pairs(unit, source)
            if pairs is None:
                continue
            for idx, ch in pairs:
                if idx is None or not (0 <= idx < len(params)):
                    continue
                x, y, w, h = params[idx]
                if w <= 0 or h <= 0 or x + w > atlas.width or y + h > atlas.height:
                    continue
                im = atlas.crop((x, y, x+w, y+h)).copy()
                digest = hashlib.sha1(struct.pack('<4H', x, y, w, h) + im.tobytes()).hexdigest()
                key = (ch, digest)
                if key in seen:
                    continue
                seen.add(key)
                bank[ch].append((block.jmb_index, im))
    return bank


def resolve_font_path(font_path: str | None = None) -> str | None:
    """Resuelve una fuente externa opcional.

    Una fuente instalada mejora el parecido de los glifos que no existen en los
    atlas originales, pero NO es un requisito. Si no hay ninguna disponible, el
    compilador usa la fuente interna escalable de Pillow (incluida en el runtime).
    """
    if font_path:
        if Path(font_path).exists():
            return str(Path(font_path))
        raise K7Error(f'No se encontró la fuente de apoyo: {font_path}')
    for candidate in DEFAULT_FONT_CANDIDATES:
        if Path(candidate).exists():
            return candidate
    return None


def _font_for_height(height: int, font_path: str | None):
    # El raster original ocupa un recuadro alto (p.ej. 36 px) pero su cuerpo visual es
    # bastante menor. ~70% da una escala mucho más próxima para glifos de apoyo.
    size = max(10, int(round(height * 0.70)))
    path = resolve_font_path(font_path)
    if path is not None:
        return ImageFont.truetype(path, size)
    # Pillow >= 10 incluye una fuente FreeType interna con soporte Latin-1. El
    # proyecto distribuye Pillow como parte de su runtime, por lo que este camino
    # funciona incluso en sistemas sin /usr/share/fonts (p.ej. SteamOS minimalista).
    try:
        return ImageFont.load_default(size=size)
    except TypeError:
        # Compatibilidad defensiva con Pillow antiguo; nuestro runtime actual es 12.x.
        return ImageFont.load_default()


def _normalize_glyph(im: Image.Image, height: int) -> Image.Image:
    im = im.convert('L')
    if im.height == height:
        return im
    # Conserva escala cuando procede; sólo centra/pad vertical si la diferencia es pequeña.
    if im.height < height:
        out = Image.new('L', (im.width, height), 0)
        out.paste(im, (0, max(0, (height-im.height)//2)))
        return out
    # Recorte vertical centrado para un banco de altura ligeramente distinta.
    top = max(0, (im.height-height)//2)
    return im.crop((0, top, im.width, top+height))


def _render_fallback_glyph(ch: str, height: int, font_path: str | None) -> Image.Image:
    font = _font_for_height(height, font_path)
    # Avance real + pequeño margen. El alto se mantiene idéntico a los fParams del bloque.
    try:
        advance = font.getlength(ch)
    except Exception:
        advance = font.getbbox(ch)[2]
    width = max(3, int(math.ceil(advance)) + 2)
    im = Image.new('L', (width, height), 17)
    draw = ImageDraw.Draw(im)
    ascent, descent = font.getmetrics()
    baseline = min(height - 2, ascent + 1)
    try:
        draw.text((1, baseline), ch, font=font, fill=255, anchor='ls')
    except Exception:
        bbox = draw.textbbox((0, 0), ch, font=font)
        draw.text((1, max(0, (height-(bbox[3]-bbox[1]))//2 - bbox[1])), ch, font=font, fill=255)
    # 4bpp real: cuantiza ya la imagen a los 16 niveles que puede almacenar el DIC.
    im = im.point(lambda v: int(round(v / 17.0)) * 17)
    return im



SPANISH_COMPOSE = {
    'á': ('a', 'acute'), 'é': ('e', 'acute'), 'í': ('i', 'acute'),
    'ó': ('o', 'acute'), 'ú': ('u', 'acute'), 'ü': ('u', 'diaeresis'),
    'ñ': ('n', 'tilde'),
    'Á': ('A', 'acute'), 'É': ('E', 'acute'), 'Í': ('I', 'acute'),
    'Ó': ('O', 'acute'), 'Ú': ('U', 'acute'), 'Ü': ('U', 'diaeresis'),
    'Ñ': ('N', 'tilde'),
}


def _mode_level(im: Image.Image) -> int:
    from collections import Counter
    vals = Counter(im.convert('L').getdata())
    return int(vals.most_common(1)[0][0]) if vals else 17


def _adapt_glyph_background(im: Image.Image, target_bg: int) -> Image.Image:
    """Iguala el fondo modal de un glifo importado con el atlas de destino.

    Algunos atlas de Killer7 usan nivel 0 y otros 17 como fondo. Copiar un glifo
    sin esta normalización deja un rectángulo gris visible aunque ambos sean 4bpp.
    Sólo sustituimos el nivel modal; los píxeles de borde/antialias se conservan.
    """
    out = im.convert('L').copy()
    source_bg = _mode_level(out)
    target_bg = int(round(target_bg / 17.0)) * 17
    if source_bg == target_bg:
        return out
    lut = list(range(256))
    lut[source_bg] = max(0, min(255, target_bg))
    return out.point(lut)


def _crop_current_glyph(atlas: Image.Image, params, idx: int, height: int) -> Image.Image | None:
    if idx is None or not (0 <= idx < len(params)):
        return None
    x, y, w, h = params[idx]
    if x + w > atlas.width or y + h > atlas.height:
        return None
    return _normalize_glyph(atlas.crop((x, y, x+w, y+h)), height)


def _erase_i_dot(im: Image.Image, bg: int) -> None:
    """Quita sólo el punto superior de una i antes de convertirla en í.

    Implementación sin numpy para que el runtime portátil de Steam Deck no
    necesite paquetes científicos externos.
    """
    pix = im.load()
    active = [
        sum(1 for x in range(im.width) if abs(int(pix[x, y]) - int(bg)) > 20)
        for y in range(im.height)
    ]
    groups = []
    start = None
    for y, count in enumerate(active):
        if count and start is None:
            start = y
        elif not count and start is not None:
            groups.append((start, y))
            start = None
    if start is not None:
        groups.append((start, len(active)))
    # La i original suele tener un componente pequeño arriba y el asta más abajo.
    if len(groups) >= 2 and groups[0][1] <= groups[1][0] and (groups[0][1]-groups[0][0]) <= 8:
        d = ImageDraw.Draw(im)
        d.rectangle((0, groups[0][0], im.width-1, groups[0][1]-1), fill=bg)


def _draw_mark(im: Image.Image, mark: str, bg: int, base_char: str = '') -> Image.Image:
    """Añade diacríticos pixelados dentro del alto original del atlas."""
    out = im.convert('L').copy()
    draw = ImageDraw.Draw(out)
    cx = out.width // 2
    if mark == 'acute':
        if base_char in {'i', 'I'}:
            _erase_i_dot(out, bg)
        # Diagonal corta, con un borde gris para imitar el antialias 4bpp del juego.
        pts = [(cx-2, 4), (cx-1, 3), (cx, 2), (cx+1, 1)]
        for x, y in pts:
            if 0 <= x < out.width and 0 <= y < out.height:
                out.putpixel((x, y), 255)
            if 0 <= x-1 < out.width and 0 <= y < out.height:
                if out.getpixel((x-1, y)) == bg:
                    out.putpixel((x-1, y), 102)
    elif mark == 'diaeresis':
        for x0 in (cx-4, cx+2):
            for yy in (2, 3):
                for xx in (x0, x0+1):
                    if 0 <= xx < out.width and 0 <= yy < out.height:
                        out.putpixel((xx, yy), 255)
    elif mark == 'tilde':
        wave = [(-4,3),(-3,2),(-2,2),(-1,3),(0,3),(1,4),(2,4),(3,3),(4,3)]
        for dx, yy in wave:
            xx = cx + dx
            if 0 <= xx < out.width and 0 <= yy < out.height:
                out.putpixel((xx, yy), 255)
    return out.point(lambda v: int(round(v / 17.0)) * 17)


def _synthesize_spanish_glyph(ch: str, atlas: Image.Image, params, char_to_index: dict[str, int], bank, height: int, font_path: str | None, prefer_index: int | None = None, allow_font_fallback: bool = True) -> Image.Image | None:
    """Crea letras españolas reutilizando el cuerpo de la tipografía de Killer7.

    Prioridad: glifo del mismo bloque -> banco global confirmado -> fuente de apoyo.
    Para ¿/¡ se invierte la puntuación normal cuando está disponible.
    """
    if ch in SPANISH_COMPOSE:
        base_char, mark = SPANISH_COMPOSE[ch]
        base = _crop_current_glyph(atlas, params, char_to_index.get(base_char), height)
        if base is None:
            base = _choose_bank_glyph(bank, base_char, height, prefer_index)
            if base is not None:
                base = _normalize_glyph(base, height)
        if base is None and allow_font_fallback:
            base = _render_fallback_glyph(base_char, height, font_path)
        if base is None:
            return None
        bg = _mode_level(base)
        return _draw_mark(base, mark, bg, base_char)

    # En los DA de PS2 el signo que algunas transcripciones marcaron como '!'
    # puede ser en realidad un punto. Para exclamaciones españolas no confiamos
    # en ese glifo: usamos la 'i' original de Killer7, que ya contiene punto +
    # asta vertical. Recortamos sólo una columna vacía para que quepa en slots
    # de 6x24. '¡' conserva la orientación de la i; '!' se gira 180 grados.
    if ch in {'!', '¡'}:
        base = _crop_current_glyph(atlas, params, char_to_index.get('i'), height)
        if base is None:
            base = _choose_bank_glyph(bank, 'i', height, prefer_index)
            if base is not None:
                base = _normalize_glyph(base, height)
        if base is None and allow_font_fallback:
            base = _render_fallback_glyph('i', height, font_path)
        if base is None:
            return None
        base = _normalize_glyph(base, height)
        # El sprite DA de 'i' suele tener una columna vacía a la izquierda.
        # Quitarla conserva todos los píxeles útiles y da el ancho 6 típico
        # de la puntuación del juego.
        if base.width > 1:
            hist = []
            for x in range(base.width):
                col = [base.getpixel((x, y)) for y in range(base.height)]
                hist.append(len(set(col)))
            if hist and hist[0] == 1:
                base = base.crop((1, 0, base.width, base.height))
        if ch == '!':
            base = base.rotate(180)
        return base.point(lambda v: int(round(v / 17.0)) * 17)

    if ch == '¿':
        base = _crop_current_glyph(atlas, params, char_to_index.get('?'), height)
        if base is None:
            base = _choose_bank_glyph(bank, '?', height, prefer_index)
            if base is not None:
                base = _normalize_glyph(base, height)
        if base is None and allow_font_fallback:
            base = _render_fallback_glyph('?', height, font_path)
        if base is None:
            return None
        return base.rotate(180).point(lambda v: int(round(v / 17.0)) * 17)
    return None

def _choose_bank_glyph(bank, ch: str, height: int, prefer_index: int | None = None) -> Image.Image | None:
    """Elige un glifo confirmado de la familia visual más próxima.

    Los AFS de Killer7 agrupan recursos del mismo subsistema/fuente. Dos atlas pueden
    tener la misma altura y, aun así, estilos totalmente distintos (paneles frente a
    etiquetas). Por eso, tras priorizar la altura exacta, preferimos el bloque fuente
    más cercano al bloque que se está compilando.
    """
    raw = bank.get(ch) or []
    if not raw:
        return None
    # Compatibilidad con bancos antiguos que contenían sólo Image.
    items = [(None, x) if isinstance(x, Image.Image) else x for x in raw]
    exact = [(idx, im) for idx, im in items if im.height == height]
    pool = exact or items
    def score(item):
        idx, im = item
        hdist = abs(im.height - height)
        bdist = abs(idx - prefer_index) if (idx is not None and prefer_index is not None) else 10**9
        return (hdist, bdist, im.width)
    _idx, im = min(pool, key=score)
    return im.copy()


def _row_layout(params: list[tuple[int, int, int, int]], atlas_size: tuple[int, int], default_h: int):
    width, height = atlas_size
    rows: dict[int, dict] = {}
    for x, y, w, h in params:
        r = rows.setdefault(y, {'x': 0, 'h': h})
        r['x'] = max(r['x'], x+w)
        r['h'] = max(r['h'], h)
    if not rows:
        rows[0] = {'x': 0, 'h': default_h}
    return rows


def _place_glyph(rows: dict, atlas_size: tuple[int, int], glyph: Image.Image, target_h: int):
    width, height = atlas_size
    gw = glyph.width
    for y in sorted(rows):
        row = rows[y]
        if y + target_h <= height and row['x'] + gw <= width:
            x = row['x']
            row['x'] += gw
            row['h'] = max(row['h'], target_h)
            return x, y
    next_y = max(y + rows[y]['h'] for y in rows)
    if next_y + target_h > height or gw > width:
        raise K7Error(
            f'El atlas {width}x{height} no tiene espacio para otro glifo {gw}x{target_h}. '
            'Habrá que repaquetar o ampliar la textura.'
        )
    rows[next_y] = {'x': gw, 'h': target_h}
    return 0, next_y


def _unit_glyph_indices(unit: TextUnit) -> set[int]:
    out: set[int] = set()
    for code in unit.codes:
        idx = _glyph_index(code)
        if idx is not None and idx >= 0:
            out.add(idx)
    return out


def _target_chars(text: str) -> set[str]:
    return {value for typ, value in _text_tokens(text)
            if typ == 'char' and value not in (' ', '\u3000')}


def _recycle_and_repack_atlas(
    block: TextBlock,
    original_atlas: Image.Image,
    original_params: list[tuple[int, int, int, int]],
    base_char_to_index: dict[str, int],
    translated_rows,
    needed_glyphs: list[tuple[str, Image.Image]],
):
    """Recicla índices obsoletos y compacta el atlas sin cambiar IDs protegidos.

    Sólo se activa como plan B cuando el append conservador no cabe. Los índices
    referenciados por unidades sin traducir nunca se reutilizan. Los índices que
    una traducción sigue necesitando tampoco. Reubicar un glifo es seguro porque
    el JMB lo referencia por índice y su fParam se recompila con las coordenadas
    nuevas.
    """
    translated_ids = {row['id'] for row, _unit, _target in translated_rows}
    protected: set[int] = set()
    for unit in block.units:
        if unit.stable_id not in translated_ids:
            protected.update(i for i in _unit_glyph_indices(unit) if i < len(original_params))

    required_existing: set[int] = set()
    for _row, _unit, target in translated_rows:
        for ch in _target_chars(target):
            idx = base_char_to_index.get(ch)
            if idx is not None and 0 <= idx < len(original_params):
                required_existing.add(idx)

    recyclable = [i for i in range(len(original_params))
                  if i not in protected and i not in required_existing]

    char_to_index = dict(base_char_to_index)
    replacements: dict[int, Image.Image] = {}
    added: dict[str, int] = {}
    next_index = len(original_params)
    for ch, glyph in needed_glyphs:
        if recyclable:
            idx = recyclable.pop(0)
            # El índice deja de representar cualquier carácter antiguo conocido.
            for old_ch, old_idx in list(char_to_index.items()):
                if old_idx == idx:
                    char_to_index.pop(old_ch, None)
        else:
            idx = next_index
            next_index += 1
        replacements[idx] = glyph
        char_to_index[ch] = idx
        added[ch] = idx

    # Conserva todos los glifos originales no reciclados y añade los nuevos.
    glyphs: list[Image.Image] = []
    for idx in range(next_index):
        if idx in replacements:
            glyphs.append(replacements[idx])
            continue
        if idx >= len(original_params):
            raise K7Error(f'{block.id}: índice de glifo interno inválido al repaquetar.')
        x, y, w, h = original_params[idx]
        if w <= 0 or h <= 0 or x+w > original_atlas.width or y+h > original_atlas.height:
            raise K7Error(f'{block.id}: fParam {idx} inválido al repaquetar.')
        glyphs.append(original_atlas.crop((x, y, x+w, y+h)).copy())

    bg = _mode_level(original_atlas)
    atlas = Image.new('L', original_atlas.size, bg)
    width, height = atlas.size
    params: list[tuple[int, int, int, int]] = []
    x = y = 0
    shelf_h = 0
    for idx, glyph in enumerate(glyphs):
        gw, gh = glyph.size
        if gw < 1 or gh < 1 or gw > width or gh > height:
            raise K7Error(f'{block.id}: glifo {idx} de tamaño {gw}x{gh} no cabe en atlas {width}x{height}.')
        if x and x + gw > width:
            y += shelf_h
            x = 0
            shelf_h = 0
        if y + gh > height:
            raise K7Error(
                f'{block.id}: ni reciclando índices cabe el atlas {width}x{height}; '
                'hará falta una estrategia de textura ampliada.'
            )
        atlas.paste(glyph, (x, y))
        params.append((x, y, gw, gh))
        x += gw + 1
        shelf_h = max(shelf_h, gh)

    return atlas, params, char_to_index, added, protected


def _swizzle8(linear: bytes | bytearray, width: int, height: int) -> bytearray:
    """Inversa exacta de core._unswizzle8 para PSMT4 type-2 expandido a 8bpp."""
    if len(linear) != width * height:
        raise ValueError('Tamaño lineal incorrecto.')
    out = bytearray(width * height)
    for y in range(height):
        for x in range(width):
            block_location = (y & (~0xf)) * width + (x & (~0xf)) * 2
            swap_selector = (((y + 2) >> 2) & 1) * 4
            posY = (((y & (~3)) >> 1) + (y & 1)) & 7
            column_location = posY * width * 2 + ((x + swap_selector) & 7) * 4
            byte_num = ((y >> 1) & 1) + ((x >> 2) & 2)
            swizzleid = block_location + column_location + byte_num
            out[swizzleid] = linear[y * width + x]
    return out


def _encode_atlas_into_dic(original_dic: bytes, atlas: Image.Image) -> bytes:
    """Reescribe un DIC 4bpp respetando el paquete GS real del recurso.

    La inmensa mayoría de DIC 4bpp de Killer7 sube el payload como PSMCT16
    (TRXREG width/2 x height/2) y luego lee esa VRAM como PSMT4. Las versiones
    antiguas escribían un PSMT4 swizzleado directamente y además comenzaban
    cuatro bytes antes del payload IMAGE, lo que podía verse correcto en el
    visor interno pero corrupto en la PS2/PCSX2.
    """
    dic = bytearray(original_dic)
    if len(dic) < 0x120:
        raise K7Error('DIC demasiado corto.')
    name_len = struct.unpack_from('<I', dic, 0x40)[0]
    shift = int(name_len) - 8
    width_off = 0x78 + shift
    width, height, bpp = struct.unpack_from('<III', dic, width_off)
    if bpp != 4:
        raise K7Error(f'Textura DIC {bpp}bpp no soportada.')
    if atlas.size != (width, height):
        raise K7Error(f'Atlas recompilado {atlas.size} != atlas DIC {(width, height)}.')

    payload_size = width * height // 2
    trxreg = struct.unpack_from('<Q', dic, 0xE4 + shift)[0]
    rrw = int(trxreg & 0xFFF)
    rrh = int((trxreg >> 32) & 0xFFF)
    image_tag = struct.unpack_from('<Q', dic, 0x104 + shift)[0]
    nloop = int(image_tag & 0x7FFF)
    alias = (
        (rrw, rrh) == (width // 2, height // 2)
        and nloop * 16 == payload_size
        and rrw * rrh * 2 == payload_size
    )

    if alias:
        pixel_off = 0x114 + shift
        if pixel_off + payload_size > len(dic):
            raise K7Error('Payload GS DIC fuera de rango.')
        original_payload = bytes(dic[pixel_off:pixel_off + payload_size])
        # GS DBW está expresado en bloques de 64 píxeles CT16; para
        # transferencias más estrechas (rrw=32, usadas por st11Font) el
        # buffer sigue ocupando un bloque mínimo.
        dbw = max(1, (rrw + 63) // 64)
        vram = bytearray(4 * 1024 * 1024)
        _da_write_ct16(vram, dbw, rrw, rrh, original_payload)
        if _da_read_ct16(vram, dbw, rrw, rrh) != original_payload:
            raise K7Error('La transferencia PSMCT16 DIC no hace round-trip.')
        original_px = _da_read_t4(vram, width, height)
        target_px = bytearray(
            max(0, min(15, int(round(v / 17.0))))
            for v in atlas.convert('L').getdata()
        )
        for i, (old, new) in enumerate(zip(original_px, target_px)):
            if old != new:
                _da_write_t4(vram, width, i % width, i // width, new)
        new_payload = _da_read_ct16(vram, dbw, rrw, rrh)
        check = bytearray(4 * 1024 * 1024)
        _da_write_ct16(check, dbw, rrw, rrh, new_payload)
        if _da_read_t4(check, width, height) != target_px:
            raise K7Error('El DIC recompilado no reproduce el PSMT4 solicitado en GS.')
        dic[pixel_off:pixel_off + payload_size] = new_payload
        return bytes(dic)

    # Fallback para los pocos DIC 4bpp cuyo paquete no sigue el alias CT16->T4.
    pixel_off = 0x104 + shift
    linear = bytearray(max(0, min(15, int(round(v / 17.0)))) for v in atlas.convert('L').getdata())
    sw = _swizzle8(linear, width, height)
    packed = bytearray(width * height // 2)
    for i in range(len(packed)):
        packed[i] = (sw[i*2] & 0x0f) | ((sw[i*2+1] & 0x0f) << 4)
    if pixel_off + len(packed) > len(dic):
        raise K7Error('La textura recompilada excede el DIC original.')
    dic[pixel_off:pixel_off+len(packed)] = packed
    return bytes(dic)


def _graphic_font(size: int, font_path: str | None = None):
    candidates = ([font_path] if font_path else []) + DEFAULT_FONT_CANDIDATES
    for cand in candidates:
        if not cand:
            continue
        try:
            if Path(cand).is_file():
                return ImageFont.truetype(str(cand), size)
        except Exception:
            pass
    try:
        return ImageFont.load_default(size=size)
    except TypeError:
        return ImageFont.load_default()


def _graphic_lines(text: str, role: str) -> list[str]:
    text = ' '.join((text or '').split())
    if role == 'epilogue':
        if ',' in text:
            a, b = text.split(',', 1)
            return [a.strip() + ',', b.strip()]
        words = text.split()
        if len(words) > 3:
            mid = len(words) // 2
            return [' '.join(words[:mid]), ' '.join(words[mid:])]
    return [text]


def _fit_graphic_font(text: str, box: tuple[int, int, int, int], role: str,
                      font_path: str | None = None):
    x0, y0, x1, y1 = box
    width, height = x1 - x0, y1 - y0
    lines = _graphic_lines(text, role)
    if role == 'title':
        max_size = max(10, int(height * 0.72))
    elif role == 'epilogue':
        max_size = max(10, int(height * 0.34))
    else:
        max_size = max(10, int(height * 0.68))
    for size in range(max_size, 7, -1):
        font = _graphic_font(size, font_path)
        widths = []
        heights = []
        for line in lines:
            bb = font.getbbox(line)
            widths.append(bb[2] - bb[0])
            heights.append(bb[3] - bb[1])
        spacing = max(2, size // 6)
        total_h = sum(heights) + spacing * max(0, len(lines) - 1)
        if max(widths or [0]) <= width * 0.94 and total_h <= height * 0.90:
            return font, lines, spacing
    font = _graphic_font(8, font_path)
    return font, lines, 2


def _draw_graphic_target(atlas: Image.Image, spec: dict, target: str,
                         font_path: str | None = None) -> Image.Image:
    out = atlas.copy().convert('L')
    box = tuple(int(v) for v in spec['box'])
    clear_box = tuple(int(v) for v in spec.get('clear_box', box))
    polarity = spec.get('polarity', 'light')
    role = spec.get('role', 'small')
    bg, fg = (0, 238) if polarity == 'light' else (255, 17)
    # Limpia únicamente la región verificada del rótulo; el resto de la textura
    # se conserva byte por byte después de volver a aplicar el swizzle.
    out.paste(bg, clear_box)
    font, lines, spacing = _fit_graphic_font(target, box, role, font_path)
    draw = ImageDraw.Draw(out)
    metrics = []
    total_h = 0
    for line in lines:
        bb = draw.textbbox((0, 0), line, font=font)
        w, h = bb[2] - bb[0], bb[3] - bb[1]
        metrics.append((line, bb, w, h))
        total_h += h
    total_h += spacing * max(0, len(metrics) - 1)
    x0, y0, x1, y1 = box
    y = y0 + max(0, (y1 - y0 - total_h) // 2)
    for line, bb, w, h in metrics:
        x = x0 + max(0, (x1 - x0 - w) // 2)
        draw.text((x, y - bb[1]), line, font=font, fill=fg)
        y += h + spacing
    # El DIC sólo puede representar 16 niveles.
    return out.point(lambda v: max(0, min(255, int(round(v / 17.0)) * 17)))


def compile_k7p2_block(project: Killer7Project, block: TextBlock, parsed_file: dict) -> CompiledK7P2 | None:
    """Compila nombres mostrados de NurbsPathName/WinLocatorName.

    La entrada K7P2 primaria está duplicada dentro del DAR inmediatamente siguiente.
    Se parchean ambas copias en el mismo slot, sin tocar claves, punteros ni la tabla
    de relocación. Por diseño sólo se admiten targets ASCII que quepan en el slot.
    """
    if block.storage_kind != 'afs_k7p2':
        raise K7Error(f'{block.id}: no es un bloque K7P2 de escenario.')
    by_uid = {u.stable_id: u for u in block.units}
    original = project.entry_bytes(block.jmb_index)
    mirror_original = project.entry_bytes(block.dic_index)
    mirror_off = mirror_original.find(original)
    if mirror_off < 0:
        raise K7Error(
            f'{block.id}: el DAR AFS#{block.dic_index:04d} no contiene la copia K7P2 esperada.'
        )
    if mirror_original.find(original, mirror_off + 1) >= 0:
        raise K7Error(f'{block.id}: la copia K7P2 aparece más de una vez en el DAR; parche ambiguo.')
    primary = bytearray(original)
    mirror = bytearray(mirror_original)
    translated: list[str] = []
    for row in parsed_file['units']:
        source = row['source'].strip('\r\n')
        target = row['target'].strip('\r\n')
        if not target or target == source:
            continue
        unit = by_uid.get(row['id'])
        if unit is None:
            raise K7Error(f'{row["id"]}: unidad K7P2 no encontrada.')
        if source in ('Iwazaru', 'Travis'):
            raise K7Error(f'{row["id"]}: {source} es nombre propio/localizador y debe conservarse.')
        try:
            src_b = source.encode('ascii')
            tgt_b = target.encode('ascii')
        except UnicodeEncodeError as exc:
            raise K7Error(f'{row["id"]}: K7P2 sólo admite ASCII en esta versión.') from exc
        off = int(unit.binary_offset)
        slot = int(unit.binary_slot)
        if slot < 2 or off < 0 or off + slot > len(primary):
            raise K7Error(f'{row["id"]}: slot K7P2 inválido.')
        if len(tgt_b) > slot - 1:
            raise K7Error(
                f'{row["id"]}: {len(tgt_b)} bytes > máximo {slot-1} del slot K7P2.'
            )
        if primary[off:off+len(src_b)] != src_b or primary[off+len(src_b):off+len(src_b)+1] != b'\0':
            got = bytes(primary[off:off+slot]).split(b'\0', 1)[0]
            raise K7Error(
                f'{row["id"]}: K7P2 original no coincide en +0x{off:X}; '
                f'se esperaba {src_b!r}, encontrado {got!r}.'
            )
        payload = tgt_b + b'\0' * (slot - len(tgt_b))
        primary[off:off+slot] = payload
        moff = mirror_off + off
        mirror[moff:moff+slot] = payload
        translated.append(row['id'])
    if not translated:
        return None
    return CompiledK7P2(block, bytes(primary), bytes(mirror), translated, mirror_off)


def compile_graphic_block(project: Killer7Project, block: TextBlock, parsed_file: dict,
                          font_path: str | None = None) -> CompiledGraphic | None:
    specs = GRAPHIC_PATCH_SPECS.get(block.jmb_index)
    if not specs:
        raise K7Error(f'{block.id}: no existe especificación de regiones gráficas.')
    if len(specs) != len(block.units):
        raise K7Error(f'{block.id}: {len(specs)} regiones para {len(block.units)} unidades.')
    rows = _file_unit_map(parsed_file)
    atlas = project.decode_atlas(block)
    translated: list[str] = []
    for seq, unit in enumerate(block.units):
        row = rows.get(unit.stable_id)
        if not row:
            continue
        target = (row.get('target') or '').strip()
        if not target or target == row.get('source', ''):
            continue
        if len(target) > 80:
            raise K7Error(f'{unit.stable_id}: target gráfico anormalmente largo ({len(target)}).')
        atlas = _draw_graphic_target(atlas, specs[seq], target, font_path)
        translated.append(unit.stable_id)
    if not translated:
        return None
    original = project.entry_bytes(block.dic_index)
    data = _encode_atlas_into_dic(original, atlas)
    if len(data) != len(original):
        raise K7Error(f'{block.id}: el DIC gráfico cambió de tamaño.')
    return CompiledGraphic(block, data, translated, atlas)


def _encode_target(text: str, char_to_index: dict[str, int], max_codes: int = JMB_MAX_CODES) -> list[int]:
    out: list[int] = []
    for typ, value in _text_tokens(text):
        if typ == 'control':
            out.append(_signed16(value))
        else:
            ch = value
            if ch in (' ', '\u3000'):
                out.append(-4)
            else:
                if ch not in char_to_index:
                    raise K7Error(f'No hay glifo registrado para {ch!r}.')
                out.append(char_to_index[ch])
    if len(out) > max_codes:
        raise K7Error(f'La traducción requiere {len(out)} códigos; el máximo es {max_codes}.')
    return out


def _render_codes(atlas: Image.Image, params, codes: list[int], scale: int = 3) -> Image.Image:
    pieces = []
    wtotal = 0
    h = max([p[3] for p in params] or [36])
    for code in codes:
        if code in (-4, -3):
            pieces.append(('gap', 12)); wtotal += 12; continue
        u = code & 0xffff
        if u >= 0xff00:
            pieces.append(('gap', 18)); wtotal += 18; continue
        idx = _glyph_index(code)
        if idx is not None and 0 <= idx < len(params):
            x, y, w, gh = params[idx]
            if x+w <= atlas.width and y+gh <= atlas.height:
                g = atlas.crop((x, y, x+w, y+gh))
                pieces.append(('glyph', g)); wtotal += w+1; continue
        pieces.append(('gap', 12)); wtotal += 12
    out = Image.new('L', (max(1, wtotal), h), 0)
    x = 0
    for typ, val in pieces:
        if typ == 'glyph':
            out.paste(val, (x, 0)); x += val.width + 1
        else:
            x += val
    bbox = out.getbbox()
    if bbox:
        out = out.crop((0, max(0, bbox[1]-2), out.width, min(out.height, bbox[3]+2)))
    if scale != 1:
        out = out.resize((out.width*scale, out.height*scale), Image.Resampling.NEAREST)
    return out


def compile_block(project: Killer7Project, block: TextBlock, parsed_file: dict, glyph_bank: dict, font_path: str | None = None) -> CompiledBlock | None:
    expected = {u.stable_id: u for u in block.units}
    translated = []
    rows = []
    for row in parsed_file['units']:
        target = row['target'].strip('\r\n')
        source = row['source'].strip('\r\n')
        if not target or target == source:
            continue
        if source.startswith(PENDING_PREFIX):
            raise K7Error(f'{row["id"]}: no se puede compilar una traducción cuyo source sigue pendiente.')
        if source.startswith(SPECIAL_PREFIX):
            raise K7Error(f'{row["id"]}: recurso especial protegido; no se puede inyectar como texto.')
        unit = expected.get(row['id'])
        if unit is None:
            raise K7Error(f'{row["id"]}: unidad no encontrada en la ISO.')
        # Los flags 0x7xxx/0x8xxx son estilo/rubí; aún no los reasignamos automáticamente.
        flagged = [c for c in unit.codes if (c & 0xffff) < 0xff00 and ((c & 0x7000) or (c & 0x8000))]
        if flagged:
            raise K7Error(f'{row["id"]}: contiene flags de glifo 7xxx/8xxx todavía no soportados por el recompilador.')
        if visible_target_length(target) > JMB_MAX_CODES:
            raise K7Error(f'{row["id"]}: supera {JMB_MAX_CODES} códigos JMB.')
        rows.append((row, unit, target))
        translated.append(row['id'])
    if not rows:
        return None

    original_jmb = project.entry_bytes(block.jmb_index)
    original_dic = project.entry_bytes(block.dic_index)
    sn, cn, so, co, to = struct.unpack_from('<hhIII', original_jmb, 0)
    params = list(project.glyph_params(block))
    atlas = project.decode_atlas(block).copy()
    if len(params) != cn:
        raise K7Error(f'{block.id}: char_num inconsistente.')

    base_char_to_index = _existing_char_map(block, parsed_file)
    char_to_index = dict(base_char_to_index)
    row_h = max((h for _x,_y,_w,h in params), default=36)
    added: dict[str, int] = {}
    fallback_chars: list[str] = []
    synthesized_chars: list[str] = []

    needed = []
    for _row, _unit, target in rows:
        for typ, value in _text_tokens(target):
            if typ != 'char' or value in (' ', '\u3000'):
                continue
            if value not in char_to_index and value not in needed:
                needed.append(value)

    # Renderiza primero los glifos necesarios. Así podemos reintentar con un
    # repaquetado limpio si el append conservador agota el atlas.
    needed_glyphs: list[tuple[str, Image.Image]] = []
    for ch in needed:
        glyph = _choose_bank_glyph(glyph_bank, ch, row_h, block.jmb_index)
        if glyph is not None:
            glyph = _normalize_glyph(glyph, row_h)
        else:
            glyph = _synthesize_spanish_glyph(ch, atlas, params, char_to_index, glyph_bank, row_h, font_path, block.jmb_index)
            if glyph is not None:
                synthesized_chars.append(ch)
            else:
                glyph = _render_fallback_glyph(ch, row_h, font_path)
                fallback_chars.append(ch)
        if glyph.width < 1:
            glyph = Image.new('L', (3, row_h), _mode_level(atlas))
        glyph = _adapt_glyph_background(glyph, _mode_level(atlas))
        glyph = glyph.point(lambda v: int(round(v / 17.0)) * 17)
        needed_glyphs.append((ch, glyph))

    # Primer intento: comportamiento histórico, sólo añade al final y deja intactos
    # todos los fParams existentes.
    append_atlas = atlas.copy()
    append_params = list(params)
    append_map = dict(char_to_index)
    append_added: dict[str, int] = {}
    layout = _row_layout(append_params, append_atlas.size, row_h)
    try:
        for ch, glyph in needed_glyphs:
            x, y = _place_glyph(layout, append_atlas.size, glyph, row_h)
            append_atlas.paste(glyph, (x, y))
            idx = len(append_params)
            append_params.append((x, y, glyph.width, row_h))
            append_map[ch] = idx
            append_added[ch] = idx
        atlas, params, char_to_index, added = append_atlas, append_params, append_map, append_added
    except K7Error:
        # Plan B: reutiliza índices que han quedado obsoletos por la traducción y
        # compacta el atlas. Nunca recicla índices usados por unidades sin traducir.
        atlas, params, char_to_index, added, _protected = _recycle_and_repack_atlas(
            block, atlas, params, base_char_to_index, rows, needed_glyphs
        )

    # Parte de escenas completa, sin tocar: sólo se sustituyen char_data de unidades traducidas.
    pre = bytearray(original_jmb[:co])
    translated_codes: dict[str, list[int]] = {}
    for row, unit, target in rows:
        codes = _encode_target(target, char_to_index)
        translated_codes[row['id']] = codes
        off = so + unit.sentence * JMB_SCENE_SIZE + 76 + unit.jimaku * JMB_RECORD_SIZE + 8
        arr = codes + [-2]
        arr += [-1] * (JMB_CODE_SLOTS - len(arr))
        if len(arr) != JMB_CODE_SLOTS:
            raise K7Error(f'{row["id"]}: error interno al rellenar char_data.')
        struct.pack_into(f'<{JMB_CODE_SLOTS}h', pre, off, *arr)

    # Recompila fParams. El formato deja siempre al menos un bloque de padding de 32 bytes.
    param_bytes = b''.join(struct.pack('<4H', *p) for p in params)
    after = co + len(param_bytes)
    pad = 32 - (after % 32)
    new_to = after + pad
    struct.pack_into('<h', pre, 2, len(params))
    struct.pack_into('<I', pre, 12, new_to)
    new_jmb = bytes(pre) + param_bytes + (b'\x00' * pad)
    if len(new_jmb) != new_to:
        raise K7Error(f'{block.id}: tex_offset/tamaño recompilado inconsistente.')

    new_dic = _encode_atlas_into_dic(original_dic, atlas)
    return CompiledBlock(block, new_jmb, new_dic, translated, added, params, atlas, fallback_chars, synthesized_chars)



def _pack_da_glyphs(block: TextBlock, original_atlas: Image.Image, original_params,
                    base_char_to_index: dict[str, int], translated_rows,
                    da_glyph_bank: dict | None = None,
                    font_path: str | None = None):
    """Reempaqueta el atlas de un subtítulo DA manteniendo índices protegidos.

    Las líneas no traducidas siguen apuntando a sus índices originales. Los índices
    usados sólo por líneas traducidas se pueden reciclar; si hacen falta más, se
    añaden fParams siempre que el DAR y el hueco AFS sigan cabiendo.
    """
    translated_ids = {row['id'] for row, _unit, _target in translated_rows}
    protected: set[int] = set()
    for unit in block.units:
        if unit.stable_id not in translated_ids:
            protected.update(i for i in _unit_glyph_indices(unit) if i < len(original_params))

    required_existing: set[int] = set()
    for _row, _unit, target in translated_rows:
        for ch in _target_chars(target):
            idx = base_char_to_index.get(ch)
            if idx is not None and 0 <= idx < len(original_params):
                required_existing.add(idx)

    recyclable = [i for i in range(len(original_params))
                  if i not in protected and i not in required_existing]
    char_to_index = dict(base_char_to_index)
    replacements: dict[int, Image.Image] = {}
    added: dict[str, int] = {}
    fallback_chars: list[str] = []
    synthesized_chars: list[str] = []
    next_index = len(original_params)
    row_h = max((p[3] for p in original_params), default=24)
    bg = _mode_level(original_atlas)

    needed: list[str] = []
    seen_chars = set(char_to_index)
    for _row, _unit, target in translated_rows:
        for typ, value in _text_tokens(target):
            if typ != 'char' or value in (' ', '\u3000') or value in seen_chars:
                continue
            seen_chars.add(value)
            needed.append(value)

    da_glyph_bank = da_glyph_bank or {}
    for ch in needed:
        # Primero reutiliza EXACTAMENTE el sprite original de Killer7 de otro .da.
        # Éste es el camino normal para letras latinas que no existan en el atlas
        # local. No se redibuja con Pillow.
        glyph = _choose_bank_glyph(da_glyph_bank, ch, row_h, block.jmb_index)
        if glyph is not None:
            glyph = _normalize_glyph(glyph, row_h)
        else:
            # Los caracteres españoles inexistentes se construyen sobre la letra
            # base original del juego (local o del banco DA), conservando su cuerpo.
            glyph = _synthesize_spanish_glyph(
                ch, original_atlas, original_params, char_to_index, da_glyph_bank,
                row_h, font_path, prefer_index=block.jmb_index,
                allow_font_fallback=False,
            )
            if glyph is not None:
                synthesized_chars.append(ch)
            else:
                raise K7Error(
                    f'{block.id}: el carácter {ch!r} no está identificado en ningún '
                    'atlas de subtítulos original de Killer7. Para evitar mezclar '
                    'tipografías, esta versión no genera letras DA con fuentes externas.'
                )
        glyph = _normalize_glyph(glyph, row_h)
        glyph = _adapt_glyph_background(glyph, bg)
        glyph = glyph.point(lambda v: int(round(v / 17.0)) * 17)
        if glyph.width < 1:
            glyph = Image.new('L', (3, row_h), bg)

        if recyclable:
            idx = recyclable.pop(0)
            for old_ch, old_idx in list(char_to_index.items()):
                if old_idx == idx:
                    char_to_index.pop(old_ch, None)
        else:
            idx = next_index
            next_index += 1
        replacements[idx] = glyph
        char_to_index[ch] = idx
        added[ch] = idx

    glyphs: list[Image.Image] = []
    for idx in range(next_index):
        if idx in replacements:
            glyphs.append(replacements[idx])
            continue
        if idx >= len(original_params):
            raise K7Error(f'{block.id}: índice DA interno inválido al repaquetar.')
        x, y, w, h = original_params[idx]
        if w <= 0 or h <= 0 or x+w > original_atlas.width or y+h > original_atlas.height:
            raise K7Error(f'{block.id}: fParam DA {idx} inválido.')
        glyphs.append(original_atlas.crop((x, y, x+w, y+h)).copy())

    atlas = Image.new('L', original_atlas.size, bg)
    width, height = atlas.size
    params: list[tuple[int, int, int, int]] = []
    x = y = 0
    shelf_h = row_h
    for idx, glyph in enumerate(glyphs):
        gw, gh = glyph.size
        if gh != row_h:
            glyph = _normalize_glyph(glyph, row_h)
            gw, gh = glyph.size
        if x and x + gw > width:
            y += shelf_h
            x = 0
        if gw > width or y + row_h > height:
            raise K7Error(
                f'{block.id}: el atlas de subtítulos {width}x{height} no tiene espacio para '
                f'{len(glyphs)} glifos. Traduce más líneas del mismo .da para liberar '
                'índices antiguos o acorta el repertorio de caracteres.'
            )
        atlas.paste(glyph, (x, y))
        params.append((x, y, gw, row_h))
        x += gw

    return atlas, params, char_to_index, added, fallback_chars, synthesized_chars



def _da_glyph_is_dot_like(atlas: Image.Image, params, idx: int | None) -> bool:
    """Detecta una puntuación que visualmente es sólo un punto, no '!'."""
    if idx is None or not (0 <= idx < len(params)):
        return False
    x, y, w, h = params[idx]
    if w <= 0 or h <= 0 or x+w > atlas.width or y+h > atlas.height:
        return False
    g = atlas.crop((x, y, x+w, y+h))
    hist = g.histogram()
    bg = max(range(256), key=lambda v: hist[v])
    mask = g.point(lambda v: 255 if v != bg else 0)
    bbox = mask.getbbox()
    if not bbox:
        return True
    ink_h = bbox[3] - bbox[1]
    # Un signo de exclamación completo ocupa claramente más de un tercio
    # de la altura. El supuesto '!' de 0071010 ocupa sólo 5 px de 24.
    return ink_h <= max(6, h // 3)


def _trim_da_glyph_horizontal(glyph: Image.Image, bg: int, margin: int = 1) -> Image.Image:
    """Recorta sólo padding horizontal vacío de un glifo DA.

    No toca la forma del carácter: conserva un pequeño margen lateral y sirve para
    reutilizar sprites de otros .da cuyos fParams incluyen más side-bearing del
    necesario en el atlas de destino.
    """
    glyph = glyph.convert('L')
    mask = glyph.point(lambda v: 255 if v != bg else 0)
    bbox = mask.getbbox()
    if not bbox:
        return glyph
    left = max(0, bbox[0] - margin)
    right = min(glyph.width, bbox[2] + margin)
    if right <= left or (left == 0 and right == glyph.width):
        return glyph
    return glyph.crop((left, 0, right, glyph.height))


def _condense_da_glyph(glyph: Image.Image, max_width: int, bg: int,
                       min_ratio: float = 0.72) -> Image.Image | None:
    """Ajusta horizontalmente un sprite ORIGINAL para que quepa en un slot DA.

    Primero elimina padding vacío. Sólo si aún no cabe permite una compresión
    horizontal moderada (máximo ~28 %). Nunca cambia la altura ni rasteriza una
    fuente externa. El resultado vuelve a cuantizarse a los 16 niveles del DIC.
    """
    glyph = _trim_da_glyph_horizontal(glyph, bg, margin=1)
    if glyph.width <= max_width:
        return glyph
    if max_width < 3 or (max_width / float(glyph.width)) < min_ratio:
        return None
    resampling = getattr(Image, 'Resampling', Image)
    glyph = glyph.resize((max_width, glyph.height), resample=resampling.LANCZOS)
    glyph = glyph.point(lambda v: int(round(v / 17.0)) * 17)
    return glyph


def _pack_da_glyphs_inplace(block: TextBlock, original_atlas: Image.Image, original_params,
                            base_char_to_index: dict[str, int], translated_rows,
                            da_glyph_bank: dict | None = None,
                            font_path: str | None = None):
    """Recicla slots DA sin mover ni repaquetar ningún glifo original.

    Sólo se pueden reutilizar índices que no usa ninguna línea sin traducir y que
    tampoco son necesarios por un carácter ya existente de los targets. El nuevo
    glifo debe caber físicamente en el rectángulo del slot reciclado.
    """
    translated_ids = {row['id'] for row, _unit, _target in translated_rows}
    protected: set[int] = set()
    for unit in block.units:
        if unit.stable_id not in translated_ids:
            protected.update(i for i in _unit_glyph_indices(unit) if 0 <= i < len(original_params))

    required_existing: set[int] = set()
    for _row, _unit, target in translated_rows:
        for ch in _target_chars(target):
            idx = base_char_to_index.get(ch)
            if idx is not None and 0 <= idx < len(original_params):
                required_existing.add(idx)

    recyclable = [i for i in range(len(original_params))
                  if i not in protected and i not in required_existing]
    atlas = original_atlas.copy()
    params = list(original_params)
    char_to_index = dict(base_char_to_index)
    # Algunas fuentes DA etiquetadas a partir de transcripciones tienen el
    # punto final asociado a '!'. Si el sprite es sólo un punto, no lo uses
    # para una exclamación española: fuerza la creación del signo completo.
    bang_idx = char_to_index.get('!')
    if _da_glyph_is_dot_like(original_atlas, original_params, bang_idx):
        char_to_index.pop('!', None)
    added: dict[str, int] = {}
    synthesized: list[str] = []
    fallback: list[str] = []
    row_h = max((p[3] for p in params), default=24)
    bg = int(round(_mode_level(original_atlas)/17.0))*17
    da_glyph_bank = da_glyph_bank or {}

    needed=[]; seen=set(char_to_index)
    for _row,_unit,target in translated_rows:
        for typ,value in _text_tokens(target):
            if typ!='char' or value in (' ','\u3000') or value in seen:
                continue
            seen.add(value); needed.append(value)

    # Prepara todos los sprites antes de asignar slots. Los más anchos se colocan
    # primero para evitar que un glifo estrecho consuma accidentalmente el único
    # hueco grande disponible.
    prepared: list[tuple[int, str, Image.Image]] = []
    for order, ch in enumerate(needed):
        # Los signos invertidos y las letras españolas compuestas se generan
        # PRIMERO a partir del glifo base del atlas local. Esto es importante en DA:
        # un 'á' real tomado de otro atlas puede medir, por ejemplo, 15 px aunque la
        # 'a' local sólo mida 10 px y el bloque sólo disponga de slots de 10 px.
        # Componer el acento sobre la letra local conserva exactamente ese ancho.
        prefer_local_composition = ch in SPANISH_COMPOSE or ch in {'!', '¡', '¿'}
        if prefer_local_composition:
            glyph = _synthesize_spanish_glyph(
                ch, original_atlas, original_params, char_to_index, da_glyph_bank,
                row_h, font_path, prefer_index=block.jmb_index,
                allow_font_fallback=False,
            )
            if glyph is not None:
                synthesized.append(ch)
            else:
                # Sólo si no existe una base fiable local/global, prueba un sprite
                # ya existente de Killer7 para ese carácter exacto.
                glyph = _choose_bank_glyph(da_glyph_bank, ch, row_h, block.jmb_index)
                if glyph is not None:
                    glyph = _normalize_glyph(glyph, row_h)
        else:
            # Para caracteres ordinarios se conserva la prioridad histórica: sprite
            # real de Killer7 y, en segundo término, síntesis si está soportada.
            glyph = _choose_bank_glyph(da_glyph_bank, ch, row_h, block.jmb_index)
            if glyph is not None:
                glyph = _normalize_glyph(glyph, row_h)
            else:
                glyph = _synthesize_spanish_glyph(
                    ch, original_atlas, original_params, char_to_index, da_glyph_bank,
                    row_h, font_path, prefer_index=block.jmb_index,
                    allow_font_fallback=False,
                )
                if glyph is not None:
                    synthesized.append(ch)
        if glyph is None:
            raise K7Error(
                f'{block.id}: no existe un sprite original/base fiable para {ch!r}. '
                'No se usará una fuente externa en subtítulos DA.'
            )
        glyph = _normalize_glyph(glyph, row_h)
        glyph = _adapt_glyph_background(glyph, bg)
        glyph = glyph.point(lambda v: int(round(v/17.0))*17)
        # Muchos fParams incluyen columnas vacías de side-bearing. Quitarlas antes
        # de decidir si el glifo cabe evita falsos errores 18x24 vs 16x24.
        glyph = _trim_da_glyph_horizontal(glyph, bg, margin=1)
        prepared.append((order, ch, glyph))

    # Bin packing conservador: primero los glifos más anchos; para cada uno se usa
    # el slot válido más pequeño. Esto preserva los huecos grandes para quien los
    # necesite de verdad.
    prepared.sort(key=lambda item: (-item[2].width, item[0]))
    for _order, ch, glyph in prepared:
        fits = [i for i in recyclable
                if params[i][2] >= glyph.width and params[i][3] >= glyph.height]
        if not fits and recyclable:
            # Último recurso seguro: comprimir moderadamente el MISMO sprite de
            # Killer7 para el slot más ancho disponible. No cambia de tipografía.
            height_fits = [i for i in recyclable if params[i][3] >= glyph.height]
            if height_fits:
                widest = max(height_fits, key=lambda i: (params[i][2], -i))
                compact = _condense_da_glyph(glyph, params[widest][2], bg)
                if compact is not None:
                    glyph = compact
                    fits = [i for i in recyclable
                            if params[i][2] >= glyph.width and params[i][3] >= glyph.height]
        if not fits:
            biggest = max((params[i][2] for i in recyclable), default=0)
            raise K7Error(
                f'{block.id}: no hay un slot DA reciclable suficiente para {ch!r} '
                f'({glyph.width}x{glyph.height}; máximo libre {biggest}x{row_h}). '
                'El compilador ya probó recorte de margen y compresión moderada. '
                'Reduce el repertorio de caracteres de este .da.'
            )
        idx = min(fits, key=lambda i: (params[i][2]*params[i][3], params[i][2], i))
        recyclable.remove(idx)
        x, y, sw, sh = params[idx]
        # Remove old mapping for the recycled index.
        for old_ch, old_idx in list(char_to_index.items()):
            if old_idx == idx:
                char_to_index.pop(old_ch, None)
        # Clear only this physical slot, then paste the new sprite in place.
        ImageDraw.Draw(atlas).rectangle((x, y, x+sw-1, y+sh-1), fill=bg)
        atlas.paste(glyph, (x, y))
        params[idx] = (x, y, glyph.width, glyph.height)
        char_to_index[ch] = idx
        added[ch] = idx

    return atlas, params, char_to_index, added, fallback, synthesized

def _rebuild_da_container(original: bytes, dat: bytes, dic: bytes) -> bytes:
    """Reconstruye un DAR de 2 hijos conservando su cabecera y alineación 0x80."""
    if len(original) < 0x80 or original[:4] != b'DAR\0':
        raise K7Error('DAR original inválido al recompilar subtítulos.')
    align = 0x80
    off0 = 0x80
    off1 = (off0 + len(dat) + align - 1) & ~(align - 1)
    total = (off1 + len(dic) + align - 1) & ~(align - 1)
    out = bytearray(total)
    out[:0x80] = original[:0x80]
    struct.pack_into('<2I', out, 0x10, off0, off1)
    struct.pack_into('<2I', out, 0x30, len(dat), len(dic))
    out[off0:off0+len(dat)] = dat
    out[off1:off1+len(dic)] = dic
    return bytes(out)


def compile_da_block(project: Killer7Project, block: TextBlock, parsed_file: dict,
                     da_glyph_bank: dict | None = None,
                     font_path: str | None = None) -> CompiledDA | None:
    if block.storage_kind != 'afs_da':
        raise K7Error(f'{block.id}: no es un bloque de subtítulos .da.')
    meta = project.da_parts(block.jmb_index)
    original_atlas = project.decode_atlas(block)
    original_params = project.glyph_params(block)
    unit_map = {u.stable_id: u for u in block.units}

    rows = []
    for row in parsed_file['units']:
        source = row['source'].strip('\r\n')
        target = row['target'].strip('\r\n')
        if not target or target == source:
            continue
        unit = unit_map.get(row['id'])
        if unit is None:
            raise K7Error(f'{row["id"]}: unidad DA no encontrada.')
        rows.append((row, unit, target))
    if not rows:
        return None

    base_char_to_index = _existing_char_map(block, parsed_file)

    atlas, params, char_to_index, added, fallback_chars, synthesized_chars = _pack_da_glyphs_inplace(
        block, original_atlas, original_params, base_char_to_index, rows,
        da_glyph_bank=da_glyph_bank, font_path=font_path,
    )
    preserve_original_dic = not added

    # Cabecera + registros se conservan byte a byte, salvo glyph_count y char_data
    # de las líneas que el usuario ha traducido.
    dat = bytearray(meta['dat'][:meta['param_offset']])
    struct.pack_into('<H', dat, 2, len(params))
    translated: list[str] = []
    for row, unit, target in rows:
        codes = _encode_target(target, char_to_index, max_codes=DA_MAX_CODES)
        off = meta['record_offset'] + unit.sentence * DA_RECORD_SIZE + 8
        arr = codes + [-2]
        arr += [-1] * (DA_CODE_SLOTS - len(arr))
        if len(arr) != DA_CODE_SLOTS:
            raise K7Error(f'{row["id"]}: error interno al rellenar char_data DA.')
        struct.pack_into(f'<{DA_CODE_SLOTS}h', dat, off, *arr)
        translated.append(row['id'])
    dat.extend(b''.join(struct.pack('<4H', *p) for p in params))
    dic = meta['dic'] if preserve_original_dic else encode_da_ps2_atlas_into_dic(meta['dic'], atlas)
    rebuilt = _rebuild_da_container(meta['raw'], bytes(dat), dic)
    return CompiledDA(
        block, rebuilt, translated, added, params, atlas,
        fallback_chars, synthesized_chars,
    )


def _slot_size(project: Killer7Project, index: int) -> int:
    e = project.entries[index]
    if index + 1 < len(project.entries):
        return project.entries[index+1].offset - e.offset
    return e.size


def _identity_check(project: Killer7Project, parsed: dict):
    if not parsed['files']:
        raise K7Error('XLIFF vacío.')
    serials = []
    hashes = []
    for pf in parsed['files']:
        serials.extend(pf.get('notes', {}).get('killer7:serial', []))
        hashes.extend(x for x in pf.get('notes', {}).get('killer7:image_sha256', []) if x)
    serials = [x for x in serials if x and x != 'unknown']
    if serials and any(x != project.serial for x in serials):
        raise K7Error(f'El XLIFF no corresponde al serial {project.serial}.')
    if hashes:
        expected = hashes[0].lower()
        if any(x.lower() != expected for x in hashes):
            raise K7Error('El XLIFF contiene SHA-256 diferentes entre bloques.')
        actual = project.image_sha256().lower()
        if expected != actual:
            raise K7Error('El SHA-256 del XLIFF no coincide con la ISO seleccionada.')


def _compile_elf_strings(project: Killer7Project, block: TextBlock, parsed_file: dict, out: Path) -> tuple[list[dict], list[str]]:
    """Compila las cadenas ASCII de slot fijo del menú principal dentro de SLUS_211.54."""
    if block.jmb_index != TITLE_MENU_BLOCK_INDEX:
        raise K7Error(f'{block.id}: bloque ELF desconocido.')
    by_uid = {u.stable_id: u for u in block.units}
    records: list[dict] = []
    translated: list[str] = []
    iso_dir = out / 'iso'
    iso_dir.mkdir(exist_ok=True)
    for row in parsed_file['units']:
        source = row['source'].strip('\r\n')
        target = row['target'].strip('\r\n')
        if not target or target == source:
            continue
        unit = by_uid.get(row['id'])
        if unit is None:
            raise K7Error(f'{row["id"]}: unidad del menú no encontrada.')
        i = unit.sentence
        if not 0 <= i < len(TITLE_MENU_SPECS):
            raise K7Error(f'{row["id"]}: índice de cadena del menú inválido.')
        spec = TITLE_MENU_SPECS[i]
        try:
            encoded = target.encode('ascii')
        except UnicodeEncodeError as exc:
            raise K7Error(
                f'{row["id"]}: el menú usa titlefont.png y esta prueba sólo admite caracteres ASCII.'
            ) from exc
        slot = int(spec['slot'])
        if len(encoded) > slot - 1:
            raise K7Error(f'{row["id"]}: {len(encoded)} bytes > máximo {slot-1} del slot del ejecutable.')
        original = project.iso.read(project.exe_node, int(spec['offset']), slot)
        expected = str(spec['source']).encode('ascii')
        current_text = original.split(b'\0', 1)[0]
        # Para generar un parche reproducible exigimos la ISO inglesa original.
        if current_text != expected:
            raise K7Error(
                f'{row["id"]}: el slot del ejecutable contiene {current_text!r}; '
                f'se esperaba {expected!r}. Usa la ISO USA original sin parchear.'
            )
        payload = encoded + b'\0' * (slot - len(encoded))
        rel = f'iso/title_menu_{i:02d}.bin'
        (out / rel).write_bytes(payload)
        records.append({
            'kind': 'elf-string', 'unit_id': row['id'], 'key': spec['key'],
            'iso_path': project.exe_node.path, 'file_lba': project.exe_node.lba,
            'file_offset': int(spec['offset']), 'slot_size': slot,
            'source': spec['source'], 'target': target,
            'original_sha256': sha256_bytes(original),
            'new_sha256': sha256_bytes(payload), 'file': rel,
        })
        translated.append(row['id'])
    return records, translated



def _compile_iso_ascii(project: Killer7Project, block: TextBlock, parsed_file: dict, out: Path) -> tuple[list[dict], list[str]]:
    """Compila segmentos ASCII/SJIS fijos en SLUS o módulos ISO.

    v1.7.6.8 distingue tres casos que el escáner antiguo mezclaba:
    * claves internas del ELF (Save/Option/option), que nunca se parchean;
    * C-strings ASCII normales de slot fijo;
    * mensajes de Memory Card que contienen el carácter SJIS 81 A0 (□). Estos
      últimos se recomponen como una sola cadena lógica y sólo se rellenan al
      final, evitando espacios visibles antes del símbolo y su continuación.
    """
    by_uid = {u.stable_id: u for u in block.units}
    rows_by_offset: dict[int, tuple[dict, TextUnit]] = {}
    for row in parsed_file['units']:
        unit = by_uid.get(row['id'])
        if unit is not None:
            rows_by_offset[int(unit.binary_offset)] = (row, unit)

    records: list[dict] = []
    translated: list[str] = []
    iso_dir = out / 'iso'
    iso_dir.mkdir(exist_ok=True)
    node_cache = {}
    processed_ids: set[str] = set()

    def node_for(path: str):
        node = node_cache.get(path)
        if node is None:
            node = project.exe_node if path == project.exe_node.path or path == 'SLUS_211.54' else project.iso_node(path)
            node_cache[path] = node
        return node

    def encoded_text(row: dict, uid: str) -> bytes:
        source = row['source'].strip('\r\n')
        target = row['target'].strip('\r\n')
        text = target or source
        if '\n' in text or '\r' in text:
            raise K7Error(f'{uid}: una cadena binaria no admite saltos de línea.')
        if source.count('~') and text.count('~') != source.count('~'):
            raise K7Error(f'{uid}: debe conservarse el símbolo ~ (botón/control visual).')
        try:
            return text.encode('ascii')
        except UnicodeEncodeError as exc:
            raise K7Error(
                f'{uid}: este texto directo usa una fuente/tabla de bytes del juego; '
                'por seguridad esta versión sólo inyecta ASCII. Usa letras sin acentos en estos bloques.'
            ) from exc

    # Recompone las C-strings mixtas del menú de Memory Card. Sólo se aplica al
    # bloque del ejecutable donde están verificadas estas direcciones.
    if block.jmb_index == 9010:
        for start_off, spec in DIRECT_SJIS_COMPOSITES.items():
            parts = spec['parts']
            participant_rows: list[tuple[dict, TextUnit]] = []
            for part in parts:
                if isinstance(part, int):
                    item = rows_by_offset.get(part)
                    if item is None:
                        participant_rows = []
                        break
                    participant_rows.append(item)
            if not participant_rows:
                continue
            # Si ninguna unidad de la cadena tiene traducción efectiva no hace falta
            # generar un payload; la ISO original ya contiene la cadena correcta.
            if not any((r['target'].strip('\r\n') and r['target'].strip('\r\n') != r['source'].strip('\r\n'))
                       for r, _u in participant_rows):
                continue
            path = participant_rows[0][1].binary_path or block.storage_path
            if not path:
                raise K7Error(f'{participant_rows[0][0]["id"]}: ruta binaria ausente.')
            node = node_for(path)
            end_off = int(spec['end'])
            slot = end_off - int(start_off)
            original = project.iso.read(node, int(start_off), slot)

            expected = bytearray()
            payload = bytearray()
            participating_ids: list[str] = []
            for part in parts:
                if isinstance(part, bytes):
                    expected.extend(part)
                    payload.extend(part)
                    continue
                row, unit = rows_by_offset[part]
                participating_ids.append(row['id'])
                expected.extend(row['source'].strip('\r\n').encode('ascii'))
                payload.extend(encoded_text(row, row['id']))
            if not original.startswith(bytes(expected)):
                raise K7Error(
                    f'{participating_ids[0]}: la C-string SJIS original en {path}+0x{start_off:X} no coincide. '
                    'Usa la ISO USA original sin parchear.'
                )
            if len(payload) >= slot:
                raise K7Error(
                    f'{participating_ids[0]}: cadena Memory Card recompuesta de {len(payload)} bytes '
                    f'no cabe en el slot lógico de {slot-1} bytes.'
                )
            payload.extend(b'\0' * (slot - len(payload)))
            rel = f'iso/direct_{block.jmb_index:04d}_{start_off:08X}.bin'
            (out / rel).write_bytes(payload)
            changed_ids = [r['id'] for r, _u in participant_rows
                           if r['target'].strip('\r\n') and r['target'].strip('\r\n') != r['source'].strip('\r\n')]
            records.append({
                'kind': 'iso-ascii-mixed-sjis', 'unit_id': participating_ids[0],
                'unit_ids': participating_ids, 'iso_path': path, 'file_lba': node.lba,
                'file_offset': int(start_off), 'slot_size': slot, 'pad': 'nul-end',
                'source': bytes(expected).decode('cp932', 'replace'),
                'target': bytes(payload).split(b'\0', 1)[0].decode('cp932', 'replace'),
                'original_sha256': sha256_bytes(original),
                'new_sha256': sha256_bytes(bytes(payload)), 'file': rel,
            })
            translated.extend(changed_ids)
            processed_ids.update(participating_ids)

    for row in parsed_file['units']:
        source = row['source'].strip('\r\n')
        target = row['target'].strip('\r\n')
        unit = by_uid.get(row['id'])
        if unit is None:
            raise K7Error(f'{row["id"]}: unidad ASCII no encontrada en la ISO.')
        if row['id'] in processed_ids:
            continue
        # Estas claves son nombres de objeto/recurso verificados en el MIPS, no UI.
        # Se protegen incluso si un XLIFF antiguo contiene una traducción errónea.
        if block.storage_path == 'SLUS_211.54' and int(unit.binary_offset) in DIRECT_INTERNAL_KEYS:
            continue
        if not target or target == source:
            continue
        if '\n' in target or '\r' in target:
            raise K7Error(f'{row["id"]}: una cadena binaria no admite saltos de línea.')
        if source.count('~') and target.count('~') != source.count('~'):
            raise K7Error(f'{row["id"]}: debe conservarse el símbolo ~ (botón/control visual).')
        try:
            encoded = target.encode('ascii')
        except UnicodeEncodeError as exc:
            raise K7Error(
                f'{row["id"]}: este texto directo usa una fuente/tabla de bytes del juego; '
                'por seguridad esta versión sólo inyecta ASCII. Usa letras sin acentos en estos bloques.'
            ) from exc
        path = unit.binary_path or block.storage_path
        if not path:
            raise K7Error(f'{row["id"]}: ruta binaria ausente.')
        node = node_for(path)
        slot = int(unit.binary_slot)
        off = int(unit.binary_offset)
        pad = unit.binary_pad or 'nul'
        max_len = slot if pad == 'space' else slot - 1
        if len(encoded) > max_len:
            raise K7Error(f'{row["id"]}: {len(encoded)} bytes > máximo {max_len} del slot binario.')
        original = project.iso.read(node, off, slot)
        expected = source.encode('ascii')
        if not original.startswith(expected):
            raise K7Error(
                f'{row["id"]}: el texto original en {path}+0x{off:X} no coincide. '
                'Usa la ISO USA original sin parchear.'
            )
        if pad == 'space':
            # Los únicos fragmentos Shift-JIS conocidos del menú de Memory Card se
            # procesan arriba como C-strings lógicas. Este modo queda para controles
            # verdaderamente externos a la unidad en otros sistemas.
            payload = encoded.ljust(slot, b' ')
        else:
            payload = encoded + b'\0' * (slot - len(encoded))
        rel = f'iso/direct_{block.jmb_index:04d}_{unit.sentence:03d}.bin'
        (out / rel).write_bytes(payload)
        records.append({
            'kind': 'iso-ascii', 'unit_id': row['id'],
            'iso_path': path, 'file_lba': node.lba,
            'file_offset': off, 'slot_size': slot, 'pad': pad,
            'source': source, 'target': target,
            'original_sha256': sha256_bytes(original),
            'new_sha256': sha256_bytes(payload), 'file': rel,
        })
        translated.append(row['id'])
    return records, translated

def preflight_project(project: Killer7Project, xliff, font_path: str | None = None) -> dict:
    """Compila en seco todos los targets activos y acumula TODOS los errores.

    A diferencia de ``build_patch_directory`` no genera un parche y no se detiene
    en el primer bloque problemático. Está pensado para el control previo de los
    atlas DA: tamaño de slots, repertorio de glifos, controles y huecos AFS.
    """
    parsed = parse_project_xliff(xliff)
    issues = validate_project_xliff(parsed['root'], project.all_blocks)
    validation_errors = [x for x in issues if x[0] == 'ERR']
    report = {
        'ok': not validation_errors,
        'blocks_checked': 0,
        'translated_units': 0,
        'errors': [
            {'file_id': uid, 'kind': 'xliff', 'error': msg}
            for _sev, uid, msg in validation_errors
        ],
        'warnings': [
            {'unit_id': uid, 'message': msg}
            for sev, uid, msg in issues if sev == 'WARN'
        ],
        'blocks': [],
    }
    if validation_errors:
        report['ok'] = False
        return report

    blocks = _project_block_map(project)
    bank = _build_glyph_bank(project, parsed)
    da_bank = _build_da_glyph_bank(project, parsed)

    with tempfile.TemporaryDirectory(prefix='killer7_preflight_') as td:
        tmp = Path(td)
        for pf in parsed['files']:
            block = blocks.get(pf['file_id'])
            if block is None:
                continue
            active = [
                row for row in pf['units']
                if row['target'].strip('\r\n')
                and row['target'].strip('\r\n') != row['source'].strip('\r\n')
            ]
            if not active:
                continue
            report['blocks_checked'] += 1
            try:
                detail = {
                    'file_id': block.id,
                    'kind': block.storage_kind,
                    'translated_units': 0,
                    'synthesized_chars': [],
                    'fallback_chars': [],
                }
                if block.storage_kind == 'elf_strings':
                    _recs, translated = _compile_elf_strings(project, block, pf, tmp)
                    detail['translated_units'] = len(translated)
                elif block.storage_kind == 'iso_ascii':
                    _recs, translated = _compile_iso_ascii(project, block, pf, tmp)
                    detail['translated_units'] = len(translated)
                elif block.storage_kind == 'afs_k7p2':
                    compiled = compile_k7p2_block(project, block, pf)
                    if compiled is None:
                        continue
                    for index, kind, data in (
                        (block.jmb_index, 'k7p2', compiled.primary),
                        (block.dic_index, 'k7p2-dar-mirror', compiled.mirror_dar),
                    ):
                        slot = _slot_size(project, index)
                        if len(data) > slot:
                            raise K7Error(
                                f'AFS#{index:04d} {kind}: {len(data)} bytes > hueco fijo {slot}.'
                            )
                    detail['translated_units'] = len(compiled.translated_units)
                    detail['new_size'] = len(compiled.primary)
                    detail['mirror_size'] = len(compiled.mirror_dar)
                elif block.storage_kind == 'afs_da':
                    compiled = compile_da_block(project, block, pf, da_bank, font_path)
                    if compiled is None:
                        continue
                    slot = _slot_size(project, block.jmb_index)
                    if len(compiled.data) > slot:
                        raise K7Error(
                            f'AFS#{block.jmb_index:04d} subtítulos DA: {len(compiled.data)} bytes > '
                            f'hueco fijo {slot}.'
                        )
                    detail['translated_units'] = len(compiled.translated_units)
                    detail['synthesized_chars'] = compiled.synthesized_chars
                    detail['fallback_chars'] = compiled.fallback_chars
                    detail['new_size'] = len(compiled.data)
                    detail['slot_size'] = slot
                elif block.storage_kind == 'afs_graphic_ref':
                    compiled = compile_graphic_block(project, block, pf, font_path)
                    if compiled is None:
                        continue
                    slot = _slot_size(project, block.dic_index)
                    if len(compiled.data) > slot:
                        raise K7Error(
                            f'AFS#{block.dic_index:04d} DIC gráfico: {len(compiled.data)} bytes > '
                            f'hueco fijo {slot}.'
                        )
                    detail['translated_units'] = len(compiled.translated_units)
                    detail['new_size'] = len(compiled.data)
                    detail['slot_size'] = slot
                else:
                    compiled = compile_block(project, block, pf, bank, font_path)
                    if compiled is None:
                        continue
                    for index, kind, data in (
                        (block.jmb_index, 'jmb', compiled.jmb),
                        (block.dic_index, 'dic', compiled.dic),
                    ):
                        slot = _slot_size(project, index)
                        if len(data) > slot:
                            raise K7Error(
                                f'AFS#{index:04d} {kind}: {len(data)} bytes > hueco fijo {slot}.'
                            )
                    detail['translated_units'] = len(compiled.translated_units)
                    detail['synthesized_chars'] = compiled.synthesized_chars
                    detail['fallback_chars'] = compiled.fallback_chars
                report['translated_units'] += detail['translated_units']
                report['blocks'].append(detail)
            except Exception as exc:
                report['errors'].append({
                    'file_id': block.id,
                    'kind': block.storage_kind,
                    'error': str(exc),
                })

    report['ok'] = not report['errors']
    return report


def build_patch_directory(project: Killer7Project, xliff, output_dir: str | Path, font_path: str | None = None) -> dict:
    parsed = parse_project_xliff(xliff)
    _identity_check(project, parsed)
    issues = validate_project_xliff(parsed['root'], project.all_blocks)
    errors = [x for x in issues if x[0] == 'ERR']
    if errors:
        raise K7Error('XLIFF inválido:\n' + '\n'.join(f'{u}: {m}' for _s,u,m in errors[:20]))

    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    entries_dir = out / 'entries'
    preview_dir = out / 'preview'
    entries_dir.mkdir(exist_ok=True)
    preview_dir.mkdir(exist_ok=True)

    blocks = _project_block_map(project)
    bank = _build_glyph_bank(project, parsed)
    da_bank = _build_da_glyph_bank(project, parsed)
    manifest = {
        'format': PATCH_FORMAT,
        'version': PATCH_VERSION,
        'serial': project.serial,
        'image_name': project.iso_path.name,
        'image_size': project.iso_path.stat().st_size,
        'image_sha256': project.image_sha256(),
        'afs_path': 'D_US/DIR.AFS',
        'afs_lba': project.afs_node.lba,
        'fallback_font': (Path(font_path).name if font_path else None),
        'translated_units': 0,
        'blocks': [],
        'entries': [],
        'iso_patches': [],
    }

    for pf in parsed['files']:
        block = blocks.get(pf['file_id'])
        if block is None:
            continue
        if block.storage_kind == 'elf_strings':
            recs, translated = _compile_elf_strings(project, block, pf, out)
            manifest['iso_patches'].extend(recs)
            manifest['translated_units'] += len(translated)
            continue
        if block.storage_kind == 'iso_ascii':
            recs, translated = _compile_iso_ascii(project, block, pf, out)
            manifest['iso_patches'].extend(recs)
            manifest['translated_units'] += len(translated)
            continue
        if block.storage_kind == 'afs_k7p2':
            compiled_k7 = compile_k7p2_block(project, block, pf)
            if compiled_k7 is None:
                continue
            block_rec = {
                'file_id': block.id, 'jmb_index': block.jmb_index,
                'dic_index': block.dic_index, 'name': block.name,
                'kind': 'scenario-k7p2',
                'translated_units': compiled_k7.translated_units,
                'added_glyphs': {}, 'fallback_chars': [], 'synthesized_chars': [],
            }
            manifest['blocks'].append(block_rec)
            manifest['translated_units'] += len(compiled_k7.translated_units)
            for index, kind, data in (
                (block.jmb_index, 'scenario-k7p2', compiled_k7.primary),
                (block.dic_index, 'scenario-k7p2-dar', compiled_k7.mirror_dar),
            ):
                original = project.entry_bytes(index)
                slot = _slot_size(project, index)
                if len(data) > slot:
                    raise K7Error(
                        f'AFS#{index:04d} {kind}: {len(data)} bytes > hueco fijo {slot}.'
                    )
                rel = f'entries/{index:04d}_{kind}.bin'
                (out / rel).write_bytes(data)
                manifest['entries'].append({
                    'index': index, 'kind': kind, 'name': project.entries[index].name,
                    'offset': project.entries[index].offset, 'slot_size': slot,
                    'original_size': len(original), 'new_size': len(data),
                    'original_sha256': sha256_bytes(original),
                    'new_sha256': sha256_bytes(data), 'file': rel,
                })
            continue
        if block.storage_kind == 'afs_da':
            compiled_da = compile_da_block(project, block, pf, da_bank, font_path)
            if compiled_da is None:
                continue
            index = block.jmb_index
            original = project.entry_bytes(index)
            slot = _slot_size(project, index)
            if len(compiled_da.data) > slot:
                raise K7Error(
                    f'AFS#{index:04d} subtítulos DA: {len(compiled_da.data)} bytes > '
                    f'hueco fijo {slot}. Traduce más líneas del mismo .da para reciclar '
                    'glifos o reduce el repertorio de caracteres.'
                )
            rel = f'entries/{index:04d}_subtitle_da.bin'
            (out / rel).write_bytes(compiled_da.data)
            manifest['entries'].append({
                'index': index, 'kind': 'subtitle-da', 'name': project.entries[index].name,
                'offset': project.entries[index].offset, 'slot_size': slot,
                'original_size': len(original), 'new_size': len(compiled_da.data),
                'original_sha256': sha256_bytes(original),
                'new_sha256': sha256_bytes(compiled_da.data), 'file': rel,
            })
            manifest['blocks'].append({
                'file_id': block.id, 'jmb_index': index, 'dic_index': index,
                'name': block.name, 'kind': 'subtitle-da',
                'translated_units': compiled_da.translated_units,
                'added_glyphs': compiled_da.added_glyphs,
                'fallback_chars': compiled_da.fallback_chars,
                'synthesized_chars': compiled_da.synthesized_chars,
            })
            manifest['translated_units'] += len(compiled_da.translated_units)
            row_map = _file_unit_map(pf)
            cmap = {**_existing_char_map(block, pf), **compiled_da.added_glyphs}
            # Los índices reciclados pueden sustituir mappings antiguos; para la vista
            # previa basta con usar la tabla final devuelta por los targets recompilados.
            for uid in compiled_da.translated_units:
                row = row_map[uid]
                try:
                    codes = _encode_target(row['target'], cmap, max_codes=DA_MAX_CODES)
                    im = _render_codes(compiled_da.atlas, compiled_da.params, codes, scale=3)
                    im.save(preview_dir / f'{uid}.png')
                except Exception:
                    pass
            continue
        if block.storage_kind == 'afs_graphic_ref':
            compiled_graphic = compile_graphic_block(project, block, pf, font_path)
            if compiled_graphic is None:
                continue
            index = block.dic_index
            original = project.entry_bytes(index)
            slot = _slot_size(project, index)
            if len(compiled_graphic.data) > slot:
                raise K7Error(
                    f'AFS#{index:04d} DIC gráfico: {len(compiled_graphic.data)} bytes > '
                    f'hueco fijo {slot}.'
                )
            rel = f'entries/{index:04d}_graphic_dic.bin'
            (out / rel).write_bytes(compiled_graphic.data)
            manifest['entries'].append({
                'index': index, 'kind': 'graphic-dic', 'name': project.entries[index].name,
                'offset': project.entries[index].offset, 'slot_size': slot,
                'original_size': len(original), 'new_size': len(compiled_graphic.data),
                'original_sha256': sha256_bytes(original),
                'new_sha256': sha256_bytes(compiled_graphic.data), 'file': rel,
            })
            manifest['blocks'].append({
                'file_id': block.id, 'jmb_index': block.jmb_index, 'dic_index': index,
                'name': block.name, 'kind': 'graphic-dic',
                'translated_units': compiled_graphic.translated_units,
                'added_glyphs': {}, 'fallback_chars': [], 'synthesized_chars': [],
            })
            manifest['translated_units'] += len(compiled_graphic.translated_units)
            compiled_graphic.atlas.save(preview_dir / f'{block.id}_graphic.png')
            continue
        compiled = compile_block(project, block, pf, bank, font_path)
        if compiled is None:
            continue
        block_rec = {
            'file_id': block.id,
            'jmb_index': block.jmb_index,
            'dic_index': block.dic_index,
            'name': block.name,
            'translated_units': compiled.translated_units,
            'added_glyphs': compiled.added_glyphs,
            'fallback_chars': compiled.fallback_chars,
            'synthesized_chars': compiled.synthesized_chars,
        }
        manifest['blocks'].append(block_rec)
        manifest['translated_units'] += len(compiled.translated_units)

        for index, kind, data in (
            (block.jmb_index, 'jmb', compiled.jmb),
            (block.dic_index, 'dic', compiled.dic),
        ):
            original = project.entry_bytes(index)
            slot = _slot_size(project, index)
            if len(data) > slot:
                raise K7Error(
                    f'AFS#{index:04d} {kind}: {len(data)} bytes > hueco fijo {slot}. '
                    'Este bloque requeriría reconstruir el AFS.'
                )
            rel = f'entries/{index:04d}_{kind}.bin'
            (out / rel).write_bytes(data)
            manifest['entries'].append({
                'index': index,
                'kind': kind,
                'name': project.entries[index].name,
                'offset': project.entries[index].offset,
                'slot_size': slot,
                'original_size': len(original),
                'new_size': len(data),
                'original_sha256': sha256_bytes(original),
                'new_sha256': sha256_bytes(data),
                'file': rel,
            })

        row_map = _file_unit_map(pf)
        expected = {u.stable_id: u for u in block.units}
        for uid in compiled.translated_units:
            row = row_map[uid]
            codes = _encode_target(row['target'], {
                **_existing_char_map(block, pf), **compiled.added_glyphs,
            })
            im = _render_codes(compiled.atlas, compiled.params, codes, scale=3)
            im.save(preview_dir / f'{uid}.png')

    if not manifest['blocks'] and not manifest['iso_patches']:
        raise K7Error('No hay targets traducidos que compilar.')

    (out / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    (out / 'README.txt').write_text(
        'Killer7 PS2 XLIFF compiled patch\n\n'
        'Este paquete contiene reemplazos de entradas AFS y/o cadenas directas de archivos de la ISO, no una ISO.\n'
        'Se debe aplicar únicamente a la ISO cuyo serial y SHA-256 figuran en manifest.json.\n'
        'El aplicador siempre crea una copia nueva y nunca modifica la ISO de origen.\n',
        encoding='utf-8'
    )
    return manifest


def build_patch_zip(project: Killer7Project, xliff, output_zip: str | Path, font_path: str | None = None) -> dict:
    output_zip = Path(output_zip)
    output_zip.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix='k7patch_') as td:
        manifest = build_patch_directory(project, xliff, td, font_path)
        with zipfile.ZipFile(output_zip, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
            base = Path(td)
            for p in sorted(base.rglob('*')):
                if p.is_file():
                    z.write(p, p.relative_to(base).as_posix())
    return manifest


def _experimental_option_ps2_layout(dic: bytes) -> dict:
    """Describe el layout GS real de la primera textura de option.dat.

    Evidencia confirmada con savestate PCSX2: el DIC ordena una transferencia de
    64x64 PSMCT16 y la fuente la consume como 128x128 PSMT4. No debe tratarse el
    payload como una matriz PSMT4 ya swizzleada: hay que reproducir la escritura
    CT16 en VRAM y luego leer/escribir la misma memoria con direccionamiento T4.
    """
    if len(dic) < 0x2200:
        raise K7Error('Prueba ESTÉREO: DIC de option.dat demasiado corto.')
    name_len = struct.unpack_from('<I', dic, 0x40)[0]
    shift = int(name_len) - 8
    if not (-0x20 <= shift <= 0x100):
        raise K7Error(f'Prueba ESTÉREO: shift DIC option inesperado: {shift}.')
    try:
        width, height, bpp = struct.unpack_from('<III', dic, 0x78 + shift)
        trxreg = struct.unpack_from('<Q', dic, 0xE4 + shift)[0]
        image_tag = struct.unpack_from('<Q', dic, 0x104 + shift)[0]
    except struct.error as exc:
        raise K7Error('Prueba ESTÉREO: cabecera DIC option truncada.') from exc
    if (width, height, bpp) != (128, 128, 4):
        raise K7Error(
            f'Prueba ESTÉREO: textura option inesperada: {width}x{height}, {bpp}bpp.'
        )
    rrw = int(trxreg & 0xFFF)
    rrh = int((trxreg >> 32) & 0xFFF)
    if (rrw, rrh) != (64, 64):
        raise K7Error(f'Prueba ESTÉREO: TRXREG option inesperado: {rrw}x{rrh}.')
    nloop = int(image_tag & 0x7FFF)
    payload_size = nloop * 16
    if payload_size != width * height // 2 or payload_size != rrw * rrh * 2:
        raise K7Error(
            f'Prueba ESTÉREO: payload option inconsistente: {payload_size} bytes.'
        )
    # El IMAGE GIFtag ocupa 16 bytes desde 0x104; por tanto el payload empieza
    # en 0x114. El antiguo 0x110 incluía 4 bytes del propio tag y era el origen
    # de la É fragmentada observada en el juego.
    pixel_off = 0x114 + shift
    if pixel_off < 0 or pixel_off + payload_size > len(dic):
        raise K7Error('Prueba ESTÉREO: payload gráfico option fuera de rango.')
    dbw = rrw // 64
    if dbw <= 0:
        raise K7Error('Prueba ESTÉREO: DBW option inválido.')
    return {
        'width': width, 'height': height, 'bpp': bpp,
        'rrw': rrw, 'rrh': rrh, 'dbw': dbw,
        'pixel_off': pixel_off, 'payload_size': payload_size,
    }


def _decode_experimental_option_atlas(dic: bytes) -> tuple[Image.Image, dict]:
    layout = _experimental_option_ps2_layout(dic)
    width, height = layout['width'], layout['height']
    po, ps = layout['pixel_off'], layout['payload_size']
    payload = dic[po:po + ps]
    vram = bytearray(4 * 1024 * 1024)
    _da_write_ct16(vram, layout['dbw'], layout['rrw'], layout['rrh'], payload)
    if _da_read_ct16(vram, layout['dbw'], layout['rrw'], layout['rrh']) != payload:
        raise K7Error('Prueba ESTÉREO: la transferencia PSMCT16 option no hace round-trip.')
    px = _da_read_t4(vram, width, height)
    atlas = Image.new('L', (width, height))
    atlas.putdata([v * 17 for v in px])
    return atlas, layout


def _encode_experimental_option_atlas(dic: bytes, atlas: Image.Image, layout: dict) -> bytes:
    """Reescribe option.dat con el mismo alias PSMCT16 -> PSMT4 que usa el GS.

    Sólo toca los píxeles lógicos cuyo valor cambia; el resto del DIC y del payload
    permanece byte por byte. Después reconstruye una VRAM de control y comprueba
    que el PSMT4 visible por el GS coincide exactamente con el atlas solicitado.
    """
    width, height = layout['width'], layout['height']
    if atlas.size != (width, height):
        raise K7Error(f'Prueba ESTÉREO: atlas option {atlas.size} != {(width, height)}.')
    po, ps = layout['pixel_off'], layout['payload_size']
    original_payload = dic[po:po + ps]
    vram = bytearray(4 * 1024 * 1024)
    _da_write_ct16(vram, layout['dbw'], layout['rrw'], layout['rrh'], original_payload)
    original_px = _da_read_t4(vram, width, height)
    target_px = bytearray(
        max(0, min(15, int(round(v / 17.0))))
        for v in atlas.convert('L').getdata()
    )
    for i, (old, new) in enumerate(zip(original_px, target_px)):
        if old != new:
            _da_write_t4(vram, width, i % width, i // width, new)
    new_payload = _da_read_ct16(vram, layout['dbw'], layout['rrw'], layout['rrh'])

    check = bytearray(4 * 1024 * 1024)
    _da_write_ct16(check, layout['dbw'], layout['rrw'], layout['rrh'], new_payload)
    if _da_read_t4(check, width, height) != target_px:
        raise K7Error('Prueba ESTÉREO: la É no supera la verificación GS PSMT4.')

    out = bytearray(dic)
    out[po:po + ps] = new_payload
    return bytes(out)


def _build_experimental_option_font(original: bytes) -> tuple[bytes, dict]:
    """Reutiliza el glifo 'j' de option.dat como É con el layout REAL del GS.

    La v1.7.7.4 reutilizaba correctamente el registro j, pero construía su bitmap
    con el decodificador DIC genérico. El savestate demuestra que option.dat usa
    el alias PSMCT16->PSMT4: al decodificarlo correctamente la E original aparece
    limpia y el glifo defectuoso queda aislado exactamente en la casilla j.
    """
    raw = bytearray(original)
    if len(raw) < 0x100 or raw[:4] != b'DAR\0':
        raise K7Error('Prueba ESTÉREO: option.dat no es el DAR esperado.')
    child_count = struct.unpack_from('<I', raw, 8)[0]
    if child_count != 2:
        raise K7Error(f'Prueba ESTÉREO: option.dat tiene {child_count} hijos; se esperaban 2.')
    offsets = struct.unpack_from('<2I', raw, 0x10)
    sizes = list(struct.unpack_from('<2I', raw, 0x30))
    o_dic, o_ihe = offsets
    s_dic, s_ihe = sizes
    if any(o < 0x80 or sz <= 0 or o + sz > len(raw) for o, sz in zip(offsets, sizes)):
        raise K7Error('Prueba ESTÉREO: layout DAR de option.dat fuera de rango.')

    dic = bytes(raw[o_dic:o_dic + s_dic])
    ihe = bytearray(raw[o_ihe:o_ihe + s_ihe])
    if len(ihe) < 32 or ihe[:8] != b'STRIMAGE':
        raise K7Error('Prueba ESTÉREO: el segundo hijo de option.dat no es STRIMAGE.')
    glyph_count = struct.unpack_from('<I', ihe, 0x18)[0]
    if len(ihe) != 32 + glyph_count * 20:
        raise K7Error('Prueba ESTÉREO: tamaño de tabla STRIMAGE no reconocido.')

    entries = [struct.unpack_from('<10H', ihe, 32 + i * 20) for i in range(glyph_count)]
    codes = [row[0] for row in entries]
    expected_codes = (
        list(range(ord('A'), ord('Z') + 1))
        + list(range(ord('a'), ord('z') + 1))
        + [ord('.'), ord(' ')]
    )
    if glyph_count != 54 or codes != expected_codes:
        raise K7Error('Prueba ESTÉREO: repertorio de option.dat distinto del verificado (54 glifos).')

    e_index = ord('E') - ord('A')
    j_index = 26 + (ord('j') - ord('a'))
    e = entries[e_index]
    j = entries[j_index]
    _ecode, ex, ey, ew, eh, exoff, eyoff, eadvance, epage, _edup = e
    if (_ecode, ex, ey, ew, eh, exoff, eyoff, eadvance, epage) != (
        ord('E'), 36, 0, 9, 21, 0, 2, 10, 1
    ):
        raise K7Error(f'Prueba ESTÉREO: métricas de E no coinciden: {e}.')
    _jcode, jx, jy, jw, jh, jxoff, jyoff, jadvance, jpage, _jdup = j
    if j != (ord('j'), 13, 75, 9, 25, 0, 2, 10, 1, ord('j')):
        raise K7Error('Prueba ESTÉREO: el glifo j ya no coincide con el slot original verificado.')

    atlas, layout = _decode_experimental_option_atlas(dic)
    bg = int(round(_mode_level(atlas) / 17.0)) * 17

    # É de 9x23: dos filas para el agudo + la E original 9x21. Con yoff=0,
    # la E empieza internamente en y=2, exactamente la misma posición visual que
    # la E original (yoff=2). La casilla física j sigue siendo 9x25; las dos filas
    # inferiores se limpian y no son muestreadas por la nueva métrica h=23.
    glyph = Image.new('L', (jw, jh), bg)
    e_bitmap = atlas.crop((ex, ey, ex + ew, ey + eh))
    glyph.paste(e_bitmap, (0, 2))
    px = glyph.load()
    for gx, gy, level in (
        (6, 0, 255), (5, 0, 153),
        (5, 1, 255), (4, 1, 153),
    ):
        px[gx, gy] = level

    ImageDraw.Draw(atlas).rectangle((jx, jy, jx + jw - 1, jy + jh - 1), fill=bg)
    atlas.paste(glyph, (jx, jy))
    patched_dic = _encode_experimental_option_atlas(dic, atlas, layout)

    # Verificación independiente usando de nuevo el camino GS correcto.
    decoded, _ = _decode_experimental_option_atlas(patched_dic)
    expected_visible = glyph.crop((0, 0, jw, 23))
    actual_visible = decoded.crop((jx, jy, jx + jw, jy + 23))
    if list(actual_visible.getdata()) != list(expected_visible.getdata()):
        raise K7Error('Prueba ESTÉREO: el glifo É no supera el round-trip GS real.')
    raw[o_dic:o_dic + s_dic] = patched_dic

    new_j = struct.pack(
        '<10H', ord('j'), jx, jy, jw, 23,
        0, 0, 10, 1, ord('j'),
    )
    ihe[32 + j_index * 20:32 + (j_index + 1) * 20] = new_j
    raw[o_ihe:o_ihe + s_ihe] = ihe

    return bytes(raw), {
        'font': EXPERIMENTAL_OPTION_FONT_NAME,
        'code': ord('j'),
        'glyph_count_before': glyph_count,
        'glyph_count_after': glyph_count,
        'reused_glyph': 'j',
        'glyph_rect': [jx, jy, jw, 23],
        'storage_rect': [jx, jy, jw, jh],
        'yoff': 0,
        'gs_upload': f"{layout['rrw']}x{layout['rrh']} PSMCT16",
        'gs_texture': f"{layout['width']}x{layout['height']} PSMT4",
        'pixel_offset': layout['pixel_off'],
        'dar_child_size_before': s_ihe,
        'dar_child_size_after': s_ihe,
    }

def apply_experimental_menu_accent_to_patch(project: Killer7Project, patch_zip: str | Path) -> dict:
    """Activa la prueba ESTÉREO del botón «Nueva Prueba».

    El flujo estable se compila primero sin cambios. Después:
      1) el slot STEREO se cambia de ESTEREO a ESTjREO (8 bytes exactos), y
      2) option.dat reutiliza el glifo 'j' como É dentro de su rectángulo original.

    La sustitución sólo afecta a la fuente de la pantalla de opciones; 'j' se
    reutiliza únicamente en option.dat y el XLIFF maestro sigue usando ESTEREO.
    El bitmap se reescribe reproduciendo el alias PSMCT16->PSMT4 real del GS.
    """
    patch_zip = Path(patch_zip)
    tmp_zip = patch_zip.with_name(patch_zip.name + '.accent-font-test.tmp')
    if tmp_zip.exists():
        tmp_zip.unlink()

    option_matches = [e for e in project.entries if e.name.lower() == EXPERIMENTAL_OPTION_FONT_NAME]
    if len(option_matches) != 1:
        raise K7Error(
            f'Prueba ESTÉREO: se esperaba una única entrada {EXPERIMENTAL_OPTION_FONT_NAME}; '
            f'se encontraron {len(option_matches)}.'
        )
    option_entry = option_matches[0]
    option_index = int(option_entry.index)
    original_option = project.entry_bytes(option_index)

    with zipfile.ZipFile(patch_zip, 'r') as src:
        manifest = json.loads(src.read('manifest.json').decode('utf-8'))
        matches = [
            rec for rec in manifest.get('iso_patches', [])
            if rec.get('unit_id') == EXPERIMENTAL_STEREO_UNIT
        ]
        if len(matches) != 1:
            raise K7Error(
                f'Prueba ESTÉREO: se esperaba un único payload {EXPERIMENTAL_STEREO_UNIT}; '
                f'se encontraron {len(matches)}.'
            )
        rec = matches[0]
        if (rec.get('iso_path') != 'SLUS_211.54' or
                int(rec.get('file_offset', -1)) != EXPERIMENTAL_STEREO_OFFSET or
                int(rec.get('slot_size', -1)) != len(EXPERIMENTAL_STEREO_PAYLOAD) or
                rec.get('source') != 'STEREO'):
            raise K7Error('Prueba ESTÉREO: la unidad ya no coincide con el slot verificado de SLUS_211.54.')

        payload_name = rec.get('file')
        if not payload_name:
            raise K7Error('Prueba ESTÉREO: el manifiesto no contiene el payload de la unidad.')
        stable_payload = src.read(payload_name)
        if stable_payload != b'ESTEREO\x00':
            raise K7Error(
                'Prueba ESTÉREO: el parche estable no contiene ESTEREO en el slot esperado; '
                'se cancela para no alterar otra traducción.'
            )

        # Si el parche estable ya toca option.dat, construir encima de ese payload;
        # de lo contrario partir exactamente del recurso original de la ISO.
        option_recs = [r for r in manifest.get('entries', []) if int(r.get('index', -1)) == option_index]
        if len(option_recs) > 1:
            raise K7Error('Prueba ESTÉREO: option.dat aparece duplicado en el parche estable.')
        if option_recs:
            option_rec = option_recs[0]
            option_payload_name = option_rec.get('file')
            if not option_payload_name:
                raise K7Error('Prueba ESTÉREO: payload AFS de option.dat sin archivo.')
            option_base = src.read(option_payload_name)
        else:
            option_payload_name = f'entries/{option_index:04d}_experimental_option_font.bin'
            option_base = original_option
            option_rec = {
                'index': option_index,
                'kind': 'experimental-option-font',
                'name': option_entry.name,
                'offset': option_entry.offset,
                'slot_size': _slot_size(project, option_index),
                'original_size': len(original_option),
                'new_size': len(original_option),
                'original_sha256': sha256_bytes(original_option),
                'new_sha256': '',
                'file': option_payload_name,
            }
            manifest.setdefault('entries', []).append(option_rec)

        patched_option, font_info = _build_experimental_option_font(option_base)
        if len(patched_option) != len(option_base):
            raise K7Error('Prueba ESTÉREO: option.dat cambió de tamaño total inesperadamente.')

        rec['target'] = 'ESTÉREO'
        rec['new_sha256'] = sha256_bytes(EXPERIMENTAL_STEREO_PAYLOAD)
        rec['experimental'] = True
        rec['experimental_encoding'] = 'option-font reuse: ASCII j (0x6A) => É'
        option_rec['new_size'] = len(patched_option)
        option_rec['new_sha256'] = sha256_bytes(patched_option)
        option_rec['experimental'] = True

        manifest.setdefault('experimental_tests', []).append({
            'name': 'menu-stereo-accent-option-font',
            'unit_id': EXPERIMENTAL_STEREO_UNIT,
            'iso_path': 'SLUS_211.54',
            'file_offset': EXPERIMENTAL_STEREO_OFFSET,
            'text': 'ESTÉREO',
            'payload_hex': EXPERIMENTAL_STEREO_PAYLOAD.hex().upper(),
            'font_afs_index': option_index,
            'font_resource': option_entry.name,
            'font_code': '0x6A (j)',
            'font_info': font_info,
            'note': (
                'Se reutiliza el glifo j ya existente de option.dat: no aumenta la tabla, no se '
                'usa padding nuevo y el bitmap queda en una región del atlas ya utilizada por el juego.'
            ),
        })
        manifest_bytes = (json.dumps(manifest, ensure_ascii=False, indent=2) + '\n').encode('utf-8')

        with zipfile.ZipFile(tmp_zip, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as dst:
            written = set()
            for info in src.infolist():
                if info.filename == 'manifest.json':
                    data = manifest_bytes
                elif info.filename == payload_name:
                    data = EXPERIMENTAL_STEREO_PAYLOAD
                elif info.filename == option_payload_name:
                    data = patched_option
                else:
                    data = src.read(info.filename)
                dst.writestr(info, data)
                written.add(info.filename)
            if option_payload_name not in written:
                dst.writestr(option_payload_name, patched_option)

    tmp_zip.replace(patch_zip)
    return {
        'unit_id': EXPERIMENTAL_STEREO_UNIT,
        'offset': EXPERIMENTAL_STEREO_OFFSET,
        'text': 'ESTÉREO',
        'payload_hex': EXPERIMENTAL_STEREO_PAYLOAD.hex().upper(),
        'font_afs_index': option_index,
        'font_resource': option_entry.name,
        'font_code': '0x6A (j → É)',
        'glyph_count': '54 → 54 (reutiliza j)',
    }


def read_patch_manifest(patch_zip: str | Path) -> dict:
    with zipfile.ZipFile(patch_zip, 'r') as z:
        return json.loads(z.read('manifest.json').decode('utf-8'))


def verify_patch_for_iso(project: Killer7Project, patch_zip: str | Path, deep_hash: bool = True) -> list[str]:
    problems = []
    with zipfile.ZipFile(patch_zip, 'r') as z:
        manifest = json.loads(z.read('manifest.json').decode('utf-8'))
        if manifest.get('format') != PATCH_FORMAT:
            problems.append('Formato de parche desconocido.')
        if manifest.get('serial') != project.serial:
            problems.append(f"Serial {manifest.get('serial')} != {project.serial}.")
        if manifest.get('image_size') != project.iso_path.stat().st_size:
            problems.append('Tamaño de ISO distinto.')
        if deep_hash and manifest.get('image_sha256') != project.image_sha256():
            problems.append('SHA-256 de ISO distinto.')
        for rec in manifest.get('entries', []):
            idx = int(rec['index'])
            if not (0 <= idx < len(project.entries)):
                problems.append(f'Entrada AFS #{idx} fuera de rango.')
                continue
            original = project.entry_bytes(idx)
            if sha256_bytes(original) != rec.get('original_sha256'):
                problems.append(f'Entrada AFS #{idx:04d}: hash original distinto.')
            data = z.read(rec['file'])
            if sha256_bytes(data) != rec.get('new_sha256'):
                problems.append(f'Entrada AFS #{idx:04d}: payload del parche corrupto.')
            if len(data) > _slot_size(project, idx):
                problems.append(f'Entrada AFS #{idx:04d}: no cabe en su hueco fijo.')
        for rec in manifest.get('iso_patches', []):
            slot = int(rec['slot_size'])
            off = int(rec['file_offset'])
            path = rec.get('iso_path') or project.exe_node.path
            try:
                node = project.exe_node if path == project.exe_node.path or path == 'SLUS_211.54' else project.iso_node(path)
            except Exception:
                problems.append(f"{rec.get('unit_id','ISO')}: archivo ISO no encontrado: {path}.")
                continue
            if off < 0 or off + slot > node.size:
                problems.append(f"{rec.get('unit_id','ISO')}: slot fuera de {path}.")
                continue
            current = project.iso.read(node, off, slot)
            if sha256_bytes(current) != rec.get('original_sha256'):
                problems.append(f"{rec.get('unit_id','ISO')}: hash original de {path} distinto.")
            payload = z.read(rec['file'])
            if len(payload) != slot:
                problems.append(f"{rec.get('unit_id','ISO')}: payload de tamaño incorrecto.")
            if sha256_bytes(payload) != rec.get('new_sha256'):
                problems.append(f"{rec.get('unit_id','ISO')}: payload binario corrupto.")
    return problems


def apply_patch_to_iso(source_iso: str | Path, patch_zip: str | Path, output_iso: str | Path, verify_hash: bool = True) -> dict:
    source_iso = Path(source_iso).resolve()
    output_iso = Path(output_iso).resolve()
    if source_iso == output_iso:
        raise K7Error('Por seguridad, la ISO de salida debe ser un archivo distinto de la ISO original.')
    project = Killer7Project(source_iso)
    try:
        problems = verify_patch_for_iso(project, patch_zip, deep_hash=verify_hash)
        if problems:
            raise K7Error('El parche no puede aplicarse:\n' + '\n'.join(problems))
        with zipfile.ZipFile(patch_zip, 'r') as z:
            manifest = json.loads(z.read('manifest.json').decode('utf-8'))
            output_iso.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(source_iso, output_iso)
            with output_iso.open('r+b') as f:
                afs_base = project.afs_node.lba * 2048
                for rec in manifest['entries']:
                    idx = int(rec['index'])
                    e = project.entries[idx]
                    payload = z.read(rec['file'])
                    slot = _slot_size(project, idx)
                    f.seek(afs_base + e.offset)
                    f.write(payload)
                    if len(payload) < slot:
                        f.write(b'\x00' * (slot-len(payload)))
                    # Tabla AFS: tras magic+count, cada registro es offset,size.
                    f.seek(afs_base + 8 + idx*8 + 4)
                    f.write(struct.pack('<I', len(payload)))
                for rec in manifest.get('iso_patches', []):
                    payload = z.read(rec['file'])
                    if len(payload) != int(rec['slot_size']):
                        raise K7Error(f"{rec.get('unit_id','ISO')}: tamaño de payload binario inválido.")
                    path = rec.get('iso_path') or project.exe_node.path
                    node = project.exe_node if path == project.exe_node.path or path == 'SLUS_211.54' else project.iso_node(path)
                    off = int(rec['file_offset'])
                    if off < 0 or off + len(payload) > node.size:
                        raise K7Error(f"{rec.get('unit_id','ISO')}: slot fuera de {path}.")
                    absolute = node.lba * 2048 + off
                    f.seek(absolute)
                    f.write(payload)
        return manifest
    finally:
        project.close()

# ---------------------------------------------------------------------------
# Experimental EUR/French base transplant (v1.7.7.6)
# ---------------------------------------------------------------------------



def _eur_file_sha256(path: str | Path) -> str:
    h = hashlib.sha256()
    with Path(path).open('rb') as fh:
        while True:
            chunk = fh.read(1024 * 1024)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()

def _eur_align(value: int, alignment: int = 2048) -> int:
    return ((int(value) + alignment - 1) // alignment) * alignment


def _eur_parse_afs(afs_path: str | Path):
    """Read only the AFS index/name table; payloads remain on disk."""
    afs_path = Path(afs_path)
    with afs_path.open('rb') as fh:
        if fh.read(4) != b'AFS\0':
            raise K7Error('Base francesa: D_EU/DIR_E.AFS no tiene cabecera AFS válida.')
        raw_count = fh.read(4)
        if len(raw_count) != 4:
            raise K7Error('Base francesa: cabecera AFS truncada.')
        count = struct.unpack('<I', raw_count)[0]
        if not (1 <= count <= 20000):
            raise K7Error(f'Base francesa: número de entradas AFS no razonable: {count}.')
        raw_entries = []
        for _ in range(count):
            raw = fh.read(8)
            if len(raw) != 8:
                raise K7Error('Base francesa: tabla AFS truncada.')
            raw_entries.append(struct.unpack('<II', raw))
        tail = fh.read(8)
        if len(tail) != 8:
            raise K7Error('Base francesa: falta la referencia a la tabla de nombres AFS.')
        name_off, name_size = struct.unpack('<II', tail)
        file_size = afs_path.stat().st_size
        for idx, (off, size) in enumerate(raw_entries):
            if off < 0 or size < 0 or off + size > file_size:
                raise K7Error(f'Base francesa: entrada AFS #{idx} fuera del archivo.')
        if name_off + name_size > file_size or name_size < count * 48:
            raise K7Error('Base francesa: tabla de nombres AFS inválida o truncada.')
        fh.seek(name_off)
        name_table = fh.read(name_size)
        if len(name_table) != name_size:
            raise K7Error('Base francesa: no se pudo leer la tabla de nombres completa.')
    names = []
    for i in range(count):
        row = name_table[i * 48:(i + 1) * 48]
        names.append(row[:32].split(b'\0', 1)[0].decode('latin1', 'replace'))
    return raw_entries, name_off, name_size, name_table, names


def _eur_read_entry(fh, raw_entries, index: int) -> bytes:
    off, size = raw_entries[index]
    fh.seek(off)
    data = fh.read(size)
    if len(data) != size:
        raise K7Error(f'Base francesa: entrada AFS #{index} truncada.')
    return data


def _eur_is_jmb_blob(data: bytes) -> bool:
    if len(data) < 20:
        return False
    try:
        scene_n, char_n, scene_off, char_off, total_off = struct.unpack_from('<hhIII', data, 0)
    except struct.error:
        return False
    return (
        0 < scene_n < 100 and 0 < char_n < 500 and
        scene_off == 16 + 4 * scene_n and
        char_off - scene_off == JMB_SCENE_SIZE * scene_n and
        char_off <= total_off <= len(data)
    )


def _eur_is_dic_blob(data: bytes) -> bool:
    if len(data) < 0x90 or data[:4] != b'\x16\x00\x00\x00':
        return False
    try:
        next_len = struct.unpack_from('<I', data, 0x40)[0]
        shift = next_len - 8
        width, height, bpp = struct.unpack_from('<III', data, 0x78 + shift)
    except (struct.error, ValueError):
        return False
    return bpp in (4, 8) and 0 < width <= 4096 and 0 < height <= 4096


def _eur_is_dar_blob(data: bytes) -> bool:
    return data[:4] == b'DAR\0'


def _eur_norm_us_name(name: str) -> str:
    import re
    if name.startswith('P'):
        m = re.match(r'(P\d{6})', name)
        return m.group(1) if m else name.rstrip('.')
    if name.startswith('h_'):
        return name[:5]
    if name.startswith('Hand'):
        return 'Handso'
    if name.startswith('Select'):
        return 'Select'
    if re.fullmatch(r'\d{4}', name):
        return name
    return name.rstrip('.')


def _eur_norm_name(name: str) -> str:
    import re
    if name.startswith('P'):
        m = re.match(r'(P\d{6})', name)
        return m.group(1) if m else name
    if name.startswith('h_'):
        return name[:5]
    if name.startswith('Hand'):
        return 'Handso'
    if name.startswith('Select'):
        return 'Select'
    if re.fullmatch(r'\d{5}', name):
        return name[:4]
    return name


# Glifos oficiales tomados de subtítulos franceses EUR.  Esta tabla no cambia
# códigos de texto: sólo proporciona el bitmap europeo para cada carácter cuando
# reconstruimos los atlas de los .da españoles ya compilados.
_EUR_DA_FRENCH_GLYPH_REFS = {
    'M': ('0071010F.da', 0), 'a': ('0071010F.da', 1), 'î': ('0071010F.da', 2),
    't': ('0071010F.da', 3), 'r': ('0071010F.da', 4), 'e': ('0071010F.da', 5),
    '!': ('0071020F.da', 8), 'O': ('0071010F.da', 7), 'n': ('0071010F.da', 8),
    's': ('0071010F.da', 9), 'd': ('0071010F.da', 10), 'l': ('0071010F.da', 11),
    'p': ('0071010F.da', 12), 'é': ('0071010F.da', 13), 'i': ('0071010F.da', 14),
    'J': ('0071010F.da', 15), 'u': ('0071010F.da', 16), 'q': ('0071010F.da', 17),
    "'": ('0071010F.da', 18), 'c': ('0071010F.da', 19), 'o': ('0071010F.da', 20),
    'v': ('0071010F.da', 21), 'C': ('0071010F.da', 22), 'm': ('0071010F.da', 23),
    ',': ('0071010F.da', 24), 'V': ('0071010F.da', 25), 'D': ('0071010F.da', 26),
    'B': ('0071010F.da', 27), 'I': ('0071010F.da', 28), 'w': ('0071010F.da', 29),
    'z': ('0071010F.da', 30), 'f': ('0071010F.da', 31), 'à': ('0071010F.da', 32),
    'A': ('0071010F.da', 33), '-': ('0071010F.da', 34), 'L': ('0071010F.da', 35),
    'g': ('0071010F.da', 36), 'À': ('0071010F.da', 37), 'h': ('0071010F.da', 38),
    'b': ('0071010F.da', 39), 'T': ('0071010F.da', 40), 'Q': ('0071010F.da', 41),
    'H': ('0071010F.da', 42),
    'x': ('0071040F.da', 32), 'y': ('0071020F.da', 32), 'S': ('0071020F.da', 31),
    '?': ('0071020F.da', 18), 'j': ('0071020F.da', 24), '.': ('0071020F.da', 34),
    'k': ('0071080F.da', 28), 'K': ('0071080F.da', 27), 'É': ('0071100F.da', 36),
    'P': ('0071120F.da', 26), 'R': ('0071120F.da', 34), 'U': ('0071120F.da', 40),
    'X': ('0071120F.da', 43), 'F': ('0100152F.da', 19), 'G': ('0100152F.da', 31),
    'N': ('0100152F.da', 32), 'E': ('0100152F.da', 38), 'Y': ('0100070F.da', 53),
    'Z': ('0100070F.da', 47), 'W': ('0901190F.da', 30),
    '0': ('0201050F.da', 16), '1': ('0071120F.da', 35), '2': ('0100070F.da', 42),
    '3': ('0300600F.da', 30), '4': ('0071160F.da', 34), '5': ('0072042F.da', 37),
    '6': ('0300300F.da', 37), '7': ('0121000F.da', 26), '9': ('0201040F.da', 22),
    '(': ('0073010F.da', 15), ')': ('0073010F.da', 18), '/': ('0073010F.da', 19),
    '^': ('0073010F.da', 16), ':': ('0201030F.da', 31), '#': ('0112031F.da', 32),
    '+': ('0121030F.da', 41), '=': ('0201020F.da', 29), '&': ('0901110F.da', 33),
    '"': ('0071030F.da', 17),
    # v1.7.7.206: símbolos de botones/emoticonos localizados en los .da franceses retail.
    # Se usan como donantes oficiales cuando una revisión introduce el símbolo en
    # un bloque cuyo atlas histórico español no lo contenía.
    '□': ('0074070F.da', 36), '△': ('0112030F.da', 52),
    '○': ('0121110F.da', 41), '¯': ('0112030F.da', 40),
}


def _eur_da_params(meta: dict) -> list[tuple[int, int, int, int]]:
    return [
        struct.unpack_from('<4H', meta['dat'], meta['param_offset'] + i * 8)
        for i in range(meta['glyph_count'])
    ]


def _eur_da_build_french_glyph_bank(afs, raw_entries, names) -> dict[str, Image.Image]:
    """Extrae bitmaps de caracteres directamente de .da franceses oficiales."""
    name_to_index = {name.lower(): i for i, name in enumerate(names)}
    cache = {}
    bank: dict[str, Image.Image] = {}
    for ch, (filename, glyph_index) in _EUR_DA_FRENCH_GLYPH_REFS.items():
        key = filename.lower()
        if key not in name_to_index:
            raise K7Error(f'Base EUR: falta el subtítulo francés de referencia {filename}.')
        if key not in cache:
            blob = _eur_read_entry(afs, raw_entries, name_to_index[key])
            meta = Killer7Project._parse_da_blob(blob)
            atlas = Killer7Project.decode_da_ps2_atlas(meta['dic']) if hasattr(Killer7Project, 'decode_da_ps2_atlas') else None
            if atlas is None:
                # decode_da_ps2_atlas es función de módulo importada por core; el proyecto
                # expone el mismo decodificador a través del parser actual.
                from core import decode_da_ps2_atlas
                atlas = decode_da_ps2_atlas(meta['dic'])
            cache[key] = (meta, atlas, _eur_da_params(meta))
        meta, atlas, params = cache[key]
        if not (0 <= glyph_index < meta['glyph_count']):
            raise K7Error(f'Base EUR: índice de glifo inválido {filename}#{glyph_index}.')
        x, y, w, h = params[glyph_index]
        bank[ch] = atlas.crop((x, y, x + w, y + h)).copy()
    return bank


def _eur_da_master_files_by_name() -> dict[str, dict]:
    master_path = editable_path('resources', 'master', 'Killer7_SLUS-21154_master_ES_started.xlf')
    if not master_path.is_file():
        raise K7Error(f'Base EUR: falta el XLIFF maestro español integrado: {master_path.name}.')
    parsed = parse_project_xliff(master_path)
    result = {}
    for f in parsed.get('files', []):
        vals = f.get('notes', {}).get('killer7:afs_name', [])
        if vals:
            result[str(vals[0]).lower()] = f
    return result


def _eur_da_line_codes(meta: dict, line: int) -> list[int]:
    off = meta['record_offset'] + line * DA_RECORD_SIZE + 8
    codes = list(struct.unpack_from(f'<{DA_CODE_SLOTS}h', meta['dat'], off))
    if -2 in codes:
        codes = codes[:codes.index(-2)]
    elif -1 in codes:
        codes = codes[:codes.index(-1)]
    return codes


def _eur_da_effective_text(unit: dict) -> str:
    source = (unit.get('source') or '').strip('\r\n')
    target = (unit.get('target') or '').strip('\r\n')
    return target if target and target != source else source


def _eur_da_pair_codes_to_chars(codes: list[int], text: str):
    tokens = _text_tokens(text)
    pos = 0
    pairs = []
    for code in codes:
        if code in (-4, -3):
            if pos >= len(tokens) or tokens[pos][0] != 'char' or tokens[pos][1] not in (' ', '\u3000'):
                return None
            pos += 1
            continue
        unsigned = code & 0xFFFF
        if unsigned >= 0xFF00:
            if pos >= len(tokens) or tokens[pos][0] != 'control' or tokens[pos][1] != unsigned:
                return None
            pos += 1
            continue
        if pos >= len(tokens) or tokens[pos][0] != 'char':
            return None
        pairs.append((_glyph_index(code), tokens[pos][1]))
        pos += 1
    return pairs if pos == len(tokens) else None


def _eur_da_synth_spanish_glyph(ch: str, bank: dict[str, Image.Image]) -> tuple[Image.Image | None, bool]:
    """Devuelve glifo EUR; sintetiza sólo signos/letras españolas ausentes en francés."""
    if ch in bank:
        return bank[ch].copy(), False
    acute = {'á': 'a', 'í': 'i', 'ó': 'o', 'ú': 'u', 'Ú': 'U'}
    if ch in acute and acute[ch] in bank and 'é' in bank:
        base = bank[acute[ch]].copy().convert('L')
        if ch == 'í':
            ImageDraw.Draw(base).rectangle((0, 0, base.width - 1, min(7, base.height - 1)), fill=0)
        accent = bank['é'].convert('L').crop((0, 0, bank['é'].width, min(8, bank['é'].height)))
        bbox = accent.getbbox()
        if bbox:
            accent = accent.crop(bbox)
            x = max(0, min(base.width - accent.width, (base.width - accent.width) // 2 + 1))
            base.paste(accent, (x, 0), accent)
        return base, True
    if ch == 'ñ' and 'n' in bank:
        base = bank['n'].copy().convert('L')
        draw = ImageDraw.Draw(base)
        draw.rectangle((0, 0, base.width - 1, min(6, base.height - 1)), fill=0)
        # Tilde pequeña, con antialias discreto para imitar el raster de los .da EUR.
        for x, y, value in [(2,4,153),(3,3,255),(4,3,255),(5,4,153),(6,4,153),(7,3,255),(8,3,255),(9,2,153)]:
            if x < base.width and y < base.height:
                draw.point((x, y), fill=value)
        return base, True
    if ch == '¡' and '!' in bank:
        return bank['!'].transpose(Image.Transpose.ROTATE_180), True
    if ch == '¿' and '?' in bank:
        return bank['?'].transpose(Image.Transpose.ROTATE_180), True
    return None, False


def _eur_da_previous_compiled_text(unit: dict) -> str:
    """Texto que corresponde a los códigos del payload .da precompilado v1.7.7.19.

    v1.7.7.20 guarda este valor en el XLIFF antes de revisar los subtítulos.  Así
    podemos recuperar con precisión el mapa carácter→índice del atlas antiguo y
    recompilar el texto revisado sin necesitar la ISO USA original.
    """
    vals = unit.get('notes', {}).get('killer7:compiled_target_v17719', [])
    if vals:
        return str(vals[0]).strip('\r\n')
    # Compatibilidad con proyectos que no hayan cambiado esta unidad desde la base.
    target = (unit.get('target') or '').strip('\r\n')
    source = (unit.get('source') or '').strip('\r\n')
    return target or source


def _eur_recompile_spanish_da_from_master(
    compiled_da: bytes,
    afs_name: str,
    xlf_file: dict,
    french_bank: dict[str, Image.Image],
) -> tuple[bytes, dict]:
    """Recompila un .da español usando los targets actuales del XLIFF maestro.

    El parche histórico contiene el texto español de v1.7.7.19.  A partir de sus
    códigos y de la nota ``compiled_target_v17719`` reconstruimos el mapa de glifos,
    liberamos los índices de las líneas que sí tienen traducción y generamos de nuevo
    char_data + fParams + DIC.  Las líneas SOURCE PENDING quedan byte a byte intactas.
    """
    from core import decode_da_ps2_atlas

    meta = Killer7Project._parse_da_blob(compiled_da)
    original_atlas = decode_da_ps2_atlas(meta['dic'])
    original_params = _eur_da_params(meta)

    file_notes = xlf_file.get('notes', {})
    try:
        jmb_index = int((file_notes.get('killer7:jmb_index') or ['0'])[0])
    except (TypeError, ValueError):
        jmb_index = 0

    units: list[TextUnit] = []
    rows = []
    char_to_index: dict[str, int] = {}
    conflicts: set[str] = set()
    pair_failures: list[int] = []

    for row in xlf_file.get('units', []):
        vals = row.get('notes', {}).get('killer7:sentence', [])
        if not vals:
            continue
        try:
            line = int(vals[0])
        except (TypeError, ValueError):
            continue
        if not (0 <= line < meta['line_count']):
            continue

        codes = _eur_da_line_codes(meta, line)
        unit = TextUnit(
            id=row.get('id', ''), afs_jmb_index=jmb_index, afs_dic_index=jmb_index,
            afs_name=afs_name, sentence=line, jimaku=0, wait=0, disp_time=0,
            codes=codes, source=_eur_da_previous_compiled_text(row),
            source_state='verified', max_codes=DA_MAX_CODES,
        )
        units.append(unit)

        old_text = _eur_da_previous_compiled_text(row)
        if old_text and not old_text.startswith(PENDING_PREFIX) and not old_text.startswith(SPECIAL_PREFIX):
            pairs = _eur_da_pair_codes_to_chars(codes, old_text)
            if pairs is None:
                pair_failures.append(line)
            else:
                for glyph_index, ch in pairs:
                    if glyph_index is None:
                        continue
                    previous = char_to_index.get(ch)
                    if previous is None:
                        char_to_index[ch] = glyph_index
                    elif previous != glyph_index:
                        conflicts.add(ch)

        target = (row.get('target') or '').strip('\r\n')
        source = (row.get('source') or '').strip('\r\n')
        if not target or target.startswith(PENDING_PREFIX) or target.startswith(SPECIAL_PREFIX):
            continue
        if source.startswith(PENDING_PREFIX) or source.startswith(SPECIAL_PREFIX):
            continue
        rows.append((row, unit, target))

    if pair_failures:
        raise K7Error(
            f'Base EUR: el texto anterior guardado no coincide con el .da precompilado '
            f'{afs_name}, líneas {pair_failures[:8]}.'
        )
    for ch in conflicts:
        char_to_index.pop(ch, None)

    if not rows:
        return compiled_da, {
            'translated_lines': 0, 'added_glyphs': [], 'synthesized_chars': [],
            'fallback_chars': [], 'glyph_conflicts': len(conflicts),
        }

    block = TextBlock(
        jmb_index=jmb_index, dic_index=jmb_index, name=afs_name,
        sentence_num=meta['line_count'], char_num=meta['glyph_count'], units=units,
        storage_kind='afs_da', storage_path=f'D_US/DIR.AFS#{jmb_index}:{afs_name}',
    )
    bank = {ch: [(None, image)] for ch, image in french_bank.items()}

    # Reempaquetar es intencionado: en EUR podemos hacer crecer el DAR/AFS de forma
    # segura y así no sacrificamos tildes/signos por los slots de la versión antigua.
    # Si el atlas 512x32 no basta, probamos 64/128: son tamaños DA nativos del propio
    # Killer7 EUR y la misma ruta se usa para las cinemáticas editables.
    atlas = params = char_map = added = fallback_chars = synthesized_chars = None
    pack_errors = []
    bg = int(round(_mode_level(original_atlas) / 17.0)) * 17
    candidate_heights = [h for h in (32, 64, 128) if h >= original_atlas.height]
    for candidate_h in candidate_heights:
        try:
            candidate_atlas = Image.new('L', (original_atlas.width, candidate_h), bg)
            candidate_atlas.paste(original_atlas, (0, 0))
            atlas, params, char_map, added, fallback_chars, synthesized_chars = _pack_da_glyphs(
                block, candidate_atlas, original_params, char_to_index, rows,
                da_glyph_bank=bank, font_path=None,
            )
            break
        except K7Error as exc:
            pack_errors.append(str(exc))
    if atlas is None:
        raise K7Error(
            f'Base EUR: el repertorio revisado de {afs_name} no cabe ni en 512x128. ' +
            (pack_errors[-1] if pack_errors else '')
        )

    dat = bytearray(meta['dat'][:meta['param_offset']])
    struct.pack_into('<H', dat, 2, len(params))
    translated = []
    for row, unit, target in rows:
        codes = _encode_target(target, char_map, max_codes=DA_MAX_CODES)
        off = meta['record_offset'] + unit.sentence * DA_RECORD_SIZE + 8
        arr = codes + [-2]
        arr += [-1] * (DA_CODE_SLOTS - len(arr))
        if len(arr) != DA_CODE_SLOTS:
            raise K7Error(f'{row["id"]}: error interno al rellenar char_data DA EUR.')
        struct.pack_into(f'<{DA_CODE_SLOTS}h', dat, off, *arr)
        translated.append(row['id'])
    dat.extend(b''.join(struct.pack('<4H', *param) for param in params))
    dic = _eur_encode_resized_da_dic(meta['dic'], atlas)
    rebuilt = _rebuild_da_container(meta['raw'], bytes(dat), dic)

    verify = Killer7Project._parse_da_blob(rebuilt)
    if verify['line_count'] != meta['line_count']:
        raise K7Error(f'Base EUR: cambió el número de líneas al recompilar {afs_name}.')
    for row, unit, target in rows:
        pairs = _eur_da_pair_codes_to_chars(_eur_da_line_codes(verify, unit.sentence), target)
        if pairs is None:
            raise K7Error(f'Base EUR: round-trip texto↔código falló en {row["id"]}.')

    return rebuilt, {
        'translated_lines': len(translated),
        'glyph_count_before': meta['glyph_count'],
        'glyph_count_after': len(params),
        'added_glyphs': sorted(added),
        'synthesized_chars': sorted(set(synthesized_chars)),
        'fallback_chars': sorted(set(fallback_chars)),
        'glyph_conflicts': len(conflicts),
        'atlas_size_before': list(original_atlas.size),
        'atlas_size_after': list(atlas.size),
        'atlas_expanded': atlas.size != original_atlas.size,
    }


def _eur_restyle_spanish_da_with_french(
    compiled_da: bytes,
    afs_name: str,
    xlf_file: dict,
    french_bank: dict[str, Image.Image],
) -> tuple[bytes, dict]:
    """Conserva texto/códigos españoles pero reconstruye el atlas con sprites franceses EUR."""
    from core import decode_da_ps2_atlas

    meta = Killer7Project._parse_da_blob(compiled_da)
    old_atlas = decode_da_ps2_atlas(meta['dic'])
    params = _eur_da_params(meta)
    index_chars: dict[int, str] = {}
    conflicts: set[int] = set()
    pair_failures = []

    for unit in xlf_file.get('units', []):
        vals = unit.get('notes', {}).get('killer7:sentence', [])
        if not vals:
            continue
        try:
            line = int(vals[0])
        except (TypeError, ValueError):
            continue
        if not (0 <= line < meta['line_count']):
            continue
        text = _eur_da_effective_text(unit)
        if not text or text.startswith(PENDING_PREFIX) or text.startswith(SPECIAL_PREFIX):
            continue
        pairs = _eur_da_pair_codes_to_chars(_eur_da_line_codes(meta, line), text)
        if pairs is None:
            pair_failures.append(line)
            continue
        for glyph_index, ch in pairs:
            if glyph_index is None:
                continue
            previous = index_chars.get(glyph_index)
            if previous is not None and previous != ch:
                conflicts.add(glyph_index)
            else:
                index_chars[glyph_index] = ch
    for glyph_index in conflicts:
        index_chars.pop(glyph_index, None)
    if pair_failures:
        raise K7Error(
            f'Base EUR: no se pudo asociar texto↔glifo en {afs_name}, líneas {pair_failures[:8]}.'
        )

    glyphs: dict[int, Image.Image] = {}
    fallback_chars = set()
    synthesized_chars = set()
    # Empaquetamos TODOS los índices. Los no identificados o conflictivos conservan
    # su bitmap español anterior, evitando glifos vacíos en códigos especiales.
    for glyph_index in range(meta['glyph_count']):
        ch = index_chars.get(glyph_index)
        glyph = None
        synthesized = False
        if ch is not None:
            glyph, synthesized = _eur_da_synth_spanish_glyph(ch, french_bank)
        if glyph is None:
            x, y, w, h = params[glyph_index]
            glyph = old_atlas.crop((x, y, x + w, y + h)).copy()
            if ch is not None:
                fallback_chars.add(ch)
        elif synthesized:
            synthesized_chars.add(ch)
        glyphs[glyph_index] = glyph.convert('L')

    width, height = old_atlas.size
    atlas = Image.new('L', (width, height), 0)
    new_params = list(params)
    x = y = row_h = 0
    for glyph_index in range(meta['glyph_count']):
        glyph = glyphs[glyph_index]
        if x + glyph.width > width:
            x = 0
            y += row_h + 1
            row_h = 0
        if y + glyph.height > height:
            raise K7Error(
                f'Base EUR: atlas francés no cabe en {afs_name} '
                f'({width}x{height}, glifo #{glyph_index}).'
            )
        atlas.paste(glyph, (x, y))
        new_params[glyph_index] = (x, y, glyph.width, glyph.height)
        x += glyph.width + 1
        row_h = max(row_h, glyph.height)

    dat = bytearray(meta['dat'])
    for glyph_index, param in enumerate(new_params):
        struct.pack_into('<4H', dat, meta['param_offset'] + glyph_index * 8, *param)
    dic = encode_da_ps2_atlas_into_dic(meta['dic'], atlas)
    rebuilt = _rebuild_da_container(meta['raw'], bytes(dat), dic)

    # Invariante crítica: esta operación es sólo visual. Los códigos de todas las
    # líneas de subtítulo deben permanecer exactamente iguales.
    verify = Killer7Project._parse_da_blob(rebuilt)
    if verify['line_count'] != meta['line_count'] or verify['glyph_count'] != meta['glyph_count']:
        raise K7Error(f'Base EUR: cambió la estructura del subtítulo al restilizar {afs_name}.')
    for line in range(meta['line_count']):
        if _eur_da_line_codes(verify, line) != _eur_da_line_codes(meta, line):
            raise K7Error(f'Base EUR: cambiaron los códigos de texto en {afs_name}, línea {line}.')

    return rebuilt, {
        'mapped_glyphs': len(index_chars),
        'conflict_glyphs': len(conflicts),
        'fallback_chars': sorted(fallback_chars),
        'synthesized_chars': sorted(synthesized_chars),
        'atlas': [width, height],
    }



def _eur_patch_option_f_font(original: bytes) -> tuple[bytes, dict]:
    """Añade E y ó reales a option_f.dat usando exclusivamente formas EUR francesas.

    La fuente francesa de Opciones es deliberadamente mínima: contiene É/é/à pero
    no contiene ASCII E ni ó.  Por eso una cadena binaria correcta ESTÉREO se veía
    como STÉRO: el renderer omitía las dos E inexistentes.  Esta rutina amplía la
    tabla STRIMAGS en dos entradas sin cambiar el tamaño total de option_f.dat.

    E se deriva de la É oficial francesa eliminando sus cuatro filas de acento.
    ó se compone con la o oficial francesa y el acento agudo de é.  El atlas se
    reescribe mediante el layout GS PSMCT16->PSMT4 ya verificado con savestate.
    """
    raw = bytearray(original)
    if len(raw) < 0x100 or raw[:4] != b'DAR\0':
        raise K7Error('Base EUR: option_f.dat no es el DAR esperado.')
    child_count = struct.unpack_from('<I', raw, 8)[0]
    if child_count != 2:
        raise K7Error(f'Base EUR: option_f.dat tiene {child_count} hijos; se esperaban 2.')
    offsets = struct.unpack_from('<2I', raw, 0x10)
    sizes = list(struct.unpack_from('<2I', raw, 0x30))
    o_dic, o_ihe = offsets
    s_dic, s_ihe = sizes
    if o_dic + s_dic > len(raw) or o_ihe + s_ihe > len(raw):
        raise K7Error('Base EUR: layout DAR de option_f.dat fuera de rango.')

    dic = bytes(raw[o_dic:o_dic + s_dic])
    ihe = bytearray(raw[o_ihe:o_ihe + s_ihe])
    if len(ihe) < 32 or not ihe.startswith(b'STRIMAG'):
        raise K7Error('Base EUR: tabla STRIMAGS de option_f.dat no reconocida.')
    glyph_count = struct.unpack_from('<I', ihe, 0x18)[0]
    if len(ihe) != 32 + glyph_count * 20:
        raise K7Error('Base EUR: tamaño STRIMAGS de option_f.dat inconsistente.')
    entries = [struct.unpack_from('<10H', ihe, 32 + i * 20) for i in range(glyph_count)]
    by_code = {row[0]: row for row in entries}
    for required in (ord('o'), ord('e'), 0xE9, 0xC9):
        if required not in by_code:
            raise K7Error(f'Base EUR: option_f.dat no contiene el glifo de referencia 0x{required:02X}.')
    if ord('E') in by_code or 0xF3 in by_code:
        # Idempotencia: no volver a crecer una fuente ya adaptada.
        if ord('E') in by_code and 0xF3 in by_code:
            return bytes(raw), {'already_patched': True, 'glyph_count': glyph_count}
        raise K7Error('Base EUR: option_f.dat contiene sólo una de las dos extensiones E/ó.')

    atlas, layout = _decode_experimental_option_atlas(dic)
    bg = int(round(_mode_level(atlas) / 17.0)) * 17

    def glyph_bitmap(code: int) -> tuple[Image.Image, tuple[int, ...]]:
        row = by_code[code]
        _c, x, y, w, h, _xo, _yo, _adv, _page, _dup = row
        return atlas.crop((x, y, x + w, y + h)).copy(), row

    eacute_cap, cap_row = glyph_bitmap(0xC9)  # É
    eacute_low, low_row = glyph_bitmap(0xE9)  # é
    o_bitmap, o_row = glyph_bitmap(ord('o'))

    # E: los glifos capitales franceses son de 18 px / yoff 4.  É mide 21 px /
    # yoff 1; sus cuatro primeras filas contienen blanco+acento.  Conservamos el
    # cuerpo oficial (filas 4..20) precedido por la fila superior vacía normal.
    e_width = cap_row[3]
    if (e_width, cap_row[4], cap_row[6], cap_row[7]) != (8, 21, 1, 8):
        raise K7Error(f'Base EUR: métricas de É inesperadas en option_f.dat: {cap_row}.')
    E = Image.new('L', (8, 18), bg)
    E.paste(eacute_cap.crop((0, 4, 8, 21)), (0, 1))

    # ó: é demuestra el layout oficial del agudo en minúsculas. Copiamos sus
    # cuatro filas superiores y sustituimos el cuerpo por la o francesa.  Se
    # omite la fila blanca superior de o para mantener h=18/yoff=4 como é.
    if (low_row[3], low_row[4], low_row[6], low_row[7]) != (9, 18, 4, 9):
        raise K7Error(f'Base EUR: métricas de é inesperadas en option_f.dat: {low_row}.')
    if (o_row[3], o_row[4], o_row[6], o_row[7]) != (9, 15, 7, 9):
        raise K7Error(f'Base EUR: métricas de o inesperadas en option_f.dat: {o_row}.')
    oacute = Image.new('L', (9, 18), bg)
    oacute.paste(eacute_low.crop((0, 0, 9, 4)), (0, 0))
    oacute.paste(o_bitmap.crop((0, 1, 9, 15)), (0, 4))

    # Zona libre verificada del atlas francés, inmediatamente después de m.
    placements = [
        (ord('E'), E, 84, 50, 8, 18, 0, 4, 8, 1),
        (0xF3, oacute, 93, 50, 9, 18, 0, 4, 9, 1),
    ]
    for code, image, x, y, w, h, xoff, yoff, adv, page in placements:
        # La zona debe estar vacía/fondo antes de escribir para evitar pisar
        # futuros cambios de la edición EUR.
        region = atlas.crop((x, y, x + w, y + h))
        if any(px != bg for px in region.getdata()):
            raise K7Error(f'Base EUR: zona de atlas reservada para 0x{code:02X} ya está ocupada.')
        atlas.paste(image, (x, y))

    patched_dic = _encode_experimental_option_atlas(dic, atlas, layout)
    verify_atlas, _ = _decode_experimental_option_atlas(patched_dic)
    for code, image, x, y, w, h, *_rest in placements:
        actual = verify_atlas.crop((x, y, x + w, y + h))
        if list(actual.getdata()) != list(image.getdata()):
            raise K7Error(f'Base EUR: el glifo 0x{code:02X} no supera round-trip GS.')
    raw[o_dic:o_dic + s_dic] = patched_dic

    # Hay 104 bytes de padding tras STRIMAGS; dos registros requieren 40.
    extra = len(placements) * 20
    new_ihe_size = s_ihe + extra
    if o_ihe + new_ihe_size > len(raw):
        raise K7Error('Base EUR: option_f.dat no tiene padding para añadir E/ó.')
    tail = bytes(raw[o_ihe + s_ihe:o_ihe + new_ihe_size])
    if any(tail):
        raise K7Error('Base EUR: padding STRIMAGS de option_f.dat ya no está vacío.')

    new_ihe = bytearray(new_ihe_size)
    new_ihe[:s_ihe] = ihe
    struct.pack_into('<I', new_ihe, 0x18, glyph_count + len(placements))
    pos = 32 + glyph_count * 20
    records = []
    for code, _image, x, y, w, h, xoff, yoff, adv, page in placements:
        rec = (code, x, y, w, h, xoff, yoff, adv, page, code)
        struct.pack_into('<10H', new_ihe, pos, *rec)
        records.append(rec)
        pos += 20
    raw[o_ihe:o_ihe + new_ihe_size] = new_ihe
    sizes[1] = new_ihe_size
    struct.pack_into('<2I', raw, 0x30, *sizes)

    # Verificación final de la tabla ampliada.
    final_ihe = raw[o_ihe:o_ihe + new_ihe_size]
    final_count = struct.unpack_from('<I', final_ihe, 0x18)[0]
    final_codes = [struct.unpack_from('<H', final_ihe, 32 + i * 20)[0] for i in range(final_count)]
    if final_count != glyph_count + 2 or final_codes[-2:] != [ord('E'), 0xF3]:
        raise K7Error('Base EUR: tabla option_f.dat no conserva E/ó tras ampliarla.')

    return bytes(raw), {
        'already_patched': False,
        'glyph_count_before': glyph_count,
        'glyph_count_after': final_count,
        'added_codes': ['0x45 E', '0xF3 ó'],
        'source_glyphs': ['É oficial EUR', 'é oficial EUR', 'o oficial EUR'],
        'font_size_unchanged': len(raw),
    }




# EUR v1.7.7.14: traducción amplia de rótulos K7P2.
# Se usa ASCII deliberadamente: estos nombres se dibujan por una ruta distinta de
# option_f/.da y todavía no hemos demostrado que su fuente acepte Latin-1.
# Los nombres propios, direcciones y nombres de atracciones que no deben traducirse
# no aparecen en esta tabla.
_EUR_K7P2_SPANISH_LABELS = {
    '1F HallWay': 'Pasillo 1F',
    '1st Floor': 'Planta 1',
    '2nd Floor': 'Planta 2',
    '3F Library': 'Biblio. 3F',
    '3rd Floor': 'Planta 3',
    '4F HallWay': 'Pasillo 4F',
    '4th Floor': 'Planta 4',
    '5th Floor': 'Planta 5',
    'Adventure Plaza': 'Plaza Aventura',
    'Air Conditioner': 'Climatizador',
    'Alley': 'Callej.',
    'Ambulance': 'Ambulancia',
    'Ambulance 01': 'Ambulancia 01',
    'Ambulance 02': 'Ambulancia 02',
    'Ambulance 04': 'Ambulancia 04',
    'Ambulance 05': 'Ambulancia 05',
    'Ambulance 06': 'Ambulancia 06',
    'Ambulance 07': 'Ambulancia 07',
    'Ambulance 09': 'Ambulancia 09',
    'Ambulance 10': 'Ambulancia 10',
    'Ambulance 11': 'Ambulancia 11',
    'An Object': 'Un objeto',
    'Annex': 'Anexo',
    'Aquarium': 'Acuario',
    'Arcade': 'Arcade',
    'Attic': 'Atico',
    'Azure Dragon': 'Dragon azul',
    'Back Alley': 'Callejon',
    'Balloons': 'Globos',
    'Barrel': 'Barril',
    'Basement': 'Sotano',
    'Bathroom': 'Bano',
    'Bathtub': 'Banera',
    'Bedroom': 'Dormit.',
    'Black Warrior': 'Guerrero negro',
    'Blackburn Residence': 'Resid. Blackburn',
    'Bloodstain': 'Sangre',
    'Boiler Room': 'Calderas',
    'Bridge': 'Puente',
    'Bullet': 'Bala',
    'Bulletin Board': 'Tablon avisos',
    'Burnig Hot Hell': 'Infierno ard.',
    'Burning Bridge': 'Puente fuego',
    'Burning Hot Hell': 'Infierno ardiente',
    'Cable': 'Cable',
    'Cafeteria': 'Cafeteria',
    'Candle': 'Vela',
    'Candles': 'Velas',
    'Cards': 'Cartas',
    'Carrier Pigeon': 'Paloma mensaj.',
    'Cassette': 'Casete',
    "Chairman's Room": 'Sala presid.',
    'Child Entrance': 'Entrada ninos',
    'Church Entrance': 'Entrada igl.',
    'Cinema1': 'Cine 1',
    'Cinema2': 'Cine 2',
    'Cinema3': 'Cine 3',
    'Cinema4': 'Cine 4',
    'Classroom': 'Aula',
    'Clock': 'Reloj',
    'Closet': 'Armario',
    'Color Panel': 'Panel color',
    'Colosseum': 'Coliseo',
    'Company Property': 'Prop. empresa',
    'Control Panel': 'Panel control',
    'Control Room': 'Sala control',
    'Corridor': 'Pasillo',
    'Courtyard': 'Patio',
    'Cult Member': 'Sectario',
    'Data Room': 'Sala datos',
    'Desert': 'Yermo',
    'Deserted Building': 'Edif. abandon.',
    'Dice': 'Dados',
    'Diner': 'Cafetin',
    'Door': 'Puerta',
    'Downstairs': 'Abajo',
    'Dryer': 'Secador',
    'East House': 'Casa este',
    'Elevator': 'Ascensor',
    'Elevator Hall': 'Zona ascensor',
    'Emergency Staircase': 'Escal. emerg.',
    'Employee Passage': 'Paso empleados',
    'Entrance': 'Entrada',
    'Entrance Gate': 'Puerta entrada',
    'Entry Hall': 'Vestíbulo',
    'Exit': 'Salida',
    'Express Elevator': 'Ascensor expr.',
    'Fallen Angel': 'Angel caido',
    'Fingerprint ID': 'ID huella',
    'Fireplace': 'Chimenea',
    'First Life Bldg': 'Edif. FirstLife',
    'First Life Gate': 'Puerta First',
    'Flowers': 'Flores',
    'Forbidden Room': 'Sala prohibida',
    'Foyer': 'Vestíb.',
    'Freaky Fun House': 'Casa del terror',
    'Garage': 'Garaje',
    'Garbage Chute': 'Conducto basura',
    'Garden': 'Jardin',
    'Gas Pump': 'Surtidor',
    'Gas Station': 'Gasolinera',
    'Gate': 'Verja',
    'Gatekeeper': 'Guardian',
    'Graffiti': 'Grafiti',
    'Grand Staircase': 'Gran escalera',
    'Great Hall': 'Gran salon',
    "Guard's Room": 'Sala guardia',
    'Guesthouse': 'Casa huesp.',
    'Guestroom': 'Hab. huesp.',
    'Guestrooms': 'Hab. huesp.',
    'Gymnasium': 'Gimnasio',
    'Hall Way': 'Pasillo',
    'Hallway': 'Pasillo',
    'HallWay': 'Pasillo',
    'hallway': 'Pasillo',
    "Harman' Room": 'Sala Harman',
    "Harman Room": 'Sala Harman',
    "Harman's Room": 'Sala Harman',
    "Harman's room": 'Sala Harman',
    'Hole': 'Agujero',
    'Horse Race': 'Hipodromo',
    'Information': 'Informacion',
    'Killer Mansion': 'Mansion Killer',
    'Kitchen': 'Cocina',
    "Ladies' Room": 'Aseo mujeres',
    'Lamp': 'Lampara',
    'Large Hall': 'Gran sala',
    'Library': 'Biblio.',
    'Light Switch': 'Interruptor',
    'Living': 'Salon',
    'Living Room': 'Salon',
    'Lobby': 'Vestíb.',
    'Lounge': 'Salon',
    'Mah-jongg Room': 'Sala mahjong',
    'Main Breaker': 'Cuadro princ.',
    'Main House': 'Casa princ.',
    'Main School Gate': 'Puerta colegio',
    "Manager's Room": 'Sala gerente',
    'Mask': 'Mascara',
    'Meeting Room': 'Sala juntas',
    'Mills': 'Molinos',
    'Mountain Path': 'Senda montana',
    'North House': 'Casa norte',
    'Notice': 'Aviso',
    'Operation Panel': 'Panel operac.',
    'Outside': 'Fuera',
    "Owner's Room": 'Sala dueno',
    'Painting': 'Cuadro',
    'Parking': 'Garaje',
    'Passage': 'Paso',
    'Photo': 'Foto',
    'Picture': 'Cuadro',
    'Pool': 'Piscina',
    'Poolside': 'Piscina',
    'Post Office': 'Correos',
    'Poster': 'Cartel',
    "Principal's Office": 'Direccion',
    'Railroad': 'Ferrocarril',
    'Reception': 'Recepcion',
    'Red Phoenix': 'Fenix rojo',
    'Restroom': 'Aseo',
    'Road': 'Camino',
    'Rock': 'Roca',
    'Roof': 'Tejado',
    'Room': 'Sala',
    'Room 105': 'Sala 105',
    'Room 203': 'Sala 203',
    'Room 207': 'Sala 207',
    'Room 212': 'Sala 212',
    'Room 301': 'Sala 301',
    'Room 306': 'Sala 306',
    'Room 307': 'Sala 307',
    'Room 401': 'Sala 401',
    'Room 404': 'Sala 404',
    'Room 406': 'Sala 406',
    'Room 502': 'Sala 502',
    'Room 601': 'Sala 601',
    'Safe': 'Caja f.',
    'Second House': 'Casa 2',
    'Secret Passage': 'Paso secreto',
    'Security': 'Seguridad',
    'Security Terminal': 'Terminal seg.',
    'Semi Truck': 'Camion',
    'Sheet': 'Hoja',
    'Shelves': 'Estant.',
    'Sign': 'Senal',
    'Sofa': 'Sofa',
    'South House': 'Casa sur',
    'Sprinkler': 'Rociador',
    'Stage': 'Escena',
    'Stairs': 'Escal.',
    'Stall': 'Puesto',
    'Statue': 'Estatua',
    'Storage Box': 'Caja almac.',
    'Storage Room': 'Almacen',
    'Strong Room': 'Caja fuerte',
    'Suburb': 'Afueras',
    'Suite': 'Suite',
    'Table': 'Mesa',
    'Terminal': 'Terminal',
    'Terrace': 'Terraza',
    'Toilet': 'Inodoro',
    'Top-floor': 'Ult. piso',
    'Toy Dispenser': 'Exp. juguetes',
    'Treasure Chest': 'Cofre tesoro',
    "Trevor's Atelier": 'Taller Trevor',
    "Trevor's House": 'Casa Trevor',
    'Trophy': 'Trofeo',
    'Upstairs': 'Arriba',
    'Valve': 'Valvula',
    'Vase': 'Jarrón',
    'Vending Machine': 'Expendedora',
    'Vinculum Gate': 'Puerta Vinc.',
    'Wagon': 'Vagon',
    'Waiting Room': 'Sala espera',
    'Wall': 'Pared',
    'Warehouse': 'Almacen',
    'Water Tank': 'Deposito',
    'West House': 'Casa oeste',
    'White Tiger': 'Tigre bl.',
    'Windmill': 'Molino',
}

# v1.7.7.23: ortografía ES-ES y cobertura completa del catálogo K7P2 EUR.
# Se conservan los nombres propios; los rótulos funcionales usan tildes reales.
_EUR_K7P2_SPANISH_LABELS.update({
    'Arcade': 'Galería',
    'Attic': 'Ático',
    'Azure Dragon': 'Dragón azul',
    'Back Alley': 'Callejón',
    'Basement': 'Sótano',
    'Bathroom': 'Baño',
    'Bathtub': 'Bañera',
    'Bulletin Board': 'Tablón avisos',
    'Cafeteria': 'Cafetería',
    'Child Entrance': 'Entrada niños',
    'Diner': 'Cafetín',
    'Entry Hall': 'Vestíbulo',
    'Foyer': 'Vestíb.',
    'Lobby': 'Vestíb.',
    'Fallen Angel': 'Ángel caído',
    'Freaky Fun House': 'Casa de locos',
    'Garden': 'Jardín',
    'Gatekeeper': 'Guardián',
    'Great Hall': 'Gran salón',
    'Guesthouse': 'Casa huésp.',
    'Guestroom': 'Hab. huésp.',
    'Guestrooms': 'Hab. huésp.',
    'Horse Race': 'Hipódromo',
    'Information': 'Información',
    'Killer Mansion': 'Mansión Killer',
    'Lamp': 'Lámpara',
    'Living': 'Salón',
    'Living Room': 'Salón',
    'Lounge': 'Salón',
    'Mask': 'Máscara',
    'Mills': 'Mills',
    'Mountain Path': 'Senda montaña',
    "Owner's Room": 'Sala del dueño',
    "Principal's Office": 'Dirección',
    'Reception': 'Recepción',
    'Red Phoenix': 'Fénix rojo',
    'Roof': 'Azotea',
    'Semi Truck': 'Camión',
    'Sign': 'Señal',
    'Sofa': 'Sofá',
    'Storage Room': 'Almacén',
    'Top-floor': 'Últ. piso',
    'Valve': 'Válvula',
    'Wagon': 'Vagón',
    'Warehouse': 'Almacén',
    'Water Tank': 'Depósito',
    # Rótulos que antes no estaban en la tabla amplia.
    'Iwazaru': 'Iwazaru',
    'Travis': 'Travis',
    'Yoon-Hyun': 'Yoon-Hyun',
    'TV': 'TV',
    'ISZK String Quartet': 'Cuarteto ISZK',
    'Samantha': 'Samantha',
    'Squeaker`s Attack': 'Ataque Squeaker',
    'Loop da Loop': 'Loop da Loop',
    'Harman': 'Harman',
    'De Paul': 'De Paul',
    'H': 'H',
    'Car': 'Car',  # slot de 3 bytes útiles; no cabe «Coche».
    'Kisugi': 'Kisugi',
    'Ulmeyda Collection': 'Colección Ulmeyda',
    'Spinny-Spinny': 'Gira-Gira',
    'Gun': 'Gun',  # slot de 3 bytes útiles; no cabe «Arma».
    '206 Terry St.': '206 Terry St.',
    '220 Terry St.': '220 Terry St.',
    '210 Terry St.': '210 Terry St.',
    '219 Terry St.': '219 Terry St.',
    '209 Terry St.': '209 Terry St.',
    '218 Terry St.': '218 Terry St.',
    '208 Terry St.': '208 Terry St.',
    '217 Terry St.': '217 Terry St.',
    'Kurahashi & Akiba': 'Kurahashi & Akiba',
    'Susie': 'Susie',
    'Ulmeyda': 'Ulmeyda',
    'Curtis': 'Curtis',
    'Handsome Black': 'Handsome Black',
    'Keane': 'Keane',
})

# v1.7.7.113 — excepciones para la copia francesa del K7P2.
# «Cuarto de Harman» cabe en el slot francés de «Chambre d'Harman» (20 bytes),
# pero NO en el slot inglés de «Harman's Room» (16 bytes incluyendo terminador).
# Por eso se mantiene «Sala Harman» en el K7P2 primario y se usa la forma larga
# únicamente en el child francés del DAR.
_EUR_FRENCH_K7P2_TARGET_OVERRIDES = {
    # v1.7.7.122: la rama francesa usa «Hall» para los Hallway ingleses.
    # Se traduce como «Pasillo», igual que el K7P2 primario. La cadena ocupa
    # 7 bytes útiles y cabe directamente en el slot francés de 8 bytes, por lo
    # que estos casos ya no necesitan relocalización dentro del DAR.
    'Hall Way': 'Pasillo',
    'Hallway': 'Pasillo',
    'HallWay': 'Pasillo',
    'hallway': 'Pasillo',
    'Elevator Hall': 'Ascensores',
    "Harman' Room": 'Cuarto de Harman',
    "Harman Room": 'Cuarto de Harman',
    "Harman's Room": 'Cuarto de Harman',
    "Harman's room": 'Cuarto de Harman',

    # v1.7.7.116: formas completas para los rótulos que antes se abreviaban
    # para caber en los slots del K7P2 inglés. El child francés puede relocalizar
    # estas cadenas al padding seguro del DAR, así que no es necesario abreviarlas.
    '3F Library': 'Biblioteca 3F',
    'Alley': 'Callejón',
    'Bedroom': 'Dormitorio',
    'Blackburn Residence': 'Residencia Blackburn',
    'Burnig Hot Hell': 'Infierno ardiente',
    'Carrier Pigeon': 'Paloma mensajera',
    "Chairman's Room": 'Sala del presidente',
    'Church Entrance': 'Entrada de la iglesia',
    'Company Property': 'Propiedad de la empresa',
    'Deserted Building': 'Edificio abandonado',
    'Emergency Staircase': 'Escalera de emergencia',
    'Express Elevator': 'Ascensor exprés',
    'First Life Bldg': 'Edificio FirstLife',
    'Foyer': 'Vestíbulo',
    'Guesthouse': 'Casa de huéspedes',
    'Guestroom': 'Habitación de huéspedes',
    'Guestrooms': 'Habitaciones de huéspedes',
    'Library': 'Biblioteca',
    'Lobby': 'Vestíbulo',
    'Main Breaker': 'Cuadro principal',
    'Main House': 'Casa principal',
    'Operation Panel': 'Panel de operación',
    'Safe': 'Caja fuerte',
    'Security Terminal': 'Terminal de seguridad',
    'Shelves': 'Estanterías',
    'Stairs': 'Escaleras',
    'Storage Box': 'Caja de almacén',
    'Top-floor': 'Último piso',
    'Toy Dispenser': 'Expendedora de juguetes',
    'Vinculum Gate': 'Puerta Vinculum',
    'White Tiger': 'Tigre blanco',
}

# v1.7.7.135 — traducción completa de rótulos físicos del mapa.
# Se aplica tanto al catálogo visible como al child francés; las formas largas
# están autorizadas para relocalización dentro del padding seguro del DAR.
_EUR_K7P2_SPANISH_LABELS.update({'1F HallWay': 'Pasillo planta 1',
 '1st Floor': 'Planta 1',
 '2nd Floor': 'Planta 2',
 '3F Library': 'Biblioteca planta 3',
 '3rd Floor': 'Planta 3',
 '4F HallWay': 'Pasillo planta 4',
 '4th Floor': 'Planta 4',
 '5th Floor': 'Planta 5',
 'Alley': 'Callejón',
 'Arcade': 'Galería',
 'Attic': 'Ático',
 'Back Alley': 'Callejón trasero',
 'Basement': 'Sótano',
 'Bathroom': 'Baño',
 'Bathtub': 'Bañera',
 'Bedroom': 'Dormitorio',
 'Blackburn Residence': 'Residencia Blackburn',
 'Boiler Room': 'Sala de calderas',
 'Bridge': 'Puente',
 'Cafeteria': 'Cafetería',
 "Chairman's Room": 'Sala del presidente',
 'Child Entrance': 'Entrada infantil',
 'Church Entrance': 'Entrada de la iglesia',
 'Classroom': 'Aula',
 'Colosseum': 'Coliseo',
 'Company Property': 'Propiedad de la empresa',
 'Control Panel': 'Panel de control',
 'Control Room': 'Sala de control',
 'Corridor': 'Pasillo',
 'Courtyard': 'Patio',
 'Data Room': 'Sala de datos',
 'Desert': 'Desierto',
 'Deserted Building': 'Edificio abandonado',
 'Diner': 'Cafetería',
 'Door': 'Puerta',
 'Downstairs': 'Planta inferior',
 'East House': 'Casa este',
 'Elevator': 'Ascensor',
 'Elevator Hall': 'Ascensores',
 'Emergency Staircase': 'Escalera de emergencia',
 'Employee Passage': 'Pasillo de empleados',
 'Entrance': 'Entrada',
 'Entrance Gate': 'Puerta de entrada',
 'Entry Hall': 'Vestíbulo',
 'Express Elevator': 'Ascensor exprés',
 'First Life Bldg': 'Edificio FirstLife',
 'First Life Gate': 'Puerta FirstLife',
 'Forbidden Room': 'Sala prohibida',
 'Foyer': 'Vestíbulo',
 'Freaky Fun House': 'Casa de los horrores',
 'Garage': 'Garaje',
 'Garden': 'Jardín',
 'Gas Station': 'Gasolinera',
 'Gate': 'Puerta',
 'Grand Staircase': 'Gran escalera',
 'Great Hall': 'Gran salón',
 "Guard's Room": 'Sala de guardia',
 'Guesthouse': 'Casa de huéspedes',
 'Guestroom': 'Habitación de huéspedes',
 'Guestrooms': 'Habitaciones de huéspedes',
 'Gymnasium': 'Gimnasio',
 'Hall Way': 'Pasillo',
 'Hallway': 'Pasillo',
 'HallWay': 'Pasillo',
 'hallway': 'Pasillo',
 "Harman' Room": 'Cuarto de Harman',
 'Harman Room': 'Cuarto de Harman',
 "Harman's Room": 'Cuarto de Harman',
 "Harman's room": 'Cuarto de Harman',
 'Killer Mansion': 'Mansión Killer',
 'Kitchen': 'Cocina',
 "Ladies' Room": 'Aseo de mujeres',
 'Large Hall': 'Gran salón',
 'Library': 'Biblioteca',
 'Living': 'Salón',
 'Living Room': 'Salón',
 'Lobby': 'Vestíbulo',
 'Lounge': 'Salón',
 'Mah-jongg Room': 'Sala de mahjong',
 'Main House': 'Casa principal',
 'Main School Gate': 'Entrada principal del colegio',
 "Manager's Room": 'Despacho del gerente',
 'Meeting Room': 'Sala de reuniones',
 'Mountain Path': 'Sendero de montaña',
 'North House': 'Casa norte',
 'Outside': 'Exterior',
 "Owner's Room": 'Sala del propietario',
 'Parking': 'Aparcamiento',
 'Passage': 'Pasillo',
 'Pool': 'Piscina',
 'Poolside': 'Zona de piscina',
 'Post Office': 'Correos',
 "Principal's Office": 'Despacho del director',
 'Railroad': 'Ferrocarril',
 'Reception': 'Recepción',
 'Restroom': 'Aseo',
 'Road': 'Carretera',
 'Roof': 'Azotea',
 'Room': 'Sala',
 'Secret Passage': 'Pasadizo secreto',
 'Security': 'Seguridad',
 'Security Terminal': 'Terminal de seguridad',
 'South House': 'Casa sur',
 'Stage': 'Escenario',
 'Stairs': 'Escaleras',
 'Storage Box': 'Caja de almacén',
 'Storage Room': 'Almacén',
 'Strong Room': 'Cámara acorazada',
 'Suburb': 'Afueras',
 'Suite': 'Suite',
 'Terrace': 'Terraza',
 'Toilet': 'Aseo',
 "Trevor's Atelier": 'Taller de Trevor',
 "Trevor's House": 'Casa de Trevor',
 'Upstairs': 'Planta superior',
 'Vinculum Gate': 'Puerta Vinculum',
 'Wagon': 'Vagón',
 'Waiting Room': 'Sala de espera',
 'Warehouse': 'Almacén',
 'West House': 'Casa oeste',
 'Adventure Plaza': 'Plaza Aventura',
 'Burning Hot Hell': 'Infierno abrasador',
 'Cinema1': 'Cine 1',
 'Cinema2': 'Cine 2',
 'Cinema3': 'Cine 3',
 'Cinema4': 'Cine 4',
 'Room 105': 'Sala 105',
 'Room 203': 'Sala 203',
 'Room 207': 'Sala 207',
 'Room 212': 'Sala 212',
 'Room 301': 'Sala 301',
 'Room 306': 'Sala 306',
 'Room 307': 'Sala 307',
 'Room 401': 'Sala 401',
 'Room 404': 'Sala 404',
 'Room 406': 'Sala 406',
 'Room 502': 'Sala 502',
 'Room 601': 'Sala 601',
 'Second House': 'Casa 2',
 'Spinny-Spinny': 'Gira-Gira',
 'Squeaker`s Attack': 'Ataque de Squeaker',
 'Table': 'Mesa',
 'Terminal': 'Terminal',
 'Trophy': 'Trofeo'})
_EUR_FRENCH_K7P2_TARGET_OVERRIDES.update({'1F HallWay': 'Pasillo planta 1',
 '1st Floor': 'Planta 1',
 '2nd Floor': 'Planta 2',
 '3F Library': 'Biblioteca planta 3',
 '3rd Floor': 'Planta 3',
 '4F HallWay': 'Pasillo planta 4',
 '4th Floor': 'Planta 4',
 '5th Floor': 'Planta 5',
 'Alley': 'Callejón',
 'Arcade': 'Galería',
 'Attic': 'Ático',
 'Back Alley': 'Callejón trasero',
 'Basement': 'Sótano',
 'Bathroom': 'Baño',
 'Bathtub': 'Bañera',
 'Bedroom': 'Dormitorio',
 'Blackburn Residence': 'Residencia Blackburn',
 'Boiler Room': 'Sala de calderas',
 'Bridge': 'Puente',
 'Cafeteria': 'Cafetería',
 "Chairman's Room": 'Sala del presidente',
 'Child Entrance': 'Entrada infantil',
 'Church Entrance': 'Entrada de la iglesia',
 'Classroom': 'Aula',
 'Colosseum': 'Coliseo',
 'Company Property': 'Propiedad de la empresa',
 'Control Panel': 'Panel de control',
 'Control Room': 'Sala de control',
 'Corridor': 'Pasillo',
 'Courtyard': 'Patio',
 'Data Room': 'Sala de datos',
 'Desert': 'Desierto',
 'Deserted Building': 'Edificio abandonado',
 'Diner': 'Cafetería',
 'Door': 'Puerta',
 'Downstairs': 'Planta inferior',
 'East House': 'Casa este',
 'Elevator': 'Ascensor',
 'Elevator Hall': 'Ascensores',
 'Emergency Staircase': 'Escalera de emergencia',
 'Employee Passage': 'Pasillo de empleados',
 'Entrance': 'Entrada',
 'Entrance Gate': 'Puerta de entrada',
 'Entry Hall': 'Vestíbulo',
 'Express Elevator': 'Ascensor exprés',
 'First Life Bldg': 'Edificio FirstLife',
 'First Life Gate': 'Puerta FirstLife',
 'Forbidden Room': 'Sala prohibida',
 'Foyer': 'Vestíbulo',
 'Freaky Fun House': 'Casa de los horrores',
 'Garage': 'Garaje',
 'Garden': 'Jardín',
 'Gas Station': 'Gasolinera',
 'Gate': 'Puerta',
 'Grand Staircase': 'Gran escalera',
 'Great Hall': 'Gran salón',
 "Guard's Room": 'Sala de guardia',
 'Guesthouse': 'Casa de huéspedes',
 'Guestroom': 'Habitación de huéspedes',
 'Guestrooms': 'Habitaciones de huéspedes',
 'Gymnasium': 'Gimnasio',
 'Hall Way': 'Pasillo',
 'Hallway': 'Pasillo',
 'HallWay': 'Pasillo',
 'hallway': 'Pasillo',
 "Harman' Room": 'Cuarto de Harman',
 'Harman Room': 'Cuarto de Harman',
 "Harman's Room": 'Cuarto de Harman',
 "Harman's room": 'Cuarto de Harman',
 'Killer Mansion': 'Mansión Killer',
 'Kitchen': 'Cocina',
 "Ladies' Room": 'Aseo de mujeres',
 'Large Hall': 'Gran salón',
 'Library': 'Biblioteca',
 'Living': 'Salón',
 'Living Room': 'Salón',
 'Lobby': 'Vestíbulo',
 'Lounge': 'Salón',
 'Mah-jongg Room': 'Sala de mahjong',
 'Main House': 'Casa principal',
 'Main School Gate': 'Entrada principal del colegio',
 "Manager's Room": 'Despacho del gerente',
 'Meeting Room': 'Sala de reuniones',
 'Mountain Path': 'Sendero de montaña',
 'North House': 'Casa norte',
 'Outside': 'Exterior',
 "Owner's Room": 'Sala del propietario',
 'Parking': 'Aparcamiento',
 'Passage': 'Pasillo',
 'Pool': 'Piscina',
 'Poolside': 'Zona de piscina',
 'Post Office': 'Correos',
 "Principal's Office": 'Despacho del director',
 'Railroad': 'Ferrocarril',
 'Reception': 'Recepción',
 'Restroom': 'Aseo',
 'Road': 'Carretera',
 'Roof': 'Azotea',
 'Room': 'Sala',
 'Secret Passage': 'Pasadizo secreto',
 'Security': 'Seguridad',
 'Security Terminal': 'Terminal de seguridad',
 'South House': 'Casa sur',
 'Stage': 'Escenario',
 'Stairs': 'Escaleras',
 'Storage Box': 'Caja de almacén',
 'Storage Room': 'Almacén',
 'Strong Room': 'Cámara acorazada',
 'Suburb': 'Afueras',
 'Suite': 'Suite',
 'Terrace': 'Terraza',
 'Toilet': 'Aseo',
 "Trevor's Atelier": 'Taller de Trevor',
 "Trevor's House": 'Casa de Trevor',
 'Upstairs': 'Planta superior',
 'Vinculum Gate': 'Puerta Vinculum',
 'Wagon': 'Vagón',
 'Waiting Room': 'Sala de espera',
 'Warehouse': 'Almacén',
 'West House': 'Casa oeste',
 'Adventure Plaza': 'Plaza Aventura',
 'Burning Hot Hell': 'Infierno abrasador',
 'Cinema1': 'Cine 1',
 'Cinema2': 'Cine 2',
 'Cinema3': 'Cine 3',
 'Cinema4': 'Cine 4',
 'Room 105': 'Sala 105',
 'Room 203': 'Sala 203',
 'Room 207': 'Sala 207',
 'Room 212': 'Sala 212',
 'Room 301': 'Sala 301',
 'Room 306': 'Sala 306',
 'Room 307': 'Sala 307',
 'Room 401': 'Sala 401',
 'Room 404': 'Sala 404',
 'Room 406': 'Sala 406',
 'Room 502': 'Sala 502',
 'Room 601': 'Sala 601',
 'Second House': 'Casa 2',
 'Spinny-Spinny': 'Gira-Gira',
 'Squeaker`s Attack': 'Ataque de Squeaker',
 'Table': 'Mesa',
 'Terminal': 'Terminal',
 'Trophy': 'Trofeo'})

_EUR_K7P2_SPANISH_LABELS['Top-floor'] = 'Última planta'
_EUR_FRENCH_K7P2_TARGET_OVERRIDES['Top-floor'] = 'Última planta'

# Compatibilidad puntual: S119M no dispone de padding suficiente para la forma
# «Habitaciones de huéspedes». Se conserva una abreviatura española legible.
_EUR_K7P2_SPANISH_LABELS['Guestrooms'] = 'Hab. huéspedes'
_EUR_FRENCH_K7P2_TARGET_OVERRIDES['Guestrooms'] = 'Hab. huéspedes'

# Los targets completos del child francés pueden relocalizarse al padding entre
# child 2 y child 3 cuando no caben en el slot original. Sólo se redirige el
# value_ptr de la misma (section,key), sin tocar el contenido semántico de otros
# idiomas/children.
_EUR_FRENCH_K7P2_RELOCATABLE_TARGETS = set(_EUR_FRENCH_K7P2_TARGET_OVERRIDES.values())


# v1.7.7.162 — plantas numéricas K7P2.
#
# Estos rótulos aparecen en el child 2 francés de varios DAR (S130M..S775M).
# Aunque la capa K7P2 general ya los traduce por emparejado EN->FR, se mantiene
# una pasada dedicada que toma como referencia el child 0 inglés DEL MISMO DAR.
# Así `1er ´tage`/`2e ´tage`/... no puede sobrevivir en la ISO final por un
# cambio de orden, hash o catálogo de la capa general. Los cinco targets caben
# siempre en los slots de 12 bytes del juego original.
_EUR_NUMERIC_FLOOR_TARGETS = {
    '1st Floor': 'Planta 1',
    '2nd Floor': 'Planta 2',
    '3rd Floor': 'Planta 3',
    '4th Floor': 'Planta 4',
    '5th Floor': 'Planta 5',
}
_EUR_NUMERIC_FLOOR_EXPECTED_MIN_UNITS = 23
_EUR_FLOOR_FAMILY_TARGETS = {
    **_EUR_NUMERIC_FLOOR_TARGETS,
    'Top-floor': 'Última planta',
    'Upstairs': 'Planta superior',
    'Downstairs': 'Planta inferior',
}
_EUR_FLOOR_FAMILY_EXPECTED_MIN_UNITS = 37

# v1.7.7.47 — clasificación semántica de rótulos de lugares/zonas K7P2.
# Toda ruta NurbsPathName es una ubicación navegable. Para WinLocatorName añadimos
# los nombres espaciales aunque sólo aparezcan como punto interactivo/puerta.
_EUR_K7P2_PLACE_WORDS = (
    'room', 'hall', 'hallway', 'house', 'floor', 'entrance', 'gate', 'office',
    'passage', 'corridor', 'lobby', 'foyer', 'lounge', 'bedroom', 'bathroom',
    'kitchen', 'attic', 'basement', 'roof', 'garden', 'courtyard', 'warehouse',
    'garage', 'parking', 'station', 'path', 'road', 'alley', 'building', 'bldg',
    'residence', 'school', 'church', 'suite', 'reception', 'library', 'classroom',
    'gymnasium', 'cafeteria', 'diner', 'post office', 'mansion', 'pool', 'terrace',
    'outside', 'upstairs', 'downstairs', 'elevator', 'staircase', 'storage',
    'boiler', 'data', 'control', 'waiting', 'guest', 'principal', 'manager',
    'owner', 'chairman', 'ladies', 'guard', 'security', 'terminal', 'arcade',
    'colosseum', 'cinema', 'plaza', 'suburb', 'desert', 'property', 'railroad',
    'atelier', 'restroom', 'toilet', 'living',
)


def eur_k7p2_is_place_label(source: str, section: str = '') -> bool:
    """Indica si un rótulo K7P2 representa una ruta/lugar físico del escenario."""
    if str(section) == 'NurbsPathName':
        return True
    value = f' {str(source).casefold()} '
    return any(f' {word} ' in value or value.strip().startswith(word + ' ') or
               value.strip().endswith(' ' + word) or value.strip() == word
               for word in _EUR_K7P2_PLACE_WORDS)


# MapFontF tiene los mismos signos/accentos franceses que TVFontF. Los bytes de
# esos slots se mantienen; sólo sustituimos su dibujo por el carácter español.
_EUR_MAPFONT_ES_CODEMAP = {
    'Á': 'À', 'Í': 'Î', 'Ó': 'Ô', 'Ú': 'Û', 'Ñ': 'Â', 'Ü': 'Ù',
    'á': 'à', 'í': 'î', 'ó': 'ô', 'ú': 'û', 'ñ': 'â', 'ü': 'ê',
}

def _eur_mapfont_encode_spanish(text: str) -> bytes:
    remapped = ''.join(_EUR_MAPFONT_ES_CODEMAP.get(ch, ch) for ch in str(text))
    try:
        return remapped.encode('latin-1')
    except UnicodeEncodeError as exc:
        raise K7Error(f'MapFontF EUR: carácter no soportado en {text!r}: {exc}') from exc


def _eur_detect_all_k7p2_english_labels(afs, raw_entries, names):
    """Detecta los rótulos K7P2 ingleses sin modificar ningún payload.

    En PAL, el K7P2 standalone/child 0 sirve como referencia inglesa para
    emparejar ``(section, key)`` con el child 2 francés. Desde v1.7.7.130 esta
    fase es estrictamente de lectura: el inglés se detecta y se informa, pero
    nunca se inserta en ``replacements``.
    """
    detected_entries = 0
    detected_units = 0
    labels = set()
    place_labels = set()
    place_units = 0
    indices = []
    for idx, (_off, size) in enumerate(raw_entries):
        if size <= 0 or size > 200000:
            continue
        original = _eur_read_entry(afs, raw_entries, idx)
        if not original.startswith(b'K7P2'):
            continue
        rows = Killer7Project._parse_k7p2_name_tables(original)
        rows = [r for r in rows if r.get('section') in ('NurbsPathName', 'WinLocatorName')]
        if not rows:
            continue
        detected_entries += 1
        indices.append(idx)
        seen_offsets = set()
        for row in rows:
            off = int(row['value_offset'])
            if off in seen_offsets:
                continue
            seen_offsets.add(off)
            source = str(row['value'])
            detected_units += 1
            labels.add(source)
            if eur_k7p2_is_place_label(source, str(row.get('section', ''))):
                place_units += 1
                place_labels.add(source)
    return {
        'entries': detected_entries,
        'units': detected_units,
        'unique_labels': len(labels),
        'labels': sorted(labels),
        'place_units': place_units,
        'place_unique_labels': len(place_labels),
        'place_labels': sorted(place_labels),
        'english_primary_indices': indices,
        'mode': 'detect-only',
        'note': 'K7P2 inglés detectado como referencia; no se modifica ningún K7P2 primario/inglés.',
    }


def _eur_patch_all_k7p2_labels(afs, raw_entries, names, replacements):
    """Traduce todos los rótulos funcionales K7P2 que caben en su slot.

    Opera sobre el payload ya reemplazado, si existe, para conservar las traducciones
    K7P2 antiguas (Hallway/Parking) y extenderlas al resto de localizadores. También
    actualiza el espejo K7P2 dentro del DAR inmediato cuando es único.
    """
    changed_entries = 0
    changed_units = 0
    mirror_entries = 0
    labels = set()
    preserved = set()
    place_labels = set()
    place_units = 0
    place_preserved = set()
    count = len(raw_entries)

    for idx, (_off, size) in enumerate(raw_entries):
        if size <= 0 or size > 200000:
            continue
        original = _eur_read_entry(afs, raw_entries, idx)
        base = replacements.get(idx, original)
        if not base.startswith(b'K7P2'):
            continue
        rows = Killer7Project._parse_k7p2_name_tables(base)
        if not rows:
            continue

        patched = bytearray(base)
        seen_offsets = set()
        local_changes = 0
        for row in rows:
            if row.get('section') not in ('NurbsPathName', 'WinLocatorName'):
                continue
            off = int(row['value_offset'])
            if off in seen_offsets:
                continue
            seen_offsets.add(off)
            source = row['value']
            target = _EUR_K7P2_SPANISH_LABELS.get(source)
            is_place = eur_k7p2_is_place_label(source, str(row.get('section', '')))
            if target is None or target == source:
                if source not in _EUR_K7P2_SPANISH_LABELS:
                    preserved.add(source)
                if is_place:
                    place_preserved.add(source)
                continue
            target_b = _eur_mapfont_encode_spanish(target)
            slot = int(row['slot'])
            if len(target_b) > slot - 1:
                raise K7Error(
                    f'Base EUR: K7P2 {source!r}->{target!r} no cabe: '
                    f'{len(target_b)} bytes > {slot - 1}.'
                )
            payload = target_b + b'\0' * (slot - len(target_b))
            patched[off:off + slot] = payload
            local_changes += 1
            labels.add((source, target))
            if is_place:
                place_units += 1
                place_labels.add((source, target))

        if not local_changes:
            continue

        patched_b = bytes(patched)
        replacements[idx] = patched_b
        changed_entries += 1
        changed_units += local_changes

        # El recurso activo suele llevar un DAR inmediato con una única copia exacta.
        # Si ya fue parcheado por la capa K7P2 anterior, buscamos el payload `base`;
        # si no, buscamos el original.
        if idx + 1 < count:
            mirror_original = _eur_read_entry(afs, raw_entries, idx + 1)
            mirror_base = replacements.get(idx + 1, mirror_original)
            if mirror_base.startswith(b'DAR\0'):
                pos = mirror_base.find(base)
                needle = base
                if pos < 0 and base != original:
                    pos = mirror_base.find(original)
                    needle = original
                if pos >= 0 and mirror_base.find(needle, pos + 1) < 0:
                    m = bytearray(mirror_base)
                    m[pos:pos + len(needle)] = patched_b
                    replacements[idx + 1] = bytes(m)
                    mirror_entries += 1

    return {
        'entries': changed_entries,
        'units': changed_units,
        'mirrors': mirror_entries,
        'unique_labels': len(labels),
        'labels': [{'source': a, 'target': b} for a, b in sorted(labels)],
        'place_units': int(place_units),
        'place_unique_labels': len(place_labels),
        'place_labels': [{'source': a, 'target': b} for a, b in sorted(place_labels)],
        'place_preserved': sorted(place_preserved),
        'preserved_unmapped': sorted(preserved),
        'encoding': 'Latin-1 remapeado a MapFontF ES',
    }


# v1.7.7.111 — K7P2 localizado dentro del DAR EUR.
#
# En los escenarios PAL el K7P2 standalone/child 0 es la referencia inglesa,
# mientras que el K7P2 del child 2 contiene los rótulos franceses que realmente
# usa la rama F (p. ej. Hall, Chambre d'Harman, Hall d'ascenseur).  Las dos tablas
# comparten section+key, aunque sus strings y tamaños de slot pueden ser distintos.
def _eur_dar_child_ranges(raw: bytes) -> list[tuple[int, int]]:
    """Devuelve (offset, size) de un DAR estándar EUR, validando sus límites."""
    if len(raw) < 0x80 or raw[:4] != b'DAR\0':
        return []
    try:
        child_count = struct.unpack_from('<I', raw, 8)[0]
    except struct.error:
        return []
    # La cabecera observada reserva ocho offsets en 0x10 y ocho tamaños en 0x30.
    if not (1 <= child_count <= 8):
        return []
    try:
        offsets = struct.unpack_from('<' + 'I' * child_count, raw, 0x10)
        sizes = struct.unpack_from('<' + 'I' * child_count, raw, 0x30)
    except struct.error:
        return []
    out = []
    for off, size in zip(offsets, sizes):
        off = int(off)
        size = int(size)
        if off < 0x80 or size <= 0 or off + size > len(raw):
            return []
        out.append((off, size))
    return out


def _eur_parse_localized_k7p2_name_tables(raw: bytes) -> list[dict]:
    """Parser K7P2 de nombres localizado (Latin-1), equivalente al parser ASCII base.

    El parser histórico de :class:`Killer7Project` se detiene ante É/é/à/etc.,
    algo correcto para la rama USA pero insuficiente para los children FR/DE.
    Aquí sólo exponemos las dos tablas de nombres que necesitamos parchear.
    """
    if len(raw) < 0x38 or raw[:4] != b'K7P2':
        return []

    def cstr(offset: int) -> str | None:
        if not (0 <= int(offset) < len(raw)):
            return None
        end = raw.find(b'\0', int(offset))
        if end < 0:
            return None
        try:
            return raw[int(offset):end].decode('latin-1')
        except UnicodeDecodeError:
            return None

    try:
        section_count = struct.unpack_from('<I', raw, 0x0C)[0]
    except struct.error:
        return []
    if not (1 <= section_count <= 16) or 0x20 + section_count * 8 > len(raw):
        return []

    wanted_sections = {'NurbsPathName', 'WinLocatorName'}
    out = []
    for si in range(section_count):
        name_ptr, table_ptr = struct.unpack_from('<II', raw, 0x20 + si * 8)
        section = cstr(name_ptr)
        if section not in wanted_sections:
            continue
        q = int(table_ptr)
        seen_pairs = set()
        for _ in range(4096):
            if q + 4 > len(raw):
                break
            pair_ptr = struct.unpack_from('<I', raw, q)[0]
            q += 4
            if pair_ptr == 0:
                break
            if pair_ptr in seen_pairs or pair_ptr + 8 > len(raw):
                break
            seen_pairs.add(pair_ptr)
            key_ptr, value_ptr = struct.unpack_from('<II', raw, pair_ptr)
            key = cstr(key_ptr)
            value = cstr(value_ptr)
            if key is None or value is None:
                break
            slot = (len(value.encode('latin-1')) + 1 + 3) & ~3
            if value_ptr + slot > len(raw):
                break
            out.append({
                'section': section, 'key': key, 'value': value,
                'pair_offset': int(pair_ptr), 'value_offset': int(value_ptr),
                'slot': int(slot),
            })
    return out



def _eur_force_numeric_floor_labels(afs, raw_entries, names, replacements):
    """Fuerza todos los `Nth Floor` del child FR a ``Planta N``.

    A diferencia del parche K7P2 general, esta guarda no depende de la entrada
    K7P2 standalone situada antes del DAR. Lee child 0 (EN) y child 2 (FR) del
    propio contenedor, los empareja por ``(section,key)`` y escribe únicamente
    el value del child francés. En la base EUR verificada hay 23 unidades.
    """
    seen_units = 0
    changed_units = 0
    already_units = 0
    changed_entries = 0
    details = []

    for idx, (_off, size) in enumerate(raw_entries):
        if size <= 0 or size > 200000:
            continue
        original = _eur_read_entry(afs, raw_entries, idx)
        current = replacements.get(idx, original)
        if not current.startswith(b'DAR\0'):
            continue
        ranges = _eur_dar_child_ranges(current)
        if len(ranges) <= 2:
            continue
        en_off, en_size = ranges[0]
        fr_off, fr_size = ranges[2]
        en_child = current[en_off:en_off + en_size]
        fr_child = current[fr_off:fr_off + fr_size]
        if not (en_child.startswith(b'K7P2') and fr_child.startswith(b'K7P2')):
            continue

        en_rows = _eur_parse_localized_k7p2_name_tables(en_child)
        fr_rows = _eur_parse_localized_k7p2_name_tables(fr_child)
        if not en_rows or not fr_rows:
            continue
        fr_map = {(str(r['section']), str(r['key'])): r for r in fr_rows}
        patched = bytearray(current)
        local_changes = 0

        for en_row in en_rows:
            source = str(en_row.get('value', ''))
            target = _EUR_NUMERIC_FLOOR_TARGETS.get(source)
            if target is None:
                continue
            row_key = (str(en_row['section']), str(en_row['key']))
            fr_row = fr_map.get(row_key)
            if fr_row is None:
                raise K7Error(
                    f'Plantas EUR: falta la unidad FR {row_key!r} en AFS #{idx} '
                    f'{names[idx] if idx < len(names) else ""!r}.'
                )
            seen_units += 1
            target_b = _eur_mapfont_encode_spanish(target)
            slot = int(fr_row['slot'])
            if len(target_b) > slot - 1:
                raise K7Error(
                    f'Plantas EUR: {target!r} no cabe en AFS #{idx} '
                    f'{row_key[0]}/{row_key[1]} (slot={slot}).'
                )
            absolute = int(fr_off) + int(fr_row['value_offset'])
            before = bytes(patched[absolute:absolute + slot])
            payload = target_b + b'\0' * (slot - len(target_b))
            before_text = str(fr_row.get('value', ''))
            if before == payload:
                already_units += 1
            else:
                patched[absolute:absolute + slot] = payload
                local_changes += 1
                changed_units += 1
            details.append({
                'afs_index': int(idx),
                'name': names[idx] if idx < len(names) else '',
                'section': row_key[0], 'key': row_key[1],
                'english': source, 'before': before_text, 'target': target,
            })

        if local_changes:
            # Verificación inmediata del DAR ya escrito: los punteros y slots no
            # cambian, por lo que basta con volver a parsear child 2.
            verify_ranges = _eur_dar_child_ranges(bytes(patched))
            voff, vsize = verify_ranges[2]
            verify_rows = _eur_parse_localized_k7p2_name_tables(
                bytes(patched[voff:voff + vsize])
            )
            verify_map = {(str(r['section']), str(r['key'])): str(r['value']) for r in verify_rows}
            for item in details:
                if int(item['afs_index']) != idx:
                    continue
                key = (str(item['section']), str(item['key']))
                if verify_map.get(key) != item['target']:
                    raise K7Error(
                        f'Plantas EUR: round-trip fallido en AFS #{idx} {key!r}: '
                        f'{verify_map.get(key)!r} != {item["target"]!r}.'
                    )
            replacements[idx] = bytes(patched)
            changed_entries += 1

    if seen_units < _EUR_NUMERIC_FLOOR_EXPECTED_MIN_UNITS:
        raise K7Error(
            'Plantas EUR: sólo se localizaron '
            f'{seen_units} unidades numéricas; se esperaban al menos '
            f'{_EUR_NUMERIC_FLOOR_EXPECTED_MIN_UNITS}.'
        )

    # Auditoría final sobre el estado combinado (original + replacements).
    remaining = []
    verified = 0
    for item in details:
        idx = int(item['afs_index'])
        current = replacements.get(idx)
        if current is None:
            current = _eur_read_entry(afs, raw_entries, idx)
        ranges = _eur_dar_child_ranges(current)
        fr_off, fr_size = ranges[2]
        rows = _eur_parse_localized_k7p2_name_tables(current[fr_off:fr_off + fr_size])
        row_map = {(str(r['section']), str(r['key'])): str(r['value']) for r in rows}
        key = (str(item['section']), str(item['key']))
        actual = row_map.get(key)
        if actual == item['target']:
            verified += 1
        else:
            remaining.append({**item, 'actual': actual})
    if remaining:
        sample = ', '.join(
            f"#{r['afs_index']} {r['name']} {r['key']}={r.get('actual')!r}"
            for r in remaining[:8]
        )
        raise K7Error(f'Plantas EUR: quedaron rótulos sin traducir: {sample}')

    return {
        'expected_min_units': _EUR_NUMERIC_FLOOR_EXPECTED_MIN_UNITS,
        'units': seen_units,
        'verified_units': verified,
        'changed_units': changed_units,
        'already_spanish_units': already_units,
        'changed_entries': changed_entries,
        'targets': dict(_EUR_NUMERIC_FLOOR_TARGETS),
        'details': details,
        'matching': 'DAR child0 EN -> child2 FR por section+key',
        'encoding': 'MapFontF ES',
    }



def _eur_verify_floor_family_labels(afs, raw_entries, names, replacements):
    """Verifica en bytes la familia completa de rótulos de plantas K7P2.

    Incluye los 23 niveles numéricos, ``Top-floor`` y los accesos
    ``Upstairs``/``Downstairs``. La comparación se hace contra los bytes
    MapFontF reales para aceptar los slots donantes usados por Ú/acentos.
    """
    seen = 0
    verified = 0
    details = []
    failures = []
    for idx, (_off, size) in enumerate(raw_entries):
        if size <= 0 or size > 200000:
            continue
        current = replacements.get(idx)
        if current is None:
            current = _eur_read_entry(afs, raw_entries, idx)
        if not current.startswith(b'DAR\0'):
            continue
        ranges = _eur_dar_child_ranges(current)
        if len(ranges) <= 2:
            continue
        en_off, en_size = ranges[0]
        fr_off, fr_size = ranges[2]
        en_child = current[en_off:en_off + en_size]
        fr_child = current[fr_off:fr_off + fr_size]
        if not (en_child.startswith(b'K7P2') and fr_child.startswith(b'K7P2')):
            continue
        en_rows = _eur_parse_localized_k7p2_name_tables(en_child)
        fr_rows = _eur_parse_localized_k7p2_name_tables(fr_child)
        fr_map = {(str(r['section']), str(r['key'])): r for r in fr_rows}
        for en_row in en_rows:
            source = str(en_row.get('value', ''))
            target = _EUR_FLOOR_FAMILY_TARGETS.get(source)
            if target is None:
                continue
            seen += 1
            key = (str(en_row['section']), str(en_row['key']))
            fr_row = fr_map.get(key)
            if fr_row is None:
                failures.append((idx, names[idx] if idx < len(names) else '', key, source, target, None))
                continue
            absolute = int(fr_off) + int(fr_row['value_offset'])
            slot = int(fr_row['slot'])
            actual = bytes(current[absolute:absolute + slot]).split(b'\0', 1)[0]
            expected = _eur_mapfont_encode_spanish(target)
            details.append({
                'afs_index': int(idx), 'name': names[idx] if idx < len(names) else '',
                'section': key[0], 'key': key[1], 'english': source,
                'target': target, 'target_hex': expected.hex().upper(),
            })
            if actual == expected:
                verified += 1
            else:
                failures.append((idx, names[idx] if idx < len(names) else '', key, source, target, actual.hex().upper()))
    if seen < _EUR_FLOOR_FAMILY_EXPECTED_MIN_UNITS:
        raise K7Error(
            f'Plantas EUR: sólo se localizaron {seen} rótulos de la familia completa; '
            f'se esperaban al menos {_EUR_FLOOR_FAMILY_EXPECTED_MIN_UNITS}.'
        )
    if failures:
        sample = '; '.join(
            f'#{idx} {name} {key[0]}/{key[1]} {src!r}->{target!r} actual={actual!r}'
            for idx, name, key, src, target, actual in failures[:8]
        )
        raise K7Error(f'Plantas EUR: verificación final fallida: {sample}')
    return {
        'units': seen,
        'verified_units': verified,
        'expected_min_units': _EUR_FLOOR_FAMILY_EXPECTED_MIN_UNITS,
        'targets': dict(_EUR_FLOOR_FAMILY_TARGETS),
        'details': details,
        'comparison': 'bytes MapFontF finales en child 2 FR',
    }

def _eur_verify_numeric_floor_label_constants() -> dict:
    """Guarda estática para empaquetado/startup de v1.7.7.162."""
    encoded = {src: _eur_mapfont_encode_spanish(dst) for src, dst in _EUR_FLOOR_FAMILY_TARGETS.items()}
    for src, payload in encoded.items():
        if src in _EUR_NUMERIC_FLOOR_TARGETS and len(payload) > 11:
            raise K7Error(f'Plantas EUR: target numérico demasiado largo para slot de 12 bytes: {src!r}.')
    return {
        'targets': dict(_EUR_FLOOR_FAMILY_TARGETS),
        'encoded_hex': {k: v.hex().upper() for k, v in encoded.items()},
        'expected_min_units': _EUR_FLOOR_FAMILY_EXPECTED_MIN_UNITS,
    }


def _eur_patch_french_k7p2_children(afs, raw_entries, names, replacements):
    """Propaga los targets K7P2 al child francés (índice 2) del DAR inmediato.

    El emparejado es semántico/estructural: ``(section, key)``. Nunca se supone que
    el string francés tenga el mismo offset, longitud o texto que el inglés. Desde
    v1.7.7.130 el K7P2 primario inglés es estrictamente de sólo lectura: proporciona
    la clave semántica y el target se obtiene de ``_EUR_K7P2_SPANISH_LABELS`` o de
    las excepciones francesas verificadas. Sólo se escribe el child 2 francés.

    Si un target no cabe en el slot francés se conserva el original y se informa;
    no se desplazan estructuras internas ni se escribe fuera del slot.
    """
    changed_entries = 0
    changed_units = 0
    matched_units = 0
    unchanged_units = 0
    french_entries = 0
    unmapped_units = 0
    overflow_rows = []
    unmatched_rows = []
    labels = set()
    relocated_entries = 0
    shifted_child2_entries = 0
    shifted_child3_entries = 0
    dar_growth_bytes = 0
    source_counts = {}
    count = len(raw_entries)

    for idx, (_off, size) in enumerate(raw_entries):
        if size <= 0 or size > 200000 or idx + 1 >= count:
            continue

        original_primary = _eur_read_entry(afs, raw_entries, idx)
        if not original_primary.startswith(b'K7P2'):
            continue
        original_rows = [
            r for r in Killer7Project._parse_k7p2_name_tables(original_primary)
            if r.get('section') in ('NurbsPathName', 'WinLocatorName')
        ]
        if not original_rows:
            continue

        # El primario es la referencia inglesa y se mantiene byte por byte intacto.
        # No dependemos de un payload inglés previamente traducido: el source EN
        # sólo identifica la unidad que después se escribe en el child 2 francés.
        current_primary = original_primary
        original_map = {(str(r['section']), str(r['key'])): r for r in original_rows}

        dar_original = _eur_read_entry(afs, raw_entries, idx + 1)
        dar_current = replacements.get(idx + 1, dar_original)
        ranges = _eur_dar_child_ranges(dar_current)
        if len(ranges) <= 2:
            continue
        fr_off, fr_size = ranges[2]
        french_child = dar_current[fr_off:fr_off + fr_size]
        if not french_child.startswith(b'K7P2'):
            continue
        french_rows = _eur_parse_localized_k7p2_name_tables(french_child)
        if not french_rows:
            # Algunos escenarios EUR tienen un child 2 K7P2 sin estas tablas.
            continue

        french_entries += 1
        patched_dar = bytearray(dar_current)
        local_changes = 0

        # El child 2 suele terminar antes del child 3 y el DAR conserva padding
        # de alineación entre ambos. Para targets franceses concretos que no caben
        # en el slot original, reservamos una sola
        # copia de la cadena en ese padding y redirigimos los value_ptr. No se mueve
        # ningún child ni cambia el tamaño total del DAR/AFS.
        next_child_off = ranges[3][0] if len(ranges) > 3 else len(dar_current)
        french_declared_size = int(fr_size)
        relocation_cursor = int(fr_size)
        relocated_targets = {}

        for fr_row in french_rows:
            row_key = (str(fr_row['section']), str(fr_row['key']))
            original_row = original_map.get(row_key)
            if original_row is None:
                unmatched_rows.append({
                    'afs_index': idx + 1,
                    'name': names[idx + 1] if idx + 1 < len(names) else '',
                    'section': row_key[0], 'key': row_key[1],
                    'french': str(fr_row.get('value', '')),
                })
                continue

            english_source = str(original_row['value'])
            mapped_target = _EUR_K7P2_SPANISH_LABELS.get(english_source)
            french_override = _EUR_FRENCH_K7P2_TARGET_OVERRIDES.get(english_source)

            # El inglés sólo se usa como source de detección. La traducción se
            # codifica directamente para MapFontF y se escribe únicamente en FR.
            semantic_target = french_override if french_override is not None else mapped_target
            if semantic_target is None:
                unmapped_units += 1
                continue
            target_b = _eur_mapfont_encode_spanish(semantic_target)

            fr_source = str(fr_row['value'])
            source_counts[fr_source] = int(source_counts.get(fr_source, 0)) + 1
            matched_units += 1
            slot = int(fr_row['slot'])
            if len(target_b) > slot - 1:
                # Algunos strings franceses tienen slots muy pequeños aunque el
                # DAR reserve padding después del child. Para los targets aprobados
                # como relocalizables, almacenamos una única copia allí y cambiamos
                # el value_ptr de cada par (key,value) a la nueva posición.
                if str(semantic_target) in _EUR_FRENCH_K7P2_RELOCATABLE_TARGETS:
                    target_key = bytes(target_b)
                    new_rel = relocated_targets.get(target_key)
                    if new_rel is None:
                        allocation = (len(target_b) + 1 + 3) & ~3
                        new_size = relocation_cursor + allocation
                        if fr_off + new_size > int(next_child_off):
                            # Si el padding entre child 2 y child 3 es menor que la
                            # reserva necesaria, desplazamos el último child (alemán)
                            # unos pocos bytes hacia delante. Sólo consumimos padding
                            # cero; si falta cola, el DAR puede crecer lo mínimo.
                            # Sus bytes y tamaño declarado permanecen intactos.
                            # v1.7.7.116: si una relocalización anterior ya
                            # desplazó el child 3, hay que usar su offset ACTUAL.
                            # `ranges` describe el DAR original y reutilizarlo aquí
                            # hacía que la segunda relocalización viera el child 3
                            # desplazado como «padding no nulo».
                            child3_off = int(next_child_off)
                            child3_size = int(ranges[3][1])
                            required_shift = fr_off + new_size - child3_off
                            old_child3_end = child3_off + child3_size
                            between = bytes(patched_dar[fr_off + french_declared_size:child3_off])
                            tail = bytes(patched_dar[old_child3_end:])
                            if any(between) or any(tail):
                                overflow_rows.append({
                                    'afs_index': idx + 1,
                                    'name': names[idx + 1] if idx + 1 < len(names) else '',
                                    'section': row_key[0], 'key': row_key[1],
                                    'english': english_source, 'french': fr_source,
                                    'target': str(semantic_target),
                                    'target_bytes': len(target_b), 'slot_bytes': slot,
                                    'reason': 'padding DAR no nulo; relocalización cancelada',
                                })
                                continue
                            # Si la cola posterior al child 3 no basta para
                            # desplazarlo, recuperamos primero los pocos bytes que
                            # falten moviendo el child francés hacia atrás dentro
                            # del padding cero que ya existe entre child 1 y child 2.
                            tail_space = len(patched_dar) - old_child3_end
                            pre_shift = max(0, required_shift - tail_space)
                            if pre_shift:
                                child1_off, child1_size = ranges[1]
                                child1_end = int(child1_off) + int(child1_size)
                                available_before = fr_off - child1_end
                                before_padding = bytes(patched_dar[child1_end:fr_off])
                                if pre_shift > available_before or any(before_padding):
                                    overflow_rows.append({
                                        'afs_index': idx + 1,
                                        'name': names[idx + 1] if idx + 1 < len(names) else '',
                                        'section': row_key[0], 'key': row_key[1],
                                        'english': english_source, 'french': fr_source,
                                        'target': str(semantic_target),
                                        'target_bytes': len(target_b), 'slot_bytes': slot,
                                        'reason': 'sin padding DAR suficiente para desplazar child 2/3',
                                    })
                                    continue
                                child2_payload = bytes(
                                    patched_dar[fr_off:fr_off + french_declared_size]
                                )
                                old_fr_off = fr_off
                                fr_off = old_fr_off - pre_shift
                                patched_dar[fr_off:fr_off + french_declared_size] = child2_payload
                                patched_dar[fr_off + french_declared_size:
                                            old_fr_off + french_declared_size] = b'\0' * pre_shift
                                struct.pack_into('<I', patched_dar, 0x10 + 2 * 4, int(fr_off))
                                required_shift -= pre_shift
                                shifted_child2_entries += 1

                            child3_payload = bytes(patched_dar[child3_off:old_child3_end])
                            new_child3_off = child3_off + required_shift
                            needed_len = new_child3_off + child3_size
                            if needed_len > len(patched_dar):
                                # En bases verificadas no debe ocurrir: preferimos
                                # no hacer crecer el DAR/AFS de forma silenciosa.
                                overflow_rows.append({
                                    'afs_index': idx + 1,
                                    'name': names[idx + 1] if idx + 1 < len(names) else '',
                                    'section': row_key[0], 'key': row_key[1],
                                    'english': english_source, 'french': fr_source,
                                    'target': str(semantic_target),
                                    'target_bytes': len(target_b), 'slot_bytes': slot,
                                    'reason': 'desplazamiento excedería el tamaño del DAR',
                                })
                                continue
                            patched_dar[child3_off:new_child3_off + child3_size] = (
                                b'\0' * (required_shift + child3_size)
                            )
                            patched_dar[new_child3_off:new_child3_off + child3_size] = child3_payload
                            struct.pack_into('<I', patched_dar, 0x10 + 3 * 4, new_child3_off)
                            next_child_off = new_child3_off
                            shifted_child3_entries += 1

                        new_rel = relocation_cursor
                        abs_new = fr_off + new_rel
                        patched_dar[abs_new:abs_new + allocation] = (
                            target_b + b'\0' * (allocation - len(target_b))
                        )
                        relocation_cursor = new_size
                        french_declared_size = max(french_declared_size, new_size)
                        relocated_targets[target_key] = new_rel
                        relocated_entries += 1

                    pair_value_ptr = fr_off + int(fr_row['pair_offset']) + 4
                    old_ptr = struct.unpack_from('<I', patched_dar, pair_value_ptr)[0]
                    if old_ptr != int(new_rel):
                        struct.pack_into('<I', patched_dar, pair_value_ptr, int(new_rel))
                        local_changes += 1
                        changed_units += 1
                        labels.add((english_source, fr_source, str(semantic_target)))
                    else:
                        unchanged_units += 1
                    continue

                overflow_rows.append({
                    'afs_index': idx + 1,
                    'name': names[idx + 1] if idx + 1 < len(names) else '',
                    'section': row_key[0], 'key': row_key[1],
                    'english': english_source, 'french': fr_source,
                    'target': str(semantic_target),
                    'target_bytes': len(target_b), 'slot_bytes': slot,
                })
                continue

            rel = int(fr_row['value_offset'])
            absolute = fr_off + rel
            payload = target_b + b'\0' * (slot - len(target_b))
            before = bytes(patched_dar[absolute:absolute + slot])
            if before == payload:
                unchanged_units += 1
                continue
            patched_dar[absolute:absolute + slot] = payload
            local_changes += 1
            changed_units += 1
            labels.add((english_source, fr_source, str(semantic_target)))

        # Si usamos padding para strings relocalizados, el único metadato que hay
        # que ampliar es sizes[2] de la cabecera DAR (tabla de tamaños en 0x30).
        # El offset de child 3 permanece idéntico.
        if french_declared_size != int(fr_size):
            struct.pack_into('<I', patched_dar, 0x30 + 2 * 4, int(french_declared_size))

        if local_changes:
            replacements[idx + 1] = bytes(patched_dar)
            changed_entries += 1

    return {
        'child_index': 2,
        'dar_entries_seen': french_entries,
        'entries': changed_entries,
        'matched_units': matched_units,
        'units': changed_units,
        'unchanged_units': unchanged_units,
        'overflow_units': len(overflow_rows),
        'unmapped_units': unmapped_units,
        'unmatched_units': len(unmatched_rows),
        'relocated_targets': relocated_entries,
        'shifted_child2_entries': shifted_child2_entries,
        'shifted_child3_entries': shifted_child3_entries,
        'dar_growth_bytes': dar_growth_bytes,
        'unique_changes': len(labels),
        'labels': [
            {'english': en, 'french': fr, 'target': es}
            for en, fr, es in sorted(labels)
        ],
        'source_counts': dict(sorted(source_counts.items())),
        'overflows': overflow_rows,
        'unmatched': unmatched_rows,
        'matching': 'section + key',
        'encoding': 'source EN detectado + MapFontF ES en child FR',
    }


# v1.7.7.25 — Pantallas iniciales EUR: payload GS corregido (idioma + 50/60 Hz).
#
# Estos textos NO son cadenas DIRECTO ni usan una tabla de glifos en tiempo de
# ejecución: vienen horneados como texturas 4bpp dentro de selLang.dic y
# selLangAnser. Para que el resultado sea determinista en cualquier PC del usuario,
# distribuimos los dos recursos ya recompilados y verificamos el SHA-256 de la base
# francesa antes de sustituirlos.
_EUR_SELLANG_BASE = {
    'eurgb60_f.dic': {
        'afs_index': 3870,
        'sha256': '6c16f90df586fee710c582be759f1f53e0648ad189662c3ef5294b818dbb8c82',
        'size': 33260,
        'patched_file': 'euRGB60_f_ES.dic',
        'patched_sha256': 'f96e52cbcacd2bb6a6d2ded45bb20d83b89a2aa3d164f728e263d6332e52a370',
        'previous_patched_sha256': 'e7783faac5a5b8bc434407b99c7226eb04e5525ae42d6aff11c7f34cd394b965',
        'textures': ['euRGB60_F'],
    },
    'sellang.dic': {
        'afs_index': 3896,
        'sha256': '5c0686749477155b5d0975ed272dfde33440721e460e7f4445febc4b2218a01d',
        'size': 267660,
        'patched_file': 'selLang_ES.dic',
        'patched_sha256': 'dea1827312918b8d61541a2c7b2ec17c043205e2dfcf2cc9255bba69ad86aaad',
        # v1.7.7.54 sustituye `sel` por la captura española aportada por el usuario.
        # Aceptamos tanto v1.7.7.53 como la revisión histórica anterior para que
        # «Inyectar Textos» pueda actualizar una ISO ya parcheada.
        'previous_patched_sha256': 'dad23667612967383ef75586673ee9e28fc1f5946ddd5d7b19146052f2d6bbe3',
        'previous_patched_sha256s': [
            '90c34937a56de4daeaf31eae162ea95db9d7f1cebc6882305f6ec24f7134b311',
        ],
        'source_png': 'language_select_ES.png',
        'source_png_sha256': '40b88fdfefc2067c97489b0e7597cf5a032d6d8debaafa9e7164a304a97f98b4',
        'textures': ['sel', 'PS2_60HzF', 'PS2_50HzF', 'euRGB60F'],
    },
    'sellanganser.': {
        'afs_index': 3897,
        'sha256': 'e4576968c37a8b2920e2dbf8a1bc13ab558a53ad4488d181a6bd5d1c9a1bfbce',
        'size': 133404,
        'patched_file': 'selLangAnser_ES.bin',
        'patched_sha256': '05e767c5c4144d855a7c4737b687bed7b2bf49038e9a1be5086ce4eabbc771cf',
        'previous_patched_sha256': '220e60e3bf437963a039efc41bed603f2165bf7ecf3fd039a55fba861fbb7b12',
        'textures': ['euRGB60F'],
    },
}


def _eur_patch_sellang_graphics(afs, raw_entries, name_to_indices, replacements) -> dict:
    """Sustituye las pantallas francesas de idioma y PAL/NTSC por español.

    euRGB60_f.dic contiene una copia independiente de la confirmación.
    selLang.dic contiene `sel`, `PS2_60HzF`, `PS2_50HzF` y `euRGB60F`;
    selLangAnser. repite `euRGB60F` para la pantalla de confirmación.
    Los recursos recompilados conservan exactamente el tamaño de los originales.
    """
    base_dir = resource_path('resources', 'eur_base')
    applied = []
    for norm_name, spec in _EUR_SELLANG_BASE.items():
        hits = name_to_indices.get(norm_name, [])
        if len(hits) != 1:
            raise K7Error(f'Base EUR: se esperaba un único {norm_name}: {hits}.')
        idx = hits[0]
        original = _eur_read_entry(afs, raw_entries, idx)
        if len(original) != int(spec['size']):
            raise K7Error(
                f'Base EUR: {norm_name} mide {len(original)} bytes; '
                f'se esperaban {spec["size"]}.'
            )
        digest = hashlib.sha256(original).hexdigest()
        compatible = {
            str(spec['sha256']), str(spec['patched_sha256']),
            str(spec.get('previous_patched_sha256') or ''),
        }
        compatible.update(str(x) for x in spec.get('previous_patched_sha256s', []) if x)
        if digest not in compatible:
            raise K7Error(
                f'Base EUR: {norm_name} no coincide con una revisión verificada '
                f'(SHA-256 {digest}).'
            )
        source_png = spec.get('source_png')
        if source_png:
            source_path = base_dir / str(source_png)
            if not source_path.is_file():
                raise K7Error(f'Falta la imagen fuente española integrada: {source_path}.')
            source_digest = hashlib.sha256(source_path.read_bytes()).hexdigest()
            if source_digest != str(spec.get('source_png_sha256') or ''):
                raise K7Error(
                    f'Pantalla EUR ES: {source_path.name} no supera su SHA-256 integrado.'
                )
        patched_path = base_dir / spec['patched_file']
        if not patched_path.is_file():
            raise K7Error(f'Falta el recurso español integrado: {patched_path}.')
        patched = patched_path.read_bytes()
        if len(patched) != len(original):
            raise K7Error(f'Pantalla EUR ES: {patched_path.name} cambió de tamaño.')
        pdigest = hashlib.sha256(patched).hexdigest()
        if pdigest != spec['patched_sha256']:
            raise K7Error(
                f'Pantalla EUR ES: {patched_path.name} no supera su SHA-256 integrado.'
            )
        replacements[idx] = patched
        applied.append({
            'afs_index': idx,
            'name': norm_name,
            'size': len(patched),
            'sha256_before': digest,
            'sha256_after': pdigest,
        })
    return {
        'resources': applied,
        'textures': [
            {'resource': 'euRGB60_f.dic', 'texture': 'euRGB60_F', 'target': 'Confirmación 50/60 Hz en español (copia independiente)'},
            {'resource': 'selLang.dic', 'texture': 'sel', 'target': 'Seleccionar idioma español'},
            {'resource': 'selLang.dic', 'texture': 'PS2_60HzF', 'target': 'Ajustar pantalla a NTSC (60 Hz).'},
            {'resource': 'selLang.dic', 'texture': 'PS2_50HzF', 'target': 'Ajustar pantalla a PAL (50 Hz).'},
            {'resource': 'selLang.dic', 'texture': 'euRGB60F', 'target': 'Confirmación 50/60 Hz en español'},
            {'resource': 'selLangAnser.', 'texture': 'euRGB60F', 'target': 'Confirmación 50/60 Hz en español'},
        ],
        'baked_graphics': True,
        'size_unchanged': True,
    }



# v1.7.7.56 — índice gráfico de explan_f.dat traducido al español.
#
# AFS #302 `explan_f.dat` contiene una textura DIC 4bpp llamada `Tutorial`
# (256x256). Es el índice con Infos générales / Infos combat / Infos sang /
# Heaven Smile1 / Heaven Smile2 / Données préc. Conservamos el arte y sustituimos
# sólo las etiquetas francesas por Info general / Info combate / Info sangre /
# Datos prev. mediante un PNG integrado, cuantizado contra la CLUT original.
_EUR_EXPLAN_TUTORIAL_AFS_INDEX = 302
_EUR_EXPLAN_TUTORIAL_AFS_NAME = 'explan_f.dat'
_EUR_EXPLAN_TUTORIAL_TEXTURE = 'Tutorial'
_EUR_EXPLAN_TUTORIAL_ES_FILE = 'explan_f_Tutorial_ES.png'
_EUR_EXPLAN_TUTORIAL_ES_SHA256 = 'fb631f929ba2c60806e047dc9e39b0dacf9c82d920a080295c8675de61f23aef'
_EUR_EXPLAN_TUTORIAL_ORIGINAL_SHA256 = 'b955911b775da1e925018121c6c7972aa102b6129f692d89517584a5d9b30860'
_EUR_EXPLAN_TUTORIAL_PATCHED_SHA256 = 'c17920def651617c18344ddf698efb1186b997e35dff1f01526ce7d742c61980'
_EUR_EXPLAN_MENU_LABELS_PATCHED_SHA256 = '27ad682299e3d38ed1a8f3aa3ee629377486cf3803e2fe4aaf0c0559e655e2b8'


def _eur_patch_explan_tutorial_graphic(afs, raw_entries, name_to_indices, replacements) -> dict:
    """Traduce el índice gráfico `Tutorial` de explan_f.dat sin cambiar tamaños."""
    hits = name_to_indices.get(_EUR_EXPLAN_TUTORIAL_AFS_NAME.lower(), [])
    if len(hits) != 1:
        raise K7Error(
            f'Base EUR: se esperaba un único {_EUR_EXPLAN_TUTORIAL_AFS_NAME}: {hits}.'
        )
    idx = hits[0]
    if idx != _EUR_EXPLAN_TUTORIAL_AFS_INDEX:
        raise K7Error(
            f'Base EUR: {_EUR_EXPLAN_TUTORIAL_AFS_NAME} está en AFS #{idx}; '
            f'se esperaba #{_EUR_EXPLAN_TUTORIAL_AFS_INDEX}.'
        )
    original = _eur_read_entry(afs, raw_entries, idx)
    digest = hashlib.sha256(original).hexdigest()
    if digest not in (
        _EUR_EXPLAN_TUTORIAL_ORIGINAL_SHA256,
        _EUR_EXPLAN_TUTORIAL_PATCHED_SHA256,
        _EUR_EXPLAN_MENU_LABELS_PATCHED_SHA256,
    ):
        # Las revisiones v186+ pueden tener un SHA global nuevo por las secuencias
        # del child 1. Se aceptan únicamente si el layout y todas las cadenas del
        # child 1 son reconocibles por el parche estructural estricto.
        try:
            _eur_patch_explan_menu_labels_blob(original)
        except Exception as exc:
            raise K7Error(
                f'Base EUR: {_EUR_EXPLAN_TUTORIAL_AFS_NAME} no coincide con una revisión '
                f'verificada (SHA-256 {digest}).'
            ) from exc

    asset = resource_path('resources', 'eur_base') / _EUR_EXPLAN_TUTORIAL_ES_FILE
    if not asset.is_file():
        raise K7Error(f'Falta el índice tutorial español integrado: {asset}.')
    asset_sha = hashlib.sha256(asset.read_bytes()).hexdigest()
    if asset_sha != _EUR_EXPLAN_TUTORIAL_ES_SHA256:
        raise K7Error('Base EUR: el PNG español de explan_f/Tutorial no supera su SHA-256.')

    current = replacements.get(idx, original)
    sub_off, sub = _eur_text_image_named_subresource(current, _EUR_EXPLAN_TUTORIAL_TEXTURE)
    info = Killer7Project._dic_texture_info(sub)
    if not info or (int(info['width']), int(info['height']), int(info['bpp'])) != (256, 256, 4):
        raise K7Error('Base EUR: explan_f.dat/Tutorial no es una textura DIC 256x256 4bpp válida.')
    new_sub = _eur_encode_png_into_dic(sub, asset, (256, 256))
    check = Killer7Project.decode_dic_texture_preview(new_sub)
    if check.size != (256, 256):
        raise K7Error('Base EUR: explan_f.dat/Tutorial no supera el round-trip gráfico.')

    buf = bytearray(current)
    buf[sub_off:sub_off + len(new_sub)] = new_sub
    patched = bytes(buf)
    if len(patched) != len(original):
        raise K7Error('Base EUR: explan_f.dat cambió de tamaño al traducir Tutorial.')
    pdigest = hashlib.sha256(patched).hexdigest()
    if pdigest not in (
        _EUR_EXPLAN_TUTORIAL_PATCHED_SHA256,
        _EUR_EXPLAN_MENU_LABELS_PATCHED_SHA256,
    ):
        try:
            _eur_patch_explan_menu_labels_blob(patched)
        except Exception as exc:
            raise K7Error(
                'Base EUR: explan_f.dat/Tutorial produjo una revisión estructural no validada '
                f'(SHA-256 {pdigest}).'
            ) from exc
    replacements[idx] = patched
    return {
        'afs_index': idx,
        'afs_name': _EUR_EXPLAN_TUTORIAL_AFS_NAME,
        'texture': _EUR_EXPLAN_TUTORIAL_TEXTURE,
        'png': _EUR_EXPLAN_TUTORIAL_ES_FILE,
        'size': [256, 256],
        'bpp': 4,
        'sha256_asset': asset_sha,
        'sha256_before': digest,
        'sha256_after': pdigest,
        'entry_size': len(patched),
        'labels': [
            {'source': 'Infos générales', 'target': 'Info general'},
            {'source': 'Infos combat', 'target': 'Info combate'},
            {'source': 'Infos sang', 'target': 'Info sangre'},
            {'source': 'Données préc.', 'target': 'Datos prev.'},
        ],
        'preserved': ['Heaven Smile1', 'Heaven Smile2'],
    }


# v1.7.7.185/186 — rótulos del child 1 del menú de ayuda `explan_f.dat`.
#
# El savestate s(10) confirmó que la lista de la izquierda no está rasterizada en
# `Tutorial`: vive en el child 1 del DAR y usa una tabla compacta de índices de
# glifo de 16 bits. Cada rótulo termina en -2 y el resto del slot es -1.
# Se reutiliza exclusivamente el atlas retail `exmes`; s(10) confirma al menos 47
# glifos (códigos 0..46). No cambian DIC, fParams, offsets DAR ni tamaño del AFS.
_EUR_EXPLAN_MENU_CHAR_CODES = {
    'M': 0, 'o': 1, 'u': 2, 'v': 3, 'e': 4, 'm': 5, 'n': 6, 't': 7,
    'J': 8, 'c': 9, 'i': 10, 's': 11, 'S': 12, 'a': 13, 'd': 14,
    'l': 15, 'é': 16, 'P': 17, 'r': 18, 'O': 19, 'b': 20, 'j': 21,
    'C': 22, 'L': 23, 'p': 24, 'y': 25, 'h': 26, 'R': 27, "'": 28,
    'H': 29, 'w': 30, '-': 31, 'F': 32, 'q': 33, 'A': 34, 'D': 35,
    'K': 36, 'k': 37, 'g': 38, '(': 39, 'N': 40, '+': 41, ')': 42,
    'G': 43, 'B': 44, 'U': 45, 'I': 46,
}

# v1.7.7.186: child 1 completo. Los códigos 30..46 se confirmaron también
# directamente en s(10), por lo que no es necesario redibujar ni ampliar `exmes`.
# Las traducciones evitan letras acentuadas que el atlas retail no contiene
# (por ejemplo, "Recuperacion"/"Absorcion"), preservando el recurso in-place.
_EUR_EXPLAN_MENU_LABEL_SPECS = (
    # Lista izquierda localizada en v185.
    ('Mouvement', 'Movimiento'),
    ('Jonctions', 'Cruces'),
    ('Stats de vitalité', 'Salud'),
    ('Personnalités', 'Personalidades'),
    ('Objets', 'Objetos'),
    ('Cartes', 'Mapas'),
    ('Les personnalités multiples', 'Personalidades varias'),
    ('Psychés Restantes', 'Restos de almas'),
    ("Chambre d'Harman", 'Cuarto de Harman'),
    ('Portier', 'Portero'),

    # Tutoriales restantes del mismo child 1 / atlas exmes.
    ('Combat au pistolet', 'Combate con pistola'),
    ('Post-scan', 'Postescaneo'),
    ('Faiblesse', 'Debilidad'),
    ('Rétablissement', 'Recuperacion'),
    ('Récupération du corps', 'Recuperacion del cuerpo'),
    ('Contre-attaque', 'Contraataque'),
    ('Attaques spéciales de Dan', 'Ataques especiales de Dan'),
    ('Attaques spéciales de Kaede', 'Ataques especiales de Kaede'),
    ('Attaques spéciales de Mask', 'Ataques especiales de Mask'),
    ('Attaques spéciales de Coyote', 'Ataques especiales de Coyote'),
    ('Attaques spéciales de Kevin', 'Ataques especiales de Kevin'),
    ('Sang', 'Sangre'),
    ('Absorption de sang', 'Absorcion de sangre'),
    ('Personnalités naissantes', 'Nuevas personalidades'),
    ('Développement (Niveau +)', 'Desarrollo (Nivel +)'),
    ('Sur les aptitudes spéciales', 'Sobre habilidades especiales'),
    ('Garcian (aptitudes spéciales)', 'Garcian (habilidades especiales)'),
    ('Kaede (aptitudes spéciales)', 'Kaede (habilidades especiales)'),
    ('Con (aptitudes spéciales)', 'Con (habilidades especiales)'),
    ('Coyote (aptitudes spéciales)', 'Coyote (habilidades especiales)'),
    ('Kevin (aptitudes spéciales)', 'Kevin (habilidades especiales)'),
)


def _eur_explan_menu_encode(text: str) -> list[int]:
    out: list[int] = []
    for ch in text:
        if ch == ' ':
            out.append(-4)
            continue
        try:
            out.append(int(_EUR_EXPLAN_MENU_CHAR_CODES[ch]))
        except KeyError as exc:
            raise K7Error(
                f'explan_f.dat EUR: falta glifo de menú para {ch!r} en {text!r}.'
            ) from exc
    return out


def _eur_patch_explan_menu_labels_blob(raw: bytes) -> tuple[bytes, dict]:
    """Traduce todos los rótulos franceses confirmados del child 1.

    La función busca cada secuencia francesa completa (incluido terminador -2),
    exige una única coincidencia y sólo escribe sobre esa misma zona de índices.
    También acepta el resultado ya parcheado para que la inyección sea idempotente.
    """
    ranges = _eur_dar_child_ranges(raw)
    expected_ranges = [(0x80, 0x18CB8), (0x18D80, 0x87A0), (0x21580, 0x10DC0)]
    if ranges != expected_ranges:
        raise K7Error(
            'explan_f.dat EUR: layout DAR inesperado para los rótulos de ayuda; '
            f'obtenido={ranges!r}.'
        )

    child_off, child_size = ranges[1]
    child_end = int(child_off) + int(child_size)
    out = bytearray(raw)
    before = bytes(raw)
    patches = []
    allowed_spans: list[tuple[int, int]] = []

    for source, target in _EUR_EXPLAN_MENU_LABEL_SPECS:
        source_codes = _eur_explan_menu_encode(source)
        target_codes = _eur_explan_menu_encode(target)
        source_pat = struct.pack(
            '<' + 'h' * (len(source_codes) + 1), *(source_codes + [-2])
        )
        target_pat = struct.pack(
            '<' + 'h' * (len(target_codes) + 1), *(target_codes + [-2])
        )
        region = bytes(out[child_off:child_end])
        source_hits = []
        start = 0
        while True:
            pos = region.find(source_pat, start)
            if pos < 0:
                break
            source_hits.append(int(child_off) + pos)
            start = pos + 1
        target_hits = []
        start = 0
        while True:
            pos = region.find(target_pat, start)
            if pos < 0:
                break
            target_hits.append(int(child_off) + pos)
            start = pos + 1

        already = False
        if len(source_hits) == 1:
            abs_off = source_hits[0]
        elif len(source_hits) == 0 and len(target_hits) == 1:
            abs_off = target_hits[0]
            already = True
        else:
            raise K7Error(
                f'explan_f.dat EUR: rótulo ambiguo {source!r}; '
                f'source_hits={source_hits!r}, target_hits={target_hits!r}.'
            )

        # Sólo necesitamos limpiar hasta el final de la cadena más larga. El
        # parser se detiene en -2 y los shorts restantes vuelven a -1.
        short_count = max(len(source_codes), len(target_codes)) + 1
        span = short_count * 2
        if abs_off < child_off or abs_off + span > child_end:
            raise K7Error(f'explan_f.dat EUR: slot fuera de rango para {source!r}.')
        allowed_spans.append((abs_off, abs_off + span))
        if not already:
            # Si el español es más largo, sólo puede crecer sobre shorts de relleno
            # -1 que seguían al terminador francés. Así nunca invadimos metadatos.
            if len(target_codes) > len(source_codes):
                for pos_i in range(len(source_codes) + 1, len(target_codes) + 1):
                    old_v = struct.unpack_from('<h', before, abs_off + pos_i * 2)[0]
                    if old_v != -1:
                        raise K7Error(
                            f'explan_f.dat EUR: {source!r} no tiene relleno suficiente '
                            f'para {target!r} (short +{pos_i}: {old_v}).'
                        )
            vals = target_codes + [-2] + [-1] * (short_count - len(target_codes) - 1)
            struct.pack_into('<' + 'h' * short_count, out, abs_off, *vals)

        patches.append({
            'source': source,
            'target': target,
            'offset': int(abs_off),
            'source_codes': list(source_codes),
            'target_codes': list(target_codes),
            'already_patched': bool(already),
        })

    result = bytes(out)
    if len(result) != len(raw):
        raise K7Error('explan_f.dat EUR: los rótulos cambiaron el tamaño del recurso.')

    # No puede modificarse ningún byte fuera de las secuencias seleccionadas.
    allowed = bytearray(len(result))
    for a, b in allowed_spans:
        allowed[a:b] = b'\x01' * (b - a)
    for i, (old_b, new_b) in enumerate(zip(before, result)):
        if old_b != new_b and not allowed[i]:
            raise K7Error(f'explan_f.dat EUR: cambio fuera de rótulos en 0x{i:X}.')

    # Readback: todos los targets deben existir exactamente una vez con terminador.
    child = result[child_off:child_end]
    for item in patches:
        tc = list(item['target_codes'])
        pat = struct.pack('<' + 'h' * (len(tc) + 1), *(tc + [-2]))
        if child.count(pat) != 1:
            raise K7Error(
                f"explan_f.dat EUR: readback falló para {item['target']!r}."
            )

    return result, {
        'resource': _EUR_EXPLAN_TUTORIAL_AFS_NAME,
        'dar_child': 1,
        'patched_count': len(patches),
        'same_size': True,
        'patches': patches,
    }


# v1.7.7.190 — textos del child 2 de `explan_f.dat` / atlas `exlog`.
#
# s(10) confirmó 54 slots terminados en -2 dentro del child 2. Cincuenta y tres
# son rótulos franceses que pueden localizarse con el alfabeto retail `exlog`;
# `Jean DePaul` se conserva como nombre propio. Cada slot dispone de relleno -1,
# por lo que las traducciones se escriben in-place sin tocar atlas, offsets DAR
# ni tamaño del recurso.
_EUR_EXPLAN_LOG_CHAR_CODES = {
    'I': 0, 'n': 1, 't': 2, 'r': 3, 'o': 4, 'd': 5, 'u': 6, 'c': 7,
    'i': 8, 'L': 9, "'": 10, 'e': 11, 'm': 12, 'G': 13, 'a': 14,
    'D': 15, 's': 16, '2': 17, 'U': 18, 'C': 19, ',': 20, 'p': 21,
    'l': 22, 'b': 23, 'è': 24, 'P': 25, 'ô': 26, 'E': 27, 'é': 28,
    'h': 29, 'f': 30, 'A': 31, 'q': 32, 'T': 33, 'J': 34, 'M': 35,
    'B': 36, 'V': 37, 'S': 38, 'g': 39, 'y': 40, 'É': 41, 'R': 42,
    'j': 43, 'à': 44, 'v': 45, 'F': 46,
}

# source, target, número de apariciones retail esperadas en child 2.
_EUR_EXPLAN_CHILD2_LABEL_SPECS = (
    ('Introduction', 'Introduccion', 1),
    ("L'ennemi", 'El enemigo', 1),
    ('Garant', 'Garante', 1),
    ('Destruction du nid', 'Destruccion del nido', 2),
    ("L'ennemi 2", 'El enemigo 2', 1),
    ('Lui', 'El', 1),
    ('Une cassure', 'Una grieta', 3),
    ('Cadenas', 'Candado', 1),
    ('Lui, 2e partie', 'El, 2a parte', 1),
    ('Destruction de la barrière', 'Destruccion de barrera', 1),
    ('Portier', 'Portero', 1),
    ('Dôme', 'Cupula', 1),
    ('Entrée', 'Entrada', 6),
    ('Cuisine', 'Cocina', 1),
    ('Chef sushi', 'Chef de sushi', 1),
    ('Assassin', 'Asesino', 1),
    ('Distributeur automatique', 'Maquina dispensadora', 1),
    ('Trou dans le plafond', 'Agujero en el techo', 2),
    ('Dispositif de sécurité', 'Dispositivo de seguridad', 2),
    ('Patrie', 'Patria', 1),
    ('Impatient', 'Impaciente', 1),
    ('Coiffeuse', 'Peluquera', 1),
    ('Murs fissurés', 'Muros agrietados', 1),
    ('Ballons', 'Globos', 1),
    ('Villa de Ted le tueur', 'Villa de Ted el asesino', 1),
    ('Destruction de la statue', 'Destruccion de la estatua', 1),
    ('Cheminée', 'Chimenea', 1),
    ('Eau de piscine', 'Agua de piscina', 1),
    ("Stratagème de l'artiste", 'Estratagema del artista', 1),
    ("D'après l'employée de bureau", 'Segun la oficinista', 1),
    ('Ville perdue', 'Ciudad perdida', 1),
    ('Barrière', 'Barrera', 1),
    ('Église RDC', 'Iglesia planta baja', 1),
    ('Directeur adjoint', 'Subdirector', 1),
    ("Atelier d'art", 'Taller de arte', 1),
    ('Moulin à vent', 'Molino de viento', 2),
    ('Bain électrique', 'Bano electrico', 1),
    ('Forcer le verrou', 'Abrir la cerradura', 1),
    ('Passage de roses', 'Paso de rosas', 1),
    ('Toilettes', 'Aseos', 1),
    ('Tableau noir', 'Tablero negro', 1),
    ('Dernier avertissement', 'Ultimo aviso', 1),
)
_EUR_EXPLAN_CHILD2_PRESERVED = ('Jean DePaul',)


def _eur_explan_log_encode(text: str) -> list[int]:
    out: list[int] = []
    for ch in text:
        if ch == ' ':
            out.append(-4)
            continue
        try:
            out.append(int(_EUR_EXPLAN_LOG_CHAR_CODES[ch]))
        except KeyError as exc:
            raise K7Error(
                f'explan_f.dat EUR child 2: falta glifo exlog para {ch!r} en {text!r}.'
            ) from exc
    return out


def _eur_explan_find_short_pattern(region: bytes, values: list[int]) -> list[int]:
    pat = struct.pack('<' + 'h' * len(values), *values)
    hits: list[int] = []
    start = 0
    while True:
        pos = region.find(pat, start)
        if pos < 0:
            break
        if pos % 2 == 0:
            hits.append(pos)
        start = pos + 2
    return hits


def _eur_patch_explan_child2_labels_blob(raw: bytes) -> tuple[bytes, dict]:
    """Traduce los rótulos franceses confirmados del child 2 / `exlog`.

    Se parchean todas las apariciones esperadas de cada source. El cambio sólo
    puede crecer sobre relleno -1 del propio slot y la función es idempotente.
    `Jean DePaul` se comprueba y conserva byte por byte.
    """
    ranges = _eur_dar_child_ranges(raw)
    expected_ranges = [(0x80, 0x18CB8), (0x18D80, 0x87A0), (0x21580, 0x10DC0)]
    if ranges != expected_ranges:
        raise K7Error(
            'explan_f.dat EUR: layout DAR inesperado para child 2; '
            f'obtenido={ranges!r}.'
        )

    child_off, child_size = ranges[2]
    child_end = int(child_off) + int(child_size)
    before = bytes(raw)
    out = bytearray(raw)
    patches = []
    allowed_spans: list[tuple[int, int]] = []

    for source, target, expected_count in _EUR_EXPLAN_CHILD2_LABEL_SPECS:
        source_codes = _eur_explan_log_encode(source)
        target_codes = _eur_explan_log_encode(target)
        source_vals = source_codes + [-2]
        target_vals = target_codes + [-2]
        region = bytes(out[child_off:child_end])
        source_hits_rel = _eur_explan_find_short_pattern(region, source_vals)
        target_hits_rel = _eur_explan_find_short_pattern(region, target_vals)

        if len(source_hits_rel) == int(expected_count) and not target_hits_rel:
            hit_rels = source_hits_rel
            already = False
        elif not source_hits_rel and len(target_hits_rel) == int(expected_count):
            hit_rels = target_hits_rel
            already = True
        else:
            raise K7Error(
                f'explan_f.dat EUR child 2: coincidencias inesperadas para {source!r}; '
                f'source={source_hits_rel!r}, target={target_hits_rel!r}, '
                f'esperadas={expected_count}.'
            )

        item_offsets = []
        for rel in hit_rels:
            abs_off = int(child_off) + int(rel)
            short_count = max(len(source_codes), len(target_codes)) + 1
            span = short_count * 2
            if abs_off < child_off or abs_off + span > child_end:
                raise K7Error(
                    f'explan_f.dat EUR child 2: slot fuera de rango para {source!r}.'
                )
            allowed_spans.append((abs_off, abs_off + span))
            item_offsets.append(abs_off)

            if not already:
                if len(target_codes) > len(source_codes):
                    for pos_i in range(len(source_codes) + 1, len(target_codes) + 1):
                        old_v = struct.unpack_from('<h', before, abs_off + pos_i * 2)[0]
                        if old_v != -1:
                            raise K7Error(
                                f'explan_f.dat EUR child 2: {source!r} no tiene relleno '
                                f'para {target!r} (short +{pos_i}: {old_v}).'
                            )
                vals = target_codes + [-2] + [-1] * (
                    short_count - len(target_codes) - 1
                )
                struct.pack_into('<' + 'h' * short_count, out, abs_off, *vals)

        patches.append({
            'source': source,
            'target': target,
            'offsets': item_offsets,
            'count': int(expected_count),
            'already_patched': bool(already),
        })

    result = bytes(out)
    if len(result) != len(raw):
        raise K7Error('explan_f.dat EUR child 2: cambió el tamaño del recurso.')

    allowed = bytearray(len(result))
    for a, b in allowed_spans:
        allowed[a:b] = b'\x01' * (b - a)
    for i, (old_b, new_b) in enumerate(zip(before, result)):
        if old_b != new_b and not allowed[i]:
            raise K7Error(
                f'explan_f.dat EUR child 2: cambio fuera de rótulos en 0x{i:X}.'
            )

    child = result[child_off:child_end]
    translated_occurrences = 0
    for source, target, expected_count in _EUR_EXPLAN_CHILD2_LABEL_SPECS:
        target_codes = _eur_explan_log_encode(target)
        hits = _eur_explan_find_short_pattern(child, target_codes + [-2])
        if len(hits) != int(expected_count):
            raise K7Error(
                f'explan_f.dat EUR child 2: readback falló para {target!r}: {hits!r}.'
            )
        translated_occurrences += int(expected_count)

    preserved = []
    for text in _EUR_EXPLAN_CHILD2_PRESERVED:
        codes = _eur_explan_log_encode(text)
        hits = _eur_explan_find_short_pattern(child, codes + [-2])
        if len(hits) != 1:
            raise K7Error(
                f'explan_f.dat EUR child 2: nombre propio {text!r} inesperado: {hits!r}.'
            )
        preserved.append({'text': text, 'offset': int(child_off) + hits[0]})

    return result, {
        'resource': _EUR_EXPLAN_TUTORIAL_AFS_NAME,
        'dar_child': 2,
        'patched_unique': len(_EUR_EXPLAN_CHILD2_LABEL_SPECS),
        'patched_occurrences': translated_occurrences,
        'same_size': True,
        'patches': patches,
        'preserved': preserved,
    }


def _eur_patch_explan_child2_labels(afs, raw_entries, name_to_indices, replacements) -> dict:
    hits = name_to_indices.get(_EUR_EXPLAN_TUTORIAL_AFS_NAME.lower(), [])
    if len(hits) != 1:
        raise K7Error(
            f'Base EUR: se esperaba un único {_EUR_EXPLAN_TUTORIAL_AFS_NAME}: {hits}.'
        )
    idx = int(hits[0])
    if idx != _EUR_EXPLAN_TUTORIAL_AFS_INDEX:
        raise K7Error(
            f'Base EUR: {_EUR_EXPLAN_TUTORIAL_AFS_NAME} está en AFS #{idx}; '
            f'se esperaba #{_EUR_EXPLAN_TUTORIAL_AFS_INDEX}.'
        )
    original = _eur_read_entry(afs, raw_entries, idx)
    current = replacements.get(idx, original)
    digest = hashlib.sha256(current).hexdigest()
    patched, info = _eur_patch_explan_child2_labels_blob(current)
    pdigest = hashlib.sha256(patched).hexdigest()
    replacements[idx] = patched
    info['afs_index'] = idx
    info['sha256_before'] = digest
    info['sha256_after'] = pdigest
    return info


def _eur_patch_explan_menu_labels(afs, raw_entries, name_to_indices, replacements) -> dict:
    hits = name_to_indices.get(_EUR_EXPLAN_TUTORIAL_AFS_NAME.lower(), [])
    if len(hits) != 1:
        raise K7Error(
            f'Base EUR: se esperaba un único {_EUR_EXPLAN_TUTORIAL_AFS_NAME}: {hits}.'
        )
    idx = int(hits[0])
    if idx != _EUR_EXPLAN_TUTORIAL_AFS_INDEX:
        raise K7Error(
            f'Base EUR: {_EUR_EXPLAN_TUTORIAL_AFS_NAME} está en AFS #{idx}; '
            f'se esperaba #{_EUR_EXPLAN_TUTORIAL_AFS_INDEX}.'
        )
    original = _eur_read_entry(afs, raw_entries, idx)
    current = replacements.get(idx, original)
    digest = hashlib.sha256(current).hexdigest()
    # v186 ya no depende de un SHA global para este recurso: la validación fuerte
    # se hace sobre el layout DAR exacto, las 31 secuencias source/target únicas,
    # el tamaño invariable y la prohibición de escribir fuera de sus spans.
    patched, info = _eur_patch_explan_menu_labels_blob(current)
    pdigest = hashlib.sha256(patched).hexdigest()
    replacements[idx] = patched
    info['afs_index'] = idx
    info['sha256_before'] = digest
    info['sha256_after'] = pdigest
    return info


# v1.7.7.52 — aviso inicial español integrado en «Inyectar Textos».
#
# El original francés vive en AFS #3884 logo.dic / gulo_F (1024x128, 4 bpp).
# El PNG se conserva como fuente editable y se cuantiza contra la CLUT oficial del
# propio gulo_F en el momento de reconstruir DIR_E.AFS. Así mantenemos exactamente
# el layout GS, la paleta y el tamaño del recurso europeo.
_EUR_ADULT_WARNING_AFS_INDEX = 3884
_EUR_ADULT_WARNING_AFS_NAME = 'logo.dic'
_EUR_ADULT_WARNING_TEXTURE = 'gulo_F'
_EUR_ADULT_WARNING_ES_FILE = 'adult_warning_ES.png'
_EUR_ADULT_WARNING_ES_SHA256 = 'acb0a7c653cef93b98839140e8b4f0072d819335e915d2dace70965c25ffb29f'

# v1.7.7.56 / v1.7.7.78 — atlas principal francés de menú (Sp/Special).
#
# Ambos recursos comprimidos contienen una textura `sub` 1024x512 8bpp. Desde
# v1.7.7.85 la integración automática actualiza las dos ramas que selecciona
# SLES_533.66: #2945 Sp_f_60.bin para 60 Hz y #2950 Special_f.b para 50 Hz.
# Ambos LZ pueden crecer; DIR_E.AFS se reconstruye con offsets/tamaños nuevos.
_EUR_SPECIAL_MENU_GRAPHICS = (
    {
        'spec_id': 'special_menu_sp60',
        'afs_index': 2945,
        'afs_name': 'Sp_f_60.bin',
    },
    {
        'spec_id': 'special_menu_special',
        'afs_index': 2950,
        'afs_name': 'Special_f.b',
    },
)


# v1.7.7.85 — mapa 60 Hz de los mismos 17 rótulos de Special/sub.
# SLES_533.66 selecciona AFS #2945 (Sp_f_60.bin) cuando el flag de vídeo de
# `0x1FDF00` es distinto de cero, y #2950 (Special_f.b) cuando es cero.
# Los rectángulos siguientes son las UV alternativas del atlas de 60 Hz,
# emparejadas por quad con las regiones de `_eur_special_sub_text_specs_from_sles`.
_EUR_SPECIAL_SP60_PARTS = (
    ((192, 97, 543, 148),),
    ((851, 61, 898, 103), (930, 60, 990, 102)),
    ((801, 161, 844, 203), (880, 160, 930, 202)),
    ((800, 125, 880, 167), (880, 125, 1024, 167)),
    ((800, 197, 846, 239), (850, 196, 1024, 238)),
    ((800, 233, 880, 275), (880, 233, 958, 275)),
    ((800, 270, 838, 312), (842, 269, 880, 311), (880, 268, 918, 310), (930, 269, 982, 311)),
    ((801, 312, 849, 348), (851, 312, 1007, 348)),
    ((800, 386, 1013, 411),),
    ((800, 419, 1013, 444),),
    ((800, 447, 1013, 480),),
    ((800, 480, 1013, 511),),
    ((364, 316, 544, 342),),
    ((364, 342, 544, 368),),
    ((364, 368, 544, 394),),
    ((364, 394, 544, 420),),
    ((364, 420, 544, 446),),
 )

def _eur_special_sp60_parts_for_spec(spec: dict) -> list[tuple[int, int, int, int]] | None:
    """Rectángulos equivalentes en `Sp_f_60.bin/sub` para un hijo lógico de Special/sub."""
    spec_id = str(spec.get('id') or '')
    if spec_id == 'special_menu_special__text_banner':
        return [tuple(int(v) for v in _EUR_SPECIAL_SP60_PARTS[0][0])]
    if spec_id.startswith('special_menu_special__text_'):
        slug = spec_id[len('special_menu_special__text_'):]
        # La tabla de descriptores se define más adelante en el módulo. Se resuelve
        # aquí, en tiempo de ejecución, para no depender del orden de importación.
        slugs = tuple(row[0] for row in EUR_SPECIAL_SUB_TEXT_DESCRIPTOR_GROUPS)
        try:
            idx = 1 + slugs.index(slug)
        except ValueError:
            return None
        return [tuple(int(v) for v in rect) for rect in _EUR_SPECIAL_SP60_PARTS[idx]]
    if spec_id.startswith('special_menu_special__portrait_'):
        rect = tuple(int(v) for v in spec.get('atlas_rect') or ())
        if len(rect) == 4:
            return [rect]
        return None
    return None


def _eur_mirror_special_child_regions_to_sp60(current_special: bytes, current_sp60: bytes,
                                             specs: list[dict], language: str = 'fr') -> tuple[bytes, list[dict]]:
    """Reproduce en 60 Hz exactamente la misma composición lógica usada en 50 Hz."""
    language = _eur_text_image_language(language)
    spec50 = _eur_text_image_spec('special_menu_special', language)
    spec60 = _eur_text_image_spec('special_menu_sp60', language)
    raw50 = _eur_k7_lz_decompress(current_special)
    _sub_off50, sub50 = _eur_text_image_subresource(raw50, spec50)
    atlas50 = _eur_preview_special_menu_t8(sub50).convert('RGBA')
    raw60 = _eur_k7_lz_decompress(current_sp60)
    sub_off60, sub60 = _eur_text_image_subresource(raw60, spec60)
    atlas60 = _eur_preview_special_menu_t8(sub60).convert('RGBA')
    mirrored = []
    for spec in specs:
        dst_uv_parts = _eur_special_sp60_parts_for_spec(spec)
        if not dst_uv_parts:
            continue
        # Construimos una sola imagen lógica a partir de 50 Hz y la partimos
        # otra vez según la geometría de pantalla del rótulo. Esto evita que el
        # ensamblado visual cambie entre 50 y 60 Hz.
        logical = _eur_special_compose_logical_region(atlas50, spec)
        _src50, logical_parts, _logical_size = _eur_special_logical_region_layout(spec)
        if str(spec.get('id')) == 'special_menu_special__text_banner':
            logical_parts = [(0, 0, logical.width, logical.height)]
        if len(logical_parts) != len(dst_uv_parts):
            raise K7Error(
                f"Texto Imágenes EUR: número de quads lógicos/60 Hz distinto en {spec.get('id')}. "
                f"{len(logical_parts)} != {len(dst_uv_parts)}."
            )
        for logical_rect, dst_rect in zip(logical_parts, dst_uv_parts):
            lx1, ly1, lx2, ly2 = logical_rect
            dx1, dy1, dx2, dy2 = dst_rect
            tile = logical.crop((lx1, ly1, lx2, ly2))
            dst_size = (dx2 - dx1, dy2 - dy1)
            if tile.size != dst_size:
                tile = tile.resize(dst_size, Image.Resampling.LANCZOS)
            atlas60.paste(tile, (dx1, dy1))
        mirrored.append({
            'id': spec.get('id'),
            'texture': spec.get('texture'),
            'label': spec.get('label'),
            'logical_size': [logical.width, logical.height],
            'dest_parts': [[int(v) for v in r] for r in dst_uv_parts],
        })
    new_sub60 = _eur_encode_special_menu_t8_image(sub60, atlas60, (1024, 512))
    if len(new_sub60) != len(sub60):
        raise K7Error('Texto Imágenes EUR: Sp_f_60.bin/sub cambió de tamaño al espejar regiones.')
    buf60 = bytearray(raw60)
    buf60[sub_off60:sub_off60 + len(new_sub60)] = new_sub60
    rebuilt60 = _eur_k7_lz_compress(bytes(buf60), int(current_sp60[8]))
    verify60 = _eur_k7_lz_decompress(rebuilt60)
    _voff60, vsub60 = _eur_text_image_subresource(verify60, spec60)
    if _eur_preview_special_menu_t8(vsub60).size != (1024, 512):
        raise K7Error('Texto Imágenes EUR: Sp_f_60.bin/sub no supera la validación 1024x512.')
    return rebuilt60, mirrored


def _eur_patch_special_menu_graphics(afs, raw_entries, name_to_indices, replacements, sles_data: bytes) -> dict:
    """Traduce los 17 rótulos reales de ``Special_f.b/sub`` detectados desde SLES.

    v1.7.7.83 deja de sustituir el atlas 1024x512 completo. Las coordenadas se
    obtienen de ``SLES_533.66`` con el mismo detector usado por Texto Imágenes y
    sólo se reemplazan las regiones lógicas T01..T17. Los PNG de `special_text_word_sprites` se inyectan de forma directa y transparente, sin mezclarlos con una imagen previa del atlas. Se conservan intactos los píxeles situados fuera de los quads de los rótulos.
    """
    if not isinstance(sles_data, (bytes, bytearray)) or len(sles_data) < 0x100000:
        raise K7Error('Base EUR: falta SLES_533.66 para localizar los rótulos de Special/sub.')

    cfg = next(row for row in _EUR_SPECIAL_MENU_GRAPHICS if int(row['afs_index']) == 2950)
    hits = name_to_indices.get(str(cfg['afs_name']).lower(), [])
    if len(hits) != 1:
        raise K7Error(f"Base EUR: se esperaba un único {cfg['afs_name']}: {hits}.")
    idx = hits[0]
    if idx != int(cfg['afs_index']):
        raise K7Error(
            f"Base EUR: {cfg['afs_name']} está en AFS #{idx}; se esperaba #{cfg['afs_index']}."
        )
    original = _eur_read_entry(afs, raw_entries, idx)
    current = bytes(replacements.get(idx, original))
    if len(current) != len(original):
        raise K7Error(
            f"Base EUR: {cfg['afs_name']} cambió de tamaño antes de traducir los rótulos."
        )

    text_specs = _eur_special_sub_text_specs_from_sles(bytes(sles_data), 'fr')
    if len(text_specs) != 17:
        raise K7Error(f'Base EUR: Special/sub devolvió {len(text_specs)} rótulos; se esperaban 17.')

    base_dir = resource_path('resources', 'eur_base')
    # Fuente única de verdad: los sprites transparentes T01..T17.
    # No se usa ninguna imagen de atlas auxiliar para construir los rótulos.
    manifest_path = base_dir / 'special_text_word_sprites' / 'manifest.json'
    if not manifest_path.is_file():
        raise K7Error(f'Falta el manifiesto de rótulos Special: {manifest_path}.')
    try:
        manifest_rows = json.loads(manifest_path.read_text(encoding='utf-8'))
    except Exception as exc:
        raise K7Error(f'Manifiesto de rótulos Special inválido: {exc}') from exc
    by_id = {str(row.get('id')): row for row in manifest_rows if isinstance(row, dict)}

    parent_spec = _eur_text_image_spec('special_menu_special', 'fr')
    marker = int(current[8])
    raw = _eur_k7_lz_decompress(current)
    sub_off, sub = _eur_text_image_subresource(raw, parent_spec)
    atlas = _eur_preview_special_menu_t8(sub).convert('RGBA')
    labels = []
    preserved = ['retratos', 'iconos', 'colores', 'resto del atlas fuera de los quads de rótulo']
    for number, spec in enumerate(text_specs, start=1):
        rec = by_id.get(str(spec['id']))
        if rec is None:
            raise K7Error(f'Falta el asset integrado para {spec["id"]}.')
        word_rel = Path(str(rec.get('word_asset') or ''))
        word_asset = base_dir / word_rel
        if not word_asset.is_file():
            raise K7Error(f'Falta el sprite individual de {spec["id"]}: {word_asset}.')
        expected_word_sha = str(rec.get('word_sha256') or '')
        got_word_sha = hashlib.sha256(word_asset.read_bytes()).hexdigest()
        if not expected_word_sha or got_word_sha != expected_word_sha:
            raise K7Error(f'El sprite integrado {word_asset.name} no supera su SHA-256.')
        x1, y1, x2, y2 = [int(v) for v in spec['atlas_rect']]
        try:
            with Image.open(word_asset) as sim:
                sim.load()
                sprite = sim.convert('RGBA')
        except Exception as exc:
            raise K7Error(f'No se pudo abrir {word_asset.name}: {exc}') from exc

        # Special acepta dos modos de sprite:
        #   1) lógico runtime (tamaño logical_size), útil cuando el rótulo se monta
        #      como una sola imagen compuesta.
        #   2) fuente-atlas directa (tamaño atlas_rect), útil para rótulos con quads
        #      solapados como Paloma, Cambio y Restablecimiento; así preservamos la
        #      misma partición visual que tienen los originales franceses.
        _src_parts, _logical_parts, logical_size = _eur_special_logical_region_layout(spec)
        _atlas_parts, _local_parts, source_size = _eur_special_source_region_layout(spec)
        forced_mode = str(rec.get('word_mode') or '').strip().lower()
        if forced_mode == 'atlas_source_direct':
            sprite_mode = 'source'
        elif sprite.size == tuple(logical_size):
            sprite_mode = 'logical'
        elif sprite.size == tuple(source_size):
            sprite_mode = 'source'
        else:
            raise K7Error(
                f'El sprite {word_asset.name} mide {sprite.width}x{sprite.height}; '
                f'se esperaba {logical_size[0]}x{logical_size[1]} (lógico) o '
                f'{source_size[0]}x{source_size[1]} (fuente atlas).'
            )
        # v1.7.7.108 — comprobación de identidad del resultado final.
        # El manifiesto guarda el SHA-256 del RGBA lógico objetivo. Antes de tocar
        # el atlas real reconstruimos el sprite sobre un atlas transparente y
        # exigimos coincidencia byte a byte con el objetivo preparado.
        expected_runtime_sha = str(rec.get('logical_target_rgba_sha256') or '')
        if expected_runtime_sha:
            probe_atlas = Image.new('RGBA', (1024, 512), (0, 0, 0, 0))
            if sprite_mode == 'logical':
                probe_atlas = _eur_special_apply_logical_region(probe_atlas, spec, sprite)
            else:
                probe_atlas = _eur_special_apply_source_region(probe_atlas, spec, sprite)
            probe_runtime = _eur_special_compose_logical_region(probe_atlas, spec)
            got_runtime_sha = hashlib.sha256(probe_runtime.tobytes()).hexdigest()
            if got_runtime_sha != expected_runtime_sha:
                raise K7Error(
                    f'El sprite integrado {word_asset.name} no reconstruye exactamente su rótulo objetivo '
                    f'(SHA RGBA {got_runtime_sha}, esperado {expected_runtime_sha}).'
                )
        else:
            got_runtime_sha = ''

        if sprite_mode == 'logical':
            atlas = _eur_special_apply_logical_region(atlas, spec, sprite)
            mode_label = 'direct transparent sprite · exact logical coordinates'
        else:
            atlas = _eur_special_apply_source_region(atlas, spec, sprite)
            mode_label = 'direct transparent sprite · exact atlas-source coordinates'
        label_row = {
            'code': f'T{number:02d}',
            'source': str(spec.get('logical_text') or ''),
            'target': str(spec.get('suggested_es') or ''),
            'rect': [x1, y1, x2, y2],
            'word_png': word_asset.name,
            'word_sha256': got_word_sha,
            'logical_target_rgba_sha256': expected_runtime_sha,
            'runtime_rgba_sha256': got_runtime_sha,
            'pixel_exact_verified': bool(expected_runtime_sha and got_runtime_sha == expected_runtime_sha),
            'mode': mode_label,
        }
        for extra_key in (
            'assembly_reference_language', 'assembly_reference_kind',
            'fr_runtime_reference_asset', 'fr_runtime_reference_sha256',
            'preserve_horizontal_bounds', 'bounds_policy', 'source_space_size',
            'left_margin_px', 'right_margin_px', 'top_margin_px', 'bottom_margin_px',
        ):
            if rec.get(extra_key) is not None:
                label_row[extra_key] = rec.get(extra_key)
        labels.append(label_row)

    new_sub = _eur_encode_special_menu_t8_image(sub, atlas, (1024, 512))
    if len(new_sub) != len(sub):
        raise K7Error('Base EUR: el subrecurso Special/sub cambió de tamaño al aplicar rótulos.')
    buf = bytearray(raw)
    buf[sub_off:sub_off + len(new_sub)] = new_sub
    rebuilt = _eur_k7_lz_compress(bytes(buf), marker)
    packed_size_after = len(rebuilt)
    rebuilt_raw = _eur_k7_lz_decompress(rebuilt)
    _sub_off, sub = _eur_text_image_subresource(rebuilt_raw, parent_spec)
    preview = _eur_preview_special_menu_t8(sub)
    if preview.size != (1024, 512):
        raise K7Error('Base EUR: Special_f.b/sub no supera la validación 1024x512.')

    replacements[idx] = rebuilt
    resources = [{
        'afs_index': idx,
        'afs_name': str(cfg['afs_name']),
        'texture': 'sub',
        'video_mode': '50 Hz / flag 0',
        'mode': '17 logical SLES labels · faithful translation · auto-fit',
        'entry_size_before': len(original),
        'entry_size': len(rebuilt),
        'entry_growth': len(rebuilt) - len(original),
        'packed_size_after': int(packed_size_after),
        'sha256_before': hashlib.sha256(original).hexdigest(),
        'sha256_after': hashlib.sha256(rebuilt).hexdigest(),
    }]

    # El ejecutable europeo no usa siempre #2950. En 60 Hz selecciona explícitamente
    # #2945 Sp_f_60.bin (0x0B81) en 0x2C1BC0..0x2C1BE0. Copiamos cada quad ya
    # traducido desde el atlas de 50 Hz a su UV equivalente de 60 Hz, conservando
    # intactos retratos, iconos y fondos fuera de esos quads.
    cfg60 = next(row for row in _EUR_SPECIAL_MENU_GRAPHICS if int(row['afs_index']) == 2945)
    hits60 = name_to_indices.get(str(cfg60['afs_name']).lower(), [])
    if len(hits60) != 1:
        raise K7Error(f"Base EUR: se esperaba un único {cfg60['afs_name']}: {hits60}.")
    idx60 = hits60[0]
    if idx60 != int(cfg60['afs_index']):
        raise K7Error(
            f"Base EUR: {cfg60['afs_name']} está en AFS #{idx60}; se esperaba #{cfg60['afs_index']}."
        )
    original60 = _eur_read_entry(afs, raw_entries, idx60)
    current60 = bytes(replacements.get(idx60, original60))
    if len(current60) != len(original60):
        raise K7Error(f"Base EUR: {cfg60['afs_name']} cambió de tamaño antes de traducir los rótulos.")
    spec60 = _eur_text_image_spec('special_menu_sp60', 'fr')
    marker60 = int(current60[8])
    raw60 = _eur_k7_lz_decompress(current60)
    sub_off60, sub60 = _eur_text_image_subresource(raw60, spec60)
    atlas60 = _eur_preview_special_menu_t8(sub60).convert('RGBA')
    if len(_EUR_SPECIAL_SP60_PARTS) != len(text_specs):
        raise K7Error('Base EUR: mapa UV 60 Hz de Special/sub incompleto.')

    # 60 Hz se genera también directamente desde los mismos sprites PNG.
    # No se copian píxeles del atlas de 50 Hz, evitando cualquier contaminación
    # o resto del atlas original entre modos.
    for spec_i, spec in enumerate(text_specs):
        rec = by_id.get(str(spec['id']))
        if rec is None:
            raise K7Error(f'Falta el asset integrado para {spec["id"]}.')
        word_asset = base_dir / Path(str(rec.get('word_asset') or ''))
        with Image.open(word_asset) as sim:
            sim.load()
            sprite = sim.convert('RGBA')
        _src_parts, logical_parts, logical_size = _eur_special_logical_region_layout(spec)
        _atlas_parts, local_parts, source_size = _eur_special_source_region_layout(spec)
        forced_mode = str(rec.get('word_mode') or '').strip().lower()
        if forced_mode == 'atlas_source_direct':
            sprite_mode = 'source'
        elif sprite.size == tuple(logical_size):
            sprite_mode = 'logical'
        elif sprite.size == tuple(source_size):
            sprite_mode = 'source'
        else:
            raise K7Error(
                f'El sprite {word_asset.name} mide {sprite.width}x{sprite.height}; '
                f'se esperaba {logical_size[0]}x{logical_size[1]} (lógico) o '
                f'{source_size[0]}x{source_size[1]} (fuente atlas).'
            )
        dst_parts = [tuple(int(v) for v in r) for r in _EUR_SPECIAL_SP60_PARTS[spec_i]]
        if spec_i == 0:
            # T01 tiene un único quad pero cambia de 349x61 a 351x51 en 60 Hz.
            dx1, dy1, dx2, dy2 = dst_parts[0]
            tile = sprite.resize((dx2-dx1, dy2-dy1), Image.Resampling.LANCZOS)
            atlas60.paste(tile, (dx1, dy1))
            continue
        crop_parts = logical_parts if sprite_mode == 'logical' else local_parts
        if len(crop_parts) != len(dst_parts):
            raise K7Error(f'Base EUR: número de quads {sprite_mode}/60 Hz distinto en T{spec_i+1:02d}.')
        for crop_rect, dst_rect in zip(crop_parts, dst_parts):
            lx1, ly1, lx2, ly2 = crop_rect
            dx1, dy1, dx2, dy2 = dst_rect
            tile = sprite.crop((lx1, ly1, lx2, ly2))
            dst_size = (dx2-dx1, dy2-dy1)
            if tile.size != dst_size:
                tile = tile.resize(dst_size, Image.Resampling.LANCZOS)
            atlas60.paste(tile, (dx1, dy1))

    new_sub60 = _eur_encode_special_menu_t8_image(sub60, atlas60, (1024, 512))
    if len(new_sub60) != len(sub60):
        raise K7Error('Base EUR: Sp_f_60.bin/sub cambió de tamaño al aplicar rótulos.')
    buf60 = bytearray(raw60)
    buf60[sub_off60:sub_off60+len(new_sub60)] = new_sub60
    rebuilt60 = _eur_k7_lz_compress(bytes(buf60), marker60)
    verify60 = _eur_k7_lz_decompress(rebuilt60)
    _voff60, vsub60 = _eur_text_image_subresource(verify60, spec60)
    if _eur_preview_special_menu_t8(vsub60).size != (1024, 512):
        raise K7Error('Base EUR: Sp_f_60.bin/sub no supera la validación 1024x512.')
    replacements[idx60] = rebuilt60
    resources.append({
        'afs_index': idx60,
        'afs_name': str(cfg60['afs_name']),
        'texture': 'sub',
        'video_mode': '60 Hz / flag != 0',
        'mode': '17 translated logical labels remapped to 60 Hz UV quads',
        'entry_size_before': len(original60),
        'entry_size': len(rebuilt60),
        'entry_growth': len(rebuilt60) - len(original60),
        'packed_size_after': len(rebuilt60),
        'sha256_before': hashlib.sha256(original60).hexdigest(),
        'sha256_after': hashlib.sha256(rebuilt60).hexdigest(),
    })

    return {
        'resources': resources,
        'labels': labels,
        'preserved': preserved,
        'sles_evidence': {
            'selector_va': '0x002C1BC0',
            'fr_60hz_index': 2945,
            'fr_50hz_index': 2950,
            'video_flag_getter_va': '0x001FDF00',
        },
    }

def _eur_patch_adult_warning_graphic(afs, raw_entries, name_to_indices, replacements) -> dict:
    """Sustituye gulo_F por el aviso español integrado sin cambiar logo.dic."""
    hits = name_to_indices.get(_EUR_ADULT_WARNING_AFS_NAME.lower(), [])
    if len(hits) != 1:
        raise K7Error(
            f'Base EUR: se esperaba un único {_EUR_ADULT_WARNING_AFS_NAME}: {hits}.'
        )
    idx = hits[0]
    if idx != _EUR_ADULT_WARNING_AFS_INDEX:
        raise K7Error(
            f'Base EUR: {_EUR_ADULT_WARNING_AFS_NAME} está en AFS #{idx}; '
            f'se esperaba #{_EUR_ADULT_WARNING_AFS_INDEX}.'
        )

    original = _eur_read_entry(afs, raw_entries, idx)
    current = bytes(replacements.get(idx, original))
    if len(current) != len(original):
        raise K7Error('Base EUR: logo.dic cambió de tamaño antes de parchear gulo_F.')

    spec = _eur_text_image_spec('adult_warning', 'fr')
    sub_off, sub = _eur_text_image_subresource(current, spec)
    asset = resource_path('resources', 'eur_base') / _EUR_ADULT_WARNING_ES_FILE
    if not asset.is_file():
        raise K7Error(f'Falta el aviso español integrado: {asset}.')
    asset_sha = hashlib.sha256(asset.read_bytes()).hexdigest()
    if asset_sha != _EUR_ADULT_WARNING_ES_SHA256:
        raise K7Error(
            'Base EUR: el PNG integrado del aviso de adultos no supera su SHA-256.'
        )

    new_sub = _eur_encode_png_into_dic(
        sub, asset, (int(spec['width']), int(spec['height']))
    )
    if len(new_sub) != len(sub):
        raise K7Error('Base EUR: gulo_F cambió de tamaño al recompilar el aviso español.')

    # Verificación real del recurso PS2 recompilado antes de incorporarlo al AFS.
    verify_info = Killer7Project._dic_texture_info(new_sub)
    if not verify_info or (
        int(verify_info.get('width', 0)), int(verify_info.get('height', 0)),
        int(verify_info.get('bpp', 0))
    ) != (1024, 128, 4):
        raise K7Error('Base EUR: gulo_F español no supera la validación DIC 1024x128 4bpp.')
    preview = Killer7Project.decode_dic_texture_preview(new_sub)
    if preview.size != (1024, 128):
        raise K7Error('Base EUR: gulo_F español no supera el round-trip gráfico.')

    buf = bytearray(current)
    buf[sub_off:sub_off + len(new_sub)] = new_sub
    patched = bytes(buf)
    if len(patched) != len(original):
        raise K7Error('Base EUR: logo.dic cambió de tamaño al insertar el aviso español.')
    replacements[idx] = patched

    return {
        'afs_index': idx,
        'afs_name': _EUR_ADULT_WARNING_AFS_NAME,
        'texture': _EUR_ADULT_WARNING_TEXTURE,
        'png': _EUR_ADULT_WARNING_ES_FILE,
        'size': [1024, 128],
        'bpp': 4,
        'sha256_asset': asset_sha,
        'sha256_before': hashlib.sha256(original).hexdigest(),
        'sha256_after': hashlib.sha256(patched).hexdigest(),
        'entry_size': len(patched),
        'text': 'Este juego contiene temas para adultos / y escenas de violencia explícita.',
    }


# v1.7.7.30 — botón independiente para toda la pantalla de dificultad EUR.
#
# Los textos están rasterizados dentro de AFS #3941 titleF.dic. El recurso
# integrado conserva la textura Normal original y traduce settingF.png,
# DeadlyF.png, text_a01F.png y text_b01F.png. Se distribuye ya recompilado para
# que el resultado sea determinista y no dependa de fuentes instaladas.

# v1.7.7.119 - ChargeAttack frances integrado en espanol.
#
# ``Sp_f_60.bin`` y ``Special_f.b`` contienen una textura 8bpp llamada
# ``ChargeAttack`` con el rotulo rasterizado ``Chargement``. Se recompila desde
# un PNG espanol integrado para que el boton "Inyectar Textos" deje este HUD ya
# traducido como "Carga", manteniendo "Nv." y el resto del atlas intactos.
_EUR_CHARGE_ATTACK_ES_FILE = 'charge_attack_ES.png'
_EUR_CHARGE_ATTACK_ES_SHA256 = '7e6099f7356c4c4aff0d60df85b45a15a4f5b48235b120083ea06c1df46b35c9'


def _eur_patch_charge_attack_graphics(afs, raw_entries, name_to_indices, replacements) -> dict:
    """Integra la textura francesa ChargeAttack con el rotulo 'Carga'."""
    base_dir = resource_path('resources', 'eur_base')
    asset = base_dir / _EUR_CHARGE_ATTACK_ES_FILE
    if not asset.is_file():
        raise K7Error(f'Falta el PNG integrado de ChargeAttack: {asset}.')
    asset_sha = hashlib.sha256(asset.read_bytes()).hexdigest()
    if asset_sha != _EUR_CHARGE_ATTACK_ES_SHA256:
        raise K7Error('Base EUR: el PNG integrado de ChargeAttack no supera su SHA-256.')

    resources = []
    for spec_id in ('special_charge_attack_sp60', 'special_charge_attack_special'):
        spec = _eur_text_image_spec(spec_id, 'fr')
        hits = name_to_indices.get(str(spec['afs_name']).lower(), [])
        if len(hits) != 1:
            raise K7Error(f"Base EUR: se esperaba un unico {spec['afs_name']}: {hits}.")
        idx = hits[0]
        if idx != int(spec['afs_index']):
            raise K7Error(
                f"Base EUR: {spec['afs_name']} esta en AFS #{idx}; se esperaba #{spec['afs_index']}."
            )
        original = _eur_read_entry(afs, raw_entries, idx)
        current = bytes(replacements.get(idx, original))
        rebuilt, packed_size_after = _eur_rebuild_compressed_text_image_entry(
            current, spec, asset, allow_growth=True
        )
        verify_raw = _eur_k7_lz_decompress(rebuilt)
        _sub_off, sub = _eur_text_image_subresource(verify_raw, spec)
        preview = _eur_preview_standard_alias_t8(sub)
        if preview.size != (int(spec['width']), int(spec['height'])):
            raise K7Error(
                f"Base EUR: {spec['afs_name']}/ChargeAttack no supera la validacion "
                f"{spec['width']}x{spec['height']}."
            )
        replacements[idx] = rebuilt
        resources.append({
            'afs_index': idx,
            'afs_name': str(spec['afs_name']),
            'texture': str(spec['texture']),
            'png': _EUR_CHARGE_ATTACK_ES_FILE,
            'size': [int(spec['width']), int(spec['height'])],
            'bpp': int(spec.get('bpp', 8)),
            'sha256_asset': asset_sha,
            'sha256_before': hashlib.sha256(original).hexdigest(),
            'sha256_after': hashlib.sha256(rebuilt).hexdigest(),
            'entry_size_before': len(original),
            'entry_size': len(rebuilt),
            'entry_growth': len(rebuilt) - len(original),
            'packed_size_after': int(packed_size_after),
        })
    return {
        'resources': resources,
        'text': {'Chargement': 'Carga', 'Nv.': 'Nv.'},
        'preserved': ['digitos', 'barras', 'iconos', 'paleta CLUT original', 'resto del atlas fuera del rotulo'],
    }

_EUR_DIFFICULTY_AFS_INDEX = 3941
_EUR_DIFFICULTY_AFS_NAME = 'titleF.dic'
_EUR_DIFFICULTY_ENTRY_SIZE = 3238608
_EUR_DIFFICULTY_BASE_SHA256 = 'be5dc1f67caeb58f991f435cfb8752f423d4c049a62960f77e0bafdd7e086f37'
_EUR_DIFFICULTY_LEGACY_SHA256 = 'b548f299c3dff65c4932910a1d09a1993752bd08dacd9cbd74041415a654453f'
# v1.7.7.52 y anteriores: pantalla ya traducida, pero con la versión previa de Mortal.
_EUR_DIFFICULTY_PREVIOUS_SHA256 = 'c9edb9acab5b79535b7d772e7d41d9f48630bb01b94b72486f7cd08c7774f336'
_EUR_DIFFICULTY_V168_SHA256 = '775f2869c56cf26d43c83dfd4ce0aadbd82a462fdefe0353f3a48419ac48f18a'
_EUR_DIFFICULTY_PATCHED_FILE = 'titleF_difficulty_ES_full.dic'
_EUR_DIFFICULTY_V173_SHA256 = '1ed6a474843b4d0b46d748a867be7bd7958e88e1d78627bc741fadbed21df33b'
_EUR_DIFFICULTY_PATCHED_SHA256 = '268d87594ea766fe64174574fbb8030ad0d1b97ce3e4274c43a776c8cde9fc2d'
_EUR_DIFFICULTY_TEXTURE_OFFSET = 0x3394
_EUR_DIFFICULTY_TEXTURE_END = 0x4560

# v1.7.7.184 — Las descripciones de dificultad se habían rasterizado como una
# rampa de 16 índices ordenados, pero el DIC conservaba la CLUT francesa original.
# Esa CLUT no es monotónica: un índice de cobertura alto podía apuntar a un gris
# oscuro o a un alfa menor que un índice vecino, creando letras moteadas/grises
# en juego. Los dos textos 256x64 usan ahora blanco puro y sólo varía el alfa GS.
_EUR_DIFFICULTY_WHITE_ALPHA_RAMP = (0, 9, 17, 26, 34, 43, 51, 60, 68, 77, 85, 94, 102, 111, 119, 128)
_EUR_DIFFICULTY_DESC_TEXTURES = (
    ('text_b01F.png', 0x8E54, 0xB020),
    ('text_a01F.png', 0xB020, 0xD1EC),
)

# v1.7.7.189 — ambas descripciones se prerasterizan con las mismas métricas.
# El TTF sólo se usa al construir el recurso integrado; no es necesario en runtime.
_EUR_DIFFICULTY_DESC_FONT_METRICS = {
    'family': 'Open Sans Condensed Light',
    'size': 21,
    'origin_x': 3,
    'line_y': [4, 26],
    'texture_size': [256, 64],
}


def _eur_verify_difficulty_white_clut(blob: bytes) -> dict:
    """Verifica la CLUT blanca/alpha monotónica de las dos descripciones."""
    rows = []
    for tex_name, start, end in _EUR_DIFFICULTY_DESC_TEXTURES:
        sub = bytes(blob[int(start):int(end)])
        info = Killer7Project._dic_texture_info(sub)
        if not info or (int(info['width']), int(info['height']), int(info['bpp'])) != (256, 64, 4):
            raise K7Error(f'Dificultad EUR: {tex_name} no es la textura 256x64 4bpp esperada.')
        clut_off = int(info['pixel_offset']) + int(info['payload_size']) + 0x50
        if clut_off + 16 * 4 > len(sub):
            raise K7Error(f'Dificultad EUR: CLUT truncada en {tex_name}.')
        palette = [tuple(sub[clut_off+i*4:clut_off+i*4+4]) for i in range(16)]
        expected = [(0, 0, 0, 0)] + [(255, 255, 255, int(a)) for a in _EUR_DIFFICULTY_WHITE_ALPHA_RAMP[1:]]
        if palette != expected:
            raise K7Error(f'Dificultad EUR: {tex_name} no usa la CLUT blanca monotónica v184.')
        rows.append({'texture': tex_name, 'alpha': list(_EUR_DIFFICULTY_WHITE_ALPHA_RAMP)})
    return {'textures': rows, 'white_rgb': [255, 255, 255], 'gs_alpha_max': 128}


def _eur_patch_difficulty_graphics(afs, raw_entries, name_to_indices, replacements) -> dict:
    """Integra la pantalla de dificultad española dentro del AFS reconstruido."""
    hits = name_to_indices.get(_EUR_DIFFICULTY_AFS_NAME.lower(), [])
    if len(hits) != 1:
        raise K7Error(
            f'Base EUR: se esperaba un único {_EUR_DIFFICULTY_AFS_NAME}: {hits}.'
        )
    idx = hits[0]
    if idx != _EUR_DIFFICULTY_AFS_INDEX:
        raise K7Error(
            f'Base EUR: {_EUR_DIFFICULTY_AFS_NAME} está en AFS #{idx}; '
            f'se esperaba #{_EUR_DIFFICULTY_AFS_INDEX}.'
        )
    original = _eur_read_entry(afs, raw_entries, idx)
    if len(original) != _EUR_DIFFICULTY_ENTRY_SIZE:
        raise K7Error(
            f'Base EUR: {_EUR_DIFFICULTY_AFS_NAME} mide {len(original)} bytes; '
            f'se esperaban {_EUR_DIFFICULTY_ENTRY_SIZE}.'
        )
    digest = hashlib.sha256(original).hexdigest()
    if digest not in {
        _EUR_DIFFICULTY_BASE_SHA256,
        _EUR_DIFFICULTY_LEGACY_SHA256,
        _EUR_DIFFICULTY_PREVIOUS_SHA256,
        _EUR_DIFFICULTY_V168_SHA256,
        _EUR_DIFFICULTY_V173_SHA256,
        _EUR_DIFFICULTY_PATCHED_SHA256,
    }:
        raise K7Error(
            'Base EUR: titleF.dic no coincide con una revisión francesa/española '
            f'verificada (SHA-256 {digest}).'
        )
    patched_path = resource_path('resources', 'eur_base') / _EUR_DIFFICULTY_PATCHED_FILE
    if not patched_path.is_file():
        raise K7Error(f'Falta el recurso integrado de dificultad: {patched_path}.')
    patched = patched_path.read_bytes()
    if len(patched) != _EUR_DIFFICULTY_ENTRY_SIZE:
        raise K7Error('Base EUR: titleF.dic español tiene un tamaño inesperado.')
    pdigest = hashlib.sha256(patched).hexdigest()
    if pdigest != _EUR_DIFFICULTY_PATCHED_SHA256:
        raise K7Error('Base EUR: titleF.dic español no supera su SHA-256 integrado.')
    _eur_verify_difficulty_white_clut(patched)
    replacements[idx] = patched
    return {
        'afs_index': idx,
        'name': _EUR_DIFFICULTY_AFS_NAME,
        'sha256_before': digest,
        'sha256_after': pdigest,
        'already_patched': digest == pdigest,
        'textures': ['settingF.png', 'DeadlyF.png', 'text_a01F.png', 'text_b01F.png'],
        'preserved_textures': ['normalF.png'],
    }


def _eur_iso_afs_entry_info(iso_path: Path, afs_node, index: int) -> dict:
    """Lee metadatos de una entrada AFS directamente desde su extent ISO."""
    afs_abs = int(afs_node.lba) * 2048
    with Path(iso_path).open('rb') as fh:
        fh.seek(afs_abs)
        if fh.read(4) != b'AFS\0':
            raise K7Error('Dificultad EUR: D_EU/DIR_E.AFS no tiene cabecera AFS válida.')
        raw = fh.read(4)
        if len(raw) != 4:
            raise K7Error('Dificultad EUR: cabecera AFS truncada.')
        count = struct.unpack('<I', raw)[0]
        if not (0 <= int(index) < count):
            raise K7Error(f'Dificultad EUR: AFS #{index} fuera de rango (count={count}).')
        fh.seek(afs_abs + 8 + int(index) * 8)
        row = fh.read(8)
        if len(row) != 8:
            raise K7Error('Dificultad EUR: tabla AFS truncada.')
        entry_off, entry_size = struct.unpack('<II', row)
        fh.seek(afs_abs + 8 + count * 8)
        tail = fh.read(8)
        if len(tail) != 8:
            raise K7Error('Dificultad EUR: referencia a tabla de nombres ausente.')
        name_off, name_size = struct.unpack('<II', tail)
        if name_size < count * 48:
            raise K7Error('Dificultad EUR: tabla de nombres AFS inválida.')
        fh.seek(afs_abs + name_off + int(index) * 48)
        name_row = fh.read(48)
        if len(name_row) != 48:
            raise K7Error('Dificultad EUR: nombre AFS truncado.')
        name = name_row[:32].split(b'\0', 1)[0].decode('latin1', 'replace')
    return {
        'count': int(count), 'afs_absolute': afs_abs,
        'entry_offset': int(entry_off), 'entry_size': int(entry_size),
        'name': name,
    }


def apply_eur_difficulty_texture_to_iso(eur_iso: str | Path, output_iso: str | Path) -> dict:
    """Crea una copia EUR traduciendo la pantalla de dificultad rasterizada.

    Cambia ``settingF.png``, ``DeadlyF.png``, ``text_a01F.png`` y ``text_b01F.png``;
    ``normalF.png`` se conserva porque «Normal» ya es español. No reconstruye
    DIR_E.AFS ni modifica SLES/módulos: ``titleF.dic`` conserva
    exactamente su tamaño y se reemplaza in-place en el mismo slot AFS. La salida
    se escribe primero a un temporal y se verifica antes del rename final.
    """
    eur_iso = Path(eur_iso).resolve()
    output_iso = Path(output_iso).resolve()
    if not eur_iso.is_file():
        raise K7Error(f'No existe la ISO europea: {eur_iso}')
    if eur_iso == output_iso:
        raise K7Error('La ISO EUR de salida debe ser distinta de la original.')

    patched_path = resource_path('resources', 'eur_base') / _EUR_DIFFICULTY_PATCHED_FILE
    if not patched_path.is_file():
        raise K7Error(f'Falta el recurso integrado de dificultad: {patched_path}.')
    patched = patched_path.read_bytes()
    if len(patched) != _EUR_DIFFICULTY_ENTRY_SIZE:
        raise K7Error('Dificultad EUR: titleF.dic español tiene un tamaño inesperado.')
    patched_digest = hashlib.sha256(patched).hexdigest()
    if patched_digest != _EUR_DIFFICULTY_PATCHED_SHA256:
        raise K7Error('Dificultad EUR: titleF.dic español no supera su SHA-256 integrado.')
    _eur_verify_difficulty_white_clut(patched)

    with ISO9660(eur_iso) as iso:
        ident = identify_killer7_iso(iso)
        if ident.get('edition') != 'EUR':
            reported = ident.get('reported_serial') or 'desconocido'
            raise K7Error(
                f'La imagen seleccionada no contiene una estructura Killer7 EUR compatible. '
                f'Serial de SYSTEM.CNF: {reported}; se requieren D_EU/DIR_E.AFS y {EUR_SUPPORTED_SERIAL}.'
            )
        afs_node = iso.find(['D_EU', 'DIR_E.AFS'])
        info = _eur_iso_afs_entry_info(eur_iso, afs_node, _EUR_DIFFICULTY_AFS_INDEX)

    if info['name'].lower() != _EUR_DIFFICULTY_AFS_NAME.lower():
        raise K7Error(
            f'Dificultad EUR: AFS #{_EUR_DIFFICULTY_AFS_INDEX} es {info["name"]!r}; '
            f'se esperaba {_EUR_DIFFICULTY_AFS_NAME!r}.'
        )
    if info['entry_size'] != _EUR_DIFFICULTY_ENTRY_SIZE:
        raise K7Error(
            f'Dificultad EUR: titleF.dic mide {info["entry_size"]} bytes; '
            f'se esperaban {_EUR_DIFFICULTY_ENTRY_SIZE}.'
        )

    entry_abs = info['afs_absolute'] + info['entry_offset']
    with eur_iso.open('rb') as src:
        src.seek(entry_abs)
        original = src.read(info['entry_size'])
    if len(original) != info['entry_size']:
        raise K7Error('Dificultad EUR: no se pudo leer titleF.dic completo.')
    original_digest = hashlib.sha256(original).hexdigest()
    already_patched = original_digest == _EUR_DIFFICULTY_PATCHED_SHA256
    compatible_previous = original_digest in {_EUR_DIFFICULTY_PREVIOUS_SHA256, _EUR_DIFFICULTY_V168_SHA256, _EUR_DIFFICULTY_V173_SHA256, _EUR_DIFFICULTY_LEGACY_SHA256}
    if not already_patched and not compatible_previous and original_digest != _EUR_DIFFICULTY_BASE_SHA256:
        raise K7Error(
            'Dificultad EUR: titleF.dic no coincide con la revisión francesa verificada '
            f'(SHA-256 {original_digest}).'
        )

    # Validación estructural de todas las texturas que forman la pantalla.
    candidate = patched if not already_patched else original
    expected_textures = (
        (0x3394, 0x4560, b'settingF.png', 128, 64),
        (0x4560, 0x4F28, b'normalF.png', 128, 32),
        (0x4F28, 0x58F0, b'DeadlyF.png', 128, 32),
        (0x8E54, 0xB020, b'text_b01F.png', 256, 64),
        (0xB020, 0xD1EC, b'text_a01F.png', 256, 64),
    )
    for tex_start, tex_end, tex_name, tex_w, tex_h in expected_textures:
        sub = candidate[tex_start:tex_end]
        found_name = sub[0x48:0x48+32].split(b'\0', 1)[0]
        if found_name != tex_name:
            raise K7Error(
                f'Dificultad EUR: textura inesperada en titleF.dic +0x{tex_start:X}: '
                f'{found_name!r}; se esperaba {tex_name!r}.'
            )
        dic_info = Killer7Project._dic_texture_info(sub)
        if not dic_info or (dic_info['width'], dic_info['height'], dic_info['bpp']) != (tex_w, tex_h, 4):
            raise K7Error(
                f'Dificultad EUR: {tex_name.decode()} no es la textura '
                f'{tex_w}x{tex_h} 4bpp esperada.'
            )

    output_iso.parent.mkdir(parents=True, exist_ok=True)
    tmp_output = output_iso.with_name(output_iso.name + '.k7difficulty.tmp')
    if tmp_output.exists():
        tmp_output.unlink()
    try:
        shutil.copyfile(eur_iso, tmp_output)
        if tmp_output.stat().st_size != eur_iso.stat().st_size:
            raise K7Error('Dificultad EUR: la copia temporal de la ISO tiene tamaño incorrecto.')
        if not already_patched:
            with tmp_output.open('r+b') as dst:
                dst.seek(entry_abs)
                dst.write(patched)
                dst.flush()
        with tmp_output.open('rb') as check:
            check.seek(entry_abs)
            result = check.read(info['entry_size'])
        result_digest = hashlib.sha256(result).hexdigest()
        if result_digest != _EUR_DIFFICULTY_PATCHED_SHA256:
            raise K7Error('Dificultad EUR: la verificación de titleF.dic insertado ha fallado.')
        with ISO9660(tmp_output) as verify_iso:
            if not is_compatible_eur_iso(verify_iso):
                raise K7Error('Dificultad EUR: la ISO de salida dejó de conservar la estructura SLES_533.66 compatible.')
        tmp_output.replace(output_iso)
    except Exception:
        try:
            if tmp_output.exists():
                tmp_output.unlink()
        except Exception:
            pass
        raise

    return {
        'output_iso': str(output_iso),
        'afs_index': _EUR_DIFFICULTY_AFS_INDEX,
        'afs_name': _EUR_DIFFICULTY_AFS_NAME,
        'entry_offset': info['entry_offset'],
        'entry_absolute': entry_abs,
        'texture': 'settingF.png + DeadlyF.png + text_a01F.png + text_b01F.png',
        'texture_offset': _EUR_DIFFICULTY_TEXTURE_OFFSET,
        'texture_size': [128, 64],
        'bpp': 4,
        'source_text': 'Niveau de difficulté / Mortel / textos descriptivos FR',
        'target_text': 'Elige dificultad / Mortal / descripciones ES',
        'translated_textures': ['settingF.png', 'DeadlyF.png', 'text_a01F.png', 'text_b01F.png'],
        'preserved_textures': ['normalF.png'],
        'previous_patch_upgraded': bool(compatible_previous),
        'sha256_before': original_digest,
        'sha256_after': _EUR_DIFFICULTY_PATCHED_SHA256,
        'already_patched': bool(already_patched),
        'other_resources_modified': False,
    }




def apply_eur_translated_images_to_iso(eur_iso: str | Path, output_iso: str | Path) -> dict:
    """Crea una copia EUR aplicando todas las imágenes traducidas verificadas.

    Incluye las pantallas iniciales rasterizadas (`selLang.dic`, `selLangAnser.`,
    `euRGB60_f.dic`), el selector de escenas (`sce_F.dat / SceSel_F`) y la
    pantalla de dificultad completa (`titleF.dic`). Todos los recursos mantienen
    exactamente su tamaño y se sustituyen in-place en el mismo slot AFS de la
    ISO EUR.
    """
    eur_iso = Path(eur_iso).resolve()
    output_iso = Path(output_iso).resolve()
    if not eur_iso.is_file():
        raise K7Error(f'No existe la ISO europea: {eur_iso}')
    if eur_iso == output_iso:
        raise K7Error('La ISO EUR de salida debe ser distinta de la original.')

    with ISO9660(eur_iso) as iso:
        ident = identify_killer7_iso(iso)
        if ident.get('edition') != 'EUR':
            reported = ident.get('reported_serial') or 'desconocido'
            raise K7Error(
                f'La imagen seleccionada no contiene una estructura Killer7 EUR compatible. '
                f'Serial de SYSTEM.CNF: {reported}; se requieren D_EU/DIR_E.AFS y {EUR_SUPPORTED_SERIAL}.'
            )
        afs_node = iso.find(['D_EU', 'DIR_E.AFS'])

    base_dir = resource_path('resources', 'eur_base')
    planned = []

    for norm_name, spec in _EUR_SELLANG_BASE.items():
        info = _eur_iso_afs_entry_info(eur_iso, afs_node, int(spec['afs_index']))
        if info['name'].lower() != norm_name:
            raise K7Error(
                f'Imágenes traducidas EUR: AFS #{spec["afs_index"]} es {info["name"]!r}; '
                f'se esperaba {norm_name!r}.'
            )
        if info['entry_size'] != int(spec['size']):
            raise K7Error(
                f'Imágenes traducidas EUR: {norm_name} mide {info["entry_size"]} bytes; '
                f'se esperaban {spec["size"]}.'
            )
        entry_abs = info['afs_absolute'] + info['entry_offset']
        with eur_iso.open('rb') as src:
            src.seek(entry_abs)
            original = src.read(info['entry_size'])
        if len(original) != info['entry_size']:
            raise K7Error(f'Imágenes traducidas EUR: no se pudo leer {norm_name} completo.')
        original_digest = hashlib.sha256(original).hexdigest()
        already_patched = original_digest == spec['patched_sha256']
        compatible_previous = original_digest == spec.get('previous_patched_sha256')
        if not already_patched and not compatible_previous and original_digest != spec['sha256']:
            raise K7Error(
                f'Imágenes traducidas EUR: {norm_name} no coincide con la revisión francesa '
                f'verificada (SHA-256 {original_digest}).'
            )
        patched_path = base_dir / str(spec['patched_file'])
        if not patched_path.is_file():
            raise K7Error(f'Falta el recurso español integrado: {patched_path}.')
        patched = patched_path.read_bytes()
        if len(patched) != len(original):
            raise K7Error(f'Imágenes traducidas EUR: {patched_path.name} cambió de tamaño.')
        patched_digest = hashlib.sha256(patched).hexdigest()
        if patched_digest != spec['patched_sha256']:
            raise K7Error(
                f'Imágenes traducidas EUR: {patched_path.name} no supera su SHA-256 integrado.'
            )
        planned.append({
            'kind': 'startup',
            'afs_index': int(spec['afs_index']),
            'afs_name': norm_name,
            'entry_offset': info['entry_offset'],
            'entry_absolute': entry_abs,
            'entry_size': info['entry_size'],
            'textures': list(spec.get('textures', [])),
            'patched': patched,
            'patched_sha256': patched_digest,
            'sha256_before': original_digest,
            'already_patched': bool(already_patched),
            'previous_patch_upgraded': bool(compatible_previous),
        })

    diff_info = _eur_iso_afs_entry_info(eur_iso, afs_node, _EUR_DIFFICULTY_AFS_INDEX)
    if diff_info['name'].lower() != _EUR_DIFFICULTY_AFS_NAME.lower():
        raise K7Error(
            f'Imágenes traducidas EUR: AFS #{_EUR_DIFFICULTY_AFS_INDEX} es {diff_info["name"]!r}; '
            f'se esperaba {_EUR_DIFFICULTY_AFS_NAME!r}.'
        )
    if diff_info['entry_size'] != _EUR_DIFFICULTY_ENTRY_SIZE:
        raise K7Error(
            f'Imágenes traducidas EUR: titleF.dic mide {diff_info["entry_size"]} bytes; '
            f'se esperaban {_EUR_DIFFICULTY_ENTRY_SIZE}.'
        )
    diff_abs = diff_info['afs_absolute'] + diff_info['entry_offset']
    with eur_iso.open('rb') as src:
        src.seek(diff_abs)
        diff_original = src.read(diff_info['entry_size'])
    if len(diff_original) != diff_info['entry_size']:
        raise K7Error('Imágenes traducidas EUR: no se pudo leer titleF.dic completo.')
    diff_digest = hashlib.sha256(diff_original).hexdigest()
    diff_already = diff_digest == _EUR_DIFFICULTY_PATCHED_SHA256
    diff_previous = diff_digest in {_EUR_DIFFICULTY_PREVIOUS_SHA256, _EUR_DIFFICULTY_LEGACY_SHA256}
    if not diff_already and not diff_previous and diff_digest != _EUR_DIFFICULTY_BASE_SHA256:
        raise K7Error(
            'Imágenes traducidas EUR: titleF.dic no coincide con la revisión francesa '
            f'verificada (SHA-256 {diff_digest}).'
        )
    patched_path = base_dir / _EUR_DIFFICULTY_PATCHED_FILE
    if not patched_path.is_file():
        raise K7Error(f'Falta el recurso integrado de dificultad: {patched_path}.')
    patched = patched_path.read_bytes()
    if len(patched) != _EUR_DIFFICULTY_ENTRY_SIZE:
        raise K7Error('Imágenes traducidas EUR: titleF.dic español tiene un tamaño inesperado.')
    patched_digest = hashlib.sha256(patched).hexdigest()
    if patched_digest != _EUR_DIFFICULTY_PATCHED_SHA256:
        raise K7Error('Imágenes traducidas EUR: titleF.dic español no supera su SHA-256 integrado.')
    planned.append({
        'kind': 'difficulty',
        'afs_index': _EUR_DIFFICULTY_AFS_INDEX,
        'afs_name': _EUR_DIFFICULTY_AFS_NAME,
        'entry_offset': diff_info['entry_offset'],
        'entry_absolute': diff_abs,
        'entry_size': diff_info['entry_size'],
        'textures': ['settingF.png', 'DeadlyF.png', 'text_a01F.png', 'text_b01F.png'],
        'preserved_textures': ['normalF.png'],
        'patched': patched,
        'patched_sha256': patched_digest,
        'sha256_before': diff_digest,
        'already_patched': bool(diff_already),
        'previous_patch_upgraded': bool(diff_previous),
    })


    # Selector de escenas (sce_F.dat / SceSel_F): fechas ES + OBJETIVO + Lion.
    scene_info = _eur_iso_afs_entry_info(eur_iso, afs_node, _EUR_SCENE_SELECTOR_INDEX)
    if scene_info['name'].lower() != _EUR_SCENE_SELECTOR_AFS_NAME.lower():
        raise K7Error(
            f'Imágenes traducidas EUR: AFS #{_EUR_SCENE_SELECTOR_INDEX} es {scene_info["name"]!r}; '
            f'se esperaba {_EUR_SCENE_SELECTOR_AFS_NAME!r}.'
        )
    scene_abs = scene_info['afs_absolute'] + scene_info['entry_offset']
    with eur_iso.open('rb') as src:
        src.seek(scene_abs)
        scene_original = src.read(scene_info['entry_size'])
    if len(scene_original) != scene_info['entry_size']:
        raise K7Error('Imágenes traducidas EUR: no se pudo leer sce_F.dat completo.')
    scene_patched, scene_meta = _eur_scene_selector_build_entry(scene_original, EUR_SCENE_SELECTOR_DEFAULTS)
    planned.append({
        'kind': 'scene_selector',
        'afs_index': _EUR_SCENE_SELECTOR_INDEX,
        'afs_name': _EUR_SCENE_SELECTOR_AFS_NAME,
        'entry_offset': scene_info['entry_offset'],
        'entry_absolute': scene_abs,
        'entry_size': scene_info['entry_size'],
        'textures': ['SceSel_F'],
        'patched': scene_patched,
        'patched_sha256': hashlib.sha256(scene_patched).hexdigest(),
        'sha256_before': hashlib.sha256(scene_original).hexdigest(),
        'already_patched': scene_patched == scene_original,
        'previous_patch_upgraded': False,
        'scene_targets': scene_meta.get('targets', {}),
    })

    output_iso.parent.mkdir(parents=True, exist_ok=True)
    tmp_output = output_iso.with_name(output_iso.name + '.k7images.tmp')
    if tmp_output.exists():
        tmp_output.unlink()
    try:
        shutil.copyfile(eur_iso, tmp_output)
        if tmp_output.stat().st_size != eur_iso.stat().st_size:
            raise K7Error('Imágenes traducidas EUR: la copia temporal de la ISO tiene tamaño incorrecto.')
        with tmp_output.open('r+b') as dst:
            for item in planned:
                if item['already_patched']:
                    continue
                dst.seek(int(item['entry_absolute']))
                dst.write(item['patched'])
            dst.flush()
        with tmp_output.open('rb') as check:
            for item in planned:
                check.seek(int(item['entry_absolute']))
                result = check.read(int(item['entry_size']))
                result_digest = hashlib.sha256(result).hexdigest()
                if result_digest != item['patched_sha256']:
                    raise K7Error(
                        f'Imágenes traducidas EUR: la verificación de {item["afs_name"]} insertado ha fallado.'
                    )
        with ISO9660(tmp_output) as verify_iso:
            if not is_compatible_eur_iso(verify_iso):
                raise K7Error('Imágenes traducidas EUR: la ISO de salida dejó de conservar la estructura SLES_533.66 compatible.')
        tmp_output.replace(output_iso)
    except Exception:
        try:
            if tmp_output.exists():
                tmp_output.unlink()
        except Exception:
            pass
        raise

    startup_items = [item for item in planned if item['kind'] == 'startup']
    difficulty_item = [item for item in planned if item['kind'] == 'difficulty'][0]
    scene_item = [item for item in planned if item['kind'] == 'scene_selector'][0]
    return {
        'output_iso': str(output_iso),
        'resources': [
            {
                'afs_index': item['afs_index'],
                'afs_name': item['afs_name'],
                'textures': item['textures'],
                'sha256_before': item['sha256_before'],
                'sha256_after': item['patched_sha256'],
                'already_patched': item['already_patched'],
                'previous_patch_upgraded': item['previous_patch_upgraded'],
            }
            for item in planned
        ],
        'startup_resources': [item['afs_name'] for item in startup_items],
        'startup_textures': [tex for item in startup_items for tex in item['textures']],
        'difficulty_textures': difficulty_item['textures'],
        'scene_selector_textures': scene_item['textures'],
        'scene_selector_targets': scene_item.get('scene_targets', {}),
        'preserved_textures': difficulty_item.get('preserved_textures', []),
        'already_patched_all': all(bool(item['already_patched']) for item in planned),
        'upgraded_previous_patch': any(bool(item['previous_patch_upgraded']) for item in planned),
    }




# v1.7.7.33 — pestaña "Texto Imágenes".
# Catálogo de las texturas de interfaz ya localizadas en la edición EUR. Se leen
# directamente desde la ISO seleccionada y pueden sustituirse por PNG manteniendo
# dimensiones, CLUT, PSMT4 y layout de transferencia GS del recurso original.
EUR_TEXT_IMAGE_SPECS = [
    {
        'id': 'hz_confirm_copy', 'group': 'Inicio · 50/60 Hz',
        'afs_index': 3870, 'afs_name': 'eurgb60_f.dic',
        'subresource': None, 'texture': 'euRGB60',
        'label': 'Confirmación 50/60 Hz (copia independiente)',
        'width': 512, 'height': 128, 'hidden': True,
    },
    {
        'id': 'adult_warning', 'group': 'Inicio · Aviso',
        'afs_index': 3884, 'afs_name': 'logo.dic',
        'subresource': 'gulo_F', 'texture': 'gulo_F',
        'label': 'Aviso de contenido para adultos',
        'width': 1024, 'height': 128,
    },
    {
        'id': 'scene_selector', 'group': 'Mapa / selector · Capítulos y fechas',
        'afs_index': 3891, 'afs_name': 'sce_f.dat',
        'subresource': 'SceSel_F', 'texture': 'SceSel_F',
        'label': 'Mapa / selector · capítulos, fechas y tarjeta Lion',
        'width': 512, 'height': 512, 'bpp': 8, 'format': 'psmt8_scene_selector',
    },
    {
        'id': 'special_charge_attack_sp60', 'group': 'Menú · Recursos internos Sp/Special',
        'afs_index': 2945, 'afs_name': 'Sp_f_60.bin',
        'subresource': 'ChargeAttack', 'texture': 'ChargeAttack',
        'label': 'Carga/ataque · Carga / Nv. + HUD (sincroniza Special_f)',
        'width': 256, 'height': 256, 'bpp': 8,
        'format': 'compressed_standard_alias_t8',
        'linked_ids': ['special_charge_attack_special'],
    },
    {
        'id': 'special_charge_attack_special', 'group': 'Menú · Recursos internos Sp/Special',
        'afs_index': 2950, 'afs_name': 'Special_f.b',
        'subresource': 'ChargeAttack', 'texture': 'ChargeAttack',
        'label': 'Carga/ataque · copia en Special_f (Carga / Nv.)',
        'width': 256, 'height': 256, 'bpp': 8,
        'format': 'compressed_standard_alias_t8', 'hidden': True,
    },
    {
        'id': 'special_blood_sp60', 'group': 'Menú · Recursos internos Sp/Special',
        'afs_index': 2945, 'afs_name': 'Sp_f_60.bin',
        'subresource': 'Blood', 'texture': 'Blood',
        'label': 'Atlas Blood · dígitos 0–9 / X (sincroniza Special_f)',
        'width': 128, 'height': 64, 'bpp': 4,
        'format': 'compressed_dic4',
        'linked_ids': ['special_blood_special'],
    },
    {
        'id': 'special_blood_special', 'group': 'Menú · Recursos internos Sp/Special',
        'afs_index': 2950, 'afs_name': 'Special_f.b',
        'subresource': 'Blood', 'texture': 'Blood',
        'label': 'Atlas Blood · copia en Special_f',
        'width': 128, 'height': 64, 'bpp': 4,
        'format': 'compressed_dic4', 'hidden': True,
    },
    {
        'id': 'special_ifont_sp60', 'group': 'Menú · Recursos internos Sp/Special',
        'afs_index': 2945, 'afs_name': 'Sp_f_60.bin',
        'subresource': 'IFont', 'texture': 'IFont',
        'label': 'Fuente IFont · letras, símbolos y acentos (sincroniza Special_f)',
        'width': 256, 'height': 128, 'bpp': 4,
        'format': 'compressed_dic4',
        'linked_ids': ['special_ifont_special'],
    },
    {
        'id': 'special_ifont_special', 'group': 'Menú · Recursos internos Sp/Special',
        'afs_index': 2950, 'afs_name': 'Special_f.b',
        'subresource': 'IFont', 'texture': 'IFont',
        'label': 'Fuente IFont · copia en Special_f',
        'width': 256, 'height': 128, 'bpp': 4,
        'format': 'compressed_dic4', 'hidden': True,
    },
    {
        'id': 'special_conpas_sp60', 'group': 'Menú · Recursos internos Sp/Special',
        'afs_index': 2945, 'afs_name': 'Sp_f_60.bin',
        'subresource': 'conpas', 'texture': 'conpas',
        'label': 'Brújula / ojos / N-S-O-E (sincroniza Special_f)',
        'width': 128, 'height': 256, 'bpp': 8,
        'format': 'compressed_standard_alias_t8',
        'linked_ids': ['special_conpas_special'],
    },
    {
        'id': 'special_conpas_special', 'group': 'Menú · Recursos internos Sp/Special',
        'afs_index': 2950, 'afs_name': 'Special_f.b',
        'subresource': 'conpas', 'texture': 'conpas',
        'label': 'Brújula / ojos · copia en Special_f',
        'width': 128, 'height': 256, 'bpp': 8,
        'format': 'compressed_standard_alias_t8', 'hidden': True,
    },
    {
        'id': 'special_menu_sp60', 'group': 'Menú · Atlas principal Sp/Special',
        'afs_index': 2945, 'afs_name': 'Sp_f_60.bin',
        'subresource': 'sub', 'texture': 'sub',
        'label': 'Atlas principal francés · retratos y rótulos (Sp_f_60)',
        'width': 1024, 'height': 512, 'bpp': 8,
        'format': 'compressed_psmct32_alias_t8',
        'linked_ids': ['special_menu_special'],
    },
    {
        'id': 'special_menu_special', 'group': 'Menú · Atlas principal Sp/Special',
        'afs_index': 2950, 'afs_name': 'Special_f.b',
        'subresource': 'sub', 'texture': 'sub',
        'label': 'Atlas principal francés · retratos y rótulos (Special_f)',
        'width': 1024, 'height': 512, 'bpp': 8,
        'format': 'compressed_psmct32_alias_t8',
        'linked_ids': ['special_menu_sp60'],
    },
    {
        'id': 'language_select', 'group': 'Inicio · Idioma',
        'afs_index': 3896, 'afs_name': 'sellang.dic',
        'subresource': 'sel', 'texture': 'sel',
        'label': 'Seleccionar idioma', 'width': 512, 'height': 128,
    },
    {
        'id': 'hz_60', 'group': 'Inicio · 50/60 Hz',
        'afs_index': 3896, 'afs_name': 'sellang.dic',
        'subresource': 'PS2_60HzF', 'texture': 'PS2_60HzF',
        'label': 'Opción NTSC 60 Hz', 'width': 512, 'height': 64,
    },
    {
        'id': 'hz_50', 'group': 'Inicio · 50/60 Hz',
        'afs_index': 3896, 'afs_name': 'sellang.dic',
        'subresource': 'PS2_50HzF', 'texture': 'PS2_50HzF',
        'label': 'Opción PAL 50 Hz', 'width': 512, 'height': 64,
    },
    {
        'id': 'hz_confirm', 'group': 'Inicio · 50/60 Hz',
        'afs_index': 3896, 'afs_name': 'sellang.dic',
        'subresource': 'euRGB60F', 'texture': 'euRGB60F',
        'label': 'Pregunta y confirmaciones 50/60 Hz',
        'width': 512, 'height': 128,
        'linked_ids': ['hz_confirm_copy', 'hz_confirm_answer'],
    },
    {
        'id': 'hz_confirm_answer', 'group': 'Inicio · 50/60 Hz',
        'afs_index': 3897, 'afs_name': 'selLangAnser.',
        'subresource': 'euRGB60F', 'texture': 'euRGB60F',
        'label': 'Confirmación 50/60 Hz (pantalla de respuesta)',
        'width': 512, 'height': 128, 'hidden': True,
    },
    {
        'id': 'difficulty_title', 'group': 'Dificultad',
        'afs_index': 3941, 'afs_name': 'titleF.dic',
        'subresource': 'settingF.png', 'texture': 'settingF.png',
        'label': 'Título · Elige dificultad', 'width': 128, 'height': 64,
    },
    {
        'id': 'difficulty_normal', 'group': 'Dificultad',
        'afs_index': 3941, 'afs_name': 'titleF.dic',
        'subresource': 'normalF.png', 'texture': 'normalF.png',
        'label': 'Rótulo · Normal', 'width': 128, 'height': 32,
    },
    {
        'id': 'difficulty_mortal', 'group': 'Dificultad',
        'afs_index': 3941, 'afs_name': 'titleF.dic',
        'subresource': 'DeadlyF.png', 'texture': 'DeadlyF.png',
        'label': 'Rótulo · Mortal', 'width': 128, 'height': 32,
    },
    {
        'id': 'difficulty_normal_desc', 'group': 'Dificultad',
        'afs_index': 3941, 'afs_name': 'titleF.dic',
        'subresource': 'text_a01F.png', 'texture': 'text_a01F.png',
        'label': 'Descripción · Normal', 'width': 256, 'height': 64,
    },
    {
        'id': 'difficulty_mortal_desc', 'group': 'Dificultad',
        'afs_index': 3941, 'afs_name': 'titleF.dic',
        'subresource': 'text_b01F.png', 'texture': 'text_b01F.png',
        'label': 'Descripción · Mortal', 'width': 256, 'height': 64,
    },
    {
        'id': 'explan_tutorial_index', 'group': 'Tutorial · Índice',
        'afs_index': 302, 'afs_name': 'explan_f.dat',
        'subresource': 'Tutorial', 'texture': 'Tutorial',
        'label': 'Índice del tutorial · Info general / combate / sangre / registros',
        'width': 256, 'height': 256,
    },
    {
        'id': 'tutorial_controls', 'group': 'Tutorial · Controles',
        'afs_index': 3976, 'afs_name': 'tutorial_f',
        'subresource': 'Tutorial', 'texture': 'Tutorial',
        'label': 'Tutorial completo · controles e instrucciones',
        'width': 1024, 'height': 1024, 'bpp': 8, 'format': 'psmct32_alias_t8',
    },
    {
        'id': 'tutorial_yes_no', 'group': 'Tutorial · Controles',
        'afs_index': 3976, 'afs_name': 'tutorial_f',
        'subresource': 'Satu', 'texture': 'Satu',
        'label': 'Tutorial · Sí / No',
        'width': 1024, 'height': 1024, 'bpp': 4, 'format': 'linear_indexed_texture',
        'display_roll_x': 640, 'export_preview_image': True,
    },
]



_EUR_MAP_TEXTURE_FAMILIES = [
    {'slug': 'cel', 'label': 'Celtic', 'en': 344, 'fr': 345, 'de': 346, 'afs_en': 'cel_e.dat', 'afs_fr': 'cel_f.dat', 'afs_de': 'cel_g.dat', 'tex_n': 'cel_n', 'tex_a': 'cel_a', 'n_size': (128, 64), 'a_size': (512, 512)},
    {'slug': 'cur', 'label': 'Cur', 'en': 348, 'fr': 349, 'de': 350, 'afs_en': 'cur_e.dat', 'afs_fr': 'cur_f.dat', 'afs_de': 'cur_g.dat', 'tex_n': 'kur_n', 'tex_a': 'kur_a', 'n_size': (128, 128), 'a_size': (512, 1024)},
    {'slug': 'dmi', 'label': 'Dimitri', 'en': 352, 'fr': 353, 'de': 354, 'afs_en': 'dmi_e.dat', 'afs_fr': 'dmi_f.dat', 'afs_de': 'dmi_g.dat', 'tex_n': 'dmi_n', 'tex_a': 'dmi_a', 'n_size': (128, 128), 'a_size': (512, 1024)},
    {'slug': 'fuk', 'label': 'Fukushima', 'en': 356, 'fr': 357, 'de': 358, 'afs_en': 'fuk_e.dat', 'afs_fr': 'fuk_f.dat', 'afs_de': 'fuk_g.dat', 'tex_n': 'fuk_n', 'tex_a': 'fuk_a', 'n_size': (128, 128), 'a_size': (512, 512)},
    {'slug': 'ht2', 'label': 'Hotel / HT2', 'en': 360, 'fr': 361, 'de': 362, 'afs_en': 'ht2_e.dat', 'afs_fr': 'ht2_f.dat', 'afs_de': 'ht2_g.dat', 'tex_n': 'htl_n', 'tex_a': 'htl_a', 'n_size': (128, 64), 'a_size': (512, 1024)},
    {'slug': 'htl', 'label': 'Hotel Union', 'en': 364, 'fr': 365, 'de': 366, 'afs_en': 'htl_e.dat', 'afs_fr': 'htl_f.dat', 'afs_de': 'htl_g.dat', 'tex_n': 'htl_n', 'tex_a': 'htl_a', 'n_size': (128, 64), 'a_size': (512, 1024)},
    {'slug': 'isz', 'label': 'InterCity', 'en': 368, 'fr': 369, 'de': 370, 'afs_en': 'isz_e.dat', 'afs_fr': 'isz_f.dat', 'afs_de': 'isz_g.dat', 'tex_n': 'isz_n', 'tex_a': 'isz_a', 'n_size': (128, 128), 'a_size': (512, 1024)},
    {'slug': 'kak', 'label': 'Kaku', 'en': 372, 'fr': 373, 'de': 374, 'afs_en': 'kak_e.dat', 'afs_fr': 'kak_f.dat', 'afs_de': 'kak_g.dat', 'tex_n': 'kak_n', 'tex_a': 'kak_a', 'n_size': (128, 128), 'a_size': (512, 1024)},
    {'slug': 'scl', 'label': 'School', 'en': 380, 'fr': 381, 'de': 382, 'afs_en': 'scl_e.dat', 'afs_fr': 'scl_f.dat', 'afs_de': 'scl_g.dat', 'tex_n': 'scl_n', 'tex_a': 'scl_a', 'n_size': (128, 128), 'a_size': (512, 1024)},
    {'slug': 'sen', 'label': 'Sendero / Sen', 'en': 384, 'fr': 385, 'de': 386, 'afs_en': 'sen_e.dat', 'afs_fr': 'sen_f.dat', 'afs_de': 'sen_g.dat', 'tex_n': 'sen_n', 'tex_a': 'sen_a', 'n_size': (128, 128), 'a_size': (512, 1024)},
    {'slug': 'txs', 'label': 'Texas', 'en': 388, 'fr': 389, 'de': 390, 'afs_en': 'txs_e.dat', 'afs_fr': 'txs_f.dat', 'afs_de': 'txs_g.dat', 'tex_n': 'txs_n', 'tex_a': 'txs_a', 'n_size': (128, 128), 'a_size': (512, 1024)},
]


def _eur_map_texture_specs() -> list[dict]:
    rows = []
    for item in _EUR_MAP_TEXTURE_FAMILIES:
        slug = str(item['slug'])
        label = str(item['label'])
        rows.append({
            'id': f'maptex_{slug}_n',
            'group': 'Mapa · Texturas rasterizadas',
            'afs_index': int(item['fr']), 'afs_name': str(item['afs_fr']),
            'subresource': str(item['tex_n']), 'texture': str(item['tex_n']),
            'label': f'Mapa rasterizado · {label} · plantas / pisos ({item["tex_n"]})',
            'width': int(item['n_size'][0]), 'height': int(item['n_size'][1]), 'bpp': 8,
            'format': 'map_raster_t8', 'map_family': slug, 'map_role': 'n',
        })
        rows.append({
            'id': f'maptex_{slug}_a',
            'group': 'Mapa · Texturas rasterizadas',
            'afs_index': int(item['fr']), 'afs_name': str(item['afs_fr']),
            'subresource': str(item['tex_a']), 'texture': str(item['tex_a']),
            'label': f'Mapa rasterizado · {label} · cabecera / fecha / plano ({item["tex_a"]})',
            'width': int(item['a_size'][0]), 'height': int(item['a_size'][1]), 'bpp': 8,
            'format': 'map_raster_t8', 'map_family': slug, 'map_role': 'a',
        })
    return rows

EUR_TEXT_IMAGE_SPECS.extend(_eur_map_texture_specs())


EUR_TEXT_IMAGE_LANGUAGE_NAMES = {
    'en': 'Inglés',
    'fr': 'Francés',
    'de': 'Alemán',
}

# Los atlas de nombres de planta ingleses no tienen la misma geometría que FR/DE.
# Los `*_a` ingleses, además, son DIC 4bpp normales; FR/DE usan 8bpp.
_EUR_MAP_EN_N_SIZES = {
    'cel': (128, 128),
    'cur': (256, 128),
    'dmi': (256, 128),
    'fuk': (256, 128),
    'ht2': (128, 128),
    'htl': (128, 128),
    'isz': (256, 128),
    'kak': (256, 128),
    'scl': (256, 128),
    'sen': (128, 256),
    'txs': (128, 256),
}


def _eur_remap_map_texture_specs(specs: list[dict], code: str) -> None:
    """Apunta las vistas de mapa a la rama EN/FR/DE real.

    v1.7.7.143-145 añadía estos recursos después del catálogo histórico pero no
    los remapeaba en ``eur_text_image_specs``; al cambiar el selector de idioma
    seguían apuntando silenciosamente a los AFS franceses.
    """
    family = {str(row['slug']): row for row in _EUR_MAP_TEXTURE_FAMILIES}
    for spec in specs:
        slug = spec.get('map_family')
        role = spec.get('map_role')
        if slug not in family or role not in ('n', 'a'):
            continue
        src = family[str(slug)]
        spec['afs_index'] = int(src[code])
        spec['afs_name'] = str(src[f'afs_{code}'])
        spec['subresource'] = str(src[f'tex_{role}'])
        spec['texture'] = str(src[f'tex_{role}'])
        if role == 'a' and (code == 'en' or (code == 'de' and str(slug) == 'cel')):
            # La rama inglesa conserva los planos grandes como DIC 4bpp estándar.
            # Celtic alemán comparte esa variante 4bpp; el resto de DE es 8bpp.
            spec['width'], spec['height'] = map(int, src['a_size'])
            spec['bpp'] = 4
            spec.pop('format', None)
        else:
            size = _EUR_MAP_EN_N_SIZES[str(slug)] if (code == 'en' and role == 'n') else src[f'{role}_size']
            spec['width'], spec['height'] = map(int, size)
            spec['bpp'] = 8
            spec['format'] = 'map_raster_t8'


def _eur_text_image_language(language: str | None) -> str:
    code = str(language or 'fr').strip().lower()
    aliases = {
        'en': 'en', 'eng': 'en', 'english': 'en', 'inglés': 'en', 'ingles': 'en',
        'fr': 'fr', 'fra': 'fr', 'fre': 'fr', 'french': 'fr', 'francés': 'fr', 'frances': 'fr',
        'de': 'de', 'ger': 'de', 'deu': 'de', 'german': 'de', 'alemán': 'de', 'aleman': 'de',
    }
    code = aliases.get(code, code)
    if code not in EUR_TEXT_IMAGE_LANGUAGE_NAMES:
        raise K7Error(
            f'Texto Imágenes EUR: idioma no soportado {language!r}; '
            'usa Inglés, Francés o Alemán.'
        )
    return code


def eur_text_image_specs(language: str = 'fr') -> list[dict]:
    """Devuelve el catálogo Texto Imágenes para la rama de idioma indicada.

    La edición EUR contiene recursos paralelos ingleses, franceses y alemanes. El
    catálogo histórico se conserva como plantilla francesa y aquí se remapean
    índices AFS, nombres de archivo y nombres internos sin duplicar la lógica de
    decodificación/recompilación.
    """
    code = _eur_text_image_language(language)
    lang_name = EUR_TEXT_IMAGE_LANGUAGE_NAMES[code]
    specs = [dict(row) for row in EUR_TEXT_IMAGE_SPECS]
    by_id = {str(row['id']): row for row in specs}

    def setrow(spec_id: str, **changes):
        row = by_id[spec_id]
        row.update(changes)
        row['language'] = code
        row['language_name'] = lang_name

    # Todos reciben metadatos de idioma, incluso los recursos compartidos.
    for row in specs:
        row['language'] = code
        row['language_name'] = lang_name

    # Los mapas se añadieron después del remapeo histórico y necesitan una
    # selección explícita de la rama real (EN/FR/DE).
    _eur_remap_map_texture_specs(specs, code)

    # Selector de idioma: es un único atlas compartido por las tres ramas.
    setrow(
        'language_select',
        label='Seleccionar idioma · atlas compartido EN/FR/DE',
        language_shared=True,
    )

    if code == 'fr':
        # La plantilla ya apunta a la rama francesa; sólo aclaramos el idioma.
        for sid in ('special_menu_sp60', 'special_menu_special'):
            by_id[sid]['label'] = by_id[sid]['label'].replace('francés', 'francés')
        return specs

    if code == 'en':
        setrow('hz_confirm_copy', afs_index=3869, afs_name='euRGB60.dic',
               subresource=None, texture='euRGB60', bpp=4,
               label='Confirmación 50/60 Hz · inglés (copia independiente)')
        setrow('adult_warning', subresource='gulo_E', texture='gulo_E',
               label='Aviso de contenido para adultos · inglés')
        setrow('scene_selector', afs_index=3890, afs_name='sce.dat',
               subresource='SceSel_E', texture='SceSel_E',
               label='Selector de capítulos y fechas · inglés')

        for sid, idx, name, label in (
            ('special_charge_attack_sp60', 2944, 'Sp_e_60.bin', 'Carga/ataque + HUD · inglés (sincroniza Special_e)'),
            ('special_charge_attack_special', 2949, 'Special_e.b', 'Carga/ataque + HUD · copia en Special_e'),
            ('special_blood_sp60', 2944, 'Sp_e_60.bin', 'Atlas Blood · inglés (sincroniza Special_e)'),
            ('special_blood_special', 2949, 'Special_e.b', 'Atlas Blood · copia en Special_e'),
            ('special_ifont_sp60', 2944, 'Sp_e_60.bin', 'Fuente IFont · inglés (sincroniza Special_e)'),
            ('special_ifont_special', 2949, 'Special_e.b', 'Fuente IFont · copia en Special_e'),
            ('special_conpas_sp60', 2944, 'Sp_e_60.bin', 'Brújula / ojos · inglés (sincroniza Special_e)'),
            ('special_conpas_special', 2949, 'Special_e.b', 'Brújula / ojos · copia en Special_e'),
            ('special_menu_sp60', 2944, 'Sp_e_60.bin', 'Atlas principal inglés · retratos y rótulos (Sp_e_60)'),
            ('special_menu_special', 2949, 'Special_e.b', 'Atlas principal inglés · retratos y rótulos (Special_e)'),
        ):
            setrow(sid, afs_index=idx, afs_name=name, label=label)

        setrow('hz_60', subresource='PS2_60Hz', texture='PS2_60Hz',
               label='Opción NTSC 60 Hz · inglés')
        setrow('hz_50', subresource='PS2_50Hz', texture='PS2_50Hz',
               label='Opción PAL 50 Hz · inglés')
        setrow('hz_confirm', subresource='euRGB60', texture='euRGB60', bpp=4,
               label='Pregunta y confirmaciones 50/60 Hz · inglés')
        setrow('hz_confirm_answer', subresource='euRGB60', texture='euRGB60', bpp=4,
               label='Confirmación 50/60 Hz · respuesta inglesa')

        difficulty = {
            'difficulty_title': 'setting.png',
            'difficulty_normal': 'normal.png',
            'difficulty_mortal': 'Deadly.png',
            'difficulty_normal_desc': 'text_a01.png',
            'difficulty_mortal_desc': 'text_b01.png',
        }
        for sid, tex in difficulty.items():
            setrow(sid, afs_index=3940, afs_name='title.dic', subresource=tex, texture=tex)
        setrow('explan_tutorial_index', afs_index=301, afs_name='explan.dat',
               label='Índice del tutorial · inglés')
        setrow('tutorial_controls', afs_index=3975, afs_name='tutorial_e',
               label='Tutorial completo · inglés')
        setrow('tutorial_yes_no', afs_index=3975, afs_name='tutorial_e',
               label='Tutorial Sí / No · inglés')
        return specs

    # Alemán.
    setrow('hz_confirm_copy', afs_index=3871, afs_name='euRGB60_g.dic',
           subresource=None, texture='euRGB60', bpp=8, format='standard_alias_t8',
           label='Confirmación 50/60 Hz · alemán (copia independiente)')
    setrow('adult_warning', subresource='gulo_G', texture='gulo_G',
           label='Aviso de contenido para adultos · alemán')
    setrow('scene_selector', afs_index=3892, afs_name='sce_G.dat',
           subresource='SceSel_G', texture='SceSel_G',
           label='Selector de capítulos y fechas · alemán')

    for sid, idx, name, label in (
        ('special_charge_attack_sp60', 2946, 'Sp_g_60.bin', 'Carga/ataque + HUD · alemán (sincroniza Special_g)'),
        ('special_charge_attack_special', 2951, 'Special_g.b', 'Carga/ataque + HUD · copia en Special_g'),
        ('special_blood_sp60', 2946, 'Sp_g_60.bin', 'Atlas Blood · alemán (sincroniza Special_g)'),
        ('special_blood_special', 2951, 'Special_g.b', 'Atlas Blood · copia en Special_g'),
        ('special_ifont_sp60', 2946, 'Sp_g_60.bin', 'Fuente IFont · alemán (sincroniza Special_g)'),
        ('special_ifont_special', 2951, 'Special_g.b', 'Fuente IFont · copia en Special_g'),
        ('special_conpas_sp60', 2946, 'Sp_g_60.bin', 'Brújula / ojos · alemán (sincroniza Special_g)'),
        ('special_conpas_special', 2951, 'Special_g.b', 'Brújula / ojos · copia en Special_g'),
        ('special_menu_sp60', 2946, 'Sp_g_60.bin', 'Atlas principal alemán · retratos y rótulos (Sp_g_60)'),
        ('special_menu_special', 2951, 'Special_g.b', 'Atlas principal alemán · retratos y rótulos (Special_g)'),
    ):
        setrow(sid, afs_index=idx, afs_name=name, label=label)

    setrow('hz_60', subresource='PS2_60HzG', texture='PS2_60HzG',
           label='Opción NTSC 60 Hz · alemán')
    setrow('hz_50', subresource='PS2_50HzG', texture='PS2_50HzG',
           label='Opción PAL 50 Hz · alemán')
    setrow('hz_confirm', subresource='euRGB60G', texture='euRGB60G', bpp=8,
           format='standard_alias_t8', label='Pregunta y confirmaciones 50/60 Hz · alemán')
    setrow('hz_confirm_answer', subresource='euRGB60G', texture='euRGB60G', bpp=8,
           format='standard_alias_t8', label='Confirmación 50/60 Hz · respuesta alemana')

    difficulty = {
        'difficulty_title': 'settingG.png',
        'difficulty_normal': 'normalG.png',
        'difficulty_mortal': 'DeadlyG.png',
        'difficulty_normal_desc': 'text_a01G.png',
        'difficulty_mortal_desc': 'text_b01G.png',
    }
    for sid, tex in difficulty.items():
        setrow(sid, afs_index=3944, afs_name='titleG.dic', subresource=tex, texture=tex)
    setrow('explan_tutorial_index', afs_index=303, afs_name='explan_g.dat',
           label='Índice del tutorial · alemán')
    setrow('tutorial_controls', afs_index=3977, afs_name='tutorial_g',
           label='Tutorial completo · alemán')
    setrow('tutorial_yes_no', afs_index=3977, afs_name='tutorial_g',
           label='Tutorial Ja / Nein · alemán')
    return specs



# v1.7.7.80 — rótulos reales del atlas `sub` del menú Special.
#
# La revisión anterior exponía rectángulos UV aislados. Eso era demasiado bajo
# nivel: varios rótulos están divididos en dos o cuatro quads, y otras tablas
# contienen variantes/animaciones del mismo texto. Para edición sólo nos interesan
# las zonas de texto lógicas.
#
# Estas regiones se reconstruyen desde SLES_533.66:
#   * los rótulos de la derecha y la lista inferior salen de descriptores de 24
#     bytes (x,y,w,h,u,v) usados por el renderer de Special;
#   * el lema "Arrête de faire l'imbécile !" usa UV construidas directamente por
#     código MIPS; se leen los inmediatos de la rama 16:9 en vez de inferirlos del
#     PNG. La rama 4:3 solapa la misma zona de texto.
#
# El resultado son 17 zonas editables sin iconos/retratos: una por rótulo visible.
EUR_SPECIAL_SUB_TEXTURE_ANCHOR = b'conpas\0\0Sub\0'
EUR_SPECIAL_SUB_ANCHOR_VA = 0x005FA600
EUR_SLES_LOAD_VA = 0x00100000
EUR_SLES_FILE_BIAS = 0x180

# id, francés, español orientativo, VAs de descriptores que forman el rótulo.
EUR_SPECIAL_SUB_TEXT_DESCRIPTOR_GROUPS = (
    ('blood_top', 'Sang', 'Sangre', (0x005F9350, 0x005F9368)),
    ('pigeon', 'Pigeon', 'Paloma', (0x005F9320, 0x005F93C8)),
    ('personalities', 'Personnalités', 'Personalidades', (0x005F9188, 0x005F91A0)),
    ('service_notes_top', 'Notes de service', 'Notas de servicio', (0x005F92F0, 0x005F9308)),
    ('change', 'Changement', 'Cambio', (0x005F91E8, 0x005F9620)),
    ('objects_top', 'Objets', 'Objetos', (0x005F9218, 0x005F9230, 0x005F9248, 0x005F9260)),
    ('restoration', 'Rétablissement', 'Restablecimiento', (0x005F9380, 0x005F9398)),
    ('smiths', 'Smiths', 'Smiths', (0x005F93E0,)),
    ('service_notes_bottom', 'Notes de service', 'Notas de servicio', (0x005F9548,)),
    ('blood_bottom', 'Sang', 'Sangre', (0x005F95A8,)),
    ('objects_bottom', 'Objets', 'Objetos', (0x005F9470,)),
    # La segunda tabla de cinco rótulos usa bandas de 26 px que no se pisan entre sí.
    ('rings', 'Anneaux', 'Anillos', (0x005F8550,)),
    ('photos', 'Photos', 'Fotos', (0x005F8568,)),
    ('collection', 'Collection', 'Colección', (0x005F8580,)),
    ('color_samples', 'Échantillons de couleur', 'Muestras de color', (0x005F8598,)),
    ('cassette_player', 'Lecteur de cassette', 'Reproductor de casetes', (0x005F85B0,)),
)


# v1.7.7.81 — retratos lógicos del mismo atlas `sub`.
#
# El ejecutable europeo calcula sus UV con la fórmula x = 202 + 64 * índice y usa
# dos alturas alternativas (ramas A/B). Para edición exponemos una única celda
# lógica por retrato, usando la variante más alta y conservando ambas como metadatos.
EUR_SPECIAL_SUB_PORTRAIT_SETUP_VA = 0x0029D808
EUR_SPECIAL_SUB_PORTRAIT_NAME_TABLE_VA = 0x005B8970
EUR_SPECIAL_SUB_PORTRAIT_JUMP_TABLE_VA = 0x005F7A70
EUR_SPECIAL_SUB_PORTRAIT_RUNTIME_TABLE_VA = 0x005F7A90
EUR_SPECIAL_SUB_PORTRAIT_ROWS = (
    ('garcian', 'Garcian', 'Garcian', 0, 'rama especial ID=1'),
    ('dan', 'Dan', 'Dan', 1, 'lista de 7 nombres'),
    ('kaede', 'KAEDE', 'Kaede', 2, 'lista de 7 nombres'),
    ('kevin', 'Kevin', 'Kevin', 3, 'lista de 7 nombres'),
    ('coyote', 'Coyote', 'Coyote', 4, 'lista de 7 nombres'),
    ('con', 'Con', 'Con', 5, 'lista de 7 nombres'),
    ('mask_de_base', 'MASK De', 'Mask de Smith', 6, 'forma base'),
    ('harman', 'Harman', 'Harman', 7, 'lista de 7 nombres'),
    ('mask_de_var1', 'MASK De', 'Mask de Smith · variante 1', 8, 'variante de máscara'),
    ('mask_de_var2', 'MASK De', 'Mask de Smith · variante 2', 9, 'variante de máscara'),
)


def _eur_sles_va_to_offset(va: int) -> int:
    return int(va) - EUR_SLES_LOAD_VA + EUR_SLES_FILE_BIAS


def _eur_special_sub_descriptor_rect(sles: bytes, va: int) -> tuple[tuple[int, int, int, int], tuple[float, ...], int]:
    """Lee un descriptor (x,y,w,h,u,v) de Special y devuelve su rectángulo fuente."""
    off = _eur_sles_va_to_offset(va)
    if off < 0 or off + 24 > len(sles):
        raise K7Error(f'Texto Imágenes EUR: descriptor Special 0x{va:X} fuera de SLES_533.66.')
    vals = struct.unpack_from('<6f', sles, off)
    if not all(math.isfinite(v) for v in vals):
        raise K7Error(f'Texto Imágenes EUR: descriptor Special 0x{va:X} contiene valores no finitos.')
    _dx, _dy, width, height, u, v = vals
    if not (4.0 <= width <= 600.0 and 4.0 <= height <= 220.0 and 0.0 <= u <= 1.0 and 0.0 <= v <= 1.0):
        raise K7Error(f'Texto Imágenes EUR: descriptor Special 0x{va:X} no coincide con la revisión soportada.')
    x1 = int(round(u * 1024.0))
    y1 = int(round(v * 512.0))
    x2 = int(round(x1 + width))
    y2 = int(round(y1 + height))
    if not (0 <= x1 < x2 <= 1024 and 0 <= y1 < y2 <= 512):
        raise K7Error(f'Texto Imágenes EUR: descriptor Special 0x{va:X} sale del atlas 1024x512.')
    return (x1, y1, x2, y2), tuple(float(v) for v in vals), off


def _eur_mips_imm16(sles: bytes, va: int) -> int:
    off = _eur_sles_va_to_offset(va)
    if off < 0 or off + 4 > len(sles):
        raise K7Error(f'Texto Imágenes EUR: instrucción MIPS 0x{va:X} fuera de SLES_533.66.')
    return int(struct.unpack_from('<I', sles, off)[0] & 0xFFFF)


def _eur_mips_float_constant(sles: bytes, hi_va: int, lo_va: int | None = None) -> float:
    bits = _eur_mips_imm16(sles, hi_va) << 16
    if lo_va is not None:
        bits |= _eur_mips_imm16(sles, lo_va)
    return float(struct.unpack('<f', struct.pack('<I', bits))[0])


def _eur_special_banner_text_rect(sles: bytes) -> tuple[tuple[int, int, int, int], list[int]]:
    """Recupera del código MIPS la UV 16:9 del lema central de Special."""
    # 0x2A4280..0x2A42E0 construye las cuatro esquinas UV del sprite frontal.
    x0 = _eur_mips_float_constant(sles, 0x002A4280) * 1024.0
    y0 = _eur_mips_float_constant(sles, 0x002A4288) * 512.0
    x1 = _eur_mips_float_constant(sles, 0x002A4298, 0x002A42A0) * 1024.0
    y1 = _eur_mips_float_constant(sles, 0x002A42B8) * 512.0
    rect = tuple(int(round(v)) for v in (x0, y0, x1, y1))
    if rect != (194, 111, 543, 172):
        raise K7Error(
            'Texto Imágenes EUR: las UV del lema de Special no coinciden con SLES_533.66 '
            f'(detectado {rect!r}).'
        )
    return rect, [
        _eur_sles_va_to_offset(0x002A4280),
        _eur_sles_va_to_offset(0x002A4288),
        _eur_sles_va_to_offset(0x002A4298),
        _eur_sles_va_to_offset(0x002A42A0),
        _eur_sles_va_to_offset(0x002A42B8),
    ]



def _eur_special_sub_portrait_specs_from_sles(sles: bytes, language: str = 'fr') -> list[dict]:
    """Devuelve los 10 retratos lógicos de ``Special/sub`` localizados desde SLES."""
    language = _eur_text_image_language(language)
    parent = next(
        (row for row in eur_text_image_specs(language) if row.get('id') == 'special_menu_special'),
        None,
    )
    if parent is None:
        raise K7Error('Texto Imágenes EUR: falta la especificación del atlas Special/sub.')
    rows = []
    source_off = _eur_sles_va_to_offset(EUR_SPECIAL_SUB_PORTRAIT_SETUP_VA)
    for number, (slug, fr_text, es_text, cell_index, evidence) in enumerate(EUR_SPECIAL_SUB_PORTRAIT_ROWS, start=1):
        x1 = 202 + 64 * int(cell_index)
        x2 = x1 + 64
        rect_a = (x1, 1, x2, 96)
        rect_b = (x1, 1, x2, 110)
        rect = rect_b
        code = f'P{number:02d}'
        rows.append({
            **dict(parent),
            'id': f'special_menu_special__portrait_{slug}',
            'group': 'Menú · Special · retratos del atlas',
            'texture': f'sub / retrato {code}',
            'label': f'{code} · {fr_text}  →  {es_text}',
            'width': rect[2] - rect[0], 'height': rect[3] - rect[1],
            'format': 'atlas_region', 'atlas_parent_id': 'special_menu_special',
            'atlas_rect': rect,
            'runtime_variants': [rect_a, rect_b],
            'logical_text': fr_text, 'suggested_es': es_text,
            'portrait_name': fr_text, 'cell_index': int(cell_index),
            'evidence': str(evidence),
            'source_sles_offset': int(source_off),
            'source_sles_offsets': [int(source_off)],
            'source_sles_vas': [
                int(EUR_SPECIAL_SUB_PORTRAIT_SETUP_VA),
                int(EUR_SPECIAL_SUB_PORTRAIT_NAME_TABLE_VA),
                int(EUR_SPECIAL_SUB_PORTRAIT_JUMP_TABLE_VA),
                int(EUR_SPECIAL_SUB_PORTRAIT_RUNTIME_TABLE_VA),
            ],
            'detected_from_sles': True,
            'export_preview_image': False,
            'is_portrait': True,
        })
    if len(rows) != 10:
        raise K7Error(f'Texto Imágenes EUR: se detectaron {len(rows)} retratos de Sub; se esperaban 10.')
    return rows


def _eur_special_sub_text_specs_from_sles(sles: bytes, language: str = 'fr') -> list[dict]:
    """Devuelve los 17 rótulos lógicos de ``Special/sub`` localizados desde SLES."""
    language = _eur_text_image_language(language)
    hits = []
    pos = 0
    while True:
        hit = sles.find(EUR_SPECIAL_SUB_TEXTURE_ANCHOR, pos)
        if hit < 0:
            break
        hits.append(hit)
        pos = hit + 1
    if len(hits) != 1:
        raise K7Error(
            'Texto Imágenes EUR: no se pudo identificar de forma única la textura Sub '
            f'en SLES_533.66 (coincidencias: {len(hits)}).'
        )
    anchor = int(hits[0])
    detected_anchor_va = anchor - EUR_SLES_FILE_BIAS + EUR_SLES_LOAD_VA
    if detected_anchor_va != EUR_SPECIAL_SUB_ANCHOR_VA:
        raise K7Error(
            'Texto Imágenes EUR: la cadena Sub está en una dirección inesperada; '
            f'esta revisión de SLES no está soportada (0x{detected_anchor_va:X}).'
        )
    parent = next(
        (row for row in eur_text_image_specs(language) if row.get('id') == 'special_menu_special'),
        None,
    )
    if parent is None:
        raise K7Error('Texto Imágenes EUR: falta la especificación del atlas Special/sub.')

    rows = []
    banner_rect, banner_offsets = _eur_special_banner_text_rect(sles)
    rows.append({
        **dict(parent),
        'id': 'special_menu_special__text_banner',
        'group': 'Menú · Special · textos del atlas',
        'texture': 'sub / texto T01',
        'label': "T01 · Arrête de faire l'imbécile !  →  ¡Deja de hacer el imbécil!",
        'width': banner_rect[2] - banner_rect[0], 'height': banner_rect[3] - banner_rect[1],
        'format': 'atlas_region', 'atlas_parent_id': 'special_menu_special',
        'atlas_rect': banner_rect,
        'logical_text': "Arrête de faire l'imbécile !", 'suggested_es': '¡Deja de hacer el imbécil!',
        'source_sles_offset': int(banner_offsets[0]), 'source_sles_offsets': banner_offsets,
        'source_sles_vas': [0x002A4280, 0x002A4288, 0x002A4298, 0x002A42A0, 0x002A42B8],
        'detected_from_sles': True, 'export_preview_image': False,
    })

    for number, (slug, fr_text, es_text, vas) in enumerate(EUR_SPECIAL_SUB_TEXT_DESCRIPTOR_GROUPS, start=2):
        parts = []
        dest_parts = []
        offsets = []
        for va in vas:
            rect, vals, off = _eur_special_sub_descriptor_rect(sles, va)
            parts.append(rect)
            dx, dy, width, height, _u, _v = vals
            dest_parts.append((
                int(round(dx)), int(round(dy)),
                int(round(dx + width)), int(round(dy + height)),
            ))
            offsets.append(int(off))
        x1 = min(r[0] for r in parts)
        y1 = min(r[1] for r in parts)
        x2 = max(r[2] for r in parts)
        y2 = max(r[3] for r in parts)
        rect = (x1, y1, x2, y2)
        # Para la edición/inyección del atlas usamos la geometría UV fuente,
        # no las coordenadas dx/dy de esos descriptores. Esas coordenadas pertenecen
        # a instancias/renderers distintos y no son comparables globalmente: en T03
        # y T06 daban falsos saltos verticales de ~41 px. El atlas, en cambio, ya
        # contiene esos rótulos montados horizontalmente. La única excepción conocida
        # es T07 (Objets), cuyos cuatro quads sí se solapan al renderizarse.
        if slug == 'objects_top':
            logical_parts = [
                (0, 0, 38, 42),
                (22, 0, 60, 42),
                (49, 0, 87, 42),
                (74, 0, 126, 42),
            ]
            logical_w, logical_h = 126, 42
        elif slug == 'pigeon':
            # Ajuste v1.7.7.110: en la GUI y al reinyectar el rótulo lógico usamos
            # la separación real que muestran los recortes franceses de juego.
            # Las dos mitades se encadenan sin solape: «Pig» + «eon».
            logical_parts = [
                (0, 0, 43, 42),
                (43, 0, 93, 42),
            ]
            logical_w, logical_h = 93, 42
        elif slug == 'change':
            # Ajuste v1.7.7.110: «Chang» + «ement» se muestran en la GUI sin
            # chafarse, respetando el ancho completo de 80+78 px.
            logical_parts = [
                (0, 0, 80, 42),
                (80, 0, 158, 42),
            ]
            logical_w, logical_h = 158, 42
        elif slug == 'restoration':
            # Ajuste v1.7.7.110: «Réta» + «blissement» se encadenan sin solape y
            # mantienen el ancho completo original de 48+156 px.
            logical_parts = [
                (0, 0, 48, 36),
                (48, 0, 204, 36),
            ]
            logical_w, logical_h = 204, 36
        else:
            logical_parts = [
                (int(r[0] - x1), int(r[1] - y1), int(r[2] - x1), int(r[3] - y1))
                for r in parts
            ]
            logical_w = x2 - x1
            logical_h = y2 - y1
        code = f'T{number:02d}'
        rows.append({
            **dict(parent),
            'id': f'special_menu_special__text_{slug}',
            'group': 'Menú · Special · textos del atlas',
            'texture': f'sub / texto {code}',
            'label': f'{code} · {fr_text}  →  {es_text}',
            'width': int(logical_w), 'height': int(logical_h),
            'format': 'atlas_region', 'atlas_parent_id': 'special_menu_special',
            'atlas_rect': rect, 'runtime_parts': [tuple(r) for r in parts],
            'runtime_dest_parts': [tuple(r) for r in logical_parts],
            'logical_size': (int(logical_w), int(logical_h)),
            'logical_text': fr_text, 'suggested_es': es_text,
            'source_sles_offset': int(offsets[0]), 'source_sles_offsets': offsets,
            'source_sles_vas': [int(v) for v in vas],
            'detected_from_sles': True, 'export_preview_image': False,
        })
    if len(rows) != 17:
        raise K7Error(f'Texto Imágenes EUR: se detectaron {len(rows)} rótulos de Sub; se esperaban 17.')
    return rows


def detect_eur_special_sub_sprites(eur_iso: str | Path, language: str = 'fr') -> list[dict]:
    """Compatibilidad/API: detecta los 17 rótulos editables de ``Special/sub``."""
    eur_iso = Path(eur_iso).resolve()
    with ISO9660(eur_iso) as iso:
        if not is_compatible_eur_iso(iso):
            raise K7Error(f'Texto Imágenes EUR requiere una estructura compatible con {EUR_SUPPORTED_SERIAL}.')
        sles_node = iso.find([EUR_SUPPORTED_SERIAL])
        sles = iso.read(sles_node)
    if len(sles) != sles_node.size:
        raise K7Error('Texto Imágenes EUR: no se pudo leer SLES_533.66 completo.')
    return _eur_special_sub_text_specs_from_sles(sles, language)


def _eur_text_image_spec(spec_id: str, language: str = 'fr') -> dict:
    for row in eur_text_image_specs(language):
        if row['id'] == spec_id:
            return row
    raise K7Error(f'Texto Imágenes EUR: recurso desconocido {spec_id!r}.')


def _eur_text_image_named_subresource(entry: bytes, name: str) -> tuple[int, bytes]:
    needle = name.encode('ascii') + b'\0'
    name_off = entry.find(needle)
    if name_off < 0:
        raise K7Error(f'Texto Imágenes EUR: no se encontró el recurso {name}.')
    ps2_off = entry.rfind(b'PS2\0', 0, name_off)
    if ps2_off < 0 or ps2_off < 0x34:
        raise K7Error(f'Texto Imágenes EUR: cabecera PS2 de {name} no localizada.')
    start = ps2_off - 0x34
    next_ps2 = entry.find(b'PS2\0', ps2_off + 4)
    end = (next_ps2 - 0x34) if next_ps2 >= 0 and next_ps2 >= 0x34 else len(entry)
    if end <= start:
        end = len(entry)
    return start, entry[start:end]


def _eur_text_image_subresource(entry: bytes, spec: dict) -> tuple[int, bytes]:
    name = spec.get('subresource')
    if name:
        return _eur_text_image_named_subresource(entry, str(name))
    # Sin subrecurso: la entrada AFS completa es la textura. El formato concreto
    # (DIC 4bpp o alias GS 8bpp) lo valida el llamador según ``spec['format']``.
    return 0, entry




def _eur_k7_lz_decompress(data: bytes) -> bytes:
    """Descomprime el contenedor LZ usado por Sp_*_60.bin / Special_*.b.

    Cabecera: u32 tamaño descomprimido, u32 tamaño comprimido total, u8 marcador.
    El tamaño total permite que el recurso permanezca rellenado hasta el tamaño
    original del slot AFS tras una recompresión más corta.
    """
    if len(data) < 9:
        raise K7Error('Texto Imágenes EUR: contenedor LZ truncado.')
    out_size, total_size = struct.unpack_from('<II', data, 0)
    marker = int(data[8])
    if out_size <= 0 or total_size < 9 or total_size > len(data):
        raise K7Error(
            f'Texto Imágenes EUR: cabecera LZ inválida '
            f'(raw={out_size}, packed={total_size}, slot={len(data)}).'
        )
    src = 9
    end = int(total_size)
    out = bytearray()
    while src < end and len(out) < int(out_size):
        b = int(data[src])
        if b != marker:
            out.append(b)
            src += 1
            continue
        if src + 1 >= end:
            raise K7Error('Texto Imágenes EUR: marcador LZ truncado.')
        code = int(data[src + 1])
        if code == marker:
            out.append(marker)
            src += 2
            continue
        if code > marker:
            code -= 1
        src += 2
        length_code = code >> 3
        if code & 4:
            if src >= end:
                raise K7Error('Texto Imágenes EUR: longitud LZ truncada.')
            length_code |= int(data[src]) << 5
            src += 1
        low = code & 3
        dist_bytes = 1 if low == 0 else (3 if low == 2 else 2)
        if src + dist_bytes > end:
            raise K7Error('Texto Imágenes EUR: distancia LZ truncada.')
        distance = int.from_bytes(data[src:src+dist_bytes], 'little') + 1
        src += dist_bytes
        length = int(length_code) + 4
        if distance <= 0 or distance > len(out):
            raise K7Error(
                f'Texto Imágenes EUR: referencia LZ inválida '
                f'(distancia={distance}, salida={len(out)}).'
            )
        for _ in range(length):
            out.append(out[-distance])
            if len(out) >= int(out_size):
                break
    if len(out) != int(out_size):
        raise K7Error(
            f'Texto Imágenes EUR: LZ produjo {len(out)} bytes; se esperaban {out_size}.'
        )
    return bytes(out)


def _eur_k7_lz_compress(raw: bytes, marker: int, *, max_chain: int = 96) -> bytes:
    """Recompresor compatible con el descompresor LZ de SLES_533.66."""
    if not (0 <= int(marker) <= 0xFF):
        raise K7Error('Texto Imágenes EUR: marcador LZ fuera de rango.')
    marker = int(marker)
    n = len(raw)
    stream = bytearray()
    chains: dict[int, list[int]] = {}
    i = 0

    def add_pos(pos: int) -> None:
        if pos + 4 > n:
            return
        key = int.from_bytes(raw[pos:pos+4], 'little')
        arr = chains.get(key)
        if arr is None:
            chains[key] = [pos]
        else:
            arr.append(pos)
            if len(arr) > max_chain * 2:
                del arr[:len(arr) - max_chain]

    marker_byte = bytes((marker,))
    while i < n:
        best_len = 0
        best_dist = 0
        if i + 4 <= n:
            key = int.from_bytes(raw[i:i+4], 'little')
            arr = chains.get(key, ())
            checked = 0
            max_len = min(8195, n - i)
            for pos in reversed(arr):
                dist = i - int(pos)
                if dist <= 0:
                    continue
                if dist > 0x1000000:
                    break
                checked += 1
                length = 4
                while (length + 16 <= max_len and
                       raw[pos+length:pos+length+16] == raw[i+length:i+length+16]):
                    length += 16
                while length < max_len and raw[pos+length] == raw[i+length]:
                    length += 1
                if length > best_len:
                    lc = length - 4
                    dv = dist - 1
                    dcode = 0 if dv <= 0xFF else (1 if dv <= 0xFFFF else 2)
                    ref_cost = 2 + (1 if lc >= 32 else 0) + dcode + 1
                    if length > ref_cost:
                        best_len = length
                        best_dist = dist
                        if length == max_len:
                            break
                if checked >= max_chain:
                    break
        if best_len >= 4:
            literal_cost = best_len + raw[i:i+best_len].count(marker_byte)
            lc = best_len - 4
            dv = best_dist - 1
            dcode = 0 if dv <= 0xFF else (1 if dv <= 0xFFFF else 2)
            ref_cost = 2 + (1 if lc >= 32 else 0) + dcode + 1
            if ref_cost < literal_cost:
                logical = ((lc & 31) << 3) | (4 if lc >= 32 else 0) | dcode
                stored = logical + 1 if logical >= marker else logical
                if stored > 0xFF:
                    raise K7Error('Texto Imágenes EUR: código LZ no representable.')
                stream.extend((marker, stored))
                if lc >= 32:
                    stream.append((lc >> 5) & 0xFF)
                stream.extend(dv.to_bytes(dcode + 1, 'little'))
                end = i + best_len
                while i < end:
                    add_pos(i)
                    i += 1
                continue
        value = int(raw[i])
        if value == marker:
            stream.extend((marker, marker))
        else:
            stream.append(value)
        add_pos(i)
        i += 1
    packed = struct.pack('<II', n, 9 + len(stream)) + bytes((marker,)) + bytes(stream)
    # Defensa fuerte: cualquier cambio futuro en el encoder debe seguir haciendo
    # round-trip antes de tocar la ISO.
    if _eur_k7_lz_decompress(packed) != raw:
        raise K7Error('Texto Imágenes EUR: la recompresión LZ no supera round-trip.')
    return packed



def _eur_standard_alias_t8_layout(sub: bytes) -> dict:
    """Layout 8bpp estándar de ChargeAttack/conpas dentro de Sp/Special.

    Estos recursos usan el mismo alias de memoria GS que Tutorial: el IMAGE se
    transfiere como PSMCT32 con dimensiones (w/2,h/2) y luego se lee como PSMT8.
    A diferencia del atlas ``sub``, conservan el paquete GS estándar de 0x50
    bytes entre IMAGE y la CLUT de 256 colores.
    """
    if len(sub) < 0x180:
        raise K7Error('Texto Imágenes EUR: textura 8bpp comprimida truncada.')
    try:
        name_len = int(struct.unpack_from('<I', sub, 0x40)[0])
        shift = name_len - 8
        width, height, bpp = struct.unpack_from('<III', sub, 0x78 + shift)
        trxreg = struct.unpack_from('<Q', sub, 0xE4 + shift)[0]
        image_tag = struct.unpack_from('<Q', sub, 0x104 + shift)[0]
    except struct.error as exc:
        raise K7Error('Texto Imágenes EUR: cabecera 8bpp comprimida truncada.') from exc
    if shift < -8 or shift > 0x100 or int(bpp) != 8:
        raise K7Error(
            f'Texto Imágenes EUR: textura comprimida incompatible '
            f'(name_len={name_len}, bpp={bpp}).'
        )
    width, height = int(width), int(height)
    if not (1 <= width <= 4096 and 1 <= height <= 4096):
        raise K7Error(f'Texto Imágenes EUR: dimensiones 8bpp inválidas: {width}x{height}.')
    rrw = int(trxreg & 0xFFF)
    rrh = int((trxreg >> 32) & 0xFFF)
    nloop = int(image_tag & 0x7FFF)
    payload_size = width * height
    if (rrw, rrh) != (width // 2, height // 2) or nloop * 16 != payload_size:
        raise K7Error(
            f'Texto Imágenes EUR: transferencia GS 8bpp inesperada '
            f'({rrw}x{rrh}, nloop={nloop}) para {width}x{height}.'
        )
    pixel_off = 0x114 + shift
    clut_off = pixel_off + payload_size + 0x50
    if pixel_off < 0 or clut_off + 256 * 4 > len(sub):
        raise K7Error('Texto Imágenes EUR: payload/CLUT 8bpp comprimido fuera de rango.')
    return {
        'name_len': name_len, 'shift': shift,
        'width': width, 'height': height, 'bpp': 8,
        'pixel_offset': pixel_off, 'payload_size': payload_size,
        'clut_offset': clut_off, 'rrw': rrw, 'rrh': rrh, 'nloop': nloop,
    }


def _eur_standard_alias_t8_palette(sub: bytes, layout: dict | None = None) -> list[tuple[int, int, int, int]]:
    layout = layout or _eur_standard_alias_t8_layout(sub)
    base = int(layout['clut_offset'])
    palette = []
    for i in range(256):
        r, g, b, a = sub[base+i*4:base+i*4+4]
        if int(a) > 0x80:
            raise K7Error('Texto Imágenes EUR: alfa CLUT 8bpp fuera del rango GS esperado.')
        palette.append((int(r), int(g), int(b), min(255, int(a) * 2)))
    return palette


def _eur_preview_standard_alias_t8(sub: bytes) -> Image.Image:
    layout = _eur_standard_alias_t8_layout(sub)
    width, height = int(layout['width']), int(layout['height'])
    po, ps = int(layout['pixel_offset']), int(layout['payload_size'])
    payload = sub[po:po+ps]
    vram = bytearray(4 * 1024 * 1024)
    rrw, rrh = int(layout['rrw']), int(layout['rrh'])
    dbw = max(1, rrw // 64)
    _eur_write_ct32(vram, dbw, rrw, rrh, payload)
    if _eur_read_ct32(vram, dbw, rrw, rrh) != payload:
        raise K7Error('Texto Imágenes EUR: transferencia PSMCT32 8bpp no supera round-trip.')
    indices = _eur_read_t8(vram, width, height)
    palette = _eur_standard_alias_t8_palette(sub, layout)
    image = Image.new('P', (width, height))
    image.putdata(indices)
    flat_rgb = []
    alpha = []
    for r, g, b, a in palette:
        flat_rgb.extend((r, g, b))
        alpha.append(a)
    image.putpalette(flat_rgb)
    image.info['transparency'] = bytes(alpha)
    return image


def _eur_encode_standard_alias_t8_image(sub: bytes, image: Image.Image,
                                         expected_size: tuple[int, int]) -> bytes:
    layout = _eur_standard_alias_t8_layout(sub)
    width, height = int(layout['width']), int(layout['height'])
    if (width, height) != tuple(expected_size) or image.size != (width, height):
        raise K7Error(
            f'Texto Imágenes EUR: la textura 8bpp debe medir exactamente {width}x{height}.'
        )
    po, ps = int(layout['pixel_offset']), int(layout['payload_size'])
    payload = sub[po:po+ps]
    vram = bytearray(4 * 1024 * 1024)
    rrw, rrh = int(layout['rrw']), int(layout['rrh'])
    dbw = max(1, rrw // 64)
    _eur_write_ct32(vram, dbw, rrw, rrh, payload)
    original_indices = _eur_read_t8(vram, width, height)
    palette = _eur_standard_alias_t8_palette(sub, layout)

    if _eur_special_menu_png_palette_matches(image, palette):
        target_indices = bytearray(image.getdata())
    else:
        rgba = image.convert('RGBA')
        pixels = list(rgba.getdata())
        transparent = next((i for i, (_r, _g, _b, a) in enumerate(palette) if a == 0), 0)
        cache: dict[tuple[int, int, int, int], int] = {}
        target_indices = bytearray(len(pixels))
        for pos, px in enumerate(pixels):
            old = int(original_indices[pos])
            if tuple(px) == tuple(palette[old]):
                target_indices[pos] = old
                continue
            if px in cache:
                target_indices[pos] = cache[px]
                continue
            r, g, b, a = px
            if int(a) <= 3:
                best_i = transparent
            else:
                best_i = 0
                best_d = None
                for idx, (pr, pg, pb, pa) in enumerate(palette):
                    d = ((int(r)-pr)*(int(r)-pr) + (int(g)-pg)*(int(g)-pg) +
                         (int(b)-pb)*(int(b)-pb) + 3*(int(a)-pa)*(int(a)-pa))
                    if best_d is None or d < best_d:
                        best_d = d
                        best_i = idx
            cache[px] = int(best_i)
            target_indices[pos] = int(best_i)

    for pos, new_idx in enumerate(target_indices):
        if int(original_indices[pos]) != int(new_idx):
            _eur_write_t8(vram, width, pos % width, pos // width, int(new_idx))
    new_payload = _eur_read_ct32(vram, dbw, rrw, rrh)
    check = bytearray(4 * 1024 * 1024)
    _eur_write_ct32(check, dbw, rrw, rrh, new_payload)
    if _eur_read_t8(check, width, height) != target_indices:
        raise K7Error('Texto Imágenes EUR: recompilación 8bpp no reproduce los índices solicitados.')
    out = bytearray(sub)
    out[po:po+ps] = new_payload
    return bytes(out)


def _eur_encode_png_into_standard_alias_t8(sub: bytes, png_path: str | Path,
                                            expected_size: tuple[int, int]) -> bytes:
    png_path = Path(png_path)
    if not png_path.is_file():
        raise K7Error(f'No existe la imagen de reemplazo: {png_path}')
    try:
        with Image.open(png_path) as src:
            src.load()
            if src.size != tuple(expected_size):
                raise K7Error(
                    f'{png_path.name} mide {src.width}x{src.height}; '
                    f'debe medir exactamente {expected_size[0]}x{expected_size[1]}.'
                )
            image = src.copy()
    except K7Error:
        raise
    except Exception as exc:
        raise K7Error(f'No se pudo abrir {png_path.name}: {exc}') from exc
    return _eur_encode_standard_alias_t8_image(sub, image, expected_size)


def _eur_special_menu_t8_layout(sub: bytes) -> dict:
    """Layout de ``sub`` en Sp_f_60.bin / Special_f.b.

    Es una textura de 1024x512 PSMT8 cuya transferencia física usa PSMCT32
    (512x256 RGBA32) y una CLUT de 256 colores al final del payload.
    """
    if len(sub) < 0x804BC:
        raise K7Error('Texto Imágenes EUR: atlas especial 8bpp truncado.')
    if sub[0x34:0x38] != b'PS2\0' or sub[0x48:0x4C] != b'sub\0':
        raise K7Error('Texto Imágenes EUR: cabecera PS2/sub del atlas especial no reconocida.')
    try:
        width, height, bpp = struct.unpack_from('<III', sub, 0x74)
    except struct.error as exc:
        raise K7Error('Texto Imágenes EUR: cabecera del atlas especial truncada.') from exc
    if (int(width), int(height), int(bpp)) != (1024, 512, 8):
        raise K7Error(
            f'Texto Imágenes EUR: atlas sub es {width}x{height} {bpp}bpp; '
            'se esperaba 1024x512 8bpp.'
        )
    # El subrecurso compacto `sub` no usa el mismo inicio de IMAGE que los
    # DIC estándar. Los cuatro bytes 0xBC..0xBF pertenecen al final de la
    # cabecera; el flujo de texels empieza realmente en 0xC0. Leer desde 0xBC
    # desplaza el stream CT32 y produce el típico atlas "rasgado" aunque los
    # rótulos aún sean reconocibles.
    pixel_off = 0xC0
    payload_size = int(width) * int(height)
    clut_off = pixel_off + payload_size
    if clut_off + 256 * 4 > len(sub):
        raise K7Error('Texto Imágenes EUR: payload/CLUT del atlas especial fuera de rango.')
    return {
        'width': int(width), 'height': int(height), 'bpp': int(bpp),
        'pixel_offset': int(pixel_off), 'payload_size': int(payload_size),
        'clut_offset': int(clut_off),
    }


def _eur_special_menu_palette(sub: bytes, layout: dict | None = None) -> list[tuple[int, int, int, int]]:
    """Devuelve la CLUT lógica PSMT8 del atlas `sub`.

    La tabla física de 256 RGBA32 está almacenada en el orden CSM1 del GS.
    En CSM1 para PSMT8 los bits 3 y 4 del índice seleccionan mitades cruzadas
    de la CLUT; tratarlos como una paleta lineal conserva la geometría pero
    asigna colores/transparencias equivocados. El intercambio es involutivo.
    """
    layout = layout or _eur_special_menu_t8_layout(sub)
    base = int(layout['clut_offset'])
    physical = [tuple(sub[base+i*4:base+i*4+4]) for i in range(256)]
    palette = []
    for i in range(256):
        j = (i & 0xE7) | ((i & 0x08) << 1) | ((i & 0x10) >> 1)
        r, g, b, a = physical[j]
        # Alfa GS: 0x80 equivale a 255 en PNG.
        palette.append((int(r), int(g), int(b), min(255, int(a) * 2)))
    return palette


def _eur_preview_special_menu_t8(sub: bytes) -> Image.Image:
    layout = _eur_special_menu_t8_layout(sub)
    width, height = int(layout['width']), int(layout['height'])
    po, ps = int(layout['pixel_offset']), int(layout['payload_size'])
    payload = sub[po:po+ps]
    vram = bytearray(4 * 1024 * 1024)
    rrw, rrh = width // 2, height // 2
    dbw = max(1, rrw // 64)
    _eur_write_ct32(vram, dbw, rrw, rrh, payload)
    if _eur_read_ct32(vram, dbw, rrw, rrh) != payload:
        raise K7Error('Texto Imágenes EUR: atlas especial PSMCT32 no supera round-trip.')
    indices = _eur_read_t8(vram, width, height)
    palette = _eur_special_menu_palette(sub, layout)
    image = Image.new('P', (width, height))
    image.putdata(indices)
    flat_rgb = []
    alpha = []
    for r, g, b, a in palette:
        flat_rgb.extend((r, g, b))
        alpha.append(a)
    image.putpalette(flat_rgb)
    image.info['transparency'] = bytes(alpha)
    return image


def _eur_special_menu_png_palette_matches(src: Image.Image,
                                           palette: list[tuple[int, int, int, int]]) -> bool:
    if src.mode != 'P':
        return False
    raw_pal = src.getpalette()
    if not raw_pal or len(raw_pal) < 256 * 3:
        return False
    trans = src.info.get('transparency')
    if isinstance(trans, bytes):
        alpha = list(trans[:256]) + [255] * max(0, 256 - len(trans))
    elif isinstance(trans, int):
        alpha = [255] * 256
        if 0 <= trans < 256:
            alpha[trans] = 0
    else:
        alpha = [255] * 256
    for i, (r, g, b, a) in enumerate(palette):
        j = i * 3
        if tuple(raw_pal[j:j+3]) != (r, g, b) or int(alpha[i]) != int(a):
            return False
    return True


def _eur_encode_special_menu_t8_image(sub: bytes, image: Image.Image,
                                       expected_size: tuple[int, int]) -> bytes:
    layout = _eur_special_menu_t8_layout(sub)
    width, height = int(layout['width']), int(layout['height'])
    if (width, height) != tuple(expected_size) or image.size != (width, height):
        raise K7Error(
            f'Texto Imágenes EUR: el atlas especial debe medir exactamente {width}x{height}.'
        )
    po, ps = int(layout['pixel_offset']), int(layout['payload_size'])
    payload = sub[po:po+ps]
    vram = bytearray(4 * 1024 * 1024)
    rrw, rrh = width // 2, height // 2
    dbw = max(1, rrw // 64)
    _eur_write_ct32(vram, dbw, rrw, rrh, payload)
    original_indices = _eur_read_t8(vram, width, height)
    palette = _eur_special_menu_palette(sub, layout)

    if _eur_special_menu_png_palette_matches(image, palette):
        target_indices = bytearray(image.getdata())
    else:
        rgba = image.convert('RGBA')
        pixels = list(rgba.getdata())
        transparent = next((i for i, (_r, _g, _b, a) in enumerate(palette) if a == 0), 0)
        cache: dict[tuple[int, int, int, int], int] = {}
        target_indices = bytearray(len(pixels))
        for pos, px in enumerate(pixels):
            old = int(original_indices[pos])
            if tuple(px) == tuple(palette[old]):
                target_indices[pos] = old
                continue
            if px in cache:
                target_indices[pos] = cache[px]
                continue
            r, g, b, a = px
            if int(a) <= 3:
                best_i = transparent
            else:
                best_i = 0
                best_d = None
                for idx, (pr, pg, pb, pa) in enumerate(palette):
                    d = ((int(r)-pr)*(int(r)-pr) + (int(g)-pg)*(int(g)-pg) +
                         (int(b)-pb)*(int(b)-pb) + 3*(int(a)-pa)*(int(a)-pa))
                    if best_d is None or d < best_d:
                        best_d = d
                        best_i = idx
            cache[px] = int(best_i)
            target_indices[pos] = int(best_i)

    for pos, new_idx in enumerate(target_indices):
        if int(original_indices[pos]) != int(new_idx):
            _eur_write_t8(vram, width, pos % width, pos // width, int(new_idx))
    new_payload = _eur_read_ct32(vram, dbw, rrw, rrh)
    check = bytearray(4 * 1024 * 1024)
    _eur_write_ct32(check, dbw, rrw, rrh, new_payload)
    if _eur_read_t8(check, width, height) != target_indices:
        raise K7Error('Texto Imágenes EUR: atlas especial no supera round-trip PSMCT32→PSMT8.')
    out = bytearray(sub)
    out[po:po+ps] = new_payload
    return bytes(out)


def _eur_encode_png_into_special_menu_t8(sub: bytes, png_path: str | Path,
                                          expected_size: tuple[int, int]) -> bytes:
    png_path = Path(png_path)
    if not png_path.is_file():
        raise K7Error(f'No existe la imagen de reemplazo: {png_path}')
    try:
        with Image.open(png_path) as src:
            src.load()
            if src.size != tuple(expected_size):
                raise K7Error(
                    f'{png_path.name} mide {src.width}x{src.height}; '
                    f'debe medir exactamente {expected_size[0]}x{expected_size[1]}.'
                )
            image = src.copy()
    except K7Error:
        raise
    except Exception as exc:
        raise K7Error(f'No se pudo abrir {png_path.name}: {exc}') from exc
    return _eur_encode_special_menu_t8_image(sub, image, expected_size)


def _eur_rebuild_compressed_text_image_entry(entry: bytes, spec: dict,
                                              png_path: str | Path, *,
                                              allow_growth: bool = False) -> tuple[bytes, int]:
    """Edita ``sub`` dentro del LZ.

    Por defecto conserva el tamaño histórico del slot AFS para los reemplazos
    directos de Texto Imágenes. El flujo integrado de ``Special_f.b`` puede usar
    ``allow_growth=True``: devuelve entonces el stream LZ con su tamaño real y
    deja que ``_eur_rebuild_afs`` recalcule offsets y, si hace falta, haga crecer
    DIR_E.AFS de forma segura.
    """
    if len(entry) < 9:
        raise K7Error('Texto Imágenes EUR: recurso comprimido truncado.')
    marker = int(entry[8])
    raw = _eur_k7_lz_decompress(entry)
    sub_off, sub = _eur_text_image_subresource(raw, spec)
    fmt = str(spec.get('format') or '')
    expected = (int(spec['width']), int(spec['height']))
    if fmt == 'compressed_psmct32_alias_t8':
        new_sub = _eur_encode_png_into_special_menu_t8(sub, png_path, expected)
    elif fmt == 'compressed_standard_alias_t8':
        new_sub = _eur_encode_png_into_standard_alias_t8(sub, png_path, expected)
    elif fmt == 'compressed_dic4':
        new_sub = _eur_encode_png_into_dic(sub, png_path, expected)
    else:
        raise K7Error(f'Texto Imágenes EUR: formato comprimido no soportado: {fmt!r}.')
    if len(new_sub) != len(sub):
        raise K7Error('Texto Imágenes EUR: el subrecurso especial cambió de tamaño.')
    buf = bytearray(raw)
    buf[sub_off:sub_off+len(new_sub)] = new_sub
    packed = _eur_k7_lz_compress(bytes(buf), marker)
    if len(packed) > len(entry) and not allow_growth:
        raise K7Error(
            f'Texto Imágenes EUR: {spec["afs_name"]} recompilado ocupa {len(packed)} bytes; '
            f'el slot AFS sólo admite {len(entry)}.'
        )
    # En el editor directo seguimos rellenando hasta el tamaño anterior porque
    # allí se escribe sobre la ISO sin reconstruir el AFS. En el flujo integrado
    # devolvemos exactamente el stream LZ: _eur_rebuild_afs actualizará la tabla.
    slot = packed if allow_growth else packed + bytes(len(entry) - len(packed))
    if _eur_k7_lz_decompress(slot) != bytes(buf):
        raise K7Error('Texto Imágenes EUR: verificación LZ del recurso recompilado fallida.')
    return slot, len(packed)




def _eur_special_logical_region_layout(spec: dict) -> tuple[list[tuple[int, int, int, int]], list[tuple[int, int, int, int]], tuple[int, int]]:
    src_parts = [tuple(int(v) for v in r) for r in (spec.get('runtime_parts') or [spec.get('atlas_rect')])]
    dst_parts = [tuple(int(v) for v in r) for r in (spec.get('runtime_dest_parts') or [])]
    if not dst_parts:
        if not src_parts:
            raise K7Error('Texto Imágenes EUR: spec Special sin rectángulos.')
        x1, y1, x2, y2 = src_parts[0]
        dst_parts = [(0, 0, x2 - x1, y2 - y1)]
    if len(src_parts) != len(dst_parts):
        raise K7Error('Texto Imágenes EUR: el número de partes fuente/destino no coincide.')
    size = spec.get('logical_size')
    if isinstance(size, (list, tuple)) and len(size) == 2:
        logical_size = (int(size[0]), int(size[1]))
    else:
        logical_size = (
            max(int(r[2]) for r in dst_parts),
            max(int(r[3]) for r in dst_parts),
        )
    return src_parts, dst_parts, logical_size


def _eur_special_compose_logical_region(atlas_rgba: Image.Image, spec: dict) -> Image.Image:
    src_parts, dst_parts, logical_size = _eur_special_logical_region_layout(spec)
    out = Image.new('RGBA', logical_size, (0, 0, 0, 0))
    for src_rect, dst_rect in zip(src_parts, dst_parts):
        sx1, sy1, sx2, sy2 = src_rect
        dx1, dy1, dx2, dy2 = dst_rect
        tile = atlas_rgba.crop((sx1, sy1, sx2, sy2))
        target_size = (dx2 - dx1, dy2 - dy1)
        if tile.size != target_size:
            tile = tile.resize(target_size, Image.Resampling.LANCZOS)
        out.alpha_composite(tile, (dx1, dy1))
    return out


def _eur_special_apply_logical_region(atlas_rgba: Image.Image, spec: dict, logical_image: Image.Image) -> Image.Image:
    src_parts, dst_parts, logical_size = _eur_special_logical_region_layout(spec)
    if logical_image.size != logical_size:
        raise K7Error(
            f'La imagen lógica mide {logical_image.width}x{logical_image.height}; '
            f'se esperaba {logical_size[0]}x{logical_size[1]}.'
        )
    out = atlas_rgba.copy()
    for src_rect, dst_rect in zip(src_parts, dst_parts):
        sx1, sy1, sx2, sy2 = src_rect
        dx1, dy1, dx2, dy2 = dst_rect
        tile = logical_image.crop((dx1, dy1, dx2, dy2))
        source_size = (sx2 - sx1, sy2 - sy1)
        if tile.size != source_size:
            tile = tile.resize(source_size, Image.Resampling.LANCZOS)
        out.paste(tile, (sx1, sy1))
    return out


def _eur_special_source_region_layout(spec: dict) -> tuple[list[tuple[int, int, int, int]], list[tuple[int, int, int, int]], tuple[int, int]]:
    rect = spec.get('atlas_rect')
    if not rect:
        raise K7Error('Texto Imágenes EUR: región Special sin atlas_rect.')
    x1, y1, x2, y2 = [int(v) for v in rect]
    src_parts = [tuple(int(v) for v in r) for r in (spec.get('runtime_parts') or [])]
    if not src_parts:
        src_parts = [(x1, y1, x2, y2)]
    local_parts = [(sx1 - x1, sy1 - y1, sx2 - x1, sy2 - y1) for (sx1, sy1, sx2, sy2) in src_parts]
    source_size = (x2 - x1, y2 - y1)
    return src_parts, local_parts, source_size


def _eur_special_apply_source_region(atlas_rgba: Image.Image, spec: dict, source_image: Image.Image) -> Image.Image:
    src_parts, local_parts, source_size = _eur_special_source_region_layout(spec)
    if source_image.size != source_size:
        raise K7Error(
            f'La imagen fuente mide {source_image.width}x{source_image.height}; '
            f'se esperaba {source_size[0]}x{source_size[1]}.'
        )
    out = atlas_rgba.copy()
    for src_rect, local_rect in zip(src_parts, local_parts):
        sx1, sy1, sx2, sy2 = src_rect
        lx1, ly1, lx2, ly2 = local_rect
        tile = source_image.crop((lx1, ly1, lx2, ly2))
        target_size = (sx2 - sx1, sy2 - sy1)
        if tile.size != target_size:
            tile = tile.resize(target_size, Image.Resampling.LANCZOS)
        out.paste(tile, (sx1, sy1))
    return out


def _eur_rebuild_special_menu_region_entry(
    entry: bytes, parent_spec: dict, png_path: str | Path, spec: dict, *, allow_growth: bool = True
) -> tuple[bytes, int]:
    """Reemplaza una región lógica de Special/sub y recompone el LZ."""
    if len(entry) < 9:
        raise K7Error('Texto Imágenes EUR: recurso Special comprimido truncado.')
    rect = spec.get('atlas_rect')
    if not rect:
        raise K7Error('Texto Imágenes EUR: región Special sin atlas_rect.')
    x1, y1, x2, y2 = [int(v) for v in rect]
    if not (0 <= x1 < x2 <= 1024 and 0 <= y1 < y2 <= 512):
        raise K7Error(f'Texto Imágenes EUR: rectángulo UV inválido: {rect!r}.')
    png_path = Path(png_path)
    if not png_path.is_file():
        raise K7Error(f'No existe la imagen de reemplazo: {png_path}')
    try:
        with Image.open(png_path) as src:
            src.load()
            expected = (int(spec['width']), int(spec['height']))
            if src.size != expected:
                raise K7Error(
                    f'{png_path.name} mide {src.width}x{src.height}; '
                    f'el rótulo requiere exactamente {expected[0]}x{expected[1]}.'
                )
            tile = src.convert('RGBA')
    except K7Error:
        raise
    except Exception as exc:
        raise K7Error(f'No se pudo abrir {png_path.name}: {exc}') from exc

    marker = int(entry[8])
    raw = _eur_k7_lz_decompress(entry)
    sub_off, sub = _eur_text_image_subresource(raw, parent_spec)
    atlas = _eur_preview_special_menu_t8(sub).convert('RGBA')
    atlas = _eur_special_apply_logical_region(atlas, spec, tile)
    new_sub = _eur_encode_special_menu_t8_image(sub, atlas, (1024, 512))
    if len(new_sub) != len(sub):
        raise K7Error('Texto Imágenes EUR: el subrecurso Special/sub cambió de tamaño.')
    buf = bytearray(raw)
    buf[sub_off:sub_off + len(new_sub)] = new_sub
    packed = _eur_k7_lz_compress(bytes(buf), marker)
    if len(packed) > len(entry) and not allow_growth:
        raise K7Error(
            f'Texto Imágenes EUR: Special recompilado ocupa {len(packed)} bytes; '
            f'el slot AFS sólo admite {len(entry)}.'
        )
    slot = packed if allow_growth else packed + bytes(len(entry) - len(packed))
    if _eur_k7_lz_decompress(slot) != bytes(buf):
        raise K7Error('Texto Imágenes EUR: verificación LZ del rótulo Special fallida.')
    return slot, len(packed)


def _eur_rebuild_special_menu_regions_entry(
    entry: bytes, parent_spec: dict, rows: list[tuple[dict, Path]], *, allow_growth: bool = True
) -> tuple[bytes, int]:
    """Aplica varias regiones de ``Special/sub`` en una única decodificación/compresión."""
    if len(entry) < 9:
        raise K7Error('Texto Imágenes EUR: recurso Special comprimido truncado.')
    marker = int(entry[8])
    raw = _eur_k7_lz_decompress(entry)
    sub_off, sub = _eur_text_image_subresource(raw, parent_spec)
    atlas = _eur_preview_special_menu_t8(sub).convert('RGBA')

    occupied = []
    for spec, png_path in rows:
        x1, y1, x2, y2 = [int(v) for v in spec['atlas_rect']]
        if not (0 <= x1 < x2 <= 1024 and 0 <= y1 < y2 <= 512):
            raise K7Error(f'Texto Imágenes EUR: rectángulo UV inválido: {(x1,y1,x2,y2)!r}.')
        for ox1, oy1, ox2, oy2 in occupied:
            # Sólo se permiten solapes si son exactamente la misma caja; los 17 rótulos
            # verificados no se solapan y esto detecta manifiestos dañados.
            if x1 < ox2 and x2 > ox1 and y1 < oy2 and y2 > oy1:
                raise K7Error(
                    f'Texto Imágenes EUR: regiones Special solapadas: {(x1,y1,x2,y2)} y {(ox1,oy1,ox2,oy2)}.'
                )
        occupied.append((x1, y1, x2, y2))
        png_path = Path(png_path)
        try:
            with Image.open(png_path) as src:
                src.load()
                expected = (x2 - x1, y2 - y1)
                if src.size != expected:
                    raise K7Error(
                        f'{png_path.name} mide {src.width}x{src.height}; '
                        f'la región requiere {expected[0]}x{expected[1]}.'
                    )
                tile = src.convert('RGBA')
        except K7Error:
            raise
        except Exception as exc:
            raise K7Error(f'No se pudo abrir {png_path.name}: {exc}') from exc
        atlas.paste(tile, (x1, y1))

    new_sub = _eur_encode_special_menu_t8_image(sub, atlas, (1024, 512))
    if len(new_sub) != len(sub):
        raise K7Error('Texto Imágenes EUR: el subrecurso Special/sub cambió de tamaño.')
    buf = bytearray(raw)
    buf[sub_off:sub_off + len(new_sub)] = new_sub
    packed = _eur_k7_lz_compress(bytes(buf), marker)
    if len(packed) > len(entry) and not allow_growth:
        raise K7Error(
            f'Texto Imágenes EUR: Special recompilado ocupa {len(packed)} bytes; '
            f'el slot AFS sólo admite {len(entry)}.'
        )
    slot = packed if allow_growth else packed + bytes(len(entry) - len(packed))
    if _eur_k7_lz_decompress(slot) != bytes(buf):
        raise K7Error('Texto Imágenes EUR: verificación LZ de las regiones Special fallida.')
    return slot, len(packed)


def _eur_roll_image_x(image: Image.Image, source_x_at_zero: int) -> Image.Image:
    """Rotación circular horizontal sin interpolación ni pérdida."""
    width, height = image.size
    if width <= 0:
        return image.copy()
    shift = int(source_x_at_zero) % int(width)
    if shift == 0:
        return image.copy()
    out = Image.new(image.mode, image.size)
    out.paste(image.crop((shift, 0, width, height)), (0, 0))
    out.paste(image.crop((0, 0, shift, height)), (width - shift, 0))
    return out


def _eur_satu_display_image(image: Image.Image, roll_x: int = 640) -> Image.Image:
    return _eur_roll_image_x(image, int(roll_x))


def _eur_satu_storage_image(image: Image.Image, roll_x: int = 640) -> Image.Image:
    width = int(image.width)
    if width <= 0:
        return image.copy()
    return _eur_roll_image_x(image, (width - (int(roll_x) % width)) % width)


def _eur_linear_indexed_texture_layout(sub: bytes) -> dict:
    """Layout lineal 4bpp usado por `tutorial_* / Satu`.

    Satu declara 1024x1024 4bpp, pero los últimos 0x40 bytes del bloque físico
    no son texels: son la CLUT RGBA32 de 16 entradas que el juego coloca al final
    del mismo subrecurso. Interpretarlos como 128 píxeles produce la franja blanca
    espuria del borde inferior. Conservamos la CLUT aparte y tratamos esos 128
    texels lógicos finales como zona vacía/no almacenada.
    """
    if len(sub) < 0x120:
        raise K7Error('Texto Imágenes EUR: textura indexada truncada.')
    try:
        name_len = struct.unpack_from('<I', sub, 0x40)[0]
        shift = int(name_len) - 8
        width, height, bpp = struct.unpack_from('<III', sub, 0x78 + shift)
    except struct.error as exc:
        raise K7Error('Texto Imágenes EUR: cabecera de textura indexada truncada.') from exc
    if int(bpp) != 4:
        raise K7Error(f'Texto Imágenes EUR: se esperaba una textura lineal 4bpp, no {bpp}bpp.')
    pixel_off = 0x104 + shift
    logical_payload_size = int(width) * int(height) // 2
    clut_size = 16 * 4
    stored_pixel_size = logical_payload_size - clut_size
    clut_off = pixel_off + stored_pixel_size
    if pixel_off < 0 or stored_pixel_size <= 0 or clut_off + clut_size > len(sub):
        raise K7Error('Texto Imágenes EUR: payload/CLUT 4bpp lineal fuera de rango.')
    # Firma estructural de la CLUT: 16 RGBA32 grises, alfa GS creciente. No
    # exigimos valores exactos entre idiomas, sólo que R=G=B en las 16 entradas.
    clut = sub[clut_off:clut_off + clut_size]
    if len(clut) != clut_size or any(
        not (clut[i] == clut[i+1] == clut[i+2]) for i in range(0, clut_size, 4)
    ):
        raise K7Error('Texto Imágenes EUR: CLUT de Satu no tiene el formato de 16 grises esperado.')
    return {
        'name_len': int(name_len), 'shift': int(shift),
        'width': int(width), 'height': int(height), 'bpp': 4,
        'pixel_offset': int(pixel_off),
        'logical_payload_size': int(logical_payload_size),
        'stored_pixel_size': int(stored_pixel_size),
        'clut_offset': int(clut_off), 'clut_size': int(clut_size),
        # Compatibilidad con código existente que sólo consulta payload_size.
        'payload_size': int(stored_pixel_size),
    }


def _eur_preview_linear_indexed_texture(sub: bytes) -> Image.Image:
    info = _eur_linear_indexed_texture_layout(sub)
    width, height = int(info['width']), int(info['height'])
    raw = sub[int(info['pixel_offset']):int(info['pixel_offset']) + int(info['stored_pixel_size'])]
    px = bytearray(width * height)  # los 128 texels lógicos finales quedan negros
    for i, value in enumerate(raw):
        px[i*2] = (value & 0x0F) * 17
        px[i*2+1] = ((value >> 4) & 0x0F) * 17
    im = Image.new('L', (width, height))
    im.putdata(px)
    return im


def _eur_encode_linear_indexed_image(sub: bytes, image: Image.Image, expected_size: tuple[int, int]) -> bytes:
    info = _eur_linear_indexed_texture_layout(sub)
    width, height = int(info['width']), int(info['height'])
    if (width, height) != tuple(expected_size):
        raise K7Error(
            f'Texto Imágenes EUR: el destino mide {width}x{height}; '
            f'se esperaba {expected_size[0]}x{expected_size[1]}.'
        )
    if image.size != (width, height):
        raise K7Error(
            f'La imagen mide {image.width}x{image.height}; debe medir exactamente {width}x{height}.'
        )
    linear = bytearray(max(0, min(15, int(round(v / 17.0)))) for v in image.convert('L').getdata())
    # Sólo se almacenan los texels físicos anteriores a la CLUT. Los 128 texels
    # lógicos finales de la última fila son una zona virtual vacía y se ignoran.
    payload = bytearray(int(info['stored_pixel_size']))
    for i in range(len(payload)):
        payload[i] = (linear[i*2] & 0x0F) | ((linear[i*2+1] & 0x0F) << 4)
    out = bytearray(sub)
    po = int(info['pixel_offset'])
    out[po:po+len(payload)] = payload
    # La CLUT original queda intacta byte a byte.
    return bytes(out)


def _eur_encode_png_into_linear_indexed_texture(
        sub: bytes, png_path: str | Path, expected_size: tuple[int, int],
        display_roll_x: int = 0) -> bytes:
    png_path = Path(png_path)
    if not png_path.is_file():
        raise K7Error(f'No existe la imagen de reemplazo: {png_path}')
    try:
        with Image.open(png_path) as src:
            image = src.copy()
    except Exception as exc:
        raise K7Error(f'No se pudo abrir {png_path.name}: {exc}') from exc
    if int(display_roll_x):
        image = _eur_satu_storage_image(image, int(display_roll_x))
    return _eur_encode_linear_indexed_image(sub, image, expected_size)


# `tutorial_f / Tutorial` (1024x1024 8bpp) usa el patrón estándar del GS en el
# que 512x512 texels PSMCT32 se reinterpretan como 1024x1024 PSMT8. A diferencia
# de SceSel_F, el payload empieza en 0xC4+shift y la CLUT RGBA32 va inmediatamente
# después de los 0x100000 bytes del IMAGE.
_EUR_BLOCK32 = [
    0,1,4,5,16,17,20,21,
    2,3,6,7,18,19,22,23,
    8,9,12,13,24,25,28,29,
    10,11,14,15,26,27,30,31,
]
_EUR_COLUMN_WORD32 = [0,1,4,5,8,9,12,13,2,3,6,7,10,11,14,15]
_EUR_COLUMN_WORD8 = [
    [
        0,1,4,5,8,9,12,13, 0,1,4,5,8,9,12,13,
        2,3,6,7,10,11,14,15, 2,3,6,7,10,11,14,15,
        8,9,12,13,0,1,4,5, 8,9,12,13,0,1,4,5,
        10,11,14,15,2,3,6,7, 10,11,14,15,2,3,6,7,
    ],
    [
        8,9,12,13,0,1,4,5, 8,9,12,13,0,1,4,5,
        10,11,14,15,2,3,6,7, 10,11,14,15,2,3,6,7,
        0,1,4,5,8,9,12,13, 0,1,4,5,8,9,12,13,
        2,3,6,7,10,11,14,15, 2,3,6,7,10,11,14,15,
    ],
]
_EUR_COLUMN_BYTE8 = [
    0,0,0,0,0,0,0,0, 2,2,2,2,2,2,2,2,
    0,0,0,0,0,0,0,0, 2,2,2,2,2,2,2,2,
    1,1,1,1,1,1,1,1, 3,3,3,3,3,3,3,3,
    1,1,1,1,1,1,1,1, 3,3,3,3,3,3,3,3,
]


def _eur_tutorial_t8_layout(sub: bytes) -> dict:
    if len(sub) < 0x100400:
        raise K7Error('Tutorial EUR: textura Tutorial 8bpp truncada.')
    try:
        name_len = struct.unpack_from('<I', sub, 0x40)[0]
        shift = int(name_len) - 8
        width, height, bpp = struct.unpack_from('<III', sub, 0x78 + shift)
    except struct.error as exc:
        raise K7Error('Tutorial EUR: cabecera 8bpp truncada.') from exc
    if (int(width), int(height), int(bpp)) != (1024, 1024, 8):
        raise K7Error(f'Tutorial EUR: Tutorial es {width}x{height} {bpp}bpp; se esperaba 1024x1024 8bpp.')
    pixel_off = 0xC4 + shift
    payload_size = int(width) * int(height)
    clut_off = pixel_off + payload_size
    if clut_off + 256 * 4 > len(sub):
        raise K7Error('Tutorial EUR: payload/CLUT 8bpp fuera de rango.')
    return {
        'name_len': int(name_len), 'shift': int(shift),
        'width': int(width), 'height': int(height), 'bpp': 8,
        'pixel_offset': int(pixel_off), 'payload_size': int(payload_size),
        'clut_offset': int(clut_off),
    }


def _eur_write_ct32(vram: bytearray, dbw: int, rrw: int, rrh: int, data: bytes) -> None:
    if len(data) != rrw * rrh * 4:
        raise K7Error('Tutorial EUR: transferencia PSMCT32 con tamaño inesperado.')
    p = 0
    for y in range(rrh):
        for x in range(rrw):
            page_x, page_y = x // 64, y // 32
            page = page_x + page_y * dbw
            px, py = x - page_x * 64, y - page_y * 32
            block_x, block_y = px // 8, py // 8
            block = _EUR_BLOCK32[block_x + block_y * 8]
            bx, by = px - block_x * 8, py - block_y * 8
            column = by // 2
            cw = _EUR_COLUMN_WORD32[bx + (by - column * 2) * 8]
            addr = (page * 2048 + block * 64 + column * 16 + cw) * 4
            vram[addr:addr+4] = data[p:p+4]
            p += 4


def _eur_read_ct32(vram: bytearray, dbw: int, rrw: int, rrh: int) -> bytes:
    out = bytearray(rrw * rrh * 4)
    p = 0
    for y in range(rrh):
        for x in range(rrw):
            page_x, page_y = x // 64, y // 32
            page = page_x + page_y * dbw
            px, py = x - page_x * 64, y - page_y * 32
            block_x, block_y = px // 8, py // 8
            block = _EUR_BLOCK32[block_x + block_y * 8]
            bx, by = px - block_x * 8, py - block_y * 8
            column = by // 2
            cw = _EUR_COLUMN_WORD32[bx + (by - column * 2) * 8]
            addr = (page * 2048 + block * 64 + column * 16 + cw) * 4
            out[p:p+4] = vram[addr:addr+4]
            p += 4
    return bytes(out)


def _eur_t8_addr(width: int, x: int, y: int) -> int:
    tbw = width // 64
    dbw = tbw >> 1
    page_x, page_y = x // 128, y // 64
    page = page_x + page_y * dbw
    px, py = x - page_x * 128, y - page_y * 64
    block_x, block_y = px // 16, py // 16
    block = _EUR_BLOCK32[block_x + block_y * 8]
    bx, by = px - block_x * 16, py - block_y * 16
    column = by // 4
    i = bx + (by - column * 4) * 16
    cw = _EUR_COLUMN_WORD8[column & 1][i]
    cb = _EUR_COLUMN_BYTE8[i]
    return (page * 2048 + block * 64 + column * 16 + cw) * 4 + cb


def _eur_read_t8(vram: bytearray, width: int, height: int) -> bytearray:
    out = bytearray(width * height)
    for y in range(height):
        row = y * width
        for x in range(width):
            out[row + x] = vram[_eur_t8_addr(width, x, y)]
    return out


def _eur_write_t8(vram: bytearray, width: int, x: int, y: int, value: int) -> None:
    vram[_eur_t8_addr(width, x, y)] = int(value) & 0xFF


def _eur_tutorial_t8_palette(sub: bytes, layout: dict | None = None) -> list[tuple[int, int, int, int]]:
    layout = layout or _eur_tutorial_t8_layout(sub)
    base = int(layout['clut_offset'])
    return [tuple(sub[base+i*4:base+i*4+4]) for i in range(256)]


def _eur_preview_tutorial_t8(sub: bytes) -> Image.Image:
    layout = _eur_tutorial_t8_layout(sub)
    width, height = int(layout['width']), int(layout['height'])
    payload = sub[int(layout['pixel_offset']):int(layout['pixel_offset']) + int(layout['payload_size'])]
    vram = bytearray(4 * 1024 * 1024)
    rrw, rrh = width // 2, height // 2
    dbw = max(1, rrw // 64)
    _eur_write_ct32(vram, dbw, rrw, rrh, payload)
    if _eur_read_ct32(vram, dbw, rrw, rrh) != payload:
        raise K7Error('Tutorial EUR: la transferencia PSMCT32 no hace round-trip.')
    indices = _eur_read_t8(vram, width, height)
    palette = _eur_tutorial_t8_palette(sub, layout)
    luma = [int((int(r) + int(g) + int(b)) // 3) for r, g, b, _a in palette]
    im = Image.new('L', (width, height))
    im.putdata([luma[idx] for idx in indices])
    return im


def _eur_encode_tutorial_t8_image(sub: bytes, image: Image.Image, expected_size: tuple[int, int]) -> bytes:
    layout = _eur_tutorial_t8_layout(sub)
    width, height = int(layout['width']), int(layout['height'])
    if (width, height) != tuple(expected_size) or image.size != (width, height):
        raise K7Error(f'Tutorial EUR: la imagen debe medir exactamente {width}x{height}.')
    po, ps = int(layout['pixel_offset']), int(layout['payload_size'])
    payload = sub[po:po+ps]
    vram = bytearray(4 * 1024 * 1024)
    rrw, rrh = width // 2, height // 2
    dbw = max(1, rrw // 64)
    _eur_write_ct32(vram, dbw, rrw, rrh, payload)
    original_indices = _eur_read_t8(vram, width, height)
    palette = _eur_tutorial_t8_palette(sub, layout)
    candidates = []
    for idx, (r, g, b, a) in enumerate(palette):
        if int(a) <= 0:
            continue
        luma = (int(r) + int(g) + int(b)) / 3.0
        candidates.append((idx, luma))
    if not candidates:
        raise K7Error('Tutorial EUR: CLUT 8bpp sin colores visibles.')
    transparent = next((i for i, (_r, _g, _b, a) in enumerate(palette) if int(a) == 0), 0)
    lut = [transparent] * 256
    for level in range(1, 256):
        lut[level] = min(candidates, key=lambda row: abs(row[1] - level))[0]
    target_levels = bytearray(image.convert('L').getdata())
    palette_luma = [int((int(r) + int(g) + int(b)) // 3) for r, g, b, _a in palette]
    target_indices = bytearray(original_indices)
    for i, level in enumerate(target_levels):
        old = int(original_indices[i])
        # Si el PNG/atlas pide exactamente el mismo brillo visible que ya tenía
        # el texel, conservar su índice original. La CLUT contiene colores
        # duplicados; esto hace que extraer→reimportar sea byte a byte reversible.
        if palette_luma[old] == int(level):
            continue
        new = int(lut[int(level)])
        target_indices[i] = new
        if old != new:
            _eur_write_t8(vram, width, i % width, i // width, new)
    new_payload = _eur_read_ct32(vram, dbw, rrw, rrh)
    check = bytearray(4 * 1024 * 1024)
    _eur_write_ct32(check, dbw, rrw, rrh, new_payload)
    if _eur_read_t8(check, width, height) != target_indices:
        raise K7Error('Tutorial EUR: la recompilación PSMCT32→PSMT8 no reproduce los índices solicitados.')
    out = bytearray(sub)
    out[po:po+ps] = new_payload
    return bytes(out)


def _eur_encode_png_into_tutorial_t8(sub: bytes, png_path: str | Path, expected_size: tuple[int, int]) -> bytes:
    png_path = Path(png_path)
    if not png_path.is_file():
        raise K7Error(f'No existe la imagen de reemplazo: {png_path}')
    try:
        with Image.open(png_path) as src:
            image = src.convert('L')
    except Exception as exc:
        raise K7Error(f'No se pudo abrir {png_path.name}: {exc}') from exc
    return _eur_encode_tutorial_t8_image(sub, image, expected_size)




def _eur_map_raster_t8_layout(sub: bytes) -> dict:
    """Describe las texturas rasterizadas de MAPA (`*_n` / `*_a`) de 8 bpp.

    Hay dos variantes reales en la edición EUR:

    * ``packet``: ``*_n`` y algunos ``*_a`` 512x512 llevan TRXREG/GIFtag
      completos. El IMAGE empieza en ``0x114 + shift`` y tras el payload hay
      0x50 bytes de paquete GS antes de la CLUT.
    * ``compact``: los ``*_a`` grandes (normalmente 512x1024) usan la misma
      cabecera compacta que ``tutorial_*/Tutorial``. El IMAGE empieza en
      ``0xC4 + shift`` y la CLUT sigue inmediatamente al payload.

    En ambos casos los bytes IMAGE *no son índices PSMT8 lineales*: Killer7 los
    transfiere como PSMCT32 (w/2 x h/2) y reutiliza esa VRAM como PSMT8.
    La v1.7.7.143-145 omitía este alias del GS y por eso el visor mostraba
    bandas/texels barajados aun leyendo el offset correcto.
    """
    if len(sub) < 0x180:
        raise K7Error('Texto Imágenes EUR: textura rasterizada de mapa truncada.')
    try:
        name_len = int(struct.unpack_from('<I', sub, 0x40)[0])
        shift = name_len - 8
        width, height, bpp = struct.unpack_from('<III', sub, 0x78 + shift)
    except struct.error as exc:
        raise K7Error('Texto Imágenes EUR: cabecera rasterizada de mapa truncada.') from exc
    if shift < -8 or shift > 0x100 or int(bpp) != 8:
        raise K7Error(
            f'Texto Imágenes EUR: textura de mapa incompatible '
            f'(name_len={name_len}, bpp={bpp}).'
        )
    width, height = int(width), int(height)
    if not (1 <= width <= 4096 and 1 <= height <= 4096):
        raise K7Error(f'Texto Imágenes EUR: dimensiones de mapa inválidas: {width}x{height}.')

    payload_size = width * height
    packet = False
    rrw = rrh = nloop = 0
    try:
        trxreg = struct.unpack_from('<Q', sub, 0xE4 + shift)[0]
        image_tag = struct.unpack_from('<Q', sub, 0x104 + shift)[0]
        rrw = int(trxreg & 0xFFF)
        rrh = int((trxreg >> 32) & 0xFFF)
        nloop = int(image_tag & 0x7FFF)
        packet = (
            (rrw, rrh) == (width // 2, height // 2)
            and nloop * 16 == payload_size
        )
    except struct.error:
        packet = False

    if packet:
        storage = 'packet'
        pixel_off = 0x114 + shift
        clut_off = pixel_off + payload_size + 0x50
    else:
        # Variante compacta, ver `_eur_tutorial_t8_layout`. En estos recursos
        # 0xC4 ya es el primer byte de IMAGE; interpretar 0xC4.. como registros
        # GS (como hacía el detector antiguo) en realidad estaba leyendo texels.
        storage = 'compact'
        pixel_off = 0xC4 + shift
        clut_off = pixel_off + payload_size
        rrw, rrh = width // 2, height // 2
        nloop = payload_size // 16

    if pixel_off < 0 or pixel_off + payload_size > len(sub):
        raise K7Error('Texto Imágenes EUR: payload de mapa fuera de rango.')
    if clut_off < 0 or clut_off + 256 * 4 > len(sub):
        raise K7Error('Texto Imágenes EUR: CLUT de mapa fuera de rango.')
    return {
        'name_len': name_len, 'shift': shift,
        'width': width, 'height': height, 'bpp': 8,
        'storage': storage,
        'pixel_offset': pixel_off, 'payload_size': payload_size,
        'clut_offset': clut_off,
        'rrw': int(rrw), 'rrh': int(rrh), 'nloop': int(nloop),
    }


def _eur_map_raster_t8_palette(sub: bytes, layout: dict | None = None) -> list[tuple[int, int, int, int]]:
    """Devuelve la CLUT lógica PSMT8 de una textura rasterizada de mapa.

    La CLUT física de estos recursos está en CSM1, igual que otros atlas PSMT8
    de Killer7. En CSM1 los bits 3 y 4 del índice lógico se cruzan al direccionar
    la tabla física. Leer la CLUT linealmente mantiene la geometría correcta pero
    asigna los colores equivocados: en los `*_a` franceses, por ejemplo, el
    antialias de las letras cae en entradas 8..15 y aparece casi negro en vez de
    beige/blanco.

    v1.7.7.152: aplicar explícitamente la permutación CSM1 antes de convertir el
    alfa GS (0x80 = opacidad completa) a alpha PNG.
    """
    layout = layout or _eur_map_raster_t8_layout(sub)
    base = int(layout['clut_offset'])
    physical = [tuple(sub[base+i*4:base+i*4+4]) for i in range(256)]
    palette = []
    for i in range(256):
        # GS CSM1 PSMT8: intercambia los bits 3 y 4 del índice de CLUT.
        j = (i & 0xE7) | ((i & 0x08) << 1) | ((i & 0x10) >> 1)
        r, g, b, a = physical[j]
        if int(a) > 0x80:
            raise K7Error('Texto Imágenes EUR: alfa CLUT de mapa fuera del rango GS esperado.')
        palette.append((int(r), int(g), int(b), min(255, int(a) * 2)))
    return palette


def _eur_verify_map_clut_csm1() -> dict:
    """Guardia sintética del orden CSM1 usado por las CLUT de mapa PSMT8.

    No depende de una ISO: crea una CLUT física identificable y comprueba los
    cruces 8<->16 que causaron las letras negras en v1.7.7.146-.151.
    """
    raw = bytearray(256 * 4)
    for i in range(256):
        raw[i*4:i*4+4] = bytes((i, 255-i, (i * 3) & 0xFF, 0x80))
    pal = _eur_map_raster_t8_palette(bytes(raw), {'clut_offset': 0})
    def expected(i: int):
        j = (i & 0xE7) | ((i & 0x08) << 1) | ((i & 0x10) >> 1)
        return (j, 255-j, (j * 3) & 0xFF, 255)
    probes = (0, 7, 8, 9, 15, 16, 17, 23, 24, 232, 240, 255)
    bad = {i: (pal[i], expected(i)) for i in probes if tuple(pal[i]) != expected(i)}
    if bad:
        raise K7Error(f'Guardia CLUT CSM1 de mapas falló: {bad}')
    return {'probes': list(probes), 'swap_8_16': True, 'alpha_80_to_255': True}


def _eur_preview_map_raster_t8(sub: bytes) -> Image.Image:
    layout = _eur_map_raster_t8_layout(sub)
    width, height = int(layout['width']), int(layout['height'])
    po, ps = int(layout['pixel_offset']), int(layout['payload_size'])
    payload = sub[po:po+ps]

    # El IMAGE se vuelca como PSMCT32 con la mitad de anchura/altura y después
    # se samplea como PSMT8. Reproducir esa misma VRAM es imprescindible: tratar
    # `payload` como índices lineales genera las franjas corruptas del visor viejo.
    rrw, rrh = width // 2, height // 2
    dbw = max(1, rrw // 64)
    vram = bytearray(4 * 1024 * 1024)
    _eur_write_ct32(vram, dbw, rrw, rrh, payload)
    if _eur_read_ct32(vram, dbw, rrw, rrh) != payload:
        raise K7Error('Texto Imágenes EUR: transferencia PSMCT32 de mapa no supera round-trip.')
    indices = _eur_read_t8(vram, width, height)

    palette = _eur_map_raster_t8_palette(sub, layout)
    image = Image.new('P', (width, height))
    image.putdata(indices)
    flat_rgb = []
    alpha = []
    for r, g, b, a in palette:
        flat_rgb.extend((r, g, b))
        alpha.append(a)
    image.putpalette(flat_rgb)
    image.info['transparency'] = bytes(alpha)
    return image.convert('RGBA')



def _eur_encode_map_raster_t8_image(sub: bytes, image: Image.Image,
                                     expected_size: tuple[int, int]) -> bytes:
    """Recompila una textura MAPA PSMT8 preservando su paquete GS y su CLUT.

    El IMAGE físico se almacena mediante la alias PSMCT32->PSMT8. Sólo se
    sustituyen los índices de texel; la CLUT CSM1 y el tamaño del subrecurso se
    conservan byte a byte.
    """
    layout = _eur_map_raster_t8_layout(sub)
    width, height = int(layout['width']), int(layout['height'])
    if (width, height) != tuple(expected_size) or image.size != (width, height):
        raise K7Error(
            f'Texto Imágenes EUR: la textura de mapa debe medir exactamente {width}x{height}.'
        )
    po, ps = int(layout['pixel_offset']), int(layout['payload_size'])
    payload = sub[po:po+ps]
    rrw, rrh = width // 2, height // 2
    dbw = max(1, rrw // 64)
    vram = bytearray(4 * 1024 * 1024)
    _eur_write_ct32(vram, dbw, rrw, rrh, payload)
    original_indices = _eur_read_t8(vram, width, height)
    palette = _eur_map_raster_t8_palette(sub, layout)

    rgba = image.convert('RGBA')
    pixels = list(rgba.getdata())
    transparent = next((i for i, (_r, _g, _b, a) in enumerate(palette) if int(a) == 0), 0)
    cache: dict[tuple[int, int, int, int], int] = {}
    target_indices = bytearray(len(pixels))
    for pos, px in enumerate(pixels):
        old = int(original_indices[pos])
        if tuple(px) == tuple(palette[old]):
            target_indices[pos] = old
            continue
        if px in cache:
            target_indices[pos] = cache[px]
            continue
        r, g, b, a = [int(v) for v in px]
        if a <= 3:
            best_i = int(transparent)
        else:
            best_i = 0
            best_d = None
            for idx, (pr, pg, pb, pa) in enumerate(palette):
                # Dar más peso al alfa conserva los bordes antialiasados de las
                # letras y evita halos opacos sobre el fondo transparente.
                d = ((r-int(pr))**2 + (g-int(pg))**2 + (b-int(pb))**2 +
                     4 * (a-int(pa))**2)
                if best_d is None or d < best_d:
                    best_d = d
                    best_i = int(idx)
        cache[px] = best_i
        target_indices[pos] = best_i

    for pos, new_idx in enumerate(target_indices):
        if int(original_indices[pos]) != int(new_idx):
            _eur_write_t8(vram, width, pos % width, pos // width, int(new_idx))
    new_payload = _eur_read_ct32(vram, dbw, rrw, rrh)

    check = bytearray(4 * 1024 * 1024)
    _eur_write_ct32(check, dbw, rrw, rrh, new_payload)
    if _eur_read_t8(check, width, height) != target_indices:
        raise K7Error(
            'Texto Imágenes EUR: recompilación de mapa PSMCT32→PSMT8 no reproduce los índices solicitados.'
        )
    out = bytearray(sub)
    out[po:po+ps] = new_payload
    if len(out) != len(sub):
        raise K7Error('Texto Imágenes EUR: la textura rasterizada de mapa cambió de tamaño.')
    return bytes(out)


def _eur_encode_png_into_map_raster_t8(sub: bytes, png_path: str | Path,
                                        expected_size: tuple[int, int]) -> bytes:
    png_path = Path(png_path)
    if not png_path.is_file():
        raise K7Error(f'No existe la imagen de reemplazo: {png_path}')
    try:
        with Image.open(png_path) as src:
            src.load()
            if src.size != tuple(expected_size):
                raise K7Error(
                    f'{png_path.name} mide {src.width}x{src.height}; debe medir '
                    f'exactamente {expected_size[0]}x{expected_size[1]}.'
                )
            image = src.convert('RGBA')
    except K7Error:
        raise
    except Exception as exc:
        raise K7Error(f'No se pudo abrir {png_path.name}: {exc}') from exc
    return _eur_encode_map_raster_t8_image(sub, image, expected_size)


_EUR_MAP_RASTER_ES_ASSETS = {
    'cel': 'maptex_cel_a_es.png',
    'cur': 'maptex_cur_a_es.png',
    'dmi': 'maptex_dmi_a_es.png',
    'fuk': 'maptex_fuk_a_es.png',
    'ht2': 'maptex_ht2_a_es.png',
    'htl': 'maptex_htl_a_es.png',
    'isz': 'maptex_isz_a_es.png',
    'kak': 'maptex_kak_a_es.png',
    'scl': 'maptex_scl_a_es.png',
    'sen': 'maptex_sen_a_es.png',
    'txs': 'maptex_txs_a_es.png',
}


def _eur_verify_map_raster_spanish_assets() -> dict:
    """Guardia de release para los 11 PNG españoles integrados de MAPA."""
    base_dir = resource_path('resources', 'eur_base') / 'map_es'
    specs = {str(row['id']): row for row in eur_text_image_specs('fr')}
    rows = []
    for family in _EUR_MAP_TEXTURE_FAMILIES:
        slug = str(family['slug'])
        spec = specs[f'maptex_{slug}_a']
        asset = base_dir / _EUR_MAP_RASTER_ES_ASSETS[slug]
        if not asset.is_file():
            raise K7Error(f'Mapas EUR: falta asset español {asset.name}.')
        with Image.open(asset) as im:
            im.load()
            expected = (int(spec['width']), int(spec['height']))
            if im.size != expected:
                raise K7Error(
                    f'Mapas EUR: {asset.name} mide {im.width}x{im.height}; '
                    f'se esperaba {expected[0]}x{expected[1]}.'
                )
            if im.convert('RGBA').getchannel('A').getbbox() is None:
                raise K7Error(f'Mapas EUR: {asset.name} no contiene píxeles visibles.')
            rows.append({'family': slug, 'asset': asset.name, 'size': list(expected)})
    if len(rows) != 11:
        raise K7Error(f'Mapas EUR: guardia de assets encontró {len(rows)} mapas; se esperaban 11.')
    return {'count': len(rows), 'maps': rows, 'n_glyph_banks_handled_separately': True}


def _eur_patch_map_raster_spanish(afs, raw_entries, names,
                                  replacements: dict[int, bytes]) -> dict:
    """Inserta los rótulos rasterizados españoles de los 11 mapas EUR.

    Los ``*_a`` contienen nombre del escenario y fecha/estación horneados en la
    textura. Los ``*_n`` se dejan intactos en ESTA pasada; v1.7.7.171 los parchea
    inmediatamente después junto con sus secuencias STRIMAGS precompiladas.
    """
    base_dir = resource_path('resources', 'eur_base') / 'map_es'
    specs = {str(row['id']): row for row in eur_text_image_specs('fr')}
    report = []
    for family in _EUR_MAP_TEXTURE_FAMILIES:
        slug = str(family['slug'])
        spec = specs[f'maptex_{slug}_a']
        idx = int(family['fr'])
        if not (0 <= idx < len(raw_entries)) or str(names[idx]).lower() != str(family['afs_fr']).lower():
            raise K7Error(
                f'Mapas EUR: AFS #{idx} es {names[idx] if 0 <= idx < len(names) else "<fuera>"!r}; '
                f'se esperaba {family["afs_fr"]!r}.'
            )
        original = _eur_read_entry(afs, raw_entries, idx)
        current = bytes(replacements.get(idx, original))
        sub_off, sub = _eur_text_image_subresource(current, spec)
        asset = base_dir / _EUR_MAP_RASTER_ES_ASSETS[slug]
        new_sub = _eur_encode_png_into_map_raster_t8(
            sub, asset, (int(spec['width']), int(spec['height']))
        )
        if len(new_sub) != len(sub):
            raise K7Error(f'Mapas EUR: {spec["texture"]} cambió de tamaño.')
        out = bytearray(current)
        out[sub_off:sub_off+len(new_sub)] = new_sub
        patched = bytes(out)

        _v_off, v_sub = _eur_text_image_subresource(patched, spec)
        preview = _eur_preview_map_raster_t8(v_sub).convert('RGBA')
        if preview.getchannel('A').getbbox() is None:
            raise K7Error(f'Mapas EUR: {slug} quedó completamente transparente tras recompilar.')
        replacements[idx] = patched
        report.append({
            'family': slug, 'afs_index': idx, 'afs_name': str(names[idx]),
            'texture': str(spec['texture']), 'size': [preview.width, preview.height],
            'asset': asset.name, 'entry_size_unchanged': len(patched) == len(original),
            'sha256_before': hashlib.sha256(original).hexdigest(),
            'sha256_after': hashlib.sha256(patched).hexdigest(),
        })
    if len(report) != len(_EUR_MAP_TEXTURE_FAMILIES):
        raise K7Error('Mapas EUR: no se prepararon los 11 mapas rasterizados españoles.')
    return {'count': len(report), 'maps': report, 'glyph_banks_untouched': True}


# v1.7.7.171 — los rótulos de planta no se dibujan sólo desde K7P2.
# `cel_n`, `htl_n` (ht2/htl) son fuentes locales acompañadas por STRIMAGS.  La
# zona previa a los registros finales contiene secuencias de índices de glifo ya
# precompiladas (p. ej. 1,e,r,espacio,é,t,a,g,e,FFFF).  El juego usa esas
# secuencias para las dos vistas del mapa; por eso cambiar únicamente el string
# K7P2 deja `1er étage` visible. Conservamos count/orden/códigos de STRIMAGS y
# reutilizamos tres slots que dejan de ser necesarios al pasar a «Planta N».
_EUR_MAP_FLOOR_FONT_FAMILIES = ('cel', 'ht2', 'htl')
_EUR_MAP_FLOOR_SLOT_MAP = {
    'P': 'g',
    'l': 'r',
    'n': 'e',
}
_EUR_MAP_FLOOR_SOURCE_FAMILY = 'scl'


def _eur_map_font_parts(entry: bytes, spec: dict):
    """Extrae atlas *_n + STRIMAGS y devuelve los registros en su orden real."""
    sub_off, sub = _eur_text_image_subresource(entry, spec)
    atlas = _eur_preview_map_raster_t8(sub).convert('RGBA')
    ranges = _eur_dar_child_ranges(entry)
    if len(ranges) < 3:
        raise K7Error(f'Mapas EUR: {spec.get("afs_name", "mapa")} no contiene STRIMAGS child 2.')
    ihe_off, ihe_size = ranges[2]
    ihe = bytearray(entry[ihe_off:ihe_off + ihe_size])
    rec_start, _recs = _eur_font_ihe_records(bytes(ihe))
    count = int(struct.unpack_from('<I', ihe, 0x18)[0])
    rows = [list(struct.unpack_from('<10H', ihe, rec_start + i * 20)) for i in range(count)]
    return sub_off, sub, atlas, int(ihe_off), int(ihe_size), ihe, int(rec_start), rows


def _eur_map_floor_fit_glyph(src: Image.Image, size: tuple[int, int]) -> Image.Image:
    """Ajusta un glifo RGBA conservando transparencia y proporción lo máximo posible."""
    w, h = map(int, size)
    src = src.convert('RGBA')
    if src.size == (w, h):
        return src.copy()
    scale = min(w / max(1, src.width), h / max(1, src.height))
    nw = max(1, min(w, int(round(src.width * scale))))
    nh = max(1, min(h, int(round(src.height * scale))))
    resized = src.resize((nw, nh), Image.Resampling.LANCZOS)
    out = Image.new('RGBA', (w, h), (0, 0, 0, 0))
    out.alpha_composite(resized, ((w - nw) // 2, max(0, h - nh)))
    return out


def _eur_map_floor_patch_sequence_table(ihe: bytearray, ordered_rows: list[list[int]], family: str) -> dict:
    """Sustituye las secuencias STRIMAGS Nth étage por Planta N sin mover tablas.

    En `cel_n` existe además una composición en dos líneas para el panel grande del
    mapa: una línea superior `1er/2e/...` y otra inferior `étage`. Al reasignar
    los donors g/r/e -> P/l/n, si no se reescriben también esas secuencias el
    juego termina mostrando `1nl étaPn`. Por eso aquí parcheamos tanto la forma
    horizontal completa como, específicamente en Celtic, la pareja vertical
    `Planta` / `<dígito>`.
    """
    code_to_index = {int(row[0]): i for i, row in enumerate(ordered_rows)}
    required_codes = [ord('g'), ord('r'), ord('a'), ord('e'), ord('t'), ord(' ')]
    missing = [c for c in required_codes if c not in code_to_index]
    if missing:
        raise K7Error(f'Mapas EUR {family}: faltan slots para Planta: {missing}.')

    max_floor = 6 if family == 'cel' else 7
    patched = []
    full_positions: dict[int, list[int]] = {}
    for floor in range(1, max_floor + 1):
        old_chars = '1er étage' if floor == 1 else f'{floor}e étage'
        try:
            old_seq = [code_to_index[ord(ch)] for ch in old_chars]
        except KeyError as exc:
            raise K7Error(f'Mapas EUR {family}: no se puede formar {old_chars!r} en STRIMAGS.') from exc
        old_pat = b''.join(struct.pack('<H', n) for n in old_seq) + b'\xff\xff'

        # P/l/n apuntan a los slots g/r/e cuyos bitmaps se sustituyen abajo.
        target_codes = [ord('g'), ord('r'), ord('a'), ord('e'), ord('t'), ord('a'), ord(' '), ord(str(floor))]
        try:
            new_seq = [code_to_index[c] for c in target_codes]
        except KeyError as exc:
            raise K7Error(f'Mapas EUR {family}: falta el dígito {floor} en STRIMAGS.') from exc
        new_pat = b''.join(struct.pack('<H', n) for n in new_seq) + b'\xff\xff'
        if len(new_pat) > len(old_pat):
            raise K7Error(f'Mapas EUR {family}: Planta {floor} excede la secuencia francesa.')

        positions = []
        start_find = 0
        raw = bytes(ihe)
        while True:
            pos = raw.find(old_pat, start_find)
            if pos < 0:
                break
            positions.append(pos)
            start_find = pos + 2
        expected_occurrences = 1 if family == 'cel' else 2
        if len(positions) != expected_occurrences:
            raise K7Error(
                f'Mapas EUR {family}: {old_chars!r} aparece {len(positions)} veces; '
                f'se esperaban {expected_occurrences}.'
            )
        for pos in positions:
            ihe[pos:pos + len(new_pat)] = new_pat
            if len(new_pat) < len(old_pat):
                ihe[pos + len(new_pat):pos + len(old_pat)] = b'\0' * (len(old_pat) - len(new_pat))
        full_positions[floor] = positions
        patched.append({'floor': floor, 'old': old_chars, 'target': f'Planta {floor}', 'occurrences': len(positions)})

    split_report = []
    if family == 'cel':
        raw = bytes(ihe)
        planta_pat = b''.join(
            struct.pack('<H', code_to_index[c])
            for c in (ord('g'), ord('r'), ord('a'), ord('e'), ord('t'), ord('a'))
        ) + b'\xff\xff'
        etage_pat = b''.join(
            struct.pack('<H', code_to_index[c])
            for c in (ord('é'), ord('t'), ord('a'), ord('g'), ord('e'))
        ) + b'\xff\xff'

        head_positions: dict[int, int] = {}
        for floor in range(1, max_floor + 1):
            head_chars = '1er' if floor == 1 else f'{floor}e'
            head_pat = b''.join(struct.pack('<H', code_to_index[ord(ch)]) for ch in head_chars) + b'\xff\xff'
            positions = []
            start_find = 0
            while True:
                pos = raw.find(head_pat, start_find)
                if pos < 0:
                    break
                positions.append(pos)
                start_find = pos + 2
            if len(positions) > 1:
                raise K7Error(
                    f'Mapas EUR {family}: cabecera vertical {head_chars!r} aparece {len(positions)} veces; '
                    'se esperaba como máximo 1.'
                )
            if positions:
                head_positions[floor] = positions[0]

        # Los tests sintéticos antiguos sólo contienen las secuencias horizontales.
        # En el `cel_n` retail real aparecen las seis cabeceras verticales; si aparece
        # alguna, exigimos el conjunto completo para no aceptar una tabla parcial.
        if head_positions and len(head_positions) != max_floor:
            raise K7Error(
                f'Mapas EUR {family}: tabla vertical incompleta ({len(head_positions)}/{max_floor}).'
            )

        tail_positions = []
        start_find = 0
        while True:
            pos = raw.find(etage_pat, start_find)
            if pos < 0:
                break
            tail_positions.append(pos)
            start_find = pos + 2

        ordered_heads = [head_positions[floor] for floor in range(1, max_floor + 1)] if head_positions else []
        first_full = min(p for plist in full_positions.values() for p in plist)
        for idx, floor in enumerate(range(1, max_floor + 1)) if head_positions else []:
            head_pos = head_positions[floor]
            next_head = ordered_heads[idx + 1] if idx + 1 < len(ordered_heads) else first_full
            tail_candidates = [p for p in tail_positions if head_pos < p < next_head]
            if len(tail_candidates) != 1:
                raise K7Error(
                    f'Mapas EUR {family}: no se pudo aislar la cola vertical de Planta {floor}; '
                    f'candidatos={tail_candidates!r}.'
                )
            tail_pos = tail_candidates[0]
            digit_pat = struct.pack('<H', code_to_index[ord(str(floor))]) + b'\xff\xff'

            head_slot = tail_pos - head_pos
            if len(planta_pat) > head_slot:
                raise K7Error(f'Mapas EUR {family}: slot vertical superior insuficiente para Planta {floor}.')
            ihe[head_pos:tail_pos] = planta_pat + (b'\0' * (head_slot - len(planta_pat)))

            next_slot = ordered_heads[idx + 1] if idx + 1 < len(ordered_heads) else first_full
            tail_slot = next_slot - tail_pos
            if len(digit_pat) > tail_slot:
                raise K7Error(f'Mapas EUR {family}: slot vertical inferior insuficiente para Planta {floor}.')
            ihe[tail_pos:next_slot] = digit_pat + (b'\0' * (tail_slot - len(digit_pat)))
            split_report.append({
                'floor': floor,
                'top': 'Planta',
                'bottom': str(floor),
                'head_pos': head_pos,
                'tail_pos': tail_pos,
            })

    return {
        'family': family,
        'sequences': patched,
        'sequence_count': sum(x['occurrences'] for x in patched),
        'split_sequences': split_report,
        'split_sequence_count': len(split_report),
    }


def _eur_patch_map_floor_strimags(afs, raw_entries, names, replacements: dict[int, bytes]) -> dict:
    """Parchea las fuentes locales de planta y sus secuencias STRIMAGS reales."""
    families = {str(row['slug']): row for row in _EUR_MAP_TEXTURE_FAMILIES}
    src_family = families[_EUR_MAP_FLOOR_SOURCE_FAMILY]
    src_idx = int(src_family['fr'])
    src_original = _eur_read_entry(afs, raw_entries, src_idx)
    src_spec = _eur_text_image_spec(f'maptex_{_EUR_MAP_FLOOR_SOURCE_FAMILY}_n', 'fr')
    _so, _ssub, src_atlas, _sio, _sis, _sihe, _srs, src_rows = _eur_map_font_parts(src_original, src_spec)
    src_by_code = {int(r[0]): r for r in src_rows}
    source_glyphs = {}
    for ch in ('P', 'l', 'n'):
        rec = src_by_code.get(ord(ch))
        if rec is None:
            raise K7Error(f'Mapas EUR: la fuente de referencia no contiene {ch!r}.')
        _code, x, y, w, h, *_rest = rec
        source_glyphs[ch] = src_atlas.crop((x, y, x + w, y + h)).copy()

    reports = []
    for slug in _EUR_MAP_FLOOR_FONT_FAMILIES:
        family = families[slug]
        idx = int(family['fr'])
        if not (0 <= idx < len(raw_entries)) or str(names[idx]).lower() != str(family['afs_fr']).lower():
            raise K7Error(f'Mapas EUR: índice de fuente de planta inválido para {slug}.')
        original = _eur_read_entry(afs, raw_entries, idx)
        current = bytes(replacements.get(idx, original))
        spec = _eur_text_image_spec(f'maptex_{slug}_n', 'fr')
        sub_off, sub, atlas, ihe_off, ihe_size, ihe, rec_start, rows = _eur_map_font_parts(current, spec)
        by_code = {int(r[0]): i for i, r in enumerate(rows)}
        for donor in ('g', 'r', 'e'):
            if ord(donor) not in by_code:
                raise K7Error(f'Mapas EUR {slug}: falta donor {donor!r}.')

        patched_atlas = atlas.copy()
        # P -> g
        pidx = by_code[ord('g')]
        prec = rows[pidx]
        px, py, pw, ph = map(int, prec[1:5])
        pglyph = _eur_map_floor_fit_glyph(source_glyphs['P'], (pw, ph))
        patched_atlas.paste((0, 0, 0, 0), (px, py, px + pw, py + ph))
        patched_atlas.alpha_composite(pglyph, (px, py))
        prec[6], prec[7] = 6, 15

        # l -> r. Hay espacio vacío bajo r hasta y=30; usamos el l oficial 8x20.
        lidx = by_code[ord('r')]
        lrec = rows[lidx]
        lx, ly, old_lw, old_lh = map(int, lrec[1:5])
        lglyph = _eur_map_floor_fit_glyph(source_glyphs['l'], (8, 20))
        patched_atlas.paste((0, 0, 0, 0), (lx, ly, lx + old_lw, ly + 20))
        patched_atlas.alpha_composite(lglyph, (lx, ly))
        lrec[3], lrec[4], lrec[5], lrec[6], lrec[7] = 8, 20, 0, 6, 8

        # n -> e
        nidx = by_code[ord('e')]
        nrec = rows[nidx]
        nx, ny, nw, nh = map(int, nrec[1:5])
        nglyph = _eur_map_floor_fit_glyph(source_glyphs['n'], (nw, nh))
        patched_atlas.paste((0, 0, 0, 0), (nx, ny, nx + nw, ny + nh))
        patched_atlas.alpha_composite(nglyph, (nx, ny))
        nrec[5], nrec[6], nrec[7] = 0, 10, 15

        seq_report = _eur_map_floor_patch_sequence_table(ihe, rows, slug)
        for ridx in (pidx, lidx, nidx):
            struct.pack_into('<10H', ihe, rec_start + ridx * 20, *[int(v) for v in rows[ridx]])

        new_sub = _eur_encode_map_raster_t8_image(sub, patched_atlas, (int(spec['width']), int(spec['height'])))
        if len(new_sub) != len(sub):
            raise K7Error(f'Mapas EUR {slug}: *_n cambió de tamaño.')
        out = bytearray(current)
        out[sub_off:sub_off + len(new_sub)] = new_sub
        if ihe_off + ihe_size > len(out):
            raise K7Error(f'Mapas EUR {slug}: STRIMAGS fuera de rango al reinsertar.')
        out[ihe_off:ihe_off + ihe_size] = ihe
        patched = bytes(out)
        if len(patched) != len(original):
            raise K7Error(f'Mapas EUR {slug}: el parche de plantas cambió el tamaño del AFS entry.')

        # Round-trip de textura, registros y secuencias.
        _vo, _vsub, vatlas, _vio, _vis, vihe, _vrs, vrows = _eur_map_font_parts(patched, spec)
        vby = {int(r[0]): i for i, r in enumerate(vrows)}
        for donor, label in (('g', 'P'), ('r', 'l'), ('e', 'n')):
            r = vrows[vby[ord(donor)]]
            x, y, w, h = map(int, r[1:5])
            if vatlas.crop((x, y, x + w, y + h)).getchannel('A').getbbox() is None:
                raise K7Error(f'Mapas EUR {slug}: slot {donor}->{label} quedó vacío.')
        code_to_index = {int(r[0]): i for i, r in enumerate(vrows)}
        for floor in range(1, 7 if slug == 'cel' else 8):
            old_chars = '1er étage' if floor == 1 else f'{floor}e étage'
            old_seq = [code_to_index[ord(ch)] for ch in old_chars]
            old_pat = b''.join(struct.pack('<H', n) for n in old_seq) + b'\xff\xff'
            if old_pat in bytes(vihe):
                raise K7Error(f'Mapas EUR {slug}: sobrevivió la secuencia {old_chars!r}.')

        replacements[idx] = patched
        reports.append({
            'family': slug, 'afs_index': idx, 'afs_name': str(names[idx]),
            'texture': str(spec['texture']), 'entry_size': len(patched),
            'slot_map': dict(_EUR_MAP_FLOOR_SLOT_MAP),
            **seq_report,
        })

    return {
        'count': len(reports), 'fonts': reports,
        'source_font': f'{_EUR_MAP_FLOOR_SOURCE_FAMILY}_n',
        'method': 'bitmap donors + fixed-index STRIMAGS sequence rewrite',
    }


def _eur_text_image_scene_selector_layout(entry: bytes) -> dict:
    """Describe el paquete GS real de sce_F.dat / SceSel_F (PSMT8 512x512).

    SceSel_F tiene ``name_len=12``. Por tanto todos los campos posteriores al
    nombre están desplazados +4 respecto al layout base de nombre de 8 bytes.
    El IMAGE GIFtag ocupa 16 bytes completos: el payload empieza en
    ``0x104 + shift + 0x10``. La v1.7.7.39 usaba +0x114 sin aplicar ``shift`` y
    leía cuatro bytes del GIFtag como texels, lo que fragmentaba el texto tras
    el unswizzle PSMT8. La CLUT sufría exactamente el mismo desfase.
    """
    toff = _EUR_SCENE_SELECTOR_TEXTURE_OFFSET
    if len(entry) < toff + 0x120:
        raise K7Error('Texto Imágenes EUR: sce_F.dat / SceSel_F está truncado.')
    try:
        name_len = int(struct.unpack_from('<I', entry, toff + 0x40)[0])
    except struct.error as exc:
        raise K7Error('Texto Imágenes EUR: cabecera de SceSel_F truncada.') from exc
    shift = name_len - 8
    if not (-8 <= shift <= 0x100):
        raise K7Error(f'Texto Imágenes EUR: name_len de SceSel_F inesperado: {name_len}.')
    texture_name_raw = entry[toff+0x48:toff+0x48+name_len].split(b'\0', 1)[0]
    if texture_name_raw not in (b'SceSel_E', b'SceSel_F', b'SceSel_G'):
        raise K7Error(
            'Texto Imágenes EUR: no se encontró SceSel_E/F/G en el selector de escenas +0x444.'
        )
    texture_name = texture_name_raw.decode('ascii', 'replace')

    width_off = toff + 0x78 + shift
    image_tag_off = toff + 0x104 + shift
    try:
        width, height, bpp = struct.unpack_from('<III', entry, width_off)
        image_tag = struct.unpack_from('<Q', entry, image_tag_off)[0]
    except struct.error as exc:
        raise K7Error('Texto Imágenes EUR: paquete GS de SceSel_F truncado.') from exc
    if (int(width), int(height), int(bpp)) != (512, 512, 8):
        raise K7Error(
            f'Texto Imágenes EUR: SceSel_F es {width}x{height} {bpp}bpp; '
            'se esperaba 512x512 8bpp.'
        )

    pix_size = int(width) * int(height)
    image_nloop = int(image_tag & 0x7FFF)
    image_flg = int((image_tag >> 58) & 0x3)
    if image_flg != 2 or image_nloop * 16 != pix_size:
        raise K7Error(
            'Texto Imágenes EUR: GIFtag IMAGE de SceSel_F inconsistente '
            f'(FLG={image_flg}, NLOOP={image_nloop}, payload={pix_size}).'
        )
    pix_off = image_tag_off + 0x10

    # Tras el IMAGE principal hay 0x40 bytes de registros GS y después otro
    # GIFtag IMAGE de 16 bytes que precede a la CLUT RGBA32 de 256 colores.
    clut_tag_off = pix_off + pix_size + 0x40
    clut_off = clut_tag_off + 0x10
    try:
        clut_tag = struct.unpack_from('<Q', entry, clut_tag_off)[0]
    except struct.error as exc:
        raise K7Error('Texto Imágenes EUR: GIFtag de la CLUT SceSel_F truncado.') from exc
    clut_nloop = int(clut_tag & 0x7FFF)
    clut_flg = int((clut_tag >> 58) & 0x3)
    if clut_flg != 2 or clut_nloop * 16 != 256 * 4:
        raise K7Error(
            'Texto Imágenes EUR: GIFtag IMAGE de la CLUT SceSel_F inconsistente '
            f'(FLG={clut_flg}, NLOOP={clut_nloop}).'
        )
    if pix_off + pix_size > len(entry) or clut_off + 256 * 4 > len(entry):
        raise K7Error('Texto Imágenes EUR: payload/CLUT de SceSel_F fuera de rango.')

    return {
        'texture_offset': toff, 'texture_name': texture_name, 'name_len': name_len, 'shift': shift,
        'width': int(width), 'height': int(height), 'bpp': int(bpp),
        'image_tag_offset': image_tag_off,
        'pixel_offset': pix_off, 'pixel_size': pix_size,
        'clut_tag_offset': clut_tag_off, 'clut_offset': clut_off,
        'transparent_index': _EUR_SCENE_SELECTOR_TRANSPARENT_INDEX,
    }


def _eur_scene_selector_rgba_palette(entry: bytes, layout: dict | None = None) -> list[tuple[int, int, int, int]]:
    """CLUT SceSel_F convertida del alfa GS 0..0x80 a RGBA 0..255."""
    layout = layout or _eur_text_image_scene_selector_layout(entry)
    base = int(layout['clut_offset'])
    palette = []
    for i in range(256):
        r, g, b, a = entry[base+i*4:base+i*4+4]
        palette.append((int(r), int(g), int(b), min(255, int(a) * 2)))
    return palette


def _eur_text_image_scene_selector_preview(entry: bytes) -> Image.Image:
    """Decodifica SceSel_F con sus índices PSMT8 y su CLUT real."""
    layout = _eur_text_image_scene_selector_layout(entry)
    raw = entry[layout['pixel_offset']:layout['pixel_offset'] + layout['pixel_size']]
    linear = _unswizzle8(raw, layout['width'], layout['height'])
    palette = _eur_scene_selector_rgba_palette(entry, layout)

    # Mantener modo P permite que "Extraer PNG" conserve los índices exactos de
    # la textura. El tRNS de PNG transporta el alfa de los 256 colores y la UI
    # puede convertirla a RGBA para mostrarla con los colores reales del juego.
    image = Image.new('P', (layout['width'], layout['height']))
    image.putdata(linear)
    flat_rgb = []
    alpha = []
    for r, g, b, a in palette:
        flat_rgb.extend((r, g, b))
        alpha.append(a)
    image.putpalette(flat_rgb)
    image.info['transparency'] = bytes(alpha)
    return image


def _eur_scene_selector_png_palette_matches(src: Image.Image, palette: list[tuple[int, int, int, int]]) -> bool:
    """True si un PNG P conserva exactamente la CLUT exportada por el programa."""
    if src.mode != 'P':
        return False
    raw_pal = src.getpalette()
    if not raw_pal or len(raw_pal) < 256 * 3:
        return False
    trans = src.info.get('transparency')
    if isinstance(trans, bytes):
        alpha = list(trans[:256]) + [255] * max(0, 256-len(trans))
    elif isinstance(trans, int):
        alpha = [255] * 256
        if 0 <= trans < 256:
            alpha[trans] = 0
    else:
        alpha = [255] * 256
    for i, (r, g, b, a) in enumerate(palette):
        j = i * 3
        if tuple(raw_pal[j:j+3]) != (r, g, b) or alpha[i] != a:
            return False
    return True


def _eur_encode_png_into_scene_selector(entry: bytes, png_path: str | Path,
                                          expected_size: tuple[int, int]) -> bytes:
    layout = _eur_text_image_scene_selector_layout(entry)
    width, height = layout['width'], layout['height']
    if (width, height) != tuple(expected_size):
        raise K7Error(
            f'Texto Imágenes EUR: SceSel_F mide {width}x{height}; '
            f'se esperaba {expected_size[0]}x{expected_size[1]}.'
        )
    png_path = Path(png_path)
    if not png_path.is_file():
        raise K7Error(f'No existe la imagen de reemplazo: {png_path}')
    try:
        with Image.open(png_path) as src0:
            src0.load()
            if src0.size != (width, height):
                raise K7Error(
                    f'{png_path.name} mide {src0.width}x{src0.height}; '
                    f'debe medir exactamente {width}x{height}.'
                )
            palette = _eur_scene_selector_rgba_palette(entry, layout)
            if _eur_scene_selector_png_palette_matches(src0, palette):
                # Ruta sin pérdidas para un PNG extraído por esta versión.
                indices = bytearray(src0.getdata())
            else:
                rgba = src0.convert('RGBA')
                pixels = list(rgba.getdata())
                # Compatibilidad con los PNG índice-en-gris exportados por v1.7.7.39.
                grayscale_index_map = all(r == g == b for r, g, b, _a in pixels)
                transparent_index = int(layout['transparent_index'])
                if grayscale_index_map:
                    indices = bytearray(
                        transparent_index if a <= 3 else int(r)
                        for r, _g, _b, a in pixels
                    )
                else:
                    # PNG RGBA normal: cuantizar al color más cercano de la CLUT
                    # original, ponderando alfa para conservar bordes/transparencia.
                    cache: dict[tuple[int, int, int, int], int] = {}
                    indices = bytearray(width * height)
                    for pos, px in enumerate(pixels):
                        if px in cache:
                            indices[pos] = cache[px]
                            continue
                        if px[3] <= 3:
                            best_i = transparent_index
                        else:
                            r, g, b, a = px
                            best_i = 0
                            best_d = None
                            for i, (pr, pg, pb, pa) in enumerate(palette):
                                d = ((r-pr)*(r-pr) + (g-pg)*(g-pg) + (b-pb)*(b-pb)
                                     + 3 * (a-pa)*(a-pa))
                                if best_d is None or d < best_d:
                                    best_d = d
                                    best_i = i
                        cache[px] = best_i
                        indices[pos] = best_i
    except K7Error:
        raise
    except Exception as exc:
        raise K7Error(f'No se pudo abrir {png_path.name}: {exc}') from exc

    swizzled = _swizzle8(indices, width, height)
    if _unswizzle8(swizzled, width, height) != indices:
        raise K7Error('Texto Imágenes EUR: SceSel_F no supera round-trip PSMT8.')
    out = bytearray(entry)
    po = int(layout['pixel_offset'])
    out[po:po+len(swizzled)] = swizzled
    return bytes(out)


# v1.7.7.148 — codec específico del nombre de capítulo del selector de escenas.
#
# SceSel_F no contiene todos los glifos que necesitamos en español. El renderer
# usa el byte de la C-string para escoger un glifo de este atlas; no utiliza la
# fuente titlefont de 00__f.dic. Reutilizamos tres códigos que dejan de ser
# necesarios en la rama francesa una vez traducidos los nombres:
#   R (0x52) -> Á   |   ä (0xE4) -> b   |   ö (0xF6) -> ó
# Los tres donors conservan la clase de métricas adecuada (mayúscula/minúscula).
_EUR_SCENE_SELECTOR_CHAPTER_CODEMAP = {'Á': 'R', 'b': 'ä', 'ó': 'ö'}
_EUR_SCENE_SELECTOR_CHAPTER_DONOR_CODES = {'R', 'ä', 'ö'}
_EUR_SCENE_SELECTOR_PRIMARY_TABLE = 0x4C5EE4
_EUR_SCENE_SELECTOR_VADDR_DELTA = 0xFFE80


def _eur_scene_selector_encode_chapter(text: str) -> bytes:
    """Codifica un título español usando sólo glifos existentes/remapeados de SceSel_F."""
    text = str(text)
    # Evita ambigüedad: esos códigos físicos están reservados como donors en la
    # rama FR. Los targets integrados no los necesitan literalmente.
    for ch in _EUR_SCENE_SELECTOR_CHAPTER_DONOR_CODES:
        if ch in text and ch not in _EUR_SCENE_SELECTOR_CHAPTER_CODEMAP:
            raise K7Error(
                f'Selector EUR: el título {text!r} usa el donor reservado {ch!r}; '
                'elige otra grafía o amplía el codec del selector.'
            )
    encoded = ''.join(_EUR_SCENE_SELECTOR_CHAPTER_CODEMAP.get(ch, ch) for ch in text)
    try:
        return encoded.encode('latin-1')
    except UnicodeEncodeError as exc:
        raise K7Error(f'Selector EUR: carácter no soportado en {text!r}: {exc}') from exc


def _eur_verify_scene_selector_chapter_codec() -> dict:
    """Guardia interna: evita volver a tratar Ángel como un simple Latin-1."""
    expected = {
        'Ángel': b'Rngel',
        'Hombre Nube': b'Hom\xE4re Nu\xE4e',
        'León': b'Le\xF6n',
    }
    got = {text: _eur_scene_selector_encode_chapter(text) for text in expected}
    if got != expected:
        raise K7Error(
            'Selector EUR: regresión del codec de capítulos; ' +
            ', '.join(f'{k}={got[k].hex().upper()}' for k in expected)
        )
    return {k: v.hex().upper() for k, v in got.items()}


def _eur_scene_selector_nontransparent_bbox(image: Image.Image, transparent_index: int):
    mask = Image.new('1', image.size, 0)
    src = image.load(); dst = mask.load()
    for yy in range(image.height):
        for xx in range(image.width):
            if int(src[xx, yy]) != int(transparent_index):
                dst[xx, yy] = 1
    return mask.getbbox()


def _eur_patch_scene_selector_spanish_glyphs(entry: bytes) -> tuple[bytes, dict]:
    """Convierte tres donors del atlas SceSel_F en Á / b / ó sin tocar la CLUT."""
    layout = _eur_text_image_scene_selector_layout(entry)
    image = _eur_text_image_scene_selector_preview(entry).copy()
    if image.mode != 'P' or image.size != (512, 512):
        raise K7Error('Selector EUR: SceSel_F no tiene el atlas PSMT8 512x512 esperado.')
    transparent = int(layout['transparent_index'])
    palette = _eur_scene_selector_rgba_palette(entry, layout)
    white = max(range(256), key=lambda i: (int(palette[i][3]), sum(int(v) for v in palette[i][:3])))

    # Celdas verificadas en el SceSel_F PAL real. Se usan celdas completas para
    # conservar las UV/métricas del carácter donor y evitar tocar vecinos.
    a_cell = (0, 0, 36, 36)
    r_cell = (238, 0, 272, 36)      # donor mayúsculo R -> Á
    d_cell = (222, 240, 258, 280)
    ae_cell = (158, 240, 192, 280)  # donor minúsculo ä -> b
    o_cell = (296, 282, 329, 315)
    oe_cell = (329, 280, 359, 315)  # donor minúsculo ö -> ó

    # Firma visual defensiva: A/d/o y donors deben contener tinta.
    for label, box in [('A', a_cell), ('R', r_cell), ('d', d_cell), ('ä', ae_cell), ('o', o_cell), ('ö', oe_cell)]:
        crop = image.crop(box)
        if _eur_scene_selector_nontransparent_bbox(crop, transparent) is None:
            raise K7Error(f'Selector EUR: el glifo {label} esperado está vacío; revisión no compatible.')

    # R -> Á. Reducimos ligeramente el A nativo para reservar espacio al acento,
    # manteniéndolo dentro de las UV del donor mayúsculo.
    a = image.crop(a_cell)
    abb = _eur_scene_selector_nontransparent_bbox(a, transparent)
    a = a.crop(abb)
    scale = min(30 / max(1, a.width), 28 / max(1, a.height))
    a = a.resize((max(1, round(a.width * scale)), max(1, round(a.height * scale))), Image.Resampling.LANCZOS)
    image.paste(transparent, r_cell)
    rx0, ry0, rx1, ry1 = r_cell
    ax = rx0 + ((rx1-rx0) - a.width)//2
    ay = ry0 + 7
    image.paste(a, (ax, ay))
    draw = ImageDraw.Draw(image)
    draw.line([(rx0+13, ry0+5), (rx0+20, ry0)], fill=int(white), width=2)

    # ä -> b. Un d serif reflejado horizontalmente proporciona el b exacto del
    # mismo atlas y evita depender de fuentes externas.
    d = image.crop(d_cell)
    dbb = _eur_scene_selector_nontransparent_bbox(d, transparent)
    d = ImageOps.mirror(d.crop(dbb))
    image.paste(transparent, ae_cell)
    x0, y0, x1, y1 = ae_cell
    image.paste(d, (x0 + ((x1-x0)-d.width)//2, y1-d.height-2))

    # ö -> ó. Conservamos el cuerpo del o nativo y sustituimos la diéresis por
    # un acento agudo dentro de las UV del donor.
    o = image.crop(o_cell)
    obb = _eur_scene_selector_nontransparent_bbox(o, transparent)
    o = o.crop(obb)
    image.paste(transparent, oe_cell)
    x0, y0, x1, y1 = oe_cell
    image.paste(o, (x0 + ((x1-x0)-o.width)//2, y1-o.height-2))
    draw = ImageDraw.Draw(image)
    draw.line([(x0+10, y0+7), (x0+17, y0+2)], fill=int(white), width=2)

    indices = bytearray(image.getdata())
    swizzled = _swizzle8(indices, int(layout['width']), int(layout['height']))
    if _unswizzle8(swizzled, int(layout['width']), int(layout['height'])) != indices:
        raise K7Error('Selector EUR: glifos españoles no superan round-trip PSMT8.')
    out = bytearray(entry)
    po = int(layout['pixel_offset'])
    out[po:po+len(swizzled)] = swizzled
    patched = bytes(out)

    # Verificación de readback: los tres donors deben diferir del atlas de entrada.
    before = _eur_text_image_scene_selector_preview(entry)
    after = _eur_text_image_scene_selector_preview(patched)
    changed = {}
    for donor, box, display in [('R', r_cell, 'Á'), ('ä', ae_cell, 'b'), ('ö', oe_cell, 'ó')]:
        changed[donor] = before.crop(box).tobytes() != after.crop(box).tobytes()
        if not changed[donor]:
            raise K7Error(f'Selector EUR: el donor {donor}->{display} no cambió tras recompilar.')
    return patched, {
        'strategy': 'scene-selector-donor-remap',
        'codemap': dict(_EUR_SCENE_SELECTOR_CHAPTER_CODEMAP),
        'changed_donors': changed,
        'atlas_size': [512, 512],
        'note': 'R→Á, ä→b y ö→ó sólo en SceSel_F francés.',
    }


# v1.7.7.150 — tabla persistente de sprites del título grande del selector.
#
# El savestate español de prueba demostró que las C-strings (Rngel, etc.) sí se
# cargaban, pero el título visible seguía saliendo como «Ange». El renderer usa
# además una tabla independiente de registros de 20 bytes y un contador por
# idioma/capítulo. Para chapter_00 FR se relocalizan 5 registros basados en el
# «Angel» inglés, cambiando sólo el ID del primer glifo A por el donor R→Á.
_EUR_SCENE_SELECTOR_SPRITE_FR_PTR_ARRAY_VADDR = 0x005B52F0
_EUR_SCENE_SELECTOR_SPRITE_EN_PTR_ARRAY_VADDR = 0x005B5310
_EUR_SCENE_SELECTOR_SPRITE_COUNT_TABLE_VADDR = 0x005F5B70
_EUR_SCENE_SELECTOR_SPRITE_RECORD_SIZE = 20
_EUR_SCENE_SELECTOR_SPRITE_ANGEL_COUNT = 5
_EUR_SCENE_SELECTOR_SPRITE_R_DONOR_ID = 52  # ID estable de R en SceSel_F; el atlas lo remapea a Á
# Hueco de 128 bytes verificado como 0 en SLES PAL limpio y también en RAM del
# savestate español estando ya en CIBLE:00. Esto evita pisar las tablas adyacentes.
_EUR_SCENE_SELECTOR_SPRITE_CAVE_OFFSET = 0x004EF6B4
_EUR_SCENE_SELECTOR_SPRITE_CAVE_SIZE = 128
_EUR_SCENE_SELECTOR_SPRITE_CAVE_MARKER = b'K7ANGEL150\0\0\0\0\0\0'
_EUR_SCENE_SELECTOR_SPRITE_CAVE_PRE = bytes.fromhex('4242424202020202020202020202020202020202020202021010101020000000')
_EUR_SCENE_SELECTOR_SPRITE_CAVE_POST = bytes.fromhex('000000000000000000000000496e66696e69747900000000000000004e614e00')
_EUR_SCENE_SELECTOR_SPRITE_OLD_CAVE_OFFSET = 0x004C8840
_EUR_SCENE_SELECTOR_SPRITE_OLD_CAVE_SIZE = 128
_EUR_SCENE_SELECTOR_SPRITE_OLD_MARKER = b'K7ANGEL149\0\0\0\0\0\0'


def _eur_patch_scene_selector_chapter_strings(sles: bytes, targets: dict[str, str] | None = None) -> tuple[bytes, dict]:
    """Reescribe sólo la columna FR de la PRIMERA tabla de títulos del selector.

    La segunda tabla duplicada pertenece a otro flujo y conserva su codec de
    titlefont. Esta rutina se ejecuta al final del parche DIRECTO para que ningún
    parche genérico/manual vuelva a sustituir el byte donor.
    """
    out = bytearray(sles)
    t = _eur_scene_selector_targets(targets)
    keys = ['chapter_00','chapter_01','chapter_02','chapter_03','chapter_04','chapter_05','chapter_06']
    changes = []
    for idx, key in enumerate(keys):
        ptr_off = int(_EUR_SCENE_SELECTOR_PRIMARY_TABLE) + idx*12 + 4
        if ptr_off + 4 > len(out):
            raise K7Error('Selector EUR: tabla primaria de capítulos fuera de SLES.')
        vaddr = struct.unpack_from('<I', out, ptr_off)[0]
        string_off = int(vaddr) - int(_EUR_SCENE_SELECTOR_VADDR_DELTA)
        if not (0 <= string_off < len(out)):
            raise K7Error(f'Selector EUR: puntero FR {key} inválido: 0x{vaddr:08X}.')
        target = str(t[key])
        encoded = _eur_scene_selector_encode_chapter(target) + b'\0'
        slot_end = _eur_cstring_slot_end(bytes(out), string_off)
        slot_size = slot_end - string_off
        if len(encoded) > slot_size:
            raise K7Error(
                f'Selector EUR: {target!r} no cabe en el slot FR de {key} '
                f'({len(encoded)}>{slot_size}).'
            )
        current = bytes(out[string_off:slot_end])
        if current[:len(encoded)] != encoded:
            out[string_off:slot_end] = encoded + b'\0' * (slot_size-len(encoded))
            changes.append({
                'key': key, 'pointer_offset': ptr_off, 'string_offset': string_off,
                'target': target, 'encoded': encoded[:-1].hex().upper(), 'slot_size': slot_size,
            })

    final = bytes(out)
    verified = []
    for idx, key in enumerate(keys):
        ptr_off = int(_EUR_SCENE_SELECTOR_PRIMARY_TABLE) + idx*12 + 4
        string_off = struct.unpack_from('<I', final, ptr_off)[0] - int(_EUR_SCENE_SELECTOR_VADDR_DELTA)
        expected = _eur_scene_selector_encode_chapter(str(t[key])) + b'\0'
        if final[string_off:string_off+len(expected)] != expected:
            raise K7Error(f'Selector EUR: verificación final fallida para {key}.')
        verified.append({'key': key, 'target': str(t[key]), 'encoded': expected[:-1].hex().upper()})
    return final, {
        'table_offset': int(_EUR_SCENE_SELECTOR_PRIMARY_TABLE),
        'changes': changes, 'verified': verified,
        'codemap': dict(_EUR_SCENE_SELECTOR_CHAPTER_CODEMAP),
        'note': 'Columna FR primaria sincronizada con los donors del atlas SceSel_F.',
    }


def _eur_patch_scene_selector_angel_sprite_records(
    sles: bytes, targets: dict[str, str] | None = None
) -> tuple[bytes, dict]:
    """Relocaliza la secuencia FR de chapter_00 para dibujar cinco glifos.

    La tabla original francesa tiene sólo 4 registros (Ange). Los registros
    contiguos pertenecen a otros títulos, por lo que aumentar el contador sin
    relocalizar corrompe el selector. Para «Ángel» se copia la geometría exacta
    del «Angel» inglés (5 registros), y únicamente el primer ID de glifo se
    sustituye por el de R, cuyo atlas SceSel_F ya se remapea visualmente a Á.

    v1.7.7.150: el cave usado por .149 estaba dentro de una gran zona que el
    juego reinicializa a cero durante el arranque. El cave actual está dentro
    de una isla de constantes estáticas que permanece idéntica en RAM en los
    savestates francés limpio y español parcheado. Se validan sentinelas antes
    y después del hueco antes de escribir.
    """
    t = _eur_scene_selector_targets(targets)
    if str(t.get('chapter_00', '')) != 'Ángel':
        return bytes(sles), {
            'applied': False,
            'reason': 'chapter_00 target is not Ángel',
            'target': str(t.get('chapter_00', '')),
        }

    out = bytearray(sles)
    delta = int(_EUR_SCENE_SELECTOR_VADDR_DELTA)
    rec_size = int(_EUR_SCENE_SELECTOR_SPRITE_RECORD_SIZE)
    count = int(_EUR_SCENE_SELECTOR_SPRITE_ANGEL_COUNT)
    payload_size = rec_size * count

    def file_off(vaddr: int) -> int:
        off = int(vaddr) - delta
        if off < 0 or off >= len(out):
            raise K7Error(f'Selector EUR: VADDR 0x{vaddr:08X} fuera de SLES.')
        return off

    fr_array_off = file_off(_EUR_SCENE_SELECTOR_SPRITE_FR_PTR_ARRAY_VADDR)
    en_array_off = file_off(_EUR_SCENE_SELECTOR_SPRITE_EN_PTR_ARRAY_VADDR)
    count_off = file_off(_EUR_SCENE_SELECTOR_SPRITE_COUNT_TABLE_VADDR) + 1

    fr_old_vaddr = struct.unpack_from('<I', out, fr_array_off)[0]
    en_angel_vaddr = struct.unpack_from('<I', out, en_array_off)[0]
    en_angel_off = file_off(en_angel_vaddr)

    if out[count_off] not in (4, 5):
        raise K7Error(
            f'Selector EUR: contador chapter_00 FR inesperado: {out[count_off]} (esperado 4/5).'
        )
    marker = _EUR_SCENE_SELECTOR_SPRITE_CAVE_MARKER
    if payload_size + len(marker) > _EUR_SCENE_SELECTOR_SPRITE_CAVE_SIZE:
        raise K7Error('Selector EUR: cave de Ángel insuficiente.')
    if en_angel_off + payload_size > len(out):
        raise K7Error('Selector EUR: tabla EN Angel truncada.')

    records = bytearray(out[en_angel_off:en_angel_off + payload_size])
    a_id = struct.unpack_from('<I', records, 16)[0]
    l_id = struct.unpack_from('<I', records, 4*rec_size + 16)[0]
    r_id = int(_EUR_SCENE_SELECTOR_SPRITE_R_DONOR_ID)
    if not all(0 < x < 0x100 for x in (a_id, l_id, r_id)) or len({a_id, l_id, r_id}) < 3:
        raise K7Error(
            f'Selector EUR: IDs de glifo inesperados A={a_id:#x} l={l_id:#x} R={r_id:#x}.'
        )
    struct.pack_into('<I', records, 16, r_id)

    cave = int(_EUR_SCENE_SELECTOR_SPRITE_CAVE_OFFSET)
    cave_end = cave + int(_EUR_SCENE_SELECTOR_SPRITE_CAVE_SIZE)
    if cave_end > len(out):
        raise K7Error('Selector EUR: cave de Ángel fuera del SLES.')

    # Guard v1.7.7.150: el hueco debe seguir incrustado entre las mismas
    # constantes estáticas del SLES PAL. Esto impide volver a usar una zona
    # grande de ceros que el juego pueda limpiar como memoria de trabajo.
    pre = _EUR_SCENE_SELECTOR_SPRITE_CAVE_PRE
    post = _EUR_SCENE_SELECTOR_SPRITE_CAVE_POST
    if bytes(out[cave-len(pre):cave]) != pre or bytes(out[cave_end:cave_end+len(post)]) != post:
        raise K7Error('Selector EUR: sentinelas del cave persistente no coinciden; se aborta.')

    # El cave tiene que pertenecer a la parte file-backed del primer PT_LOAD.
    if len(out) < 52 or out[:4] != b'\x7fELF':
        raise K7Error('Selector EUR: SLES no es un ELF válido.')
    e_phoff = struct.unpack_from('<I', out, 28)[0]
    e_phentsize = struct.unpack_from('<H', out, 42)[0]
    e_phnum = struct.unpack_from('<H', out, 44)[0]
    covered = False
    for i in range(e_phnum):
        po = e_phoff + i * e_phentsize
        if po + 32 > len(out):
            break
        p_type, p_offset, p_vaddr, _p_paddr, p_filesz, _p_memsz, _p_flags, _p_align = struct.unpack_from('<8I', out, po)
        if p_type == 1 and p_offset <= cave and cave_end <= p_offset + p_filesz:
            expected_vaddr = p_vaddr + (cave - p_offset)
            if expected_vaddr != cave + delta:
                raise K7Error('Selector EUR: mapeo ELF del cave no coincide con el delta esperado.')
            covered = True
            break
    if not covered:
        raise K7Error('Selector EUR: cave persistente no pertenece a un PT_LOAD file-backed.')

    current_cave = bytes(out[cave:cave_end])
    already = (
        current_cave[:payload_size] == bytes(records) and
        current_cave[payload_size:payload_size+len(marker)] == marker
    )
    if not already and any(current_cave):
        raise K7Error(
            'Selector EUR: el hueco reservado para Ángel ya contiene datos; '
            'se aborta para no sobrescribir memoria desconocida.'
        )

    out[cave:cave + payload_size] = records
    out[cave + payload_size:cave + payload_size + len(marker)] = marker

    # Si la entrada proviene de .149, retirar el payload abandonado del cave
    # runtime-cleared. No es funcionalmente necesario, pero deja el SLES limpio.
    old_cave = int(_EUR_SCENE_SELECTOR_SPRITE_OLD_CAVE_OFFSET)
    old_end = old_cave + int(_EUR_SCENE_SELECTOR_SPRITE_OLD_CAVE_SIZE)
    if old_end <= len(out):
        old_marker_pos = old_cave + payload_size
        if bytes(out[old_marker_pos:old_marker_pos+len(_EUR_SCENE_SELECTOR_SPRITE_OLD_MARKER)]) == _EUR_SCENE_SELECTOR_SPRITE_OLD_MARKER:
            out[old_cave:old_end] = b'\0' * (old_end-old_cave)

    new_vaddr = cave + delta
    struct.pack_into('<I', out, fr_array_off, new_vaddr)
    out[count_off] = count

    if struct.unpack_from('<I', out, fr_array_off)[0] != new_vaddr:
        raise K7Error('Selector EUR: fallo al verificar el nuevo puntero de Ángel.')
    if out[count_off] != 5:
        raise K7Error('Selector EUR: fallo al verificar contador FR=5 para Ángel.')
    if bytes(out[cave:cave + payload_size]) != bytes(records):
        raise K7Error('Selector EUR: fallo al verificar los 5 registros gráficos de Ángel.')

    return bytes(out), {
        'applied': True,
        'old_fr_vaddr': fr_old_vaddr,
        'new_fr_vaddr': new_vaddr,
        'english_template_vaddr': en_angel_vaddr,
        'count_offset': count_off,
        'count': 5,
        'glyph_ids': {'A_original': a_id, 'R_as_Á': r_id, 'l': l_id},
        'cave_offset': cave,
        'cave_size': _EUR_SCENE_SELECTOR_SPRITE_CAVE_SIZE,
        'strategy': 'persistent static cave: copy EN Angel geometry + replace first glyph A with R→Á donor',
    }


def _eur_verify_scene_selector_angel_sprite_constants() -> dict:
    """Guardia interna: Ángel visible requiere puntero + 5 registros + contador."""
    if _EUR_SCENE_SELECTOR_SPRITE_RECORD_SIZE != 20:
        raise K7Error('Selector EUR: stride de registro debe ser 20 bytes.')
    if _EUR_SCENE_SELECTOR_SPRITE_ANGEL_COUNT != 5:
        raise K7Error('Selector EUR: Ángel debe usar 5 registros.')
    if _EUR_SCENE_SELECTOR_SPRITE_CAVE_SIZE < 100 + len(_EUR_SCENE_SELECTOR_SPRITE_CAVE_MARKER):
        raise K7Error('Selector EUR: cave insuficiente para cinco registros + marcador.')
    if len(_EUR_SCENE_SELECTOR_SPRITE_CAVE_PRE) != 32 or len(_EUR_SCENE_SELECTOR_SPRITE_CAVE_POST) != 32:
        raise K7Error('Selector EUR: sentinelas del cave deben medir 32 bytes.')
    return {
        'record_size': _EUR_SCENE_SELECTOR_SPRITE_RECORD_SIZE,
        'count': _EUR_SCENE_SELECTOR_SPRITE_ANGEL_COUNT,
        'cave_offset': _EUR_SCENE_SELECTOR_SPRITE_CAVE_OFFSET,
        'cave_vaddr': _EUR_SCENE_SELECTOR_SPRITE_CAVE_OFFSET + _EUR_SCENE_SELECTOR_VADDR_DELTA,
        'guard': 'PT_LOAD + static sentinels',
    }


# v1.7.7.152 — las texturas rasterizadas de MAPA PSMT8 usan CLUT CSM1.
# v1.7.7.153 — los `*_a` de MAPA se recompilan con rótulos/fechas ES; `*_n` se preservan.
# El decoder .146-.151 ya reproducía correctamente el alias PSMCT32→PSMT8,
# pero leía la CLUT física como si fuese lineal. Eso hacía que los índices
# 8..15/16..23 se cruzasen y que el antialias de las letras apareciese negro.
# `_eur_map_raster_t8_palette` debe aplicar SIEMPRE el swap de bits 3/4 CSM1.

# v1.7.7.151 — generalización del mismo mecanismo de sprites a todos los
# capítulos horizontales del selector. chapter_06 (León) no usa esta tabla:
# permanece rasterizado en la tarjeta vertical de SceSel_F y se parchea por la
# ruta gráfica ya existente.
_EUR_SCENE_SELECTOR_FR_GLYPH_IDS = {
    'A': 21, 'C': 22, 'E': 23, 'S': 25, 'H': 50, 'N': 51, 'R': 52,
    'a': 53, 'ä': 54, 'c': 32, 'd': 26, 'e': 33, 'g': 27, 'i': 28,
    'l': 29, 'm': 34, 'n': 35, 'o': 57, 'r': 37, 's': 38, 't': 30,
    'u': 39,
}
_EUR_SCENE_SELECTOR_FR_DEFAULT_SPRITE_COUNTS = {
    'chapter_00': 5, 'chapter_01': 9, 'chapter_02': 10,
    'chapter_03': 9, 'chapter_04': 8, 'chapter_05': 7, 'chapter_06': 0,
}
# Para cada destino se reutiliza geometría PAL ya probada con la misma cantidad
# de glifos. Sólo cambian IDs de carácter y, en Hombre Nube, se desplaza el
# sexto glifo para mover el espacio de 5+5 (Homme Nuage) a 6+4.
_EUR_SCENE_SELECTOR_FR_GEOMETRY_TEMPLATE = {
    'chapter_01': 'chapter_03',  # Rencontre: 9 glifos, sin espacios
    'chapter_02': 'chapter_02',  # Homme Nuage: 10 glifos
    'chapter_03': 'chapter_03',  # Rencontre: 9 glifos
    'chapter_04': 'chapter_04',  # Alter Ego: 8 glifos, misma grafía
    'chapter_05': 'chapter_05',  # Sourire: 7 glifos
}
# v1.7.7.157 — los títulos del selector que comparten longitud visible con la
# rama inglesa reutilizan su geometría EN como plantilla. Esto conserva el
# espaciado/anchura más contenidos de la versión inglesa y evita la sensación de
# glifo demasiado grande que dejaban algunas plantillas FR. Cuando no existe una
# plantilla inglesa con el mismo número de glifos visibles, se mantiene la rama
# francesa ya validada para no inventar geometría nueva.
_EUR_SCENE_SELECTOR_EN_GEOMETRY_TEMPLATE = {
    'chapter_01': 'chapter_03',  # Atardecer (9) -> Encounter (9)
    'chapter_03': 'chapter_03',  # Encuentro (9) -> Encounter (9)
    'chapter_04': 'chapter_04',  # Alter Ego (8) -> Alter Ego (8)
}


def _eur_scene_selector_sprite_visible_codes(text: str) -> list[str]:
    physical = _eur_scene_selector_encode_chapter(str(text)).decode('latin-1')
    return [ch for ch in physical if ch != ' ']


def _eur_scene_selector_sprite_ids(text: str) -> list[int]:
    ids = []
    for ch in _eur_scene_selector_sprite_visible_codes(text):
        try:
            ids.append(int(_EUR_SCENE_SELECTOR_FR_GLYPH_IDS[ch]))
        except KeyError as exc:
            raise K7Error(
                f'Selector EUR: no hay ID de sprite francés verificado para {ch!r} en {text!r}.'
            ) from exc
    return ids


def _eur_patch_scene_selector_remaining_sprite_records(
    sles: bytes, targets: dict[str, str] | None = None
) -> tuple[bytes, dict]:
    """Sincroniza los registros gráficos FR de chapter_01..chapter_05.

    A diferencia de Ángel, todos los destinos españoles caben dentro de los
    bloques franceses originales: 9<=15, 10=10, 9=9, 8=8 y 7=7. Por tanto no
    se crean más caves ni se cambian punteros. Se reutiliza geometría existente
    y se sustituyen únicamente los IDs de glifo; esto conserva la animación del
    selector y evita pisar tablas adyacentes.
    """
    t = _eur_scene_selector_targets(targets)
    out = bytearray(sles)
    base = bytes(sles)
    delta = int(_EUR_SCENE_SELECTOR_VADDR_DELTA)
    rec_size = int(_EUR_SCENE_SELECTOR_SPRITE_RECORD_SIZE)

    def file_off(vaddr: int) -> int:
        off = int(vaddr) - delta
        if off < 0 or off >= len(out):
            raise K7Error(f'Selector EUR: VADDR 0x{vaddr:08X} fuera de SLES.')
        return off

    fr_array_off = file_off(_EUR_SCENE_SELECTOR_SPRITE_FR_PTR_ARRAY_VADDR)
    en_array_off = file_off(_EUR_SCENE_SELECTOR_SPRITE_EN_PTR_ARRAY_VADDR)
    count_base = file_off(_EUR_SCENE_SELECTOR_SPRITE_COUNT_TABLE_VADDR)
    keys = [f'chapter_{i:02d}' for i in range(7)]
    ptrs = {
        key: struct.unpack_from('<I', base, fr_array_off + idx*4)[0]
        for idx, key in enumerate(keys)
    }
    en_ptrs = {
        key: struct.unpack_from('<I', base, en_array_off + idx*4)[0]
        for idx, key in enumerate(keys)
    }

    # Capacidades verificadas del PAL limpio; coinciden con los contadores FR
    # originales. chapter_01 tiene 15 slots aunque el destino use sólo 9.
    capacities = {
        'chapter_01': 15, 'chapter_02': 10, 'chapter_03': 9,
        'chapter_04': 8, 'chapter_05': 7,
    }
    reports = []
    for chapter_index in range(1, 6):
        key = f'chapter_{chapter_index:02d}'
        target = str(t[key])
        expected_default = str(EUR_SCENE_SELECTOR_DEFAULTS[key])
        if target != expected_default:
            # La GUI permite editar estos campos. No fabricamos geometría para
            # grafías arbitrarias: el parche estructural sólo está validado con
            # los destinos españoles integrados.
            reports.append({'key': key, 'applied': False, 'reason': 'custom target', 'target': target})
            continue

        ids = _eur_scene_selector_sprite_ids(target)
        expected_count = int(_EUR_SCENE_SELECTOR_FR_DEFAULT_SPRITE_COUNTS[key])
        if len(ids) != expected_count:
            raise K7Error(
                f'Selector EUR: {key} produce {len(ids)} glifos; se esperaban {expected_count}.'
            )
        cap = int(capacities[key])
        if len(ids) > cap:
            raise K7Error(f'Selector EUR: {target!r} no cabe en los {cap} registros FR de {key}.')

        dst_off = file_off(ptrs[key])
        count_off = count_base + chapter_index*3 + 1  # tabla intercalada EN/FR/DE
        if count_off >= len(out):
            raise K7Error(f'Selector EUR: contador FR {key} fuera de SLES.')
        current_count = int(base[count_off])
        if current_count == len(ids):
            current_ids = [
                struct.unpack_from('<I', base, dst_off+i*rec_size+16)[0]
                for i in range(current_count)
            ]
            if current_ids == ids:
                reports.append({
                    'key': key, 'applied': True, 'already_patched': True,
                    'target': target, 'pointer_vaddr': int(ptrs[key]),
                    'count': len(ids), 'capacity': cap,
                    'template': _EUR_SCENE_SELECTOR_FR_GEOMETRY_TEMPLATE[key],
                    'template_source': 'fr',
                    'glyph_ids': list(ids),
                })
                continue

        template_source = 'fr'
        template_key = _EUR_SCENE_SELECTOR_FR_GEOMETRY_TEMPLATE[key]
        template_vaddr = int(ptrs[template_key])
        if key in _EUR_SCENE_SELECTOR_EN_GEOMETRY_TEMPLATE:
            en_template_key = _EUR_SCENE_SELECTOR_EN_GEOMETRY_TEMPLATE[key]
            en_visible = _eur_scene_selector_sprite_visible_codes(_EUR_SCENE_SELECTOR_CHAPTER_EN[en_template_key])
            if len(en_visible) != len(ids):
                raise K7Error(
                    f'Selector EUR: la plantilla EN {en_template_key} no coincide en longitud con {key}. '
                    f'({len(en_visible)}!={len(ids)})'
                )
            template_source = 'en'
            template_key = en_template_key
            template_vaddr = int(en_ptrs[en_template_key])
        template_off = file_off(template_vaddr)
        template_count = len(ids)
        template_bytes = base[template_off:template_off + template_count*rec_size]
        if len(template_bytes) != template_count*rec_size:
            raise K7Error(f'Selector EUR: plantilla gráfica truncada para {key}.')
        records = bytearray(template_bytes)

        # Todos estos títulos carecen de descendentes en la grafía española.
        # La fuente FR usa baseline 50 para ellos; normalizamos ambos Y para no
        # heredar el y=60 del antiguo g de Homme Nuage.
        for i, glyph_id in enumerate(ids):
            struct.pack_into('<f', records, i*rec_size + 4, 50.0)
            struct.pack_into('<f', records, i*rec_size + 12, 50.0)
            struct.pack_into('<I', records, i*rec_size + 16, int(glyph_id))

        if key == 'chapter_02':
            # Homme Nuage = 5+5; Hombre Nube = 6+4. Mantener el ancho global y
            # trasladar sólo la sexta posición 14 px a la izquierda mueve el
            # hueco visual detrás de "Hombre" sin alterar la segunda palabra.
            x = struct.unpack_from('<f', records, 5*rec_size)[0]
            struct.pack_into('<f', records, 5*rec_size, float(x - 14.0))

        block_size = cap * rec_size
        if dst_off + block_size > len(out):
            raise K7Error(f'Selector EUR: bloque FR {key} truncado.')
        out[dst_off:dst_off + len(records)] = records
        out[count_off] = len(ids)

        reports.append({
            'key': key, 'applied': True, 'target': target,
            'pointer_vaddr': int(ptrs[key]), 'count': len(ids),
            'capacity': cap, 'template': template_key, 'template_source': template_source,
            'glyph_ids': list(ids),
        })

    final = bytes(out)
    # Readback estricto de IDs/contadores. Los punteros 01..05 deben permanecer
    # exactamente iguales; sólo Ángel requiere relocalización.
    for rep in reports:
        if not rep.get('applied'):
            continue
        key = str(rep['key'])
        chapter_index = int(key[-2:])
        ptr_now = struct.unpack_from('<I', final, fr_array_off + chapter_index*4)[0]
        if ptr_now != ptrs[key]:
            raise K7Error(f'Selector EUR: {key} cambió de puntero inesperadamente.')
        count_off = count_base + chapter_index*3 + 1
        if final[count_off] != int(rep['count']):
            raise K7Error(f'Selector EUR: contador final incorrecto para {key}.')
        ro = file_off(ptr_now)
        ids_now = [struct.unpack_from('<I', final, ro+i*rec_size+16)[0] for i in range(int(rep['count']))]
        if ids_now != list(rep['glyph_ids']):
            raise K7Error(f'Selector EUR: IDs finales incorrectos para {key}: {ids_now}.')

    # chapter_06 se dibuja en la tarjeta vertical rasterizada y debe conservar
    # count FR=0; si cambia significaría que hemos confundido dos renderers.
    ch6_count_off = count_base + 6*3 + 1
    if final[ch6_count_off] != 0:
        raise K7Error('Selector EUR: chapter_06 FR debe seguir usando renderer gráfico (count=0).')
    return final, {
        'applied': sum(1 for x in reports if x.get('applied')),
        'chapters': reports,
        'chapter_06': 'León permanece en SceSel_F vertical (renderer raster).',
        'strategy': 'in-place FR sprite blocks; no new caves beyond chapter_00',
    }


def _eur_verify_scene_selector_all_sprite_constants() -> dict:
    expected = {
        'chapter_01': [21,30,53,37,26,33,32,33,37],
        'chapter_02': [50,57,34,54,37,33,51,39,54,33],
        'chapter_03': [23,35,32,39,33,35,30,37,57],
        'chapter_04': [21,29,30,33,37,23,27,57],
        'chapter_05': [25,57,35,37,28,38,53],
    }
    got = {k: _eur_scene_selector_sprite_ids(EUR_SCENE_SELECTOR_DEFAULTS[k]) for k in expected}
    if got != expected:
        raise K7Error(f'Selector EUR: regresión de IDs de sprites ES: {got!r}.')
    return {'glyph_ids': got, 'counts': dict(_EUR_SCENE_SELECTOR_FR_DEFAULT_SPRITE_COUNTS)}


# v1.7.7.133 — títulos de capítulo de Texto Imágenes leídos de la ISO REAL.
# Las versiones anteriores fabricaban una vista con el target español activo y
# por ello una ISO francesa podía parecer ya traducida en el visor. Estas filas
# se extraen ahora de `kan*_?.dic` / `SceSel_?` del archivo seleccionado.
_EUR_CHAPTER_PREVIEW_CARDS = [
    ('chapter_00', '00', 9201, 311),  # kanCel: Angel / Ange
    ('encounter_main', '', 9202, 314), # kanCur: Encounter / Rencontre
    ('mirror_image', '', 9203, 317),   # kanDmi: Mirror Image
    ('final_complete', '', 9204, 320), # kanEnd: final / complete
    ('sunset_part1', '', 9205, 323),   # kanFuk: Sunset I
    ('smile_part1', '', 9206, 326),    # kanHtl: Smile I
    ('encounter_part1', '', 9207, 329),# kanIsz: Encounter II/parte
    ('chapter_01', '01', 9208, 332),   # kanKak: Sunset / Coucher de Soleil
    ('chapter_04', '04', 9209, 335),   # kanNY: Alter Ego
    ('chapter_05', '05', 9210, 338),   # kanScl: Smile / Sourire
    ('chapter_02', '02', 9211, 341),   # kanTxs: Cloudman / Homme Nuage
]

_EUR_CHAPTER_PREVIEW_NAMES = {
    'en': ['Angel', 'Encounter', 'Mirror Image', 'Complete', 'Sunset I', 'Smile I', 'Encounter II', 'Sunset', 'Alter Ego', 'Smile', 'Cloudman', 'Lion'],
    'fr': ['Ange', 'Rencontre', 'Mirror Image', 'Terminé', 'Coucher de Soleil I', 'Sourire I', 'Rencontre II', 'Coucher de Soleil', 'Alter Ego', 'Sourire', 'Homme Nuage', 'Lion'],
    'de': ['Engel', 'Begegnung', 'Mirror Image', 'Complete', 'Sonnenuntergang I', 'Lächeln I', 'Begegnung II', 'Sonnenuntergang', 'Alter Ego', 'Lächeln', 'Wolkenmann', 'Löwe'],
}



# v1.7.7.143 — recursos reales usados por el selector/título de fase.
_EUR_PHASE_TITLE_RESOURCES = [
    (0,3823,'00_.dic',3824,'00__f.dic',3825,'00__g.dic'),
    (1,3827,'01_.dic',3828,'01__f.dic',3829,'01__g.dic'),
    (2,3831,'02_.dic',3832,'02__f.dic',3833,'02__g.dic'),
    (3,3835,'03_.dic',3836,'03__f.dic',3837,'03__g.dic'),
    (4,3838,'04_.dic',3839,'04__f.dic',3840,'04__g.dic'),
    (5,3841,'05_.dic',3842,'05__f.dic',3843,'05__g.dic'),
    (6,3844,'06_.dic',3845,'06__f.dic',3846,'06__g.dic'),
    (7,3847,'07_.dic',3848,'07__f.dic',3849,'07__g.dic'),
    (8,3850,'08_.dic',3851,'08__f.dic',3852,'08__g.dic'),
    (9,3853,'09_.dic',3854,'09__f.dic',3855,'09__g.dic'),
    (10,3856,'10_.dic',3857,'10__f.dic',3858,'10__g.dic'),
    (11,3859,'11_.dic',3860,'11__f.dic',3861,'11__g.dic'),
    (12,3862,'12_.dic',3863,'12__f.dic',3864,'12__g.dic'),
]


# v1.7.7.145 — «Ange» se muestra como «Ángel» reutilizando el glifo À real.
# El titlefont francés de fase 00 contiene un repertorio explícito con À pero no Á.
# Guardamos «Àngel» (0xC0 + ASCII) en el SLES y transformamos únicamente el dibujo
# de À -> Á dentro de 00__f.dic/titlefont. No se toca la A ASCII ni st00Font.
def _eur_phase_titlefont_projection_runs(atlas: Image.Image) -> list[list[tuple[int,int,int,int]]]:
    im=atlas.convert('L'); bg=_mode_level(im)
    def runs(flags):
        out=[]; start=None
        for i,on in enumerate(list(flags)+[False]):
            if on and start is None:
                start=i
            elif not on and start is not None:
                out.append((start,i)); start=None
        return out
    yruns=runs([any(im.getpixel((x,y)) != bg for x in range(im.width)) for y in range(im.height)])
    rows=[]
    for y0,y1 in yruns:
        xruns=runs([any(im.getpixel((x,y)) != bg for y in range(y0,y1)) for x in range(im.width)])
        rows.append([(x0,y0,x1,y1) for x0,x1 in xruns])
    return rows


def _eur_phase_titlefont_components(crop: Image.Image) -> tuple[int,list[dict]]:
    im=crop.convert('L'); w,h=im.size; bg=_mode_level(im)
    mask=bytearray(1 if v != bg else 0 for v in im.getdata())
    seen=bytearray(w*h); comps=[]
    for idx,on in enumerate(mask):
        if not on or seen[idx]:
            continue
        stack=[idx]; seen[idx]=1; pix=[]
        while stack:
            q=stack.pop(); y,x=divmod(q,w); pix.append((x,y))
            for yy in range(max(0,y-1),min(h,y+2)):
                for xx in range(max(0,x-1),min(w,x+2)):
                    j=yy*w+xx
                    if mask[j] and not seen[j]:
                        seen[j]=1; stack.append(j)
        if pix:
            xs=[p[0] for p in pix]; ys=[p[1] for p in pix]
            comps.append({'pixels':pix,'bbox':(min(xs),min(ys),max(xs)+1,max(ys)+1),'area':len(pix)})
    return bg,comps


def _eur_phase00_titlefont_agrave_to_aacute(atlas: Image.Image) -> tuple[Image.Image,dict]:
    """Convierte el À nativo de titlefont en Á usando el A ASCII del mismo atlas."""
    im=atlas.convert('L').copy()
    if im.size != (256,128):
        raise K7Error(f'Fase 00: titlefont francés inesperado {im.size}; se esperaba 256x128.')
    rows=_eur_phase_titlefont_projection_runs(im)
    counts=[len(r) for r in rows]
    # Firma exacta observada en el 00__f.dic PAL real de Killer7 EUR.
    if counts != [26,22,25,15]:
        raise K7Error(f'Fase 00: firma de titlefont francés inesperada: filas={counts}.')
    a_box=rows[1][0]       # A ASCII, primera mayúscula de la segunda fila
    agrave_box=rows[2][20] # run que contiene la marca previa + À, tras WXYZ/signos/0..9
    a=im.crop(a_box); donor=im.crop(agrave_box)
    bg,comps=_eur_phase_titlefont_components(donor)
    if len(comps) < 2:
        raise K7Error('Fase 00: firma interna del run de À inesperada.')
    agrave=max(comps,key=lambda c:c['area'])
    # El run real comparte columna con una marca pequeña previa; el À es el componente mayor.
    if agrave['area'] < 40:
        raise K7Error('Fase 00: componente À demasiado pequeño.')

    abg,acomps=_eur_phase_titlefont_components(a)
    if not acomps:
        raise K7Error('Fase 00: glifo A ASCII vacío.')
    abase=max(acomps,key=lambda c:c['area'])
    a_pixels=set(abase['pixels'])
    donor_pixels=set(agrave['pixels'])

    # Acentuar en francés desplaza el cuerpo de A hacia abajo. Buscamos su alineación
    # exacta dentro del componente À y consideramos el sobrante superior como grave.
    best=None
    for dx in range(max(0,agrave['bbox'][0]-2), min(donor.width-(abase['bbox'][2]-abase['bbox'][0]),agrave['bbox'][0]+3)+1):
        for dy in range(0, min(6,donor.height-(abase['bbox'][3]-abase['bbox'][1]))+1):
            shifted={(x+dx,y+dy) for x,y in a_pixels}
            inter=len(shifted & donor_pixels)
            precision=inter/max(1,len(shifted))
            extra=donor_pixels-shifted
            score=(precision,-len(extra),inter)
            if best is None or score>best[0]:
                best=(score,dx,dy,shifted,extra)
    if best is None:
        raise K7Error('Fase 00: no se pudo alinear A con À.')
    (_score,dx,dy,shifted,extra)=best
    precision=len(shifted & donor_pixels)/max(1,len(shifted))
    # El A PAL coincide prácticamente píxel a píxel; dejamos algo de margen por AA.
    if precision < 0.82:
        raise K7Error(f'Fase 00: el cuerpo de À no coincide con A ({precision:.1%}).')
    # Sólo los píxeles extra de la zona superior son el grave; ignora pequeñas
    # diferencias de borde del antialias en la parte baja.
    accent=[(x,y) for x,y in extra if y < dy + 6]
    if not (3 <= len(accent) <= 30):
        raise K7Error(f'Fase 00: acento grave aislado con tamaño inesperado ({len(accent)} px).')

    patched=donor.copy()
    for x,y in accent:
        patched.putpixel((x,y),bg)
    # Reflejo respecto al ancho del cuerpo de A: grave (lado izq.) -> agudo (lado der.).
    for x,y in accent:
        mx=dx + (a.width-1-(x-dx))
        if not (0 <= mx < donor.width):
            raise K7Error('Fase 00: Á calculada sale del slot de À.')
        patched.putpixel((mx,y),donor.getpixel((x,y)))
    if patched.tobytes()==donor.tobytes():
        raise K7Error('Fase 00: la conversión À->Á no produjo cambios.')
    out=im.copy(); out.paste(patched,(agrave_box[0],agrave_box[1]))
    return out,{
        'strategy':'native-A-plus-mirrored-grave', 'atlas':list(im.size),
        'ascii_A_rect':list(a_box), 'Agrave_run_rect':list(agrave_box),
        'A_alignment':[dx,dy], 'A_match':round(precision,4),
        'accent_pixels':len(accent), 'encoded_as':'À', 'byte':'0xC0', 'display':'Á',
    }


def _eur_patch_phase00_angel_font(afs, raw_entries, names, replacements: dict[int,bytes]) -> dict:
    """Parchea 00__f.dic/titlefont: el slot À pasa a dibujar Á."""
    phase0=next(row for row in _EUR_PHASE_TITLE_RESOURCES if int(row[0])==0)
    _phase,_en_idx,_en_name,fr_idx,fr_name,_de_idx,_de_name=phase0
    fr_idx=int(fr_idx)
    if fr_idx >= len(names) or str(names[fr_idx]).lower()!=str(fr_name).lower():
        found=names[fr_idx] if fr_idx < len(names) else '<fuera de rango>'
        raise K7Error(f'Fase 00: se esperaba {fr_name} en AFS #{fr_idx}, encontrado {found!r}.')
    fr_entry=replacements.get(fr_idx,_eur_read_entry(afs,raw_entries,fr_idx))
    sub_off,sub=_eur_text_image_named_subresource(fr_entry,'titlefont')
    info=Killer7Project._dic_texture_info(sub)
    if not info or int(info.get('bpp',0))!=4:
        raise K7Error('Fase 00: 00__f.dic/titlefont no es DIC 4bpp válido.')
    original=Killer7Project.decode_dic_texture(sub).convert('L')
    patched_atlas,evidence=_eur_phase00_titlefont_agrave_to_aacute(original)
    patched_sub=_encode_atlas_into_dic(sub,patched_atlas)
    if len(patched_sub)!=len(sub):
        raise K7Error('Fase 00: titlefont cambió de tamaño al convertir À->Á.')
    out=bytearray(fr_entry); out[sub_off:sub_off+len(sub)]=patched_sub
    if len(out)!=len(fr_entry):
        raise K7Error('Fase 00: 00__f.dic cambió de tamaño total.')
    verify=Killer7Project.decode_dic_texture(bytes(out[sub_off:sub_off+len(sub)])).convert('L')
    if verify.size!=original.size or verify.tobytes()==original.tobytes():
        raise K7Error('Fase 00: el parche À->Á no sobrevivió al round-trip DIC.')
    replacements[fr_idx]=bytes(out)
    return {'afs_index':fr_idx,'afs_name':str(names[fr_idx]),'subresource':'titlefont',
            'entry_size_unchanged':len(out),'evidence':evidence}


# v1.7.7.160 — los dos renglones del objetivo Heaven Smile NO usan TVFontF.
# SLES_533.66 carga ``st00Font`` para esta misión y su tabla ``st00Font_f.IH``
# contiene únicamente el pequeño repertorio francés de esos dos renglones.
#
# Para no tocar el count ni la estructura previa a los registros STRIMAGS,
# reutilizamos códigos franceses que el texto español ya no necesita. Sólo el
# slot '.' necesita crecer en altura para alojar la 'j'; su coordenada y orden
# de registro permanecen estables. El punto español se dibuja en el slot "'".
_EUR_ST00_MISSION33_CODEMAP = {
    'A': 'Q',
    's': 'é',
    'b': 'D',
    'o': 'G',
    'y': 'h',
    'j': '.',
    '.': "'",
}

_EUR_ST00_MISSION33_GLYPH_DONORS = {
    # código físico de st00Font_f -> (glifo visible, fase FR que lo dona)
    ord('Q'): ('A', 3),
    ord('é'): ('s', 1),
    ord('D'): ('b', 1),
    ord('G'): ('o', 1),
    ord('h'): ('y', 3),
    ord('.'): ('j', 7),
    ord("'"): ('.', 0),
}


def _eur_patch_st00fontf_mission33(afs, raw_entries, names, replacements: dict[int, bytes]) -> dict:
    """Prepara st00Font_f para las líneas españolas del objetivo Heaven Smile.

    La tabla francesa se conserva con 23 registros y los mismos códigos/orden.
    Los bytes españoles se proyectan a slots franceses mediante
    ``_EUR_ST00_MISSION33_CODEMAP``. Esto evita depender de TVFontF y mantiene
    intactos los índices internos de STRIMAGS que preceden a la tabla final.
    """
    from collections import defaultdict

    by_name = defaultdict(list)
    for i, nm in enumerate(names):
        by_name[str(nm).lower()].append(i)

    def unique(name: str) -> int:
        arr = by_name.get(name.lower(), [])
        if len(arr) != 1:
            raise K7Error(f'st00Font EUR: se esperaba un único {name}: {arr}.')
        return int(arr[0])

    target_dic_idx = unique('00__f.dic')
    target_ihe_idx = unique('st00Font_f.IH')
    target_dic = replacements.get(
        target_dic_idx, _eur_read_entry(afs, raw_entries, target_dic_idx)
    )
    target_ihe = _eur_read_entry(afs, raw_entries, target_ihe_idx)
    rec_start, target_recs = _eur_font_ihe_records(target_ihe)
    if len(target_recs) != 23:
        raise K7Error(
            f'st00Font EUR: count francés inesperado {len(target_recs)}; esperado 23.'
        )

    target_sub_off, target_sub = _eur_dic_named_subresource(target_dic, 'st00Font')
    target_atlas = Killer7Project.decode_dic_texture(target_sub).convert('L')
    if target_atlas.size != (128, 128):
        raise K7Error(f'st00Font EUR: atlas francés inesperado {target_atlas.size}.')

    # Cachea fuentes francesas de otras fases. Son la misma familia visual y
    # proporcionan glifos oficiales que st00 no necesitaba en francés.
    source_cache: dict[int, tuple[Image.Image, dict[int, tuple[int, ...]]]] = {}

    def source_for_phase(phase: int):
        phase = int(phase)
        cached = source_cache.get(phase)
        if cached is not None:
            return cached
        dic_idx = unique(f'{phase:02d}__f.dic')
        ihe_idx = unique(f'st{phase:02d}Font_f.IH')
        dic = replacements.get(dic_idx, _eur_read_entry(afs, raw_entries, dic_idx))
        ihe = _eur_read_entry(afs, raw_entries, ihe_idx)
        _rs, recs = _eur_font_ihe_records(ihe)
        _so, sub = _eur_dic_named_subresource(dic, f'st{phase:02d}Font')
        atlas = Killer7Project.decode_dic_texture(sub).convert('L')
        source_cache[phase] = (atlas, recs)
        return source_cache[phase]

    patched_atlas = target_atlas.copy()
    patched_ihe = bytearray(target_ihe)
    report = []

    # Necesitamos la posición exacta de cada registro para poder modificar las
    # métricas del slot '.' sin reconstruir ni reordenar la tabla.
    count = struct.unpack_from('<I', target_ihe, 0x18)[0]
    record_pos = {}
    for ri in range(int(count)):
        pos = rec_start + ri * 20
        rec = struct.unpack_from('<10H', target_ihe, pos)
        record_pos[int(rec[0])] = pos

    for physical_code, (visible, phase) in _EUR_ST00_MISSION33_GLYPH_DONORS.items():
        if physical_code not in target_recs:
            raise K7Error(f'st00Font EUR: falta slot donor 0x{physical_code:02X}.')
        src_atlas, src_recs = source_for_phase(phase)
        source_code = ord(visible)
        if source_code not in src_recs:
            raise K7Error(
                f'st00Font EUR: la fase {phase:02d} FR no contiene el glifo {visible!r}.'
            )
        src_rec = src_recs[source_code]
        glyph = _eur_ihe_glyph(src_atlas, src_recs, source_code)
        dst_rec = list(target_recs[physical_code])
        _code, x, y, w, h, *_rest = dst_rec

        # El slot '.' original es 6x6. Para la j oficial de st07Font_f se usa
        # el espacio libre a su derecha/abajo, manteniendo x/y y el índice del
        # registro. Las métricas tipográficas se copian del glifo oficial.
        if physical_code == ord('.') and visible == 'j':
            w, h = int(src_rec[3]), int(src_rec[4])
            if x + w > target_atlas.width or y + h > target_atlas.height:
                raise K7Error('st00Font EUR: el slot ampliado de j sale del atlas.')
            dst_rec[3] = w
            dst_rec[4] = h
            dst_rec[5:9] = list(src_rec[5:9])
            pos = record_pos[physical_code]
            struct.pack_into('<10H', patched_ihe, pos, *dst_rec)
        else:
            glyph = _eur_tvfont_fit_glyph(glyph, (w, h))

        # Limpia el rectángulo destino completo y copia el glifo donor oficial.
        patched_atlas.paste(0, (x, y, x + w, y + h))
        if glyph.size != (w, h):
            glyph = _eur_tvfont_fit_glyph(glyph, (w, h))
        patched_atlas.paste(glyph, (x, y))
        report.append({
            'visible': visible,
            'encoded_as': chr(physical_code),
            'code': physical_code,
            'source_phase': phase,
            'rect': [x, y, w, h],
        })

    patched_sub = _encode_atlas_into_dic(target_sub, patched_atlas)
    if len(patched_sub) != len(target_sub):
        raise K7Error('st00Font EUR: el subrecurso cambió de tamaño.')
    out = bytearray(target_dic)
    out[target_sub_off:target_sub_off + len(patched_sub)] = patched_sub
    if len(out) != len(target_dic):
        raise K7Error('st00Font EUR: 00__f.dic cambió de tamaño total.')
    if len(patched_ihe) != len(target_ihe):
        raise K7Error('st00Font EUR: st00Font_f.IH cambió de tamaño total.')

    # Round-trip: todos los códigos que usarán las dos líneas deben existir en
    # la tabla y sus slots visibles (salvo espacio) contener píxeles.
    _vrs, verify_recs = _eur_font_ihe_records(bytes(patched_ihe))
    verify_atlas = Killer7Project.decode_dic_texture(
        bytes(out[target_sub_off:])
    ).convert('L')
    line1 = _eur_st00font_encode_spanish('Arrasa la base Heaven Smile')
    line2 = _eur_st00font_encode_spanish('y captura vivo al jefe.')
    required_codes = set(line1 + line2)
    for code in sorted(required_codes):
        if code not in verify_recs:
            raise K7Error(f'st00Font EUR: código 0x{code:02X} no existe tras el parche.')
        if code == 0x20:
            continue
        rec = verify_recs[code]
        x, y, w, h = rec[1], rec[2], rec[3], rec[4]
        if verify_atlas.crop((x, y, x + w, y + h)).getbbox() is None:
            raise K7Error(f'st00Font EUR: código 0x{code:02X} quedó vacío.')

    replacements[target_dic_idx] = bytes(out)
    replacements[target_ihe_idx] = bytes(patched_ihe)
    return {
        'font': 'st00Font',
        'dic_index': target_dic_idx,
        'ihe_index': target_ihe_idx,
        'atlas': list(target_atlas.size),
        'ihe_size_unchanged': len(patched_ihe),
        'record_count': len(verify_recs),
        'encoding_map': dict(_EUR_ST00_MISSION33_CODEMAP),
        'patched_glyphs': report,
        'line_codes': [line1.hex().upper(), line2.hex().upper()],
    }


# v1.7.7.161 — el resto de las órdenes/objetivos usa la familia stXXFont de
# cada fase, no TVFontF. Igual que st00, estas fuentes PAL son repertorios
# mínimos por idioma: que una letra exista en TVFontF no implica que exista en
# stXXFont_f. Para conservar el layout/índices del juego, reutilizamos slots que
# la frase española ya no necesita. Cuando el repertorio FR es demasiado corto
# (st06) o resulta más seguro, partimos de la variante alemana de ESA MISMA
# stXXFont: F/G comparten métricas para los glifos comunes y el mismo atlas.
_EUR_MISSION_OBJECTIVE_PHASE_BY_UNIT = {
    14: 0, 15: 0,
    16: 1,
    17: 2,
    18: 3,
    19: 4,
    20: 6, 21: 6,
    22: 7, 23: 7,
    24: 8,
    25: 9,
    26: 10, 27: 10,
    28: 11,
    29: 12, 30: 12,
}

_EUR_MISSION_PHASE_TARGETS = {
    0: ('Arrasa la base Heaven Smile', 'y captura vivo al jefe.'),
    1: ('Elimina al gobernador Toru Fukushima.',),
    2: ('Elimina al agente Jean DePaul.',),
    3: ('Encuentra a Andrei Ulmeyda.',),
    4: ('Elimina al asesino', 'Curtis Blackburn.'),
    5: ('Elimina al asesino', 'Curtis Blackburn.'),
    6: ('Mata al dibujante de cómics,', 'Trevor Pearlharbor en secreto.'),
    7: ('Reunión secreta de', 'Matsuoka Kenjiro con las Naciones Unidas.'),
    8: ('Contacta el Centro Nacional.',),
    9: ('La orden final',),
    10: ('Duelo contra Handsome Man:', 'Los Punishing Rangers.'),
    11: ('Duelo final.',),
    12: ('Elimina a Steve Thunderson,', 'alto cargo del Partido Demócrata.'),
}

_EUR_MISSION_FONT_BASE_LANGUAGE = {
    1: 'g', 2: 'f', 3: 'f', 4: 'g', 5: 'g', 6: 'g',
    7: 'f', 8: 'f', 9: 'f', 10: 'f', 11: 'f', 12: 'f',
}

_EUR_MISSION_FONT_CODEMAPS = {
    0: dict(_EUR_ST00_MISSION33_CODEMAP),
    1: {'b': 'B', 'l': 'ü'},
    2: {'E': 'S', 'i': 'b', 'm': 'd'},
    3: {'E': 'T', 'c': 'o', 't': 'v'},
    4: {'E': 'd', 'm': 'A', 'o': 'g'},
    5: {'E': 'd', 'm': 'A', 'o': 'g'},
    6: {',': 'g', 'j': 'C', 'u': 'ü', 'ó': 'ö'},
    7: {'ó': 'é'},
    8: {},
    9: {},
    10: {'.': 'v', 'D': 'p', 'P': 'C', 'h': 'b'},
    11: {'D': 'É', 'a': 'c', 'i': 'p', 'l': 'd', 'n': 'v'},
    12: {'E': 'G', 'g': 'p', 'ó': 'y'},
}

# visible -> (fase fuente, idioma fuente, carácter fuente). Los glifos son
# siempre sprites de la edición EUR; no rasterizamos una fuente del sistema.
_EUR_MISSION_FONT_GLYPH_DONORS = {
    1: {'b': (1, 'f', 'b'), 'l': (2, 'f', 'l')},
    2: {'E': (1, 'g', 'E'), 'i': (2, 'g', 'i'), 'm': (1, 'g', 'm')},
    3: {'E': (1, 'g', 'E'), 'c': (4, 'f', 'c'), 't': (2, 'f', 't')},
    4: {'E': (1, 'g', 'E'), 'm': (1, 'g', 'm'), 'o': (1, 'g', 'o')},
    5: {'E': (1, 'g', 'E'), 'm': (1, 'g', 'm'), 'o': (1, 'g', 'o')},
    6: {',': (6, 'f', ','), 'j': (7, 'f', 'j'), 'u': (6, 'f', 'u')},
    7: {},
    8: {},
    9: {},
    10: {'.': (10, 'g', '.'), 'D': (10, 'g', 'D'), 'P': (6, 'f', 'P'), 'h': (6, 'f', 'h')},
    11: {'D': (10, 'g', 'D'), 'a': (10, 'f', 'a'), 'i': (10, 'f', 'i'), 'l': (10, 'f', 'l'), 'n': (10, 'f', 'n')},
    12: {'E': (1, 'g', 'E'), 'g': (2, 'f', 'g')},
}

# Sólo se amplían slots cuando hay espacio demostrado en el atlas original.
_EUR_MISSION_FONT_SIZE_OVERRIDES = {
    2: {'m': (20, 15)},
    3: {'t': (10, 17)},
    4: {'m': (20, 15)},
    5: {'m': (20, 15)},
    6: {'j': (7, 23)},
    12: {'E': (18, 20), 'g': (15, 20), 'ó': (16, 20)},
}


def _eur_mission_objective_phase(unit_ids) -> int | None:
    """Devuelve la fase stXXFont de una unidad de orden k7-9005-14..30."""
    phases = set()
    for uid in (str(x) for x in unit_ids):
        m = re.fullmatch(r'k7-9005-(\d{2})-\d{2}', uid)
        if not m:
            continue
        unit_no = int(m.group(1))
        if unit_no in _EUR_MISSION_OBJECTIVE_PHASE_BY_UNIT:
            phases.add(_EUR_MISSION_OBJECTIVE_PHASE_BY_UNIT[unit_no])
    if not phases:
        return None
    if len(phases) != 1:
        raise K7Error(f'Objetivos EUR: una unidad mezcla fases stXXFont: {sorted(phases)}.')
    return int(next(iter(phases)))


def _eur_mission_font_encode_spanish(unit_ids, text: str) -> bytes:
    """Codifica una orden española para la stXXFont real de su fase."""
    phase = _eur_mission_objective_phase(unit_ids)
    if phase is None:
        raise K7Error(f'Objetivos EUR: no se pudo resolver stXXFont para {tuple(unit_ids)!r}.')
    cmap = _EUR_MISSION_FONT_CODEMAPS.get(phase, {})
    remapped = ''.join(cmap.get(ch, ch) for ch in str(text))
    try:
        return remapped.encode('latin-1')
    except UnicodeEncodeError as exc:
        raise K7Error(
            f'st{phase:02d}Font EUR: carácter no soportado en {text!r}: {exc}'
        ) from exc


def _eur_verify_all_mission_font_codecs() -> dict:
    """Guardia estática: cada texto debe mapear caracteres visibles 1:1."""
    per_phase = {}
    for phase, lines in sorted(_EUR_MISSION_PHASE_TARGETS.items()):
        cmap = _EUR_MISSION_FONT_CODEMAPS.get(phase, {})
        visible = set(''.join(lines))
        physical = {ch: cmap.get(ch, ch) for ch in visible}
        # Dos caracteres visibles distintos no pueden terminar en el mismo slot.
        inverse = {}
        for ch, slot in physical.items():
            if slot in inverse and inverse[slot] != ch:
                raise K7Error(
                    f'st{phase:02d}Font EUR: colisión codec {inverse[slot]!r}/{ch!r} -> {slot!r}.'
                )
            inverse[slot] = ch
        encoded = []
        for text in lines:
            raw = ''.join(cmap.get(ch, ch) for ch in text).encode('latin-1')
            if len(raw) & 1:
                raw += b' '
            if len(raw) & 1:
                raise K7Error(f'st{phase:02d}Font EUR: padding por pares falló.')
            encoded.append(raw.hex().upper())
        per_phase[phase] = {
            'lines': len(lines), 'mapping': dict(cmap), 'encoded': encoded,
        }
    return {'phases': per_phase, 'phase_count': len(per_phase), 'pair_aligned': True}


def _eur_patch_remaining_mission_fonts(
    afs, raw_entries, names, replacements: dict[int, bytes]
) -> dict:
    """Parchea st01Font..st12Font para todas las órdenes españolas.

    st00 se conserva en la rutina v1.7.7.160, que además está probada in-game.
    st08/st09 ya contienen todo su repertorio español y por tanto sólo se
    validan; no se reescriben. En st01/st04/st05/st06 se usa la variante alemana
    de la misma fase como atlas/tablas base cuando ofrece slots más adecuados.
    """
    by_name = defaultdict(list)
    for i, nm in enumerate(names):
        by_name[str(nm).lower()].append(i)

    def unique(name: str) -> int:
        arr = by_name.get(str(name).lower(), [])
        if len(arr) != 1:
            raise K7Error(f'Objetivos stXXFont EUR: se esperaba un único {name}: {arr}.')
        return int(arr[0])

    def dic_name(phase: int, lang: str) -> str:
        return f'{phase:02d}__{lang}.dic'

    def ihe_name(phase: int, lang: str) -> str:
        return f'st{phase:02d}Font_{lang}.IH'

    source_cache = {}

    def source_font(phase: int, lang: str):
        key = (int(phase), str(lang))
        if key in source_cache:
            return source_cache[key]
        di = unique(dic_name(phase, lang))
        ii = unique(ihe_name(phase, lang))
        # Donors siempre salen del AFS original para que parches previos no
        # conviertan accidentalmente un donor en otro carácter.
        dic = _eur_read_entry(afs, raw_entries, di)
        ihe = _eur_read_entry(afs, raw_entries, ii)
        rec_start, recs = _eur_font_ihe_records(ihe)
        _sub_off, sub = _eur_dic_named_subresource(dic, f'st{phase:02d}Font')
        atlas = Killer7Project.decode_dic_texture(sub).convert('L')
        source_cache[key] = (atlas, ihe, rec_start, recs)
        return source_cache[key]

    # Marca aguda oficial: diferencia vertical entre e/é de st07Font_f.
    acute_atlas, _acute_ihe, _acute_start, acute_recs = source_font(7, 'f')
    e_glyph = _eur_ihe_glyph(acute_atlas, acute_recs, ord('e'))
    ea_glyph = _eur_ihe_glyph(acute_atlas, acute_recs, ord('é'))
    acute = ea_glyph.crop((0, 0, ea_glyph.width, max(1, ea_glyph.height - e_glyph.height)))
    bbox = acute.getbbox()
    if bbox is None:
        raise K7Error('Objetivos stXXFont EUR: no se pudo extraer el acento agudo oficial.')
    acute = acute.crop(bbox)

    all_reports = []
    for phase in range(1, 13):
        target_dic_idx = unique(dic_name(phase, 'f'))
        target_ihe_idx = unique(ihe_name(phase, 'f'))
        target_dic = replacements.get(
            target_dic_idx, _eur_read_entry(afs, raw_entries, target_dic_idx)
        )
        target_ihe_original = _eur_read_entry(afs, raw_entries, target_ihe_idx)
        target_sub_off, target_sub = _eur_dic_named_subresource(
            target_dic, f'st{phase:02d}Font'
        )
        target_info = Killer7Project._dic_texture_info(target_sub)
        if not target_info:
            raise K7Error(f'st{phase:02d}Font EUR: subrecurso DIC inválido.')

        base_lang = _EUR_MISSION_FONT_BASE_LANGUAGE[phase]
        base_atlas, base_ihe, rec_start, base_recs = source_font(phase, base_lang)
        if base_atlas.size != Killer7Project.decode_dic_texture(target_sub).size:
            raise K7Error(
                f'st{phase:02d}Font EUR: F/{base_lang.upper()} no comparten tamaño de atlas.'
            )

        cmap = _EUR_MISSION_FONT_CODEMAPS[phase]
        lines = _EUR_MISSION_PHASE_TARGETS[phase]
        if not cmap:
            # Validación estricta de los dos casos que ya caben en FR nativo.
            _rs, frecs = _eur_font_ihe_records(target_ihe_original)
            fatlas = Killer7Project.decode_dic_texture(target_sub).convert('L')
            required = set(''.join(lines).encode('latin-1'))
            for code in required:
                if code == 0x20:
                    continue
                if code not in frecs:
                    raise K7Error(
                        f'st{phase:02d}Font EUR: falta 0x{code:02X} aunque el codec sea nativo.'
                    )
                r = frecs[code]
                if fatlas.crop((r[1], r[2], r[1] + r[3], r[2] + r[4])).getbbox() is None:
                    raise K7Error(f'st{phase:02d}Font EUR: glifo nativo 0x{code:02X} vacío.')
            all_reports.append({
                'phase': phase, 'font': f'st{phase:02d}Font', 'base_language': 'f',
                'native_only': True, 'record_count': len(frecs), 'patched_glyphs': [],
            })
            continue

        # Si se toma G como base, todas las métricas de códigos comunes deben
        # coincidir con F: es la prueba de que ambas tablas son la misma familia.
        if base_lang == 'g':
            _fr_start, fr_recs = _eur_font_ihe_records(target_ihe_original)
            common = sorted(set(fr_recs).intersection(base_recs))
            bad = [c for c in common if tuple(fr_recs[c][3:9]) != tuple(base_recs[c][3:9])]
            if bad:
                raise K7Error(
                    f'st{phase:02d}Font EUR: métricas F/G incompatibles en códigos '
                    + ', '.join(f'0x{x:02X}' for x in bad[:8])
                )

        patched_atlas = base_atlas.copy()
        patched_ihe = bytearray(base_ihe)
        count = struct.unpack_from('<I', base_ihe, 0x18)[0]
        record_pos = {}
        for ri in range(int(count)):
            pos = rec_start + ri * 20
            rec = struct.unpack_from('<10H', base_ihe, pos)
            record_pos[int(rec[0])] = pos

        needed_visible = set(''.join(lines))
        needed_physical = {ord(cmap.get(ch, ch)) for ch in needed_visible}
        donors = _EUR_MISSION_FONT_GLYPH_DONORS.get(phase, {})
        overrides = _EUR_MISSION_FONT_SIZE_OVERRIDES.get(phase, {})
        glyph_report = []

        for visible, physical_ch in cmap.items():
            physical_code = ord(physical_ch)
            if physical_code not in base_recs or physical_code not in record_pos:
                raise K7Error(
                    f'st{phase:02d}Font EUR: slot físico {physical_ch!r} no existe en base {base_lang}.'
                )
            old = list(base_recs[physical_code])
            x, y, old_w, old_h = map(int, old[1:5])
            dst = old[:]

            if visible == 'ó':
                if ord('o') not in base_recs:
                    raise K7Error(f'st{phase:02d}Font EUR: falta o base para construir ó.')
                o_rec = base_recs[ord('o')]
                base_o = _eur_ihe_glyph(base_atlas, base_recs, ord('o'))
                tw, th = overrides.get(visible, (old_w, old_h))
                glyph = Image.new('L', (int(tw), int(th)), 0)
                bo = base_o
                if bo.width > tw or bo.height > th:
                    scale = min(float(tw) / bo.width, float(th) / bo.height)
                    bo = bo.resize(
                        (max(1, round(bo.width * scale)), max(1, round(bo.height * scale))),
                        Image.Resampling.LANCZOS,
                    )
                ox = max(0, (tw - bo.width) // 2)
                oy = max(0, th - bo.height)
                glyph.paste(bo, (ox, oy))
                top = max(1, oy if oy else th - bo.height)
                mark = acute
                if mark.height > top:
                    nw = max(1, round(mark.width * top / mark.height))
                    mark = mark.resize((nw, top), Image.Resampling.LANCZOS)
                if mark.width > tw:
                    mark = mark.resize((tw, mark.height), Image.Resampling.LANCZOS)
                # L sobre L: pegado directo conserva la intensidad del sprite.
                glyph.paste(mark, (max(0, (tw - mark.width) // 2), 0))
                dst[3], dst[4] = int(tw), int(th)
                extra_h = max(0, int(th) - int(o_rec[4]))
                dst[5] = int(o_rec[5])
                dst[6] = max(0, int(o_rec[6]) - extra_h)
                dst[7] = int(o_rec[7])
                dst[8] = int(o_rec[8])
                donor_desc = 'o + acento agudo EUR st07Font_f'
            else:
                if visible not in donors:
                    raise K7Error(f'st{phase:02d}Font EUR: falta donor para {visible!r}.')
                src_phase, src_lang, src_ch = donors[visible]
                src_atlas, _sihe, _sstart, src_recs = source_font(src_phase, src_lang)
                src_code = ord(src_ch)
                if src_code not in src_recs:
                    raise K7Error(
                        f'st{phase:02d}Font EUR: donor {src_ch!r} ausente en st{src_phase:02d}/{src_lang}.'
                    )
                src_rec = src_recs[src_code]
                glyph = _eur_ihe_glyph(src_atlas, src_recs, src_code)
                tw, th = overrides.get(visible, glyph.size)
                if glyph.size != (tw, th):
                    glyph = glyph.resize((int(tw), int(th)), Image.Resampling.LANCZOS)
                dst[3], dst[4] = int(tw), int(th)
                if phase == 12 and visible == 'E':
                    dst[5:9] = [0, 2, 18, 1]
                elif phase == 12 and visible == 'g':
                    dst[5:9] = [0, 7, 16, 1]
                else:
                    dst[5:9] = list(src_rec[5:9])
                donor_desc = f'st{src_phase:02d}Font_{src_lang}:{src_ch}'

            # Una expansión sólo es válida si no invade otro slot que la frase
            # española todavía utiliza. Si no era una expansión obligatoria,
            # encajamos el donor en el rectángulo físico original.
            def hits_live(w: int, h: int):
                rect = (x, y, x + int(w), y + int(h))
                for other_code, rr in base_recs.items():
                    if other_code == physical_code or other_code not in needed_physical:
                        continue
                    orect = (rr[1], rr[2], rr[1] + rr[3], rr[2] + rr[4])
                    if (max(rect[0], orect[0]) < min(rect[2], orect[2]) and
                            max(rect[1], orect[1]) < min(rect[3], orect[3])):
                        return other_code
                return None

            hit = hits_live(dst[3], dst[4])
            if hit is not None:
                if visible in overrides:
                    raise K7Error(
                        f'st{phase:02d}Font EUR: expansión {visible!r}->{physical_ch!r} '
                        f'invade código vivo 0x{hit:02X}.'
                    )
                dst[3], dst[4] = old_w, old_h
                glyph = _eur_tvfont_fit_glyph(glyph, (old_w, old_h))
                if hits_live(old_w, old_h) is not None:
                    raise K7Error(
                        f'st{phase:02d}Font EUR: el propio slot {physical_ch!r} solapa otro vivo.'
                    )

            if x + int(dst[3]) > patched_atlas.width or y + int(dst[4]) > patched_atlas.height:
                raise K7Error(f'st{phase:02d}Font EUR: {visible!r} sale del atlas.')
            patched_atlas.paste(
                0, (x, y, x + max(old_w, int(dst[3])), y + max(old_h, int(dst[4])))
            )
            if glyph.size != (int(dst[3]), int(dst[4])):
                glyph = _eur_tvfont_fit_glyph(glyph, (int(dst[3]), int(dst[4])))
            patched_atlas.paste(glyph, (x, y))
            struct.pack_into('<10H', patched_ihe, record_pos[physical_code], *dst)
            glyph_report.append({
                'visible': visible, 'encoded_as': physical_ch, 'code': physical_code,
                'donor': donor_desc, 'rect': [x, y, int(dst[3]), int(dst[4])],
            })

        # El atlas completo (FR o G base) se codifica dentro del contenedor DIC
        # francés. Nunca se sustituye el resto de XX__f.dic.
        patched_sub = _encode_atlas_into_dic(target_sub, patched_atlas)
        if len(patched_sub) != len(target_sub):
            raise K7Error(f'st{phase:02d}Font EUR: el subrecurso cambió de tamaño.')
        out = bytearray(target_dic)
        out[target_sub_off:target_sub_off + len(target_sub)] = patched_sub
        if len(out) != len(target_dic):
            raise K7Error(f'st{phase:02d}Font EUR: XX__f.dic cambió de tamaño.')

        # Round-trip real DIC + tabla IHE final.
        verify_atlas = Killer7Project.decode_dic_texture(
            bytes(out[target_sub_off:target_sub_off + len(target_sub)])
        ).convert('L')
        _vstart, verify_recs = _eur_font_ihe_records(bytes(patched_ihe))
        for text in lines:
            remapped = ''.join(cmap.get(ch, ch) for ch in text)
            raw = remapped.encode('latin-1')
            if len(raw) & 1:
                raw += b' '
            for code in raw:
                if code == 0x20:
                    continue
                if code not in verify_recs:
                    raise K7Error(
                        f'st{phase:02d}Font EUR: código 0x{code:02X} ausente tras round-trip.'
                    )
                rr = verify_recs[code]
                crop = verify_atlas.crop((rr[1], rr[2], rr[1] + rr[3], rr[2] + rr[4]))
                if crop.getbbox() is None:
                    raise K7Error(
                        f'st{phase:02d}Font EUR: código 0x{code:02X} vacío tras round-trip.'
                    )

        replacements[target_dic_idx] = bytes(out)
        replacements[target_ihe_idx] = bytes(patched_ihe)
        all_reports.append({
            'phase': phase,
            'font': f'st{phase:02d}Font',
            'base_language': base_lang,
            'native_only': False,
            'dic_index': target_dic_idx,
            'ihe_index': target_ihe_idx,
            'original_f_ihe_size': len(target_ihe_original),
            'output_ihe_size': len(patched_ihe),
            'record_count': len(verify_recs),
            'encoding_map': dict(cmap),
            'patched_glyphs': glyph_report,
        })

    return {
        'phase_count': len(all_reports),
        'patched_phase_count': sum(not x['native_only'] for x in all_reports),
        'native_phase_count': sum(bool(x['native_only']) for x in all_reports),
        'phases': all_reports,
    }


def _eur_load_phase_title_texture_rows(eur_iso: Path, afs_node, language: str) -> list[dict]:
    code=_eur_text_image_language(language)
    lang_name={'en':'Inglés','fr':'Francés','de':'Alemán'}[code]
    rows=[]
    for phase,en_i,en_n,fr_i,fr_n,de_i,de_n in _EUR_PHASE_TITLE_RESOURCES:
        idx, expected_name = ((en_i,en_n) if code=='en' else (de_i,de_n) if code=='de' else (fr_i,fr_n))
        idx=int(idx); expected_name=str(expected_name)
        info=_eur_iso_afs_entry_info(eur_iso,afs_node,idx)
        if str(info['name']).lower()!=expected_name.lower():
            raise K7Error(f'Texto Imágenes EUR: fase {phase:02d} esperaba {expected_name} en AFS #{idx}, pero encontró {info["name"]!r}.')
        entry_abs=int(info['afs_absolute'])+int(info['entry_offset'])
        with eur_iso.open('rb') as fh:
            fh.seek(entry_abs); entry=fh.read(int(info['entry_size']))
        if len(entry)!=int(info['entry_size']):
            raise K7Error(f'Texto Imágenes EUR: {expected_name} está truncado.')
        for order,(sub_name,role) in enumerate([('titlefont','Fuente general de título'),(f'st{phase:02d}Font','Atlas específico de la fase'),('Order','Rótulo / número de misión')],1):
            sub_off,sub=_eur_text_image_named_subresource(entry,sub_name)
            ti=Killer7Project._dic_texture_info(sub)
            if not ti or int(ti.get('bpp',0))!=4:
                raise K7Error(f'Texto Imágenes EUR: {expected_name}/{sub_name} no es DIC 4bpp válido.')
            image=Killer7Project.decode_dic_texture_preview(sub).convert('RGBA')
            rows.append({
                'id':f'phase_title_{phase:02d}_{sub_name.lower()}', 'group':'Capítulos · Inicio / selector de fase',
                'afs_index':idx,'afs_name':str(info['name']),'subresource':sub_name,'texture':sub_name,
                'label':f'Fase {phase:02d} · {sub_name} · {role}','resource_label':f'#{idx} {info["name"]}',
                'resource_display':f'AFS #{idx} · {info["name"]} · {sub_name} · ISO real',
                'width':image.width,'height':image.height,'bpp':4,'format':'phase_title_graphic_iso',
                'image':image,'preview_image':image.copy(),'export_preview_image':True,'language':code,'language_name':lang_name,
                'read_only_visual':True,'phase_number':f'{phase:02d}','phase_title_role':sub_name,
                'state_label':'ISO seleccionada · recurso real de inicio/selector','entry_offset':int(info['entry_offset']),
                'entry_absolute':entry_abs,'entry_size':int(info['entry_size']),'subresource_offset':int(sub_off),
                'sha256_entry':hashlib.sha256(entry).hexdigest(),'compressed':False,'packed_size':None,'unpacked_size':None,
                'export_filename':f'{code.upper()}_FASE_{phase:02d}_{sub_name}_{info["name"]}.png','sort_order':phase*10+order,
            })
    return rows

def _eur_load_actual_chapter_title_rows(eur_iso: Path, afs_node, language: str,
                                        existing_rows: list[dict]) -> list[dict]:
    """Devuelve siete vistas individuales procedentes de bytes reales de la ISO."""
    code = _eur_text_image_language(language)
    delta = {'en': -1, 'fr': 0, 'de': 1}[code]
    names = _EUR_CHAPTER_PREVIEW_NAMES[code]
    rows = []
    for pos, (key, chapter_no, gid, fr_index) in enumerate(_EUR_CHAPTER_PREVIEW_CARDS):
        idx = int(fr_index) + delta
        info = _eur_iso_afs_entry_info(eur_iso, afs_node, idx)
        entry_abs = int(info['afs_absolute']) + int(info['entry_offset'])
        with eur_iso.open('rb') as fh:
            fh.seek(entry_abs)
            entry = fh.read(int(info['entry_size']))
        if len(entry) != int(info['entry_size']):
            raise K7Error(f'Texto Imágenes EUR: tarjeta de capítulo AFS #{idx} truncada.')
        image = Killer7Project.decode_dic_texture_preview(entry).convert('RGBA')
        # Se muestra la tarjeta REAL completa: así el visor nunca inventa ni
        # adelanta el target español que todavía no esté escrito en la ISO.
        rows.append({
            'id': f'chapter_texture_{gid}',
            'group': 'Capítulos · Fin / completado (kan*)',
            'afs_index': idx, 'afs_name': str(info['name']),
            'subresource': None, 'texture': names[pos],
            'label': f'{pos+1:02d} · {names[pos]} · textura real de la ISO',
            'resource_label': f'#{idx} {info["name"]}',
            'resource_display': f'AFS #{idx} · {info["name"]} · DIC 4bpp real',
            'width': image.width, 'height': image.height, 'bpp': 4,
            'format': 'chapter_graphic_iso',
            'image': image, 'preview_image': image.copy(),
            'export_preview_image': True,
            'language': code,
            'language_name': {'en':'Inglés','fr':'Francés','de':'Alemán'}[code],
            'read_only_visual': True,
            'chapter_key': key, 'chapter_number': chapter_no, 'chapter_texture_role': names[pos],
            'source_text': names[pos],
            'state_label': 'ISO seleccionada · imagen real',
            'entry_offset': int(info['entry_offset']),
            'entry_absolute': int(entry_abs),
            'entry_size': int(info['entry_size']),
            'subresource_offset': 0,
            'sha256_entry': hashlib.sha256(entry).hexdigest(),
            'compressed': False, 'packed_size': None, 'unpacked_size': None,
            'export_filename': f'{code.upper()}_CAPITULO_TEXTURA_{pos+1:02d}_{info["name"]}.png',
            'graphic_id': gid,
        })

    # Lion vive en SceSel_E/F/G, no en un kanLion.dic. Se recorta directamente
    # del atlas que ya se leyó de la ISO para este idioma.
    scene = next((r for r in existing_rows if r.get('id') == 'scene_selector'), None)
    if scene is not None:
        atlas = scene['image'].convert('RGBA')
        lion = atlas.crop(_EUR_SCENE_SELECTOR_LION_CROP).rotate(270, expand=True)
        rows.append({
            'id': 'scene_chapter_title_06',
            'group': 'Capítulos · Fin / completado (kan*)',
            'afs_index': int(scene['afs_index']), 'afs_name': str(scene['afs_name']),
            'subresource': 'SceSel', 'texture': names[11],
            'label': f'12 · {names[11]} · rótulo dentro de SceSel · imagen real de la ISO',
            'resource_label': scene.get('resource_label') or f'#{scene["afs_index"]} {scene["afs_name"]}',
            'resource_display': scene.get('resource_display') or f'AFS #{scene["afs_index"]} · {scene["afs_name"]}',
            'width': lion.width, 'height': lion.height, 'bpp': 8,
            'format': 'chapter_graphic_iso',
            'image': lion, 'preview_image': lion.copy(),
            'export_preview_image': True,
            'language': code,
            'language_name': {'en':'Inglés','fr':'Francés','de':'Alemán'}[code],
            'read_only_visual': True,
            'chapter_key': 'chapter_06', 'chapter_number': '06',
            'source_text': names[11],
            'state_label': 'ISO seleccionada · imagen real',
            'entry_offset': int(scene['entry_offset']),
            'entry_absolute': int(scene['entry_absolute']),
            'entry_size': int(scene['entry_size']),
            'subresource_offset': int(scene.get('subresource_offset', 0)),
            'sha256_entry': str(scene.get('sha256_entry', '')),
            'compressed': False, 'packed_size': None, 'unpacked_size': None,
            'export_filename': f'{code.upper()}_CAPITULO_06_ISO_REAL.png',
        })
    return rows


def load_eur_text_image_previews(eur_iso: str | Path, language: str = 'fr') -> list[dict]:
    """Carga desde una ISO EUR todas las texturas del catálogo Texto Imágenes.

    Devuelve imágenes PIL RGBA junto con sus ubicaciones AFS. No modifica la ISO.
    """
    eur_iso = Path(eur_iso).resolve()
    if not eur_iso.is_file():
        raise K7Error(f'No existe la ISO europea: {eur_iso}')
    with ISO9660(eur_iso) as iso:
        ident = identify_killer7_iso(iso)
        if ident.get('edition') != 'EUR':
            reported = ident.get('reported_serial') or 'serial desconocido'
            raise K7Error(
                f'Texto Imágenes EUR requiere una estructura compatible con {EUR_SUPPORTED_SERIAL}; '
                f'SYSTEM.CNF indica {reported}.'
            )
        afs_node = iso.find(['D_EU', 'DIR_E.AFS'])
        sles_node = iso.find([EUR_SUPPORTED_SERIAL])
        sles_data = iso.read(sles_node)
        if len(sles_data) != sles_node.size:
            raise K7Error('Texto Imágenes EUR: no se pudo leer SLES_533.66 completo.')

    language = _eur_text_image_language(language)
    special_text_specs = _eur_special_sub_text_specs_from_sles(sles_data, language)
    special_portrait_specs = _eur_special_sub_portrait_specs_from_sles(sles_data, language)
    specs_for_language = eur_text_image_specs(language)
    grouped: dict[int, list[dict]] = {}
    for spec in specs_for_language:
        if spec.get('hidden'):
            continue
        grouped.setdefault(int(spec['afs_index']), []).append(spec)

    results = []
    for afs_index, specs in grouped.items():
        info = _eur_iso_afs_entry_info(eur_iso, afs_node, afs_index)
        expected_name = str(specs[0]['afs_name'])
        if info['name'].lower() != expected_name.lower():
            raise K7Error(
                f'Texto Imágenes EUR: AFS #{afs_index} es {info["name"]!r}; '
                f'se esperaba {expected_name!r}.'
            )
        entry_abs = int(info['afs_absolute']) + int(info['entry_offset'])
        with eur_iso.open('rb') as fh:
            fh.seek(entry_abs)
            entry = fh.read(int(info['entry_size']))
        if len(entry) != int(info['entry_size']):
            raise K7Error(f'Texto Imágenes EUR: AFS #{afs_index} está truncado.')
        for spec in specs:
            preview_image = None
            if spec.get('format') == 'psmt8_scene_selector':
                layout = _eur_text_image_scene_selector_layout(entry)
                image = _eur_text_image_scene_selector_preview(entry).copy()
                sub_off = int(layout['texture_offset'])
            elif str(spec.get('format') or '').startswith('compressed_'):
                raw_entry = _eur_k7_lz_decompress(entry)
                sub_off, sub = _eur_text_image_subresource(raw_entry, spec)
                fmt = str(spec.get('format') or '')
                expected = (int(spec['width']), int(spec['height']))
                if fmt == 'compressed_psmct32_alias_t8':
                    info2 = _eur_special_menu_t8_layout(sub)
                    image = _eur_preview_special_menu_t8(sub).copy()
                elif fmt == 'compressed_standard_alias_t8':
                    info2 = _eur_standard_alias_t8_layout(sub)
                    image = _eur_preview_standard_alias_t8(sub).copy()
                elif fmt == 'compressed_dic4':
                    info2 = Killer7Project._dic_texture_info(sub)
                    if not info2:
                        raise K7Error(
                            f'Texto Imágenes EUR: no se reconoce {spec["afs_name"]}/'
                            f'{spec["texture"]} como DIC 4bpp.'
                        )
                    image = Killer7Project.decode_dic_texture_preview(sub).copy()
                else:
                    raise K7Error(f'Texto Imágenes EUR: formato comprimido desconocido: {fmt!r}.')
                dims = (int(info2['width']), int(info2['height']))
                if dims != expected or int(info2.get('bpp', spec.get('bpp', 0))) != int(spec.get('bpp', info2.get('bpp', 0))):
                    raise K7Error(
                        f'Texto Imágenes EUR: {spec["afs_name"]}/{spec["texture"]} es '
                        f'{dims[0]}x{dims[1]} {info2.get("bpp", "?")}bpp; se esperaba '
                        f'{expected[0]}x{expected[1]} {spec.get("bpp", "?")}bpp.'
                    )
            elif spec.get('format') == 'standard_alias_t8':
                sub_off, sub = _eur_text_image_subresource(entry, spec)
                info2 = _eur_standard_alias_t8_layout(sub)
                dims = (int(info2['width']), int(info2['height']))
                expected = (int(spec['width']), int(spec['height']))
                if dims != expected or int(info2.get('bpp', 8)) != int(spec.get('bpp', 8)):
                    raise K7Error(
                        f'Texto Imágenes EUR: {spec["texture"]} es {dims[0]}x{dims[1]} '
                        f'{info2.get("bpp", "?")}bpp; se esperaba '
                        f'{expected[0]}x{expected[1]} {spec.get("bpp", 8)}bpp.'
                    )
                image = _eur_preview_standard_alias_t8(sub).copy()
            elif spec.get('format') == 'psmct32_alias_t8':
                sub_off, sub = _eur_text_image_subresource(entry, spec)
                info2 = _eur_tutorial_t8_layout(sub)
                dims = (int(info2['width']), int(info2['height']))
                expected = (int(spec['width']), int(spec['height']))
                if dims != expected:
                    raise K7Error(
                        f'Texto Imágenes EUR: {spec["texture"]} es {dims[0]}x{dims[1]}; '
                        f'se esperaba {expected[0]}x{expected[1]}.'
                    )
                image = _eur_preview_tutorial_t8(sub).copy()
            elif spec.get('format') == 'linear_indexed_texture':
                sub_off, sub = _eur_text_image_subresource(entry, spec)
                info2 = _eur_linear_indexed_texture_layout(sub)
                dims = (int(info2['width']), int(info2['height']))
                expected = (int(spec['width']), int(spec['height']))
                if dims != expected:
                    raise K7Error(
                        f'Texto Imágenes EUR: {spec["texture"]} es {dims[0]}x{dims[1]}; '
                        f'se esperaba {expected[0]}x{expected[1]}.'
                    )
                image = _eur_preview_linear_indexed_texture(sub).copy()
                if int(spec.get('display_roll_x') or 0):
                    preview_image = _eur_satu_display_image(
                        image, int(spec.get('display_roll_x'))
                    ).convert('RGBA')
            elif spec.get('format') == 'map_raster_t8':
                sub_off, sub = _eur_text_image_subresource(entry, spec)
                info2 = _eur_map_raster_t8_layout(sub)
                dims = (int(info2['width']), int(info2['height']))
                expected = (int(spec['width']), int(spec['height']))
                if dims != expected or int(info2.get('bpp', 8)) != int(spec.get('bpp', 8)):
                    raise K7Error(
                        f'Texto Imágenes EUR: {spec["texture"]} es {dims[0]}x{dims[1]} '
                        f'{info2.get("bpp", "?")}bpp; se esperaba '
                        f'{expected[0]}x{expected[1]} {spec.get("bpp", 8)}bpp.'
                    )
                image = _eur_preview_map_raster_t8(sub).copy()
            else:
                sub_off, sub = _eur_text_image_subresource(entry, spec)
                dic_info = Killer7Project._dic_texture_info(sub)
                if not dic_info:
                    raise K7Error(f'Texto Imágenes EUR: no se reconoce {spec["texture"]}.')
                dims = (int(dic_info['width']), int(dic_info['height']))
                expected = (int(spec['width']), int(spec['height']))
                if dims != expected or int(dic_info['bpp']) != 4:
                    raise K7Error(
                        f'Texto Imágenes EUR: {spec["texture"]} es {dims[0]}x{dims[1]} '
                        f'{dic_info["bpp"]}bpp; se esperaba {expected[0]}x{expected[1]} 4bpp.'
                    )
                image = Killer7Project.decode_dic_texture_preview(sub).copy()
            results.append({
                **spec,
                'image': image,
                'entry_offset': int(info['entry_offset']),
                'entry_absolute': int(entry_abs),
                'entry_size': int(info['entry_size']),
                'subresource_offset': int(sub_off),
                'sha256_entry': hashlib.sha256(entry).hexdigest(),
                'compressed': str(spec.get('format') or '').startswith('compressed_'),
                'packed_size': (int(struct.unpack_from('<I', entry, 4)[0])
                                if str(spec.get('format') or '').startswith('compressed_') else None),
                'unpacked_size': (int(struct.unpack_from('<I', entry, 0)[0])
                                  if str(spec.get('format') or '').startswith('compressed_') else None),
                'preview_image': (
                    preview_image if preview_image is not None else
                    (image.convert('RGBA') if str(spec.get('format') or '').startswith('compressed_') else None)
                ),
                'export_preview_image': bool(spec.get('export_preview_image')),
            })

    # Recursos de INICIO/SELECTOR DE FASE. Son distintos de las tarjetas kan*
    # de cierre/completado y se muestran antes para poder identificarlos.
    phase_title_rows = _eur_load_phase_title_texture_rows(eur_iso, afs_node, language)
    scene_pos = next((i for i, row in enumerate(results) if row.get('id') == 'scene_selector'), -1)
    insert_at = scene_pos + 1 if scene_pos >= 0 else 0
    results[insert_at:insert_at] = phase_title_rows

    # Tarjetas de FIN/COMPLETADO (kan*) leídas también desde la ISO real.
    chapter_rows = _eur_load_actual_chapter_title_rows(eur_iso, afs_node, language, results)
    chapter_insert = insert_at + len(phase_title_rows)
    results[chapter_insert:chapter_insert] = chapter_rows

    # Añadir como filas editables los rótulos lógicos que SLES_533.66 toma realmente de Special_*/sub.
    # Los quads consecutivos de un mismo rótulo se agrupan y las variantes del
    # mismo texto no se exponen como imágenes diferentes.
    parent = next((row for row in results if row.get('id') == 'special_menu_special'), None)
    if parent is None:
        raise K7Error('Texto Imágenes EUR: no se cargó el atlas Special/sub para generar rótulos.')
    parent_rgba = parent['image'].convert('RGBA')
    atlas_rows = []
    for spec in [*special_portrait_specs, *special_text_specs]:
        if spec.get('runtime_dest_parts'):
            crop = _eur_special_compose_logical_region(parent_rgba, spec)
        else:
            x1, y1, x2, y2 = [int(v) for v in spec['atlas_rect']]
            crop = parent_rgba.crop((x1, y1, x2, y2))
        atlas_rows.append({
            **spec,
            'image': crop,
            'entry_offset': int(parent['entry_offset']),
            'entry_absolute': int(parent['entry_absolute']),
            'entry_size': int(parent['entry_size']),
            'subresource_offset': int(parent['subresource_offset']),
            'sha256_entry': parent['sha256_entry'],
            'compressed': True,
            'packed_size': parent.get('packed_size'),
            'unpacked_size': parent.get('unpacked_size'),
            'preview_image': crop.copy(),
            'export_preview_image': False,
        })
    parent_pos = results.index(parent)
    results[parent_pos + 1:parent_pos + 1] = atlas_rows

    # v1.7.7.95 — Special se edita únicamente mediante los 17 rótulos T01..T17.
    # Los atlas completos, retratos y recursos auxiliares siguen existiendo como
    # estructura interna para decodificar/reinyectar, pero ya no se exponen como
    # imágenes editables ni exportables en Texto Imágenes.
    results = [
        row for row in results
        if not str(row.get('id') or '').startswith('special_')
        or str(row.get('id') or '').startswith('special_menu_special__text_')
    ]
    return results


def _eur_dic_palette_rgba(sub: bytes, info: dict) -> list[tuple[int, int, int, int]]:
    pixel_off = int(info['pixel_offset'])
    payload_size = int(info['payload_size'])
    clut_off = pixel_off + payload_size + 0x50
    if clut_off + 64 > len(sub):
        raise K7Error('Texto Imágenes EUR: la textura no contiene una CLUT 16×RGBA válida.')
    palette = []
    for i in range(16):
        r, g, b, a = sub[clut_off+i*4:clut_off+i*4+4]
        if a > 0x80:
            raise K7Error('Texto Imágenes EUR: alfa CLUT fuera del rango GS esperado.')
        palette.append((int(r), int(g), int(b), min(255, int(a) * 2)))
    return palette


def _eur_prepare_png_for_palette(image: Image.Image, palette: list[tuple[int, int, int, int]]) -> Image.Image:
    """Normaliza PNG para una CLUT GS, tratando fondo negro opaco como transparente.

    Las texturas originales usan negro/transparente como fondo. Muchos editores PNG
    exportan ese fondo como RGB negro opaco; si las cuatro esquinas son negras se
    interpreta el negro casi puro como transparencia para evitar rectángulos negros.
    """
    rgba = image.convert('RGBA')
    if palette and palette[0][3] == 0:
        corners = [rgba.getpixel((0, 0)), rgba.getpixel((rgba.width-1, 0)),
                   rgba.getpixel((0, rgba.height-1)), rgba.getpixel((rgba.width-1, rgba.height-1))]
        opaque_black_bg = all(max(px[:3]) <= 20 and px[3] >= 220 for px in corners)
        if opaque_black_bg:
            data = []
            for r, g, b, a in rgba.getdata():
                if max(r, g, b) <= 18:
                    data.append((r, g, b, 0))
                else:
                    data.append((r, g, b, a))
            rgba.putdata(data)
    return rgba


def _eur_encode_png_into_dic(sub: bytes, png_path: str | Path, expected_size: tuple[int, int]) -> bytes:
    info = Killer7Project._dic_texture_info(sub)
    if not info or int(info.get('bpp', 0)) != 4:
        raise K7Error('Texto Imágenes EUR: el destino no es una textura DIC 4bpp compatible.')
    width, height = int(info['width']), int(info['height'])
    if (width, height) != tuple(expected_size):
        raise K7Error(
            f'Texto Imágenes EUR: el destino mide {width}x{height}; '
            f'se esperaba {expected_size[0]}x{expected_size[1]}.'
        )
    png_path = Path(png_path)
    if not png_path.is_file():
        raise K7Error(f'No existe la imagen de reemplazo: {png_path}')
    try:
        with Image.open(png_path) as src:
            if src.size != (width, height):
                raise K7Error(
                    f'{png_path.name} mide {src.width}x{src.height}; '
                    f'debe medir exactamente {width}x{height}.'
                )
            image = src.convert('RGBA')
    except K7Error:
        raise
    except Exception as exc:
        raise K7Error(f'No se pudo abrir {png_path.name}: {exc}') from exc

    palette = _eur_dic_palette_rgba(sub, info)
    image = _eur_prepare_png_for_palette(image, palette)
    cache: dict[tuple[int, int, int, int], int] = {}
    indices = bytearray(width * height)
    for pos, px in enumerate(image.getdata()):
        if px in cache:
            indices[pos] = cache[px]
            continue
        r, g, b, a = px
        best_i = 0
        best_d = None
        for i, (pr, pg, pb, pa) in enumerate(palette):
            # Alfa pesa más para preservar bordes/transparencia; RGB mantiene el
            # aspecto de la CLUT original en texto/blancos y tintes de interfaz.
            d = ((r-pr)*(r-pr) + (g-pg)*(g-pg) + (b-pb)*(b-pb)
                 + 3 * (a-pa)*(a-pa))
            if best_d is None or d < best_d:
                best_d = d
                best_i = i
        cache[px] = best_i
        indices[pos] = best_i

    if not info.get('gs_ct16_alias'):
        raise K7Error('Texto Imágenes EUR: layout DIC no soportado para reemplazo seguro.')
    rrw, rrh = int(info['rrw']), int(info['rrh'])
    dbw = max(1, rrw // 64)
    vram = bytearray(4 * 1024 * 1024)
    for y in range(height):
        row = y * width
        for x in range(width):
            _da_write_t4(vram, width, x, y, int(indices[row + x]))
    payload = _da_read_ct16(vram, dbw, rrw, rrh)
    if len(payload) != int(info['payload_size']):
        raise K7Error('Texto Imágenes EUR: tamaño de payload recompilado inesperado.')
    out = bytearray(sub)
    pixel_off = int(info['pixel_offset'])
    out[pixel_off:pixel_off+len(payload)] = payload
    return bytes(out)


def apply_eur_text_image_replacements_to_iso(
    eur_iso: str | Path,
    output_iso: str | Path,
    replacements: dict[str, str | Path],
    language: str = 'fr',
) -> dict:
    """Aplica PNG de Texto Imágenes reconstruyendo DIR_E.AFS de forma segura.

    v1.7.7.80 añade reemplazos por rótulo lógico de Special/sub. Como la
    recompresión LZ puede crecer incluso al cambiar un recorte pequeño, esta ruta ya
    no escribe sobre slots AFS de tamaño fijo: reconstruye DIR_E.AFS y, si es
    necesario, lo relocaliza al final de la ISO actualizando su registro ISO9660.
    """
    eur_iso = Path(eur_iso).resolve()
    output_iso = Path(output_iso).resolve()
    if not replacements:
        raise K7Error('Texto Imágenes EUR: no hay reemplazos pendientes.')
    if not eur_iso.is_file():
        raise K7Error(f'No existe la ISO europea: {eur_iso}')
    if eur_iso == output_iso:
        raise K7Error('La ISO de salida debe ser distinta de la original.')

    language = _eur_text_image_language(language)
    with ISO9660(eur_iso) as iso:
        ident = identify_killer7_iso(iso)
        if ident.get('edition') != 'EUR':
            reported = ident.get('reported_serial') or 'serial desconocido'
            raise K7Error(
                f'Texto Imágenes EUR requiere una estructura compatible con {EUR_SUPPORTED_SERIAL}; '
                f'SYSTEM.CNF indica {reported}.'
            )
        d_eu_node = iso.find(['D_EU'])
        afs_node = iso.find(['D_EU', 'DIR_E.AFS'])
        sles_node = iso.find([EUR_SUPPORTED_SERIAL])
        sles_data = iso.read(sles_node)
        if len(sles_data) != sles_node.size:
            raise K7Error('Texto Imágenes EUR: no se pudo leer SLES_533.66 completo.')
    afs_record_offset = _iso_find_directory_record_offset(
        eur_iso, d_eu_node, 'DIR_E.AFS', afs_node.lba, afs_node.size
    )
    dynamic_rows = [
        *_eur_special_sub_text_specs_from_sles(sles_data, language),
    ]
    dynamic_specs = {str(row['id']): row for row in dynamic_rows}

    selected = []
    seen = set()
    for spec_id, png_path in replacements.items():
        spec_id = str(spec_id)
        if spec_id in seen:
            continue
        if spec_id.startswith('special_') and not spec_id.startswith('special_menu_special__text_'):
            raise K7Error(
                'Texto Imágenes EUR: Special sólo admite los rótulos T01..T17; '
                'los atlas completos, retratos y recursos auxiliares ya no son editables.'
            )
        spec = dynamic_specs.get(spec_id)
        if spec is None:
            spec = _eur_text_image_spec(spec_id, language)
        png_path = Path(png_path)
        selected.append((spec, png_path))
        seen.add(spec_id)
        for linked_id in spec.get('linked_ids', []):
            linked_id = str(linked_id)
            if linked_id in seen:
                continue
            linked = dynamic_specs.get(linked_id)
            if linked is None:
                linked = _eur_text_image_spec(linked_id, language)
            selected.append((linked, png_path))
            seen.add(linked_id)

    grouped: dict[int, list[tuple[dict, Path]]] = {}
    for spec, png_path in selected:
        grouped.setdefault(int(spec['afs_index']), []).append((spec, png_path))

    planned = []
    replacement_entries: dict[int, bytes] = {}
    original_specs_requested = {str(k) for k in replacements.keys()}
    special_child_specs_applied: list[dict] = []
    entry_context: dict[int, dict] = {}
    parent_special_spec = _eur_text_image_spec('special_menu_special', language)
    for afs_index, rows in grouped.items():
        info = _eur_iso_afs_entry_info(eur_iso, afs_node, afs_index)
        expected_name = str(rows[0][0]['afs_name'])
        if info['name'].lower() != expected_name.lower():
            raise K7Error(
                f'Texto Imágenes EUR: AFS #{afs_index} es {info["name"]!r}; '
                f'se esperaba {expected_name!r}.'
            )
        entry_abs = int(info['afs_absolute']) + int(info['entry_offset'])
        with eur_iso.open('rb') as fh:
            fh.seek(entry_abs)
            original = fh.read(int(info['entry_size']))
        if len(original) != int(info['entry_size']):
            raise K7Error(f'Texto Imágenes EUR: AFS #{afs_index} está truncado.')
        current = bytes(original)
        entry_context[int(afs_index)] = {'info': info, 'original': original, 'expected_name': expected_name}
        applied = []
        for spec, png_path in rows:
            packed_size_after = None
            fmt = str(spec.get('format') or '')
            if fmt == 'atlas_region':
                current, packed_size_after = _eur_rebuild_special_menu_region_entry(
                    current, parent_special_spec, png_path, spec, allow_growth=True
                )
            elif fmt == 'psmt8_scene_selector':
                new_entry = _eur_encode_png_into_scene_selector(
                    current, png_path, (int(spec['width']), int(spec['height']))
                )
                if len(new_entry) != len(current):
                    raise K7Error(
                        f'Texto Imágenes EUR: {spec["texture"]} cambió el tamaño de sce_F.dat.'
                    )
                current = new_entry
            elif fmt.startswith('compressed_'):
                current, packed_size_after = _eur_rebuild_compressed_text_image_entry(
                    current, spec, png_path, allow_growth=True
                )
            else:
                sub_off, sub = _eur_text_image_subresource(current, spec)
                if fmt == 'standard_alias_t8':
                    new_sub = _eur_encode_png_into_standard_alias_t8(
                        sub, png_path, (int(spec['width']), int(spec['height']))
                    )
                elif fmt == 'psmct32_alias_t8':
                    new_sub = _eur_encode_png_into_tutorial_t8(
                        sub, png_path, (int(spec['width']), int(spec['height']))
                    )
                elif fmt == 'map_raster_t8':
                    new_sub = _eur_encode_png_into_map_raster_t8(
                        sub, png_path, (int(spec['width']), int(spec['height']))
                    )
                elif fmt == 'linear_indexed_texture':
                    new_sub = _eur_encode_png_into_linear_indexed_texture(
                        sub, png_path, (int(spec['width']), int(spec['height'])),
                        display_roll_x=int(spec.get('display_roll_x') or 0),
                    )
                else:
                    new_sub = _eur_encode_png_into_dic(
                        sub, png_path, (int(spec['width']), int(spec['height']))
                    )
                if len(new_sub) != len(sub):
                    raise K7Error(
                        f'Texto Imágenes EUR: {spec["texture"]} cambió de tamaño al recompilar.'
                    )
                buf = bytearray(current)
                buf[sub_off:sub_off+len(new_sub)] = new_sub
                current = bytes(buf)
            applied_row = {
                'id': spec['id'], 'texture': spec['texture'], 'label': spec['label'],
                'png': str(png_path), 'size': [int(spec['width']), int(spec['height'])],
            }
            if spec.get('atlas_rect'):
                applied_row['atlas_rect'] = [int(v) for v in spec['atlas_rect']]
                applied_row['source_sles_offset'] = int(spec.get('source_sles_offset', 0))
            if packed_size_after is not None:
                applied_row['packed_size_after'] = int(packed_size_after)
            applied.append(applied_row)
            if fmt == 'atlas_region' and str(spec.get('id', '')).startswith('special_menu_special__'):
                special_child_specs_applied.append(spec)
        replacement_entries[int(afs_index)] = current
        planned.append({
            'afs_index': afs_index,
            'afs_name': expected_name,
            'entry_absolute_before': entry_abs,
            'entry_size_before': int(info['entry_size']),
            'entry_size_after': len(current),
            'sha256_before': hashlib.sha256(original).hexdigest(),
            'sha256_after': hashlib.sha256(current).hexdigest(),
            'images': applied,
        })

    if special_child_specs_applied and 'special_menu_sp60' not in original_specs_requested:
        ctx50 = entry_context.get(2950)
        if ctx50 is None:
            raise K7Error('Texto Imágenes EUR: no se preparó la entrada #2950 para reflejar cambios a 60 Hz.')
        info60 = _eur_iso_afs_entry_info(eur_iso, afs_node, 2945)
        expected_name60 = str(_eur_text_image_spec('special_menu_sp60', language)['afs_name'])
        if info60['name'].lower() != expected_name60.lower():
            raise K7Error(
                f"Texto Imágenes EUR: AFS #2945 es {info60['name']!r}; se esperaba {expected_name60!r}."
            )
        if 2945 not in entry_context:
            entry_abs60 = int(info60['afs_absolute']) + int(info60['entry_offset'])
            with eur_iso.open('rb') as fh:
                fh.seek(entry_abs60)
                original60 = fh.read(int(info60['entry_size']))
            if len(original60) != int(info60['entry_size']):
                raise K7Error('Texto Imágenes EUR: AFS #2945 está truncado.')
            entry_context[2945] = {'info': info60, 'original': original60, 'expected_name': expected_name60}
        current50 = replacement_entries.get(2950, entry_context[2950]['original'])
        current60 = replacement_entries.get(2945, entry_context[2945]['original'])
        mirrored60, mirrored_rows = _eur_mirror_special_child_regions_to_sp60(current50, current60, special_child_specs_applied, language)
        replacement_entries[2945] = mirrored60
        ctx = entry_context[2945]
        report = {
            'afs_index': 2945,
            'afs_name': expected_name60,
            'entry_absolute_before': int(info60['afs_absolute']) + int(info60['entry_offset']),
            'entry_size_before': int(ctx['info']['entry_size']),
            'entry_size_after': len(mirrored60),
            'sha256_before': hashlib.sha256(ctx['original']).hexdigest(),
            'sha256_after': hashlib.sha256(mirrored60).hexdigest(),
            'images': [{
                'id': row['id'], 'texture': row['texture'], 'label': row['label'],
                'mirrored_to_sp60': True, 'dest_parts': row['dest_parts'],
            } for row in mirrored_rows],
        }
        for idx, row in enumerate(planned):
            if int(row['afs_index']) == 2945:
                planned[idx] = report
                break
        else:
            planned.append(report)

    output_iso.parent.mkdir(parents=True, exist_ok=True)
    tmp_output = output_iso.with_name(output_iso.name + '.k7textimages.tmp')
    if tmp_output.exists():
        tmp_output.unlink()

    afs_build = None
    afs_location = None
    with tempfile.TemporaryDirectory(prefix='killer7_text_images_') as td_raw:
        td = Path(td_raw)
        source_afs = td / 'DIR_E.AFS'
        rebuilt_afs = td / 'DIR_E_TEXT_IMAGES.AFS'
        _eur_copy_iso_node(eur_iso, afs_node, source_afs)
        if source_afs.stat().st_size != afs_node.size:
            raise K7Error('Texto Imágenes EUR: DIR_E.AFS se extrajo con un tamaño inesperado.')
        afs_build = _eur_rebuild_afs(source_afs, rebuilt_afs, replacement_entries)

        # Verificación profunda: cada entrada reconstruida debe coincidir byte a byte.
        vr_entries, _vo, _vs, _vraw, _vnames = _eur_parse_afs(rebuilt_afs)
        with rebuilt_afs.open('rb') as check:
            for idx, expected in replacement_entries.items():
                got = _eur_read_entry(check, vr_entries, idx)
                if got != expected:
                    raise K7Error(f'Texto Imágenes EUR: verificación AFS fallida en entrada #{idx}.')
        rebuilt_sha = _eur_file_sha256(rebuilt_afs)

        try:
            shutil.copyfile(eur_iso, tmp_output)
            if tmp_output.stat().st_size != eur_iso.stat().st_size:
                raise K7Error('Texto Imágenes EUR: la copia temporal cambió de tamaño.')
            rebuilt_size = rebuilt_afs.stat().st_size
            afs_location = {
                'relocated': False, 'lba': int(afs_node.lba), 'size': int(rebuilt_size)
            }
            with tmp_output.open('r+b') as dst:
                if rebuilt_size > afs_node.size:
                    afs_location = _iso_append_and_relocate_file(
                        dst, rebuilt_afs, afs_record_offset
                    )
                else:
                    with rebuilt_afs.open('rb') as src_afs:
                        dst.seek(int(afs_node.lba) * 2048)
                        shutil.copyfileobj(src_afs, dst, length=1024 * 1024)
                    dst.flush()

            inserted_sha = _eur_hash_iso_region(
                tmp_output, int(afs_location['lba']) * 2048, int(afs_location['size'])
            )
            if inserted_sha != rebuilt_sha:
                raise K7Error('Texto Imágenes EUR: el DIR_E.AFS insertado no coincide con el reconstruido.')
            with ISO9660(tmp_output) as verify_iso:
                if not is_compatible_eur_iso(verify_iso):
                    raise K7Error('Texto Imágenes EUR: la ISO de salida ya no identifica SLES_533.66.')
                out_afs = verify_iso.find(['D_EU', 'DIR_E.AFS'])
                if out_afs.lba != int(afs_location['lba']) or out_afs.size != int(afs_location['size']):
                    raise K7Error('Texto Imágenes EUR: registro ISO9660 de DIR_E.AFS incorrecto.')
                if hashlib.sha256(verify_iso.read(out_afs)).hexdigest() != rebuilt_sha:
                    raise K7Error('Texto Imágenes EUR: lectura final de DIR_E.AFS no coincide.')
            tmp_output.replace(output_iso)
        except Exception:
            try:
                if tmp_output.exists():
                    tmp_output.unlink()
            except Exception:
                pass
            raise

    return {
        'output_iso': str(output_iso),
        'language': language,
        'language_name': EUR_TEXT_IMAGE_LANGUAGE_NAMES[language],
        'resources': planned,
        'image_count': sum(len(item['images']) for item in planned),
        'resource_count': len(planned),
        'afs': {**(afs_build or {}), **(afs_location or {})},
    }


# v1.7.7.28 — selector de escenas EUR (sce_F.dat / SceSel_F).
#
# A diferencia de los nombres de capítulo (C-strings trilingües del SLES), las
# fechas, estaciones y los rótulos CIBLE están horneados en una textura PSMT8.
# Se exponen como targets editables en el modo EUR y se recompilan conservando
# dimensiones, swizzle y CLUT originales.
EUR_SCENE_SELECTOR_ROWS = [
    {'key': 'label',      'chapter': '',   'source': 'CIBLE',                         'target': 'OBJETIVO',                     'kind': 'label'},
    {'key': 'chapter_00', 'chapter': '00', 'source': 'Ange',                          'target': 'Ángel',                        'kind': 'chapter'},
    {'key': 'date_00',    'chapter': '00', 'source': '20 janvier 2010 HIVER',         'target': '20 de enero de 2010 INVIERNO', 'kind': 'date'},
    {'key': 'chapter_01', 'chapter': '01', 'source': 'Coucher de Soleil',             'target': 'Atardecer',                    'kind': 'chapter'},
    {'key': 'date_01',    'chapter': '01', 'source': '10 février 2010 HIVER',         'target': '10 de febrero de 2010 INVIERNO','kind': 'date'},
    {'key': 'chapter_02', 'chapter': '02', 'source': 'Homme Nuage',                   'target': 'Hombre Nube',                  'kind': 'chapter'},
    {'key': 'date_02',    'chapter': '02', 'source': '3 avril 2011 PRINTEMPS',        'target': '3 de abril de 2011 PRIMAVERA', 'kind': 'date'},
    {'key': 'chapter_03', 'chapter': '03', 'source': 'Rencontre',                     'target': 'Encuentro',                    'kind': 'chapter'},
    {'key': 'date_03',    'chapter': '03', 'source': '10 août 2011 ÉTÉ',              'target': '10 de agosto de 2011 VERANO',   'kind': 'date'},
    {'key': 'chapter_04', 'chapter': '04', 'source': 'Alter Ego',                     'target': 'Alter Ego',                    'kind': 'chapter'},
    {'key': 'date_04',    'chapter': '04', 'source': '26 Octobre 2011 AUTOMNE',       'target': '26 de octubre de 2011 OTOÑO',   'kind': 'date'},
    {'key': 'chapter_05', 'chapter': '05', 'source': 'Sourire',                       'target': 'Sonrisa',                      'kind': 'chapter'},
    {'key': 'date_05',    'chapter': '05', 'source': '16 décembre 2011 HIVER',        'target': '16 de diciembre de 2011 INVIERNO','kind': 'date'},
    {'key': 'chapter_06', 'chapter': '06', 'source': 'Lion',                          'target': 'León',                         'kind': 'chapter'},
    {'key': 'yes',        'chapter': '',   'source': 'Oui',                           'target': 'Sí',                           'kind': 'ui'},
    {'key': 'no',         'chapter': '',   'source': 'Non',                           'target': 'No',                           'kind': 'ui'},
    {'key': 'return_title','chapter': '',  'source': "Retourner à l'écran Title ?", 'target': '¿Volver a la pantalla de título?', 'kind': 'ui'},
    {'key': 'unsaved_warning','chapter': '', 'source': 'Les données non sauvegardées seront supprimées.', 'target': 'Los datos no guardados se perderán.', 'kind': 'ui'},
    {'key': 'date_06',    'chapter': '06', 'source': '3 ans plus tard...',            'target': '3 años después...',            'kind': 'date'},
]
EUR_SCENE_SELECTOR_DEFAULTS = {row['key']: row['target'] for row in EUR_SCENE_SELECTOR_ROWS}

_EUR_SCENE_SELECTOR_AFS_NAME = 'sce_f.dat'
_EUR_SCENE_SELECTOR_INDEX = 3891
_EUR_SCENE_SELECTOR_BASE_SHA256 = '8fba61b381c0bd569bed6483d30144bf350739da41e3ee73d96e32317a147711'
_EUR_SCENE_SELECTOR_COMPATIBLE_SHA256 = {
    _EUR_SCENE_SELECTOR_BASE_SHA256,
    '8939727f237714806da65839a1516d2fc5a15c6a94b097416822b00e976a74be',  # v1.7.7.41
    '3f80cdde83f94784620e79f454ac3dcf9c46be3adb19ec80bd96ef16987af750',  # v1.7.7.42
}
_EUR_SCENE_SELECTOR_ES_PNG = 'scene_selector_es_base.png'
_EUR_SCENE_SELECTOR_ES_SHA256 = 'b673825df56097aab4e9ae923f750007d0453396057dbfaf93cb6618461fb25b'

_EUR_SCENE_SELECTOR_TEXTURE_OFFSET = 0x444
_EUR_SCENE_SELECTOR_PIXEL_OFFSET = 0x118  # name_len=12 => shift +4; tras GIFtag de 16 bytes
_EUR_SCENE_SELECTOR_CLUT_OFFSET = 0x40168  # misma corrección +4 para la CLUT
_EUR_SCENE_SELECTOR_WIDTH = 512
_EUR_SCENE_SELECTOR_HEIGHT = 512
_EUR_SCENE_SELECTOR_TRANSPARENT_INDEX = 1

# Cajas verificadas sobre SceSel_F ya deswizzleada. Las seis fechas ocupan dos
# columnas x tres filas. La tarjeta de Lion está girada 90° en el atlas.
_EUR_SCENE_SELECTOR_DATE_BOXES = {
    'date_00': (0,   96, 160, 112),
    'date_01': (160, 96, 320, 112),
    'date_02': (0,  112, 160, 128),
    'date_03': (160,112, 320, 128),
    'date_04': (0,  128, 160, 144),
    'date_05': (160,128, 320, 144),
}
_EUR_SCENE_SELECTOR_LABEL_BOX = (320, 96, 406, 112)
_EUR_SCENE_SELECTOR_LION_CROP = (452, 0, 512, 410)
# Coordenadas dentro del recorte anterior después de rotate(270, expand=True).
# El recorte real empieza en x=452 (no 448), por lo que la imagen girada mide
# 410x60. Estas cajas son las antiguas cajas útiles trasladadas -4 en Y.
_EUR_SCENE_SELECTOR_LION_LABEL_BOX = (35, 1, 137, 44)
_EUR_SCENE_SELECTOR_LION_TITLE_BOX = (230, 5, 313, 60)
_EUR_SCENE_SELECTOR_LION_DATE_BOX = (354, 30, 410, 60)
_EUR_SCENE_SELECTOR_YES_BOX = (0, 190, 72, 230)
_EUR_SCENE_SELECTOR_NO_BOX = (154, 190, 257, 230)
_EUR_SCENE_SELECTOR_RETURN_TITLE_BOX = (96, 390, 386, 416)
_EUR_SCENE_SELECTOR_UNSAVED_WARNING_BOX = (0, 416, 382, 446)


_EUR_TUTORIAL_AFS_NAME = 'tutorial_f'
_EUR_TUTORIAL_INDEX = 3976
_EUR_TUTORIAL_ES_FILE = 'tutorial_f_Tutorial_ES.png'
_EUR_TUTORIAL_ES_SHA256 = 'ceb9e617f4a0e076f489d106dfe5d68bab455a4df8b70d7319c421b6851768b3'

_EUR_TUTORIAL_SATU_ES_FILE = 'tutorial_f_Satu_ES.png'
_EUR_TUTORIAL_SATU_ES_SHA256 = '494f873363f1edfc7552208d04c99f1b9a49068ef9d9df3a2f4b41b188768094'

EUR_TUTORIAL_ROWS = [
    {'key': 'learn_controls', 'source': 'Apprendre les commandes ?', 'target': '¿Quieres aprender\nlos controles?', 'kind': 'tutorial'},
    {'key': 'ready_continue', 'source': 'Es-tu prêt à poursuivre ?', 'target': '¿Estás listo para continuar?', 'kind': 'tutorial'},
    {'key': 'run_up', 'source': 'Cours avec la touche × ou la touche directionnelle haut.', 'target': 'Corre con el botón × o\npulsa arriba en la cruceta.', 'kind': 'tutorial'},
    {'key': 'turn_down', 'source': 'Change de direction avec la touche △ ou la touche directionnelle bas.', 'target': 'Cambia de dirección con △ o\npulsa abajo en la cruceta.', 'kind': 'tutorial'},
    {'key': 'reload', 'source': 'Appuie sur la touche R1 pour recharger ton arme.', 'target': 'Pulsa R1 para recargar\ntu arma.', 'kind': 'tutorial'},
    {'key': 'spot_enemies', 'source': 'Appuie sur la touche L1 pour repérer les ennemis.', 'target': 'Pulsa L1 para localizar\na los enemigos.', 'kind': 'tutorial'},
    {'key': 'attack', 'source': 'Appuie sur la touche × pour attaquer.', 'target': 'Pulsa × para atacar.', 'kind': 'tutorial'},
    {'key': 'aim', 'source': 'Appuie sur la touche △ pour cibler.', 'target': 'Pulsa △ para fijar\nel objetivo.', 'kind': 'tutorial'},
    {'key': 'change_target', 'source': 'Utilise la touche directionnelle pour changer de cible.', 'target': 'Usa la cruceta para\ncambiar de objetivo.', 'kind': 'tutorial'},
    {'key': 'choose_destination', 'source': 'Sélectionne une destination avec le joystick analogique gauche ou la touche directionnelle droit/gauche. Valide avec la touche × ou la touche directionnelle haut.', 'target': 'Selecciona un destino con el stick izquierdo\no con izquierda/derecha en la cruceta.\nConfirma con × o pulsando arriba.', 'kind': 'tutorial'},
    {'key': 'review_controls', 'source': 'Revoir les commandes ?', 'target': '¿Quieres repasar\nlos controles?', 'kind': 'tutorial'},
    {'key': 'yes', 'source': 'Oui', 'target': 'Sí', 'kind': 'tutorial'},
    {'key': 'no', 'source': 'Non', 'target': 'No', 'kind': 'tutorial'},
]
EUR_TUTORIAL_DEFAULTS = {row['key']: row['target'] for row in EUR_TUTORIAL_ROWS}
_EUR_TUTORIAL_BOXES = {
    'learn_controls': (0, 0, 300, 72),
    'ready_continue': (570, 0, 970, 72),
    'run_up': (0, 82, 455, 158),
    'turn_down': (0, 168, 455, 268),
    'reload': (0, 294, 440, 372),
    'spot_enemies': (0, 384, 440, 463),
    'attack': (0, 474, 440, 552),
    'aim': (0, 558, 420, 640),
    'change_target': (0, 648, 500, 732),
    'choose_destination': (0, 776, 525, 904),
    'review_controls': (20, 930, 440, 990),
}
_EUR_TUTORIAL_O_BOXES = [
    (0, 0, 256, 256), (256, 0, 512, 256), (512, 0, 768, 256), (768, 0, 1024, 256),
    (0, 256, 256, 512),
]
# Las cajas siguientes están expresadas en la vista *recompuesta* que usa
# Texto Imágenes al extraer/reemplazar `tutorial_yes_no` (roll horizontal 640).
# En esa vista visible, el grupo UI está en la zona central-superior y ON en la
# zona central-inferior. La traducción integrada debe trabajar sobre estas mismas
# coordenadas para que “Sí / No” coincida con el juego.
_EUR_TUTORIAL_UI_BOX = (534, 256, 616, 309)
# Componentes visibles dentro de UI: U = 537..587 / 259..306; I = 590..613 / 259..305.
# Para español se borra UI completo y la Í se centra donde estaba la U.
_EUR_TUTORIAL_UI_U_BOX = (537, 258, 587, 306)
_EUR_TUTORIAL_ON_BOX = (510, 767, 638, 830)
# En ON visible, O ocupa ~514..569 / 770..829 y N ~575..636 / 771..828.
# Conservamos O original y borramos exclusivamente N.
_EUR_TUTORIAL_ON_N_BOX = (573, 768, 639, 831)


_EUR_SCENE_SELECTOR_CHAPTER_EN = {
    'chapter_00': 'Angel', 'chapter_01': 'Sunset', 'chapter_02': 'Cloudman',
    'chapter_03': 'Encounter', 'chapter_04': 'Alter Ego', 'chapter_05': 'Smile',
    'chapter_06': 'Lion',
}


def eur_scene_selector_default_targets() -> dict[str, str]:
    return dict(EUR_SCENE_SELECTOR_DEFAULTS)


def _eur_scene_selector_targets(targets: dict[str, str] | None) -> dict[str, str]:
    out = eur_scene_selector_default_targets()
    for key, value in (targets or {}).items():
        if key in out and value is not None:
            out[key] = str(value).strip()
    return out


def _eur_scene_selector_palette(entry: bytes, layout: dict | None = None) -> list[tuple[int, int, int, int]]:
    # Para el parche gráfico conservamos el alfa GS crudo 0..0x80. La versión
    # RGBA de previsualización lo escala aparte a 0..255.
    layout = layout or _eur_text_image_scene_selector_layout(entry)
    base = int(layout['clut_offset'])
    end = base + 256 * 4
    if end > len(entry):
        raise K7Error('Selector EUR: CLUT SceSel_F truncada.')
    return [tuple(entry[base+i*4:base+i*4+4]) for i in range(256)]


def _eur_scene_selector_mask_to_indices(mask: Image.Image, palette, transparent_index: int) -> bytearray:
    """Convierte máscara antialias a índices de la CLUT original.

    La CLUT PSMT8 almacena alpha PS2 (0..0x80). Elegimos, para cada nivel de
    cobertura, el gris de la paleta cuyo brillo premultiplicado más se aproxima.
    El nivel cero conserva el índice transparente real del juego.
    """
    candidates = []
    for idx, (r, g, b, a) in enumerate(palette):
        if idx == transparent_index or a <= 0:
            continue
        if max(r, g, b) - min(r, g, b) > 4:
            continue
        if max(r, g, b) < 40:
            continue
        brightness = (int(r) + int(g) + int(b)) / 3.0 * min(128, int(a)) / 128.0
        candidates.append((idx, brightness))
    if not candidates:
        raise K7Error('Selector EUR: la CLUT no contiene una rampa gris utilizable.')
    lut = [transparent_index] * 256
    for level in range(1, 256):
        lut[level] = min(candidates, key=lambda row: abs(row[1] - level))[0]
    return bytearray(lut[v] for v in mask.convert('L').getdata())


def _eur_scene_selector_draw(index_image: Image.Image, palette, box, text: str,
                              *, role: str = 'small', align: str = 'left',
                              font_path: str | None = None) -> Image.Image:
    out = index_image.copy().convert('L')
    x0, y0, x1, y1 = (int(v) for v in box)
    if x1 <= x0 or y1 <= y0:
        raise K7Error('Selector EUR: caja gráfica inválida.')
    out.paste(_EUR_SCENE_SELECTOR_TRANSPARENT_INDEX, (x0, y0, x1, y1))
    bw, bh = x1-x0, y1-y0
    mask = Image.new('L', (bw, bh), 0)
    draw = ImageDraw.Draw(mask)
    clean = ' '.join(str(text or '').split())
    if not clean:
        return out
    # El original usa una serif estrecha. Las fechas necesitan mantener una altura
    # de ~12 px; si el español es más largo se reduce horizontalmente sólo lo justo.
    if role == 'lion_title':
        max_size, min_size = 49, 12
    elif role == 'label':
        max_size, min_size = 18, 8
    elif role == 'lion_date':
        max_size, min_size = 15, 6
    elif role == 'yesno':
        max_size, min_size = 30, 10
    elif role == 'prompt':
        max_size, min_size = 14, 6
    elif role == 'warning':
        max_size, min_size = 13, 6
    else:
        max_size, min_size = 15, 6
    chosen = None
    for size in range(max_size, min_size-1, -1):
        font = _graphic_font(size, font_path)
        bb = draw.textbbox((0, 0), clean, font=font)
        tw, th = bb[2]-bb[0], bb[3]-bb[1]
        if tw <= max(1, bw-2) and th <= max(1, bh-2):
            chosen = (font, bb, tw, th)
            break
    if chosen is None:
        font = _graphic_font(min_size, font_path)
        bb = draw.textbbox((0, 0), clean, font=font)
        tw, th = bb[2]-bb[0], bb[3]-bb[1]
        chosen = (font, bb, tw, th)
    font, bb, tw, th = chosen
    if align == 'center':
        tx = max(0, (bw - tw)//2)
    elif align == 'right':
        tx = max(0, bw - tw - 1)
    else:
        tx = 1
    ty = max(0, (bh - th)//2) - bb[1]
    draw.text((tx, ty), clean, font=font, fill=255)
    idx = _eur_scene_selector_mask_to_indices(mask, palette, _EUR_SCENE_SELECTOR_TRANSPARENT_INDEX)
    patch = Image.new('L', (bw, bh)); patch.putdata(idx)
    out.paste(patch, (x0, y0))
    return out



def eur_tutorial_default_targets() -> dict[str, str]:
    return dict(EUR_TUTORIAL_DEFAULTS)


def _eur_tutorial_targets(targets: dict[str, str] | None) -> dict[str, str]:
    out = eur_tutorial_default_targets()
    for key, value in (targets or {}).items():
        if key in out and value is not None:
            out[key] = str(value).strip()
    return out


def _eur_tutorial_draw(image: Image.Image, box, text: str, *, role: str = 'body', align: str = 'center') -> Image.Image:
    out = image.copy().convert('L')
    x0, y0, x1, y1 = (int(v) for v in box)
    if x1 <= x0 or y1 <= y0:
        raise K7Error('Tutorial EUR: caja gráfica inválida.')
    out.paste(0, (x0, y0, x1, y1))
    clean = str(text or '').replace('\r', '').strip()
    if not clean:
        return out
    bw, bh = x1-x0, y1-y0
    mask = Image.new('L', (bw, bh), 0)
    draw = ImageDraw.Draw(mask)
    if role == 'prompt':
        max_size, min_size, spacing = 32, 14, 0
    elif role == 'body':
        max_size, min_size, spacing = 28, 11, 0
    elif role == 'compact':
        max_size, min_size, spacing = 22, 9, -1
    elif role == 'small':
        max_size, min_size, spacing = 54, 14, 0
    elif role == 'big':
        max_size, min_size, spacing = 180, 72, -10
    else:
        max_size, min_size, spacing = 24, 10, 0
    chosen = None
    for size in range(max_size, min_size-1, -1):
        font = _graphic_font(size)
        bb = draw.multiline_textbbox((0, 0), clean, font=font, spacing=spacing, align=align)
        tw, th = bb[2]-bb[0], bb[3]-bb[1]
        if tw <= max(1, bw-4) and th <= max(1, bh-4):
            chosen = (font, bb, tw, th)
            break
    if chosen is None:
        font = _graphic_font(min_size)
        bb = draw.multiline_textbbox((0, 0), clean, font=font, spacing=spacing, align=align)
        tw, th = bb[2]-bb[0], bb[3]-bb[1]
        chosen = (font, bb, tw, th)
    font, bb, tw, th = chosen
    if align == 'left':
        tx = 1
    elif align == 'right':
        tx = max(0, bw - tw - 1)
    else:
        tx = max(0, (bw - tw)//2)
    ty = max(0, (bh - th)//2) - bb[1]
    draw.multiline_text((tx, ty), clean, font=font, fill=255, spacing=spacing, align=align)
    out.paste(mask, (x0, y0))
    return out


def _eur_tutorial_build_entry(original: bytes, targets: dict[str, str] | None = None) -> tuple[bytes, dict]:
    t = _eur_tutorial_targets(targets)
    out = bytearray(original)

    # Textura 8bpp principal: los once bloques de texto del tutorial.
    # La revisión española por defecto se distribuye como PNG ya maquetado y
    # desgastado para conservar el estilo artístico original sin depender de
    # fuentes instaladas en el equipo del usuario. Si en el futuro se pasan
    # targets personalizados, se mantiene la ruta dinámica anterior.
    tuto_off, tuto_sub = _eur_text_image_named_subresource(original, 'Tutorial')
    if targets is None:
        asset = resource_path('resources', 'eur_base') / _EUR_TUTORIAL_ES_FILE
        if not asset.is_file():
            raise K7Error(f'Falta el tutorial español integrado: {asset}.')
        asset_sha = hashlib.sha256(asset.read_bytes()).hexdigest()
        if asset_sha != _EUR_TUTORIAL_ES_SHA256:
            raise K7Error('Tutorial EUR: el PNG español integrado no supera su SHA-256.')
        with Image.open(asset) as src:
            src.load()
            if src.size != (1024, 1024):
                raise K7Error('Tutorial EUR: el PNG español debe medir exactamente 1024x1024.')
            tuto_image = src.convert('L')
    else:
        tuto_image = _eur_preview_tutorial_t8(tuto_sub)
        roles = {
            'learn_controls': ('prompt', 'center'),
            'ready_continue': ('prompt', 'center'),
            'run_up': ('body', 'left'),
            'turn_down': ('body', 'left'),
            'reload': ('body', 'left'),
            'spot_enemies': ('body', 'left'),
            'attack': ('body', 'left'),
            'aim': ('body', 'left'),
            'change_target': ('body', 'left'),
            'choose_destination': ('compact', 'center'),
            'review_controls': ('prompt', 'center'),
        }
        for key, box in _EUR_TUTORIAL_BOXES.items():
            role, align = roles[key]
            tuto_image = _eur_tutorial_draw(tuto_image, box, t.get(key, ''), role=role, align=align)
    new_tuto = _eur_encode_tutorial_t8_image(tuto_sub, tuto_image, (1024, 1024))
    out[tuto_off:tuto_off+len(new_tuto)] = new_tuto

    # Satu contiene las variantes animadas de las letras grandes y los sufijos
    # que el juego compone para OUI/NON. Para la revisión española integrada
    # usamos un PNG ya maquetado (Sí/No) y lo insertamos con exactamente la
    # misma lógica que Texto Imágenes usa al extraer/reemplazar el PNG: primero
    # se trabaja sobre la vista recompuesta con wrap horizontal y después se
    # convierte de vuelta al layout lineal de almacenamiento.
    satu_off, satu_sub = _eur_text_image_named_subresource(bytes(out), 'Satu')
    satu_roll_x = int(_eur_text_image_spec('tutorial_yes_no', 'fr').get('display_roll_x') or 0)
    if targets is None:
        asset = resource_path('resources', 'eur_base') / _EUR_TUTORIAL_SATU_ES_FILE
        if not asset.is_file():
            raise K7Error(f'Falta el atlas Satu español integrado: {asset}.')
        asset_sha = hashlib.sha256(asset.read_bytes()).hexdigest()
        if asset_sha != _EUR_TUTORIAL_SATU_ES_SHA256:
            raise K7Error('Tutorial EUR: el PNG integrado de Sí/No no supera su SHA-256.')
        with Image.open(asset) as src:
            src.load()
            if src.size != (1024, 1024):
                raise K7Error('Tutorial EUR: el PNG integrado de Sí/No debe medir exactamente 1024x1024.')
            satu_image = src.convert('L')
        # El PNG integrado está en coordenadas de visualización (igual que el extraído).
        if satu_roll_x:
            satu_image = _eur_satu_storage_image(satu_image, satu_roll_x)
    else:
        satu_image = _eur_preview_linear_indexed_texture(satu_sub)
        # Muy importante: la traducción integrada debe usar exactamente la misma
        # geometría visible que la extracción/reimportación del PNG. Si Satu se
        # compone en almacenamiento bruto, algunos glifos que cruzan el borde
        # horizontal (como Sí/No) acaban mostrándose corruptos en juego aunque la
        # previsualización parezca razonable. Por eso traducimos sobre la vista ya
        # recompuesta con wrap y sólo al final la devolvemos al layout de storage.
        if satu_roll_x:
            satu_image = _eur_satu_display_image(satu_image, satu_roll_x)
        for box in _EUR_TUTORIAL_O_BOXES:
            satu_image = _eur_tutorial_draw(satu_image, box, 'S', role='big', align='center')
        # UI → í: se limpia el grupo completo pero la nueva í se coloca exactamente
        # en la zona que ocupaba la U original, no centrada sobre las dos letras.
        satu_image = satu_image.copy().convert('L')
        satu_image.paste(0, _EUR_TUTORIAL_UI_BOX)
        satu_image = _eur_tutorial_draw(satu_image, _EUR_TUTORIAL_UI_U_BOX,
                                        'í', role='small', align='center')
        # ON → O: la O original ya tiene el estilo correcto; sólo eliminamos la N.
        satu_image.paste(0, _EUR_TUTORIAL_ON_N_BOX)
        if satu_roll_x:
            satu_image = _eur_satu_storage_image(satu_image, satu_roll_x)
    new_satu = _eur_encode_linear_indexed_image(satu_sub, satu_image, (1024, 1024))
    # Verificación fuerte del mismo flujo que usa Texto Imágenes: decodificar lo
    # que acabamos de codificar y comprobar que la vista visible (roll incluido)
    # coincide píxel a píxel con el PNG integrado cuantizado a 4 bpp. Así evitamos
    # que una imagen que “se ve bien” en el editor quede montada de otra forma en juego.
    verify_storage = _eur_preview_linear_indexed_texture(new_satu)
    verify_display = (_eur_satu_display_image(verify_storage, satu_roll_x)
                      if satu_roll_x else verify_storage)
    expected_display = (Image.open(asset).convert('L') if targets is None else
                        (_eur_satu_display_image(satu_image, satu_roll_x)
                         if satu_roll_x else satu_image))
    # Los últimos 128 texels lógicos no existen físicamente: no participan.
    vd = list(verify_display.getdata())
    ed = list(expected_display.getdata())
    physical_texels = int(_eur_linear_indexed_texture_layout(new_satu)['stored_pixel_size']) * 2
    # Convertir expected a los mismos 16 niveles 4bpp que el encoder.
    ed = [max(0, min(15, int(round(v / 17.0)))) * 17 for v in ed]
    # La comparación física se hace en storage para no mezclar el wrap con la zona virtual.
    expected_storage = (_eur_satu_storage_image(expected_display, satu_roll_x)
                        if satu_roll_x else expected_display)
    es = [max(0, min(15, int(round(v / 17.0)))) * 17
          for v in expected_storage.convert('L').getdata()]
    vs = list(verify_storage.getdata())
    if vs[:physical_texels] != es[:physical_texels]:
        raise K7Error('Tutorial EUR: el round-trip físico de Satu no coincide con el PNG integrado.')
    out[satu_off:satu_off+len(new_satu)] = new_satu

    return bytes(out), {
        'name': 'tutorial_f',
        'afs_index': _EUR_TUTORIAL_INDEX,
        'targets': t,
        'textures': [
            {'texture': 'Tutorial', 'offset': int(tuto_off), 'size': [1024, 1024],
             'texts': [key for key in _EUR_TUTORIAL_BOXES]},
            {'texture': 'Satu', 'offset': int(satu_off), 'size': [1024, 1024], 'texts': ['yes', 'no']},
        ],
        'sha256_before': hashlib.sha256(original).hexdigest(),
        'sha256_after': hashlib.sha256(bytes(out)).hexdigest(),
        'note': 'Tutorial EUR completo traducido al español con atlas 1024x1024 integrado y estilo serif desgastado; Satu integrado desde PNG español (Sí/No), comparado y alineado con la vista original del juego, aplicando la misma lógica de wrap horizontal que usa la extracción/reemplazo PNG.',
    }


def _eur_patch_tutorial_graphics(afs, raw_entries, name_to_indices, replacements,
                                 targets: dict[str, str] | None = None) -> dict:
    hits = name_to_indices.get(_EUR_TUTORIAL_AFS_NAME, [])
    if len(hits) != 1:
        raise K7Error(f'Tutorial EUR: se esperaba un único tutorial_f: {hits}.')
    idx = hits[0]
    if idx != _EUR_TUTORIAL_INDEX:
        raise K7Error(f'Tutorial EUR: tutorial_f está en AFS #{idx}, se esperaba #{_EUR_TUTORIAL_INDEX}.')
    original = _eur_read_entry(afs, raw_entries, idx)
    patched, meta = _eur_tutorial_build_entry(original, targets)
    if len(patched) != len(original):
        raise K7Error('Tutorial EUR: tutorial_f cambió de tamaño total.')
    replacements[idx] = patched
    return meta


def _eur_scene_selector_build_entry(original: bytes, targets: dict[str, str] | None = None) -> tuple[bytes, dict]:
    """Reescribe SceSel_F con las fechas/etiquetas dadas conservando su layout GS."""
    t = _eur_scene_selector_targets(targets)
    layout = _eur_text_image_scene_selector_layout(original)
    toff = int(layout['texture_offset'])
    width, height, bpp = int(layout['width']), int(layout['height']), int(layout['bpp'])
    # Mantener las constantes como comprobación documental: si el formato cambia,
    # fallar antes de escribir en una región distinta del paquete GS.
    if int(layout['pixel_offset']) - toff != _EUR_SCENE_SELECTOR_PIXEL_OFFSET:
        raise K7Error('Selector EUR: offset IMAGE de SceSel_F no coincide con la revisión verificada.')
    if int(layout['clut_offset']) - toff != _EUR_SCENE_SELECTOR_CLUT_OFFSET:
        raise K7Error('Selector EUR: offset CLUT de SceSel_F no coincide con la revisión verificada.')
    pix_off = int(layout['pixel_offset'])
    pix_size = int(layout['pixel_size'])
    raw = original[pix_off:pix_off+pix_size]
    if len(raw) != pix_size:
        raise K7Error('Selector EUR: payload PSMT8 truncado.')
    linear = _unswizzle8(raw, width, height)
    atlas = Image.new('L', (width, height)); atlas.putdata(linear)
    palette = _eur_scene_selector_palette(original, layout)

    # Etiqueta general y seis fechas de calendario.
    label = (t.get('label') or 'OBJETIVO').rstrip(':') + ':'
    atlas = _eur_scene_selector_draw(atlas, palette, _EUR_SCENE_SELECTOR_LABEL_BOX,
                                     label, role='label', align='center')
    for key, box in _EUR_SCENE_SELECTOR_DATE_BOXES.items():
        atlas = _eur_scene_selector_draw(atlas, palette, box, t.get(key, ''), role='date', align='left')

    # OBJETIVO:06 / León / 3 años después... se redibujan sobre la tarjeta francesa girada del atlas.
    crop = atlas.crop(_EUR_SCENE_SELECTOR_LION_CROP).rotate(270, expand=True)
    crop = _eur_scene_selector_draw(crop, palette, _EUR_SCENE_SELECTOR_LION_LABEL_BOX,
                                    label.rstrip(':') + ':06', role='label', align='center')
    crop = _eur_scene_selector_draw(crop, palette, _EUR_SCENE_SELECTOR_LION_TITLE_BOX,
                                    t.get('chapter_06', 'León'), role='lion_title', align='center')
    crop = _eur_scene_selector_draw(crop, palette, _EUR_SCENE_SELECTOR_LION_DATE_BOX,
                                    t.get('date_06', ''), role='lion_date', align='right')
    crop = crop.rotate(90, expand=True)
    if crop.size != (_EUR_SCENE_SELECTOR_LION_CROP[2]-_EUR_SCENE_SELECTOR_LION_CROP[0],
                     _EUR_SCENE_SELECTOR_LION_CROP[3]-_EUR_SCENE_SELECTOR_LION_CROP[1]):
        raise K7Error('Selector EUR: rotación de tarjeta Lion cambió dimensiones.')
    atlas.paste(crop, (_EUR_SCENE_SELECTOR_LION_CROP[0], _EUR_SCENE_SELECTOR_LION_CROP[1]))

    # Confirmación de volver a la pantalla de título y botones Oui/Non.
    atlas = _eur_scene_selector_draw(atlas, palette, _EUR_SCENE_SELECTOR_YES_BOX,
                                     t.get('yes', 'Sí'), role='yesno', align='left')
    atlas = _eur_scene_selector_draw(atlas, palette, _EUR_SCENE_SELECTOR_NO_BOX,
                                     t.get('no', 'No'), role='yesno', align='left')
    atlas = _eur_scene_selector_draw(atlas, palette, _EUR_SCENE_SELECTOR_RETURN_TITLE_BOX,
                                     t.get('return_title', ''), role='prompt', align='center')
    atlas = _eur_scene_selector_draw(atlas, palette, _EUR_SCENE_SELECTOR_UNSAVED_WARNING_BOX,
                                     t.get('unsaved_warning', ''), role='warning', align='center')

    linear_out = bytearray(atlas.getdata())
    swizzled = _swizzle8(linear_out, width, height)
    check = _unswizzle8(swizzled, width, height)
    if check != linear_out:
        raise K7Error('Selector EUR: PSMT8 no supera round-trip swizzle.')
    patched = bytearray(original)
    patched[pix_off:pix_off+pix_size] = swizzled
    return bytes(patched), {
        'texture': 'SceSel_F',
        'texture_offset': toff,
        'width': width, 'height': height, 'bpp': bpp,
        'targets': t,
        'sha256_before': hashlib.sha256(original).hexdigest(),
        'sha256_after': hashlib.sha256(patched).hexdigest(),
        'note': 'CIBLE + fechas/estaciones + tarjeta Lion recompilados en PSMT8 conservando CLUT.',
    }


# v1.7.7.132 — tarjetas gráficas de capítulo EUR redibujadas sobre la rama FR.
#
# No reutilizamos el DIC compilado USA como imagen final. La edición EUR carga
# `kan*_f.dic`, por lo que abrimos cada textura francesa real, borramos únicamente
# las regiones de texto verificadas y rasterizamos los targets españoles. El inglés
# sigue siendo referencia semántica; no se escribe en ningún recurso inglés.
_EUR_GRAPHIC_DIC_OVERRIDES = {
    'K7_9201_Gráfico___Angel':          {'afs_index': 311,  'afs_name': 'kanCel_f.dic', 'graphic_id': 9201},
    'K7_9202_Gráfico___Encounter':      {'afs_index': 314,  'afs_name': 'kanCur_f.dic', 'graphic_id': 9202},
    'K7_9203_Gráfico___Minor_Image':    {'afs_index': 317,  'afs_name': 'kanDmi_f.dic', 'graphic_id': 9203},
    'K7_9204_Gráfico___final':          {'afs_index': 320,  'afs_name': 'kanEnd_f.dic', 'graphic_id': 9204},
    'K7_9205_Gráfico___Sunset_I':       {'afs_index': 323,  'afs_name': 'kanFuk_f.dic', 'graphic_id': 9205},
    'K7_9206_Gráfico___Smile_I':        {'afs_index': 326,  'afs_name': 'kanHtl_f.dic', 'graphic_id': 9206},
    'K7_9207_Gráfico___Encounter_II':   {'afs_index': 329,  'afs_name': 'kanIsz_f.dic', 'graphic_id': 9207},
    'K7_9208_Gráfico___Sunset':         {'afs_index': 332,  'afs_name': 'kanKak_f.dic', 'graphic_id': 9208},
    'K7_9209_Gráfico___Alter_Ego':      {'afs_index': 335,  'afs_name': 'kanNY_f.dic', 'graphic_id': 9209},
    'K7_9210_Gráfico___Smile':          {'afs_index': 338,  'afs_name': 'kanScl_f.dic', 'graphic_id': 9210},
    'K7_9211_Gráfico___Cloudman':       {'afs_index': 341,  'afs_name': 'kanTxs_f.dic', 'graphic_id': 9211},
    'K7_9212_Gráfico___epílogo':        {'afs_index': 3010, 'afs_name': 'staff2_f.dic','graphic_id': 9212},
}

# Targets finales del proyecto para estas texturas. Los títulos se mantienen
# sincronizados con los nombres de capítulo acordados para la versión EUR.
_EUR_GRAPHIC_DIC_ES_TARGETS = {
    9201: ['Ángel', 'Completado'],
    9202: ['Encuentro', 'Completado'],
    9203: ['Imagen menor', 'Completado'],
    9204: ['Completado'],
    9205: ['Atardecer', 'Parte I', 'Completado'],
    9206: ['Sonrisa', 'Parte I', 'Completado'],
    9207: ['Encuentro', 'Parte II', 'Completado'],
    9208: ['Atardecer', 'Completado'],
    9209: ['Alter Ego', 'Completado'],
    9210: ['Sonrisa', 'Completado'],
    9211: ['Hombre Nube', 'Completado'],
    9212: ['Shanghái, 100 años después'],
}


def _eur_patch_graphic_dic_resources(manifest: dict, patch, afs, raw_entries, names, replacements) -> dict:
    """Redibuja las tarjetas francesas de capítulo con texto español."""
    resources=[]
    seen=set()
    for block in [b for b in manifest.get('blocks', []) if str(b.get('kind')) == 'graphic-dic']:
        file_id=str(block.get('file_id') or '')
        override=_EUR_GRAPHIC_DIC_OVERRIDES.get(file_id)
        if override is None:
            raise K7Error(f'Base EUR: no existe mapeo gráfico EUR para {file_id}.')
        idx=int(override['afs_index']); gid=int(override['graphic_id'])
        if idx in seen:
            raise K7Error(f'Base EUR: recurso gráfico duplicado en AFS #{idx}.')
        seen.add(idx)
        if not (0 <= idx < len(raw_entries)):
            raise K7Error(f'Base EUR: índice gráfico fuera de rango para {file_id}: #{idx}.')
        expected=str(override['afs_name']); actual=str(names[idx])
        if actual.lower()!=expected.lower():
            raise K7Error(f'Base EUR: {file_id} esperaba {expected} en AFS #{idx}, pero encontró {actual}.')
        specs=GRAPHIC_PATCH_SPECS.get(gid)
        targets=_EUR_GRAPHIC_DIC_ES_TARGETS.get(gid)
        if not specs or not targets or len(specs)!=len(targets):
            raise K7Error(f'Base EUR: especificación gráfica incompleta para {file_id} / {gid}.')
        original=_eur_read_entry(afs, raw_entries, idx)
        # Las cajas históricas se midieron sobre la versión inglesa y algunos
        # títulos franceses son más largos/desplazados. Usamos las tres variantes
        # EN/FR/DE vecinas para detectar píxeles localizados dentro de cada zona
        # de texto; se limpian sólo esos píxeles y el clear_box verificado.
        if idx <= 0 or idx + 1 >= len(raw_entries):
            raise K7Error(f'Base EUR: faltan variantes EN/DE vecinas para {actual}.')
        en_name = str(names[idx - 1]).lower()
        de_name = str(names[idx + 1]).lower()
        stem = actual.lower().replace('_f.', '.')
        if en_name != stem or de_name != actual.lower().replace('_f.', '_g.'):
            raise K7Error(
                f'Base EUR: ternas gráfica inesperada para {actual}: '
                f'{names[idx-1]} / {actual} / {names[idx+1]}.'
            )
        english = _eur_read_entry(afs, raw_entries, idx - 1)
        german = _eur_read_entry(afs, raw_entries, idx + 1)
        atlas_en = Killer7Project.decode_dic_texture(english).convert('L')
        atlas_fr = Killer7Project.decode_dic_texture(original).convert('L')
        atlas_de = Killer7Project.decode_dic_texture(german).convert('L')
        if atlas_en.size != atlas_fr.size or atlas_de.size != atlas_fr.size:
            raise K7Error(f'Base EUR: dimensiones EN/FR/DE distintas para {actual}.')

        en_px = atlas_en.load(); fr_px = atlas_fr.load(); de_px = atlas_de.load()
        cleanup = Image.new('L', atlas_fr.size, 0)
        cleanup_px = cleanup.load()
        width, height = atlas_fr.size
        for spec in specs:
            x0, y0, x1, y1 = [int(v) for v in spec.get('clear_box', spec['box'])]
            role = str(spec.get('role', 'small'))
            expand_x = 180 if role == 'title' else (150 if role == 'epilogue' else 130)
            expand_y = 100 if role == 'title' else 80
            sx0, sy0 = max(0, x0 - expand_x), max(0, y0 - expand_y)
            sx1, sy1 = min(width, x1 + expand_x), min(height, y1 + expand_y)
            for yy in range(sy0, sy1):
                for xx in range(sx0, sx1):
                    e, f, g = en_px[xx, yy], fr_px[xx, yy], de_px[xx, yy]
                    if e != f or f != g:
                        cleanup_px[xx, yy] = 255
            # El slot inglés verificado se limpia siempre, incluso si algún trazo
            # coincide píxel a píxel entre idiomas.
            for yy in range(max(0, y0), min(height, y1)):
                for xx in range(max(0, x0), min(width, x1)):
                    cleanup_px[xx, yy] = 255

        # Dilata un píxel para retirar antialias/sombras de los rótulos originales.
        from PIL import ImageFilter
        cleanup = cleanup.filter(ImageFilter.MaxFilter(3))
        atlas = atlas_fr.copy()
        atlas.paste(0, (0, 0), cleanup)
        for spec,target in zip(specs, targets):
            atlas=_draw_graphic_target(atlas, spec, target)
        patched=_encode_atlas_into_dic(original, atlas)
        if len(patched)!=len(original):
            raise K7Error(f'Base EUR: {actual} cambió de tamaño al redibujar.')
        # Round-trip visual: el DIC generado debe decodificarse con las mismas dimensiones.
        verify=Killer7Project.decode_dic_texture(patched)
        if verify.size != atlas.size:
            raise K7Error(f'Base EUR: {actual} no supera verificación DIC 4bpp.')
        replacements[idx]=patched
        resources.append({
            'file_id':file_id,'afs_index':idx,'afs_name':actual,'graphic_id':gid,
            'targets':targets,'sha256_before':hashlib.sha256(original).hexdigest(),
            'sha256_after':hashlib.sha256(patched).hexdigest(),
        })
    return {
        'resources':resources,'count':len(resources),
        'note':'Tarjetas FR redibujadas directamente en español; recursos EN intactos.',
    }



def _eur_scene_selector_uses_default_targets(targets: dict[str, str] | None) -> bool:
    """True si el selector usa los valores integrados por defecto."""
    if not targets:
        return True
    defaults = eur_scene_selector_default_targets()
    for key, value in targets.items():
        if key not in defaults:
            continue
        if value is None:
            continue
        if str(value).strip() != str(defaults[key]).strip():
            return False
    return True


def _eur_patch_scene_selector_from_integrated_png(original: bytes) -> tuple[bytes, dict]:
    """Reconstruye sce_F.dat desde el PNG español verificado.

    Este es el método que sí confirmó cambios en juego: sustituir el payload
    PSMT8+CLUT de `SceSel_F` conservando el contenedor francés. Se usa como ruta
    prioritaria cuando el usuario no ha personalizado manualmente los targets.
    """
    base_dir = resource_path('resources', 'eur_base')
    asset = base_dir / _EUR_SCENE_SELECTOR_ES_PNG
    if not asset.is_file():
        raise K7Error(f'Selector EUR: falta el PNG integrado {asset}.')
    digest = hashlib.sha256(asset.read_bytes()).hexdigest()
    if digest != _EUR_SCENE_SELECTOR_ES_SHA256:
        raise K7Error('Selector EUR: el PNG integrado no supera la verificación SHA-256.')
    patched = _eur_encode_png_into_scene_selector(
        original,
        asset,
        (_EUR_SCENE_SELECTOR_WIDTH, _EUR_SCENE_SELECTOR_HEIGHT),
    )
    return patched, {
        'method': 'integrated_scene_selector_png',
        'png': _EUR_SCENE_SELECTOR_ES_PNG,
        'sha256_asset': digest,
        'texture': 'SceSel_F',
        'replaced': 'PSMT8 + CLUT conservando contenedor francés',
    }

def _eur_patch_scene_selector_graphic(afs, raw_entries, name_to_indices, replacements,
                                      targets: dict[str, str] | None = None) -> dict:
    t = _eur_scene_selector_targets(targets)
    hits = name_to_indices.get(_EUR_SCENE_SELECTOR_AFS_NAME, [])
    if len(hits) != 1:
        raise K7Error(f'Selector EUR: se esperaba un único sce_F.dat: {hits}.')
    idx = hits[0]
    if idx != _EUR_SCENE_SELECTOR_INDEX:
        raise K7Error(f'Selector EUR: sce_F.dat está en AFS #{idx}, se esperaba #{_EUR_SCENE_SELECTOR_INDEX}.')
    original = _eur_read_entry(afs, raw_entries, idx)
    digest = hashlib.sha256(original).hexdigest()
    if digest not in _EUR_SCENE_SELECTOR_COMPATIBLE_SHA256:
        raise K7Error(
            'Selector EUR: sce_F.dat no coincide con una revisión verificada '
            f'(SHA-256 {digest}).'
        )
    # Prioridad: cuando se usan los títulos/fechas por defecto, aplicar el PNG
    # español integrado. Es la ruta verificada en juego (la misma familia de
    # reemplazo que mostró cambios al copiar SceSel_E->SceSel_F), pero manteniendo
    # nuestro arte español traducido. Si el usuario personaliza targets concretos,
    # seguimos permitiendo la reconstrucción vectorial antigua.
    if _eur_scene_selector_uses_default_targets(targets):
        patched, meta = _eur_patch_scene_selector_from_integrated_png(original)
    else:
        patched, meta = _eur_scene_selector_build_entry(original, t)
        meta = {'method': 'dynamic_redraw', **meta}
    patched, glyph_meta = _eur_patch_scene_selector_spanish_glyphs(patched)
    meta = {**meta, 'chapter_glyph_codec': glyph_meta}
    replacements[idx] = patched
    return {
        'afs_index': idx,
        'name': 'sce_F.dat',
        **meta,
    }

# v1.7.7.163 — espejos DAR de pares JMB/DIC EUR.
#
# Muchas familias de texto PAL guardan tres entradas consecutivas con el mismo
# nombre: JMB standalone -> DAR espejo -> DIC standalone. El DAR contiene copias
# byte por byte del JMB y del DIC. El juego puede cargar el DAR en vez de los
# standalone; por eso sustituir sólo JMB/DIC deja textos franceses visibles.
def _eur_rebuild_jmb_dic_mirror_dar(original: bytes, jmb: bytes, dic: bytes) -> bytes:
    """Reconstruye un DAR espejo de 2 hijos (JMB + DIC), alineado a 0x80."""
    ranges = _eur_dar_child_ranges(original)
    if len(ranges) != 2:
        raise K7Error('JMB EUR: el DAR espejo no tiene exactamente 2 hijos.')
    (joff, jsize), (doff, dsize) = ranges
    old_jmb = original[joff:joff + jsize]
    old_dic = original[doff:doff + dsize]
    if not _eur_is_jmb_blob(old_jmb) or not _eur_is_dic_blob(old_dic):
        raise K7Error('JMB EUR: el DAR espejo no contiene JMB + DIC reconocibles.')
    align = 0x80
    off0 = 0x80
    off1 = (off0 + len(jmb) + align - 1) & ~(align - 1)
    total = (off1 + len(dic) + align - 1) & ~(align - 1)
    out = bytearray(total)
    out[:0x80] = original[:0x80]
    struct.pack_into('<2I', out, 0x10, off0, off1)
    struct.pack_into('<2I', out, 0x30, len(jmb), len(dic))
    out[off0:off0 + len(jmb)] = jmb
    out[off1:off1 + len(dic)] = dic
    vr = _eur_dar_child_ranges(bytes(out))
    if len(vr) != 2:
        raise K7Error('JMB EUR: el DAR espejo reconstruido no vuelve a parsear.')
    if out[vr[0][0]:vr[0][0] + vr[0][1]] != jmb:
        raise K7Error('JMB EUR: el JMB del DAR espejo no coincide tras el round-trip.')
    if out[vr[1][0]:vr[1][0] + vr[1][1]] != dic:
        raise K7Error('JMB EUR: el DIC del DAR espejo no coincide tras el round-trip.')
    return bytes(out)


def _eur_verify_jmb_dar_mirror_helper() -> dict:
    """Guarda sintética de empaquetado para el reconstructor JMB/DIC en DAR."""
    # JMB mínimo estructuralmente válido: 1 escena, 1 glifo y offsets coherentes.
    scene_n = 1
    scene_off = 20
    char_off = scene_off + JMB_SCENE_SIZE
    total_off = char_off + 8
    jmb = bytearray(total_off)
    struct.pack_into('<hhIII', jmb, 0, scene_n, 1, scene_off, char_off, total_off)
    # DIC sintético sólo para esta guarda: usamos un payload que satisfaga el
    # reconocedor de cabecera sin depender de assets externos.
    dic = bytearray(0x200)
    dic[:4] = b'\x16\x00\x00\x00'
    struct.pack_into('<I', dic, 0x40, 8)
    struct.pack_into('<III', dic, 0x78, 16, 16, 4)
    old_jmb = bytes(jmb)
    old_dic = bytes(dic)
    off0 = 0x80
    off1 = (off0 + len(old_jmb) + 0x7f) & ~0x7f
    original = bytearray((off1 + len(old_dic) + 0x7f) & ~0x7f)
    original[:4] = b'DAR\0'
    struct.pack_into('<I', original, 8, 2)
    struct.pack_into('<2I', original, 0x10, off0, off1)
    struct.pack_into('<2I', original, 0x30, len(old_jmb), len(old_dic))
    original[off0:off0 + len(old_jmb)] = old_jmb
    original[off1:off1 + len(old_dic)] = old_dic
    new_jmb = old_jmb + b'X' * 64
    new_dic = old_dic + b'Y' * 32
    rebuilt = _eur_rebuild_jmb_dic_mirror_dar(bytes(original), new_jmb, new_dic)
    rr = _eur_dar_child_ranges(rebuilt)
    assert rebuilt[rr[0][0]:rr[0][0] + rr[0][1]] == new_jmb
    assert rebuilt[rr[1][0]:rr[1][0] + rr[1][1]] == new_dic
    return {'children': 2, 'alignment': 0x80, 'jmb_growth': 64, 'dic_growth': 32}

# v1.7.7.170 — compatibilidad runtime para 77102 / extent AFS original.
#
# El juego puede conservar una ruta física al DIR_E.AFS aunque el inyector tenga
# que reubicar el archivo completo.  Además, trasplantar el JMB USA entero no es
# necesario para 77102: la pareja francesa tiene exactamente 17 glifos y los dos
# targets españoles necesitan sólo 16.  Reutilizamos su estructura francesa y
# recompilamos char_data/fParams/DIC sin cambiar NI UN BYTE de tamaño.
_EUR_77102_FR_TEXTS = ["Balle d'âmes reçue", 'Coffre ouvert']
# El JMB español integrado se usa únicamente como banco donante de glifos.
_EUR_77102_ES_TEXTS = ['Has obtenido una Soul Shell', 'Maletero abierto']
# v1.7.7.176: target conservador real. Sólo cambia la primera unidad; la segunda
# permanece byte por byte como en el original francés.
_EUR_77102_SOUL_TARGET = 'Soul Shell hallada'
_EUR_77102_FINAL_TEXTS = [_EUR_77102_SOUL_TARGET, 'Coffre ouvert']
# Sólo dos slots franceses exclusivos de la primera unidad se reutilizan.
_EUR_77102_SLOT_DONORS = {'S': 0, 'h': 7}
_EUR_77102_EN_TEXTS = ['Received Soul Shell', 'Trunk opened']


def _eur_jmb_active_units(raw: bytes):
    if len(raw) < 24:
        raise K7Error('JMB EUR: recurso truncado.')
    sn, cn, so, co, to = struct.unpack_from('<hhIII', raw, 0)
    out = []
    for sentence in range(int(sn)):
        sb = int(so) + sentence * JMB_SCENE_SIZE
        for jimaku in range(JMB_UNITS_PER_SCENE):
            char_off = sb + 76 + jimaku * JMB_RECORD_SIZE + 8
            if char_off + JMB_CODE_SLOTS * 2 > len(raw):
                continue
            codes = list(struct.unpack_from(f'<{JMB_CODE_SLOTS}h', raw, char_off))
            if not codes or codes[0] == -1:
                continue
            if -2 in codes:
                codes = codes[:codes.index(-2)]
            if codes:
                out.append((sentence, jimaku, codes, char_off))
    return int(sn), int(cn), int(so), int(co), int(to), out


def _eur_jmb_char_map(raw: bytes, texts: list[str]) -> dict[str, int]:
    *_meta, units = _eur_jmb_active_units(raw)
    if len(units) != len(texts):
        raise K7Error(
            f'JMB EUR: se esperaban {len(texts)} unidades activas y se encontraron {len(units)}.'
        )
    mapping: dict[str, int] = {}
    for (_sentence, _jimaku, codes, _off), text in zip(units, texts):
        pos = 0
        for code in codes:
            if pos >= len(text):
                raise K7Error('JMB EUR: el source no alinea con char_data.')
            ch = text[pos]
            pos += 1
            if code in (-4, -3):
                if ch not in (' ', '\u3000'):
                    raise K7Error('JMB EUR: espacio/source desalineado.')
                continue
            if (code & 0xffff) >= 0xff00:
                raise K7Error('JMB EUR 77102: control inesperado en la unidad localizada.')
            old = mapping.get(ch)
            if old is None:
                mapping[ch] = int(code)
            elif old != int(code):
                raise K7Error(f'JMB EUR 77102: glifo ambiguo para {ch!r}.')
        if pos != len(text):
            raise K7Error('JMB EUR: longitud source/char_data desalineada.')
    return mapping


def _eur_patch_77102_inplace_runtime(afs, raw_entries, names, replacements) -> dict:
    """Parche ultraconservador de Soul Shell sobre la terna francesa 77102.

    Sólo se modifica la primera unidad (`Balle d'âmes reçue`) y sólo se añaden
    dos glifos oficiales tomados de la versión EUR inglesa del MISMO recurso:
    `S` y `h`. La segunda unidad `Coffre ouvert` se conserva byte por byte.

    No se amplía ninguna tabla, no cambia el número de glifos y JMB/DAR/DIC
    mantienen exactamente sus tamaños retail franceses.
    """
    if len(raw_entries) <= 1744 or names[1742:1745] != ['77102', '77102', '77102']:
        raise K7Error('JMB EUR 77102: la terna FR #1742/#1743/#1744 no coincide con la base verificada.')
    if names[1739:1742] != ['77102', '77102', '77102']:
        raise K7Error('JMB EUR 77102: la terna EN #1739/#1740/#1741 no coincide con la base verificada.')

    original_jmb = _eur_read_entry(afs, raw_entries, 1742)
    original_dar = _eur_read_entry(afs, raw_entries, 1743)
    original_dic = _eur_read_entry(afs, raw_entries, 1744)
    english_jmb = _eur_read_entry(afs, raw_entries, 1739)
    english_dic = _eur_read_entry(afs, raw_entries, 1741)

    _fsn, fcn, _fso, fco, _fto, french_units = _eur_jmb_active_units(original_jmb)
    _esn, ecn, _eso, eco, _eto, english_units = _eur_jmb_active_units(english_jmb)
    if len(french_units) != 2 or len(english_units) != 2 or fcn != 17:
        raise K7Error('JMB EUR 77102: estructura inesperada; se cancela el parche conservador.')

    french_map = _eur_jmb_char_map(original_jmb, _EUR_77102_FR_TEXTS)
    english_map = _eur_jmb_char_map(english_jmb, _EUR_77102_EN_TEXTS)
    french_params = [list(struct.unpack_from('<4H', original_jmb, fco + i * 8)) for i in range(fcn)]
    english_params = [struct.unpack_from('<4H', english_jmb, eco + i * 8) for i in range(ecn)]
    original_atlas = Killer7Project.decode_dic_texture(original_dic).convert('L')
    english_atlas = Killer7Project.decode_dic_texture(english_dic).convert('L')
    patched_atlas = original_atlas.copy()
    bg = _mode_level(original_atlas)

    # `Coffre ouvert` usa C/o/f/r/e/u/v/t. Los slots 0(B) y 7(m) no aparecen
    # en esa unidad, por lo que pueden reutilizarse sin alterar ni un glifo suyo.
    second_codes = set(french_units[1][2])
    second_codes.discard(-4)
    donor_report = []
    for ch, dst_idx in _EUR_77102_SLOT_DONORS.items():
        if dst_idx in second_codes:
            raise K7Error(f'JMB EUR 77102: el slot #{dst_idx} para {ch!r} lo usa Coffre ouvert.')
        src_idx = english_map.get(ch)
        if src_idx is None or not (0 <= src_idx < len(english_params)):
            raise K7Error(f'JMB EUR 77102: el recurso EUR inglés no contiene {ch!r}.')
        sx, sy, sw, sh = map(int, english_params[src_idx])
        glyph = english_atlas.crop((sx, sy, sx + sw, sy + sh)).copy()

        dx, dy, old_w, old_h = map(int, french_params[dst_idx])
        if dst_idx + 1 < len(french_params):
            next_x = int(french_params[dst_idx + 1][0])
            max_w = next_x - dx - 1
        else:
            max_w = original_atlas.width - dx
        if sw > max_w or sh > old_h:
            raise K7Error(
                f'JMB EUR 77102: glifo oficial {ch!r} ({sw}x{sh}) no cabe en slot #{dst_idx} '
                f'({max_w}x{old_h}).'
            )
        clear_w = max(old_w, sw)
        patched_atlas.paste(bg, (dx, dy, dx + clear_w, dy + old_h))
        patched_atlas.paste(_adapt_glyph_background(glyph, bg), (dx, dy))
        french_params[dst_idx][2] = sw
        donor_report.append({'char': ch, 'from_en_slot': int(src_idx), 'to_fr_slot': int(dst_idx), 'width': int(sw)})

    final_map = dict(french_map)
    final_map.update({ch: idx for ch, idx in _EUR_77102_SLOT_DONORS.items()})
    target = _EUR_77102_SOUL_TARGET
    try:
        codes = [-4 if ch == ' ' else final_map[ch] for ch in target]
    except KeyError as exc:
        raise K7Error(f'JMB EUR 77102: target conservador requiere glifo no disponible: {exc.args[0]!r}.') from exc
    if len(codes) > JMB_MAX_CODES:
        raise K7Error('JMB EUR 77102: target conservador excede 31 códigos.')

    patched_jmb = bytearray(original_jmb)
    first_char_off = french_units[0][3]
    arr = codes + [-2] + [-1] * (JMB_CODE_SLOTS - len(codes) - 1)
    struct.pack_into(f'<{JMB_CODE_SLOTS}h', patched_jmb, first_char_off, *arr)
    for idx in _EUR_77102_SLOT_DONORS.values():
        struct.pack_into('<4H', patched_jmb, fco + idx * 8, *[int(v) for v in french_params[idx]])
    patched_jmb = bytes(patched_jmb)
    patched_dic = _encode_atlas_into_dic(original_dic, patched_atlas)

    if len(patched_jmb) != len(original_jmb) or len(patched_dic) != len(original_dic):
        raise K7Error('JMB EUR 77102: el parche conservador cambió de tamaño.')

    _psn, _pcn, _pso, _pco, _pto, patched_units = _eur_jmb_active_units(patched_jmb)
    if patched_units[1][2] != french_units[1][2]:
        raise K7Error('JMB EUR 77102: Coffre ouvert cambió durante el parche conservador.')

    # Los parámetros y píxeles de todos los glifos usados por la segunda unidad
    # deben permanecer exactamente iguales.
    for idx in sorted(second_codes):
        before_param = struct.unpack_from('<4H', original_jmb, fco + idx * 8)
        after_param = struct.unpack_from('<4H', patched_jmb, fco + idx * 8)
        if before_param != after_param:
            raise K7Error(f'JMB EUR 77102: parámetro compartido #{idx} fue alterado.')
        x, y, w, h = map(int, before_param)
        if original_atlas.crop((x, y, x+w, y+h)).tobytes() != patched_atlas.crop((x, y, x+w, y+h)).tobytes():
            raise K7Error(f'JMB EUR 77102: glifo compartido #{idx} fue alterado.')

    patched_dar = _eur_rebuild_jmb_dic_mirror_dar(original_dar, patched_jmb, patched_dic)
    if len(patched_dar) != len(original_dar):
        raise K7Error('JMB EUR 77102: el DAR conservador cambió de tamaño.')

    replacements[1742] = patched_jmb
    replacements[1743] = patched_dar
    replacements[1744] = patched_dic
    return {
        'jmb_index': 1742, 'dar_index': 1743, 'dic_index': 1744,
        'source': _EUR_77102_FR_TEXTS[0],
        'target': target,
        'untouched_second_unit': _EUR_77102_FR_TEXTS[1],
        'official_english_donors': donor_report,
        'sizes': [len(patched_jmb), len(patched_dar), len(patched_dic)],
        'structure': 'French retail structure; first char_data + 2 unused glyph slots only',
    }


# v1.7.7.202 — Fire Ring / 77304 sobre estructura francesa retail.
#
# Soul Shell (77102) demostró en juego que los JMB de este tipo son fiables cuando
# se conserva el JMB/DIC francés retail y se retoca únicamente char_data/fParams/
# atlas in-place.  77304 pasa a seguir la misma ruta: NO se trasplanta el JMB USA.
#
# FR retail #1793/#1794/#1795:
#   Anneau de feu récupéré
# ES objetivo:
#   Anillo de llama obtenido
#
# Todos los caracteres españoles ya existen en 77304 salvo `m`. El slot francés 6
# es `f`, usado sólo por la primera escena y no necesario por el target. Se conserva
# su bitmap retail en su posición original, pero su fParam se redirige a una zona
# vacía (0,72) del mismo atlas donde se copia un `m` oficial de la misma fuente FR,
# tomado de 55101 #1524/#1526 (slot 20). No cambia el número de glifos ni ningún
# tamaño de JMB/DAR/DIC.
_EUR_77304_FIRE_RING_SOURCE = 'Anneau de feu récupéré'
_EUR_77304_FIRE_RING_TARGET = 'Anillo de llama obtenido'
_EUR_77304_SOURCE_CODES = [0, 1, 1, 2, 3, 4, -4, 5, 2, -4, 6, 2, 4, -4, 7, 8, 9, 4, 10, 8, 7, 8]
_EUR_77304_TARGET_CODES = [0, 1, 35, 36, 36, 15, -4, 5, 2, -4, 36, 36, 3, 6, 3, -4, 15, 16, 13, 2, 1, 35, 5, 15]
_EUR_77304_M_SLOT = 6                 # f retail -> m para la escena 0
_EUR_77304_M_DST = (0, 72, 25, 36)   # región retail vacía del atlas 512x128
_EUR_77304_M_DONOR_JMB = 1524        # 55101 FR
_EUR_77304_M_DONOR_DIC = 1526
_EUR_77304_M_DONOR_SLOT = 20
_EUR_77304_M_DONOR_SHA256 = '3c4c4f33eb3c8fcacc11b3d7b76161a8cd6e20441c8e264b725833e96a0e3dfc'


def _eur_patch_77304_inplace_runtime(afs, raw_entries, names, replacements) -> dict:
    """Parche conservador de `Anneau de feu récupéré` sobre 77304 francés retail.

    Replica el patrón ya probado en juego por 77102/Soul Shell: conserva estructura,
    tamaños y objeto DIC francés; sólo cambia char_data de la escena 0, un fParam y
    una región previamente vacía del atlas. El DAR se recompone con esos mismos
    JMB/DIC same-size.
    """
    import hashlib

    if len(raw_entries) <= 1795 or names[1793:1796] != ['77304', '77304', '77304']:
        raise K7Error('JMB EUR 77304: la terna FR #1793/#1794/#1795 no coincide con la base verificada.')
    if len(raw_entries) <= _EUR_77304_M_DONOR_DIC or names[1524] != '55101' or names[1526] != '55101':
        raise K7Error('JMB EUR 77304: el donante FR 55101 #1524/#1526 no coincide con la base verificada.')

    original_jmb = _eur_read_entry(afs, raw_entries, 1793)
    original_dar = _eur_read_entry(afs, raw_entries, 1794)
    original_dic = _eur_read_entry(afs, raw_entries, 1795)
    donor_jmb = _eur_read_entry(afs, raw_entries, _EUR_77304_M_DONOR_JMB)
    donor_dic = _eur_read_entry(afs, raw_entries, _EUR_77304_M_DONOR_DIC)

    fsn, fcn, _fso, fco, _fto, french_units = _eur_jmb_active_units(original_jmb)
    _dsn, dcn, _dso, dco, _dto, _donor_units = _eur_jmb_active_units(donor_jmb)
    if fsn != 4 or fcn != 37 or len(french_units) != 4:
        raise K7Error('JMB EUR 77304: estructura francesa inesperada.')
    if dcn <= _EUR_77304_M_DONOR_SLOT:
        raise K7Error('JMB EUR 77304: el JMB donante 55101 no contiene el slot m esperado.')

    scene0 = next((u for u in french_units if u[0] == 0 and u[1] == 0), None)
    if scene0 is None or scene0[2] != _EUR_77304_SOURCE_CODES:
        raise K7Error('JMB EUR 77304: la escena 0 no coincide con Anneau de feu récupéré retail.')

    # El slot 6 (`f`) debe ser exclusivo de la escena 0; las otras tres escenas se
    # conservan byte por byte y no pueden depender del fParam que vamos a redirigir.
    for sentence, jimaku, codes, _off in french_units:
        if sentence == 0 and jimaku == 0:
            continue
        if _EUR_77304_M_SLOT in codes:
            raise K7Error(
                f'JMB EUR 77304: el slot donante #{_EUR_77304_M_SLOT} también se usa en '
                f'escena {sentence}/{jimaku}; se cancela el parche in-place.'
            )

    original_atlas = Killer7Project.decode_dic_texture(original_dic).convert('L')
    donor_atlas = Killer7Project.decode_dic_texture(donor_dic).convert('L')
    if original_atlas.size != (512, 128):
        raise K7Error(f'JMB EUR 77304: atlas inesperado {original_atlas.size}; se esperaba 512x128.')

    sx, sy, sw, sh = map(int, struct.unpack_from('<4H', donor_jmb, dco + _EUR_77304_M_DONOR_SLOT * 8))
    if (sw, sh) != (25, 36):
        raise K7Error(f'JMB EUR 77304: glifo m donante inesperado {sw}x{sh}.')
    m_glyph = donor_atlas.crop((sx, sy, sx + sw, sy + sh)).copy()
    if hashlib.sha256(m_glyph.tobytes()).hexdigest() != _EUR_77304_M_DONOR_SHA256:
        raise K7Error('JMB EUR 77304: hash del glifo m francés donante no coincide con la base verificada.')

    dx, dy, dw, dh = _EUR_77304_M_DST
    blank_before = original_atlas.crop((dx, dy, dx + dw, dy + dh))
    bg = _mode_level(original_atlas)
    if blank_before.getextrema() != (bg, bg):
        raise K7Error('JMB EUR 77304: la región reservada para m ya no está vacía en el atlas retail.')

    patched_atlas = original_atlas.copy()
    patched_atlas.paste(_adapt_glyph_background(m_glyph, bg), (dx, dy))

    patched_jmb = bytearray(original_jmb)
    target_codes = list(_EUR_77304_TARGET_CODES)
    if len(target_codes) > JMB_MAX_CODES:
        raise K7Error('JMB EUR 77304: Anillo de llama obtenido excede el límite JMB.')
    arr = target_codes + [-2] + [-1] * (JMB_CODE_SLOTS - len(target_codes) - 1)
    struct.pack_into(f'<{JMB_CODE_SLOTS}h', patched_jmb, scene0[3], *arr)
    struct.pack_into('<4H', patched_jmb, fco + _EUR_77304_M_SLOT * 8, dx, dy, dw, dh)
    patched_jmb = bytes(patched_jmb)
    patched_dic = _encode_atlas_into_dic(original_dic, patched_atlas)

    if len(patched_jmb) != len(original_jmb) or len(patched_dic) != len(original_dic):
        raise K7Error('JMB EUR 77304: el parche in-place cambió de tamaño.')

    # Readback lógico del DIC: todos los píxeles fuera de la nueva m deben ser
    # idénticos a retail. Esto detecta cualquier reempaquetado no localizado.
    readback_atlas = Killer7Project.decode_dic_texture(patched_dic).convert('L')
    if readback_atlas.size != original_atlas.size:
        raise K7Error('JMB EUR 77304: tamaño de atlas cambió tras reencode.')
    mask_before = bytearray(original_atlas.tobytes())
    mask_after = bytearray(readback_atlas.tobytes())
    width = original_atlas.width
    for yy in range(dy, dy + dh):
        a = yy * width + dx
        b = a + dw
        mask_before[a:b] = b'\0' * dw
        mask_after[a:b] = b'\0' * dw
    if mask_before != mask_after:
        raise K7Error('JMB EUR 77304: cambiaron píxeles fuera del glifo m añadido.')
    if readback_atlas.crop((dx, dy, dx + dw, dy + dh)).tobytes() != patched_atlas.crop((dx, dy, dx + dw, dy + dh)).tobytes():
        raise K7Error('JMB EUR 77304: readback del glifo m no coincide.')

    # Las escenas 1..3 deben conservar char_data exactamente; sólo cambia escena 0.
    _psn, pcn, _pso, pco, _pto, patched_units = _eur_jmb_active_units(patched_jmb)
    if pcn != fcn:
        raise K7Error('JMB EUR 77304: cambió char_num; debe permanecer en 37.')
    by_key_before = {(u[0], u[1]): u[2] for u in french_units}
    by_key_after = {(u[0], u[1]): u[2] for u in patched_units}
    if by_key_after.get((0, 0)) != target_codes:
        raise K7Error('JMB EUR 77304: readback de Anillo de llama obtenido falló.')
    for key, codes in by_key_before.items():
        if key == (0, 0):
            continue
        if by_key_after.get(key) != codes:
            raise K7Error(f'JMB EUR 77304: char_data de escena {key} cambió accidentalmente.')

    # Todos los fParams salvo el slot 6 deben ser byte por byte retail.
    for idx in range(fcn):
        if idx == _EUR_77304_M_SLOT:
            continue
        before = original_jmb[fco + idx * 8:fco + (idx + 1) * 8]
        after = patched_jmb[pco + idx * 8:pco + (idx + 1) * 8]
        if before != after:
            raise K7Error(f'JMB EUR 77304: fParam #{idx} cambió accidentalmente.')

    patched_dar = _eur_rebuild_jmb_dic_mirror_dar(original_dar, patched_jmb, patched_dic)
    if len(patched_dar) != len(original_dar):
        raise K7Error('JMB EUR 77304: el DAR espejo cambió de tamaño.')

    replacements[1793] = patched_jmb
    replacements[1794] = patched_dar
    replacements[1795] = patched_dic
    return {
        'jmb_index': 1793, 'dar_index': 1794, 'dic_index': 1795,
        'source': _EUR_77304_FIRE_RING_SOURCE,
        'target': _EUR_77304_FIRE_RING_TARGET,
        'char_num': int(fcn),
        'reused_slot': {'index': _EUR_77304_M_SLOT, 'retail_char': 'f', 'target_char': 'm'},
        'm_donor': {'jmb_index': _EUR_77304_M_DONOR_JMB, 'dic_index': _EUR_77304_M_DONOR_DIC,
                    'name': '55101', 'slot': _EUR_77304_M_DONOR_SLOT,
                    'rect': [sx, sy, sw, sh], 'sha256': _EUR_77304_M_DONOR_SHA256},
        'm_destination_rect': [dx, dy, dw, dh],
        'sizes': [len(patched_jmb), len(patched_dar), len(patched_dic)],
        'structure': 'French retail in-place; scene0 char_data + slot6 fParam + blank atlas rect only',
    }


# v1.7.7.204 — versiones completas de los dos JMB in-place ya verificados en juego.
# Estas definiciones sustituyen las anteriores sin cambiar su API.
def _eur_patch_77102_inplace_runtime(afs, raw_entries, names, replacements) -> dict:
    """Traduce las dos unidades de 77102 sobre la estructura francesa retail.

    Resultado:
      Balle d'âmes reçue -> Soul Shell hallada
      Coffre ouvert      -> Cofre abierto

    Se conserva char_num=17 y el tamaño JMB/DAR/DIC. Los cinco caracteres que no
    existen en la fuente FR local se colocan en slots franceses ya innecesarios y
    sus bitmaps se toman de recursos PAL de la misma familia tipográfica.
    """
    if len(raw_entries) <= 1795 or names[1742:1745] != ['77102','77102','77102']:
        raise K7Error('JMB EUR 77102: terna francesa inesperada.')
    if names[1739:1742] != ['77102','77102','77102']:
        raise K7Error('JMB EUR 77102: terna inglesa PAL inesperada.')
    if names[1524] != '55101' or names[1526] != '55101':
        raise K7Error('JMB EUR 77102: donante francés 55101 no coincide con la base verificada.')

    original_jmb = _eur_read_entry(afs, raw_entries, 1742)
    original_dar = _eur_read_entry(afs, raw_entries, 1743)
    original_dic = _eur_read_entry(afs, raw_entries, 1744)
    english_jmb = _eur_read_entry(afs, raw_entries, 1739)
    english_dic = _eur_read_entry(afs, raw_entries, 1741)
    donor_jmb = _eur_read_entry(afs, raw_entries, 1524)
    donor_dic = _eur_read_entry(afs, raw_entries, 1526)

    _sn, cn, _so, co, _to, units = _eur_jmb_active_units(original_jmb)
    _esn, ecn, _eso, eco, _eto, _eu = _eur_jmb_active_units(english_jmb)
    _dsn, dcn, _dso, dco, _dto, _du = _eur_jmb_active_units(donor_jmb)
    if cn != 17 or len(units) != 2:
        raise K7Error('JMB EUR 77102: estructura francesa inesperada.')
    fr_map = _eur_jmb_char_map(original_jmb, ["Balle d'âmes reçue", 'Coffre ouvert'])
    en_map = _eur_jmb_char_map(english_jmb, ['Received Soul Shell', 'Trunk opened'])

    params = [list(struct.unpack_from('<4H', original_jmb, co+i*8)) for i in range(cn)]
    eparams = [struct.unpack_from('<4H', english_jmb, eco+i*8) for i in range(ecn)]
    dparams = [struct.unpack_from('<4H', donor_jmb, dco+i*8) for i in range(dcn)]
    atlas = Killer7Project.decode_dic_texture(original_dic).convert('L')
    eatlas = Killer7Project.decode_dic_texture(english_dic).convert('L')
    datlas = Killer7Project.decode_dic_texture(donor_dic).convert('L')
    bg = _mode_level(atlas)
    patched_atlas = atlas.copy()

    targets = ['Soul Shell hallada', 'Cofre abierto']
    required = set(''.join(targets).replace(' ', ''))
    keep_map = {ch: idx for ch, idx in fr_map.items() if ch in required}
    # Slots retail que dejan de ser necesarios para los dos targets.
    # Se aprovecha únicamente la primera fila del atlas: 77102 mide 512x64 y no
    # dispone de una segunda fila completa de 36 px. S usa el hueco conjunto de
    # los antiguos slots 5+6; b se comprime moderadamente al ancho del slot 10.
    slots = {'h': 0, 'S': 5, 'b': 10, 'i': 15}
    if any(idx in keep_map.values() for idx in slots.values()):
        raise K7Error('JMB EUR 77102: un slot donor pasó a ser necesario por un carácter conservado.')

    def donor_from(atlas_src, pp, idx):
        x,y,w,h = map(int, pp[idx]); return atlas_src.crop((x,y,x+w,y+h)).copy()
    donors = {
        'S': donor_from(eatlas, eparams, en_map['S']),
        'i': donor_from(datlas, dparams, 11),
        'h': donor_from(datlas, dparams, 31),
        'b': donor_from(datlas, dparams, 26),
    }

    placements = {
        'h': (int(params[0][0]), int(params[0][1]), 20),
        'S': (int(params[5][0]), int(params[5][1]), int(params[7][0]) - int(params[5][0]) - 1),
        'b': (int(params[10][0]), int(params[10][1]), int(params[10][2])),
        'i': (int(params[15][0]), int(params[15][1]), int(params[15][2])),
    }
    donor_report=[]
    for ch,idx in slots.items():
        g=_adapt_glyph_background(donors[ch], bg)
        x,y,maxw = placements[ch]
        if g.width > maxw:
            compact=_condense_da_glyph(g,maxw,bg,min_ratio=0.72)
            if compact is None:
                raise K7Error(f'JMB EUR 77102: {ch!r} no cabe en región donor {maxw}x36.')
            g=compact
        clear_w=maxw
        patched_atlas.paste(bg,(x,y,x+clear_w,y+36))
        patched_atlas.paste(g,(x,y))
        params[idx]=[x,y,g.width,g.height]
        keep_map[ch]=idx
        donor_report.append({'char':ch,'slot':idx,'rect':[x,y,g.width,g.height]})

    patched_jmb=bytearray(original_jmb)
    for idx in slots.values():
        struct.pack_into('<4H',patched_jmb,co+idx*8,*params[idx])
    target_codes=[]
    for unit,target in zip(units,targets):
        codes=[-4 if ch==' ' else keep_map[ch] for ch in target]
        if len(codes)>JMB_MAX_CODES: raise K7Error('JMB EUR 77102: target excede 31 códigos.')
        arr=codes+[-2]+[-1]*(JMB_CODE_SLOTS-len(codes)-1)
        struct.pack_into(f'<{JMB_CODE_SLOTS}h',patched_jmb,unit[3],*arr)
        target_codes.append(codes)
    patched_jmb=bytes(patched_jmb)
    patched_dic=_encode_atlas_into_dic(original_dic,patched_atlas)
    if len(patched_jmb)!=len(original_jmb) or len(patched_dic)!=len(original_dic):
        raise K7Error('JMB EUR 77102: el parche completo cambió de tamaño.')
    *_m, chk_units=_eur_jmb_active_units(patched_jmb)
    if [u[2] for u in chk_units] != target_codes:
        raise K7Error('JMB EUR 77102: readback de las dos traducciones falló.')
    patched_dar=_eur_rebuild_jmb_dic_mirror_dar(original_dar,patched_jmb,patched_dic)
    if len(patched_dar)!=len(original_dar): raise K7Error('JMB EUR 77102: DAR cambió de tamaño.')
    replacements[1742]=patched_jmb; replacements[1743]=patched_dar; replacements[1744]=patched_dic
    return {'jmb_index':1742,'dar_index':1743,'dic_index':1744,
            'sources':["Balle d'âmes reçue",'Coffre ouvert'],'targets':targets,
            'donors':donor_report,'sizes':[len(patched_jmb),len(patched_dar),len(patched_dic)],
            'structure':'French retail in-place; both units translated; char_num 17 unchanged'}


def _eur_patch_77304_inplace_runtime(afs, raw_entries, names, replacements) -> dict:
    """Traduce todas las escenas textuales de 77304 manteniendo el recurso PAL FR.

    La escena 2 especial se conserva byte por byte. Sólo falta `m`; se reutiliza el
    slot 6 (`f`) y el mismo glifo francés 55101 ya validado por la v1.7.7.202.
    """
    import hashlib
    if len(raw_entries)<=1795 or names[1793:1796] != ['77304','77304','77304']:
        raise K7Error('JMB EUR 77304: terna francesa inesperada.')
    if names[1524] != '55101' or names[1526] != '55101':
        raise K7Error('JMB EUR 77304: donante 55101 inesperado.')
    oj=_eur_read_entry(afs,raw_entries,1793); odar=_eur_read_entry(afs,raw_entries,1794); od=_eur_read_entry(afs,raw_entries,1795)
    dj=_eur_read_entry(afs,raw_entries,1524); dd=_eur_read_entry(afs,raw_entries,1526)
    sn,cn,so,co,to,units=_eur_jmb_active_units(oj); _dsn,dcn,_dso,dco,_dto,_du=_eur_jmb_active_units(dj)
    if sn!=4 or cn!=37 or len(units)!=4 or dcn<=20: raise K7Error('JMB EUR 77304: estructura inesperada.')
    by={(u[0],u[1]):u for u in units}
    sources={0:'Anneau de feu récupéré',1:'Gravure étrange obtenue',3:"C'est verrouillé par cadenas"}
    targets={0:'Anillo de llama obtenido',1:'Grabado raro obtenido',3:'Cerrado con candado'}

    def map_unit(unit,text):
        m={};pos=0
        for code in unit[2]:
            if pos>=len(text): raise K7Error('JMB EUR 77304: source no alinea con char_data.')
            ch=text[pos];pos+=1
            if code in (-4,-3):
                if ch not in (' ','\u3000'): raise K7Error('JMB EUR 77304: espacio desalineado.')
                continue
            old=m.get(ch)
            if old is None:m[ch]=int(code)
            elif old!=int(code):raise K7Error(f'JMB EUR 77304: glifo ambiguo para {ch!r}.')
        if pos!=len(text): raise K7Error('JMB EUR 77304: longitud source desalineada.')
        return m
    cmap={}
    for s,text in sources.items():
        for ch,idx in map_unit(by[(s,0)],text).items():
            if ch in cmap and cmap[ch]!=idx: raise K7Error(f'JMB EUR 77304: mapa ambiguo {ch!r}.')
            cmap[ch]=idx
    special_codes=set(i for c in by[(2,0)][2] if (i:=_glyph_index(c)) is not None)
    if 6 in special_codes: raise K7Error('JMB EUR 77304: slot 6 usado por escena especial.')

    oa=Killer7Project.decode_dic_texture(od).convert('L'); da=Killer7Project.decode_dic_texture(dd).convert('L'); bg=_mode_level(oa)
    sx,sy,sw,sh=map(int,struct.unpack_from('<4H',dj,dco+20*8)); mg=da.crop((sx,sy,sx+sw,sy+sh)).copy()
    if hashlib.sha256(mg.tobytes()).hexdigest()!=_EUR_77304_M_DONOR_SHA256:
        raise K7Error('JMB EUR 77304: hash de m donante cambió.')
    dx,dy,dw,dh=_EUR_77304_M_DST
    if oa.crop((dx,dy,dx+dw,dy+dh)).getextrema()!=(bg,bg): raise K7Error('JMB EUR 77304: región m ya no está vacía.')
    pa=oa.copy(); pa.paste(_adapt_glyph_background(mg,bg),(dx,dy))
    cmap['m']=6
    pj=bytearray(oj); struct.pack_into('<4H',pj,co+6*8,dx,dy,dw,dh)
    expected={}
    for s,text in targets.items():
        codes=[-4 if ch==' ' else cmap[ch] for ch in text]
        if len(codes)>JMB_MAX_CODES: raise K7Error(f'JMB EUR 77304: escena {s} excede 31 códigos.')
        arr=codes+[-2]+[-1]*(JMB_CODE_SLOTS-len(codes)-1)
        struct.pack_into(f'<{JMB_CODE_SLOTS}h',pj,by[(s,0)][3],*arr); expected[(s,0)]=codes
    pj=bytes(pj); pd=_encode_atlas_into_dic(od,pa)
    if len(pj)!=len(oj) or len(pd)!=len(od): raise K7Error('JMB EUR 77304: cambió de tamaño.')
    *_x, pu=_eur_jmb_active_units(pj); after={(u[0],u[1]):u[2] for u in pu}
    if after.get((2,0))!=by[(2,0)][2]: raise K7Error('JMB EUR 77304: escena especial cambió.')
    for k,c in expected.items():
        if after.get(k)!=c: raise K7Error(f'JMB EUR 77304: readback escena {k} falló.')
    pdar=_eur_rebuild_jmb_dic_mirror_dar(odar,pj,pd)
    if len(pdar)!=len(odar): raise K7Error('JMB EUR 77304: DAR cambió de tamaño.')
    replacements[1793]=pj;replacements[1794]=pdar;replacements[1795]=pd
    return {'jmb_index':1793,'dar_index':1794,'dic_index':1795,
            'sources':[sources[k] for k in (0,1,3)],'targets':[targets[k] for k in (0,1,3)],
            'special_scene_preserved':2,'reused_slot':{'index':6,'retail_char':'f','target_char':'m'},
            'm_destination_rect':[dx,dy,dw,dh],'sizes':[len(pj),len(pdar),len(pd)],
            'structure':'French retail in-place; scenes 0/1/3 translated; scene 2 special unchanged'}


# v1.7.7.121 — excepciones JMB EUR verificadas visualmente.
#
# Algunas familias numéricas de DIR_E.AFS no son ternas EN/FR/DE puras. Hay
# subvariantes adicionales (20101, 77102, 77203, 77304, 77305) e incluso
# entradas japonesas entre ellas. El mapeo histórico 3*k+1 terminaba escribiendo
# en otra variante y dejaba el francés visible en juego. Estos cinco pares se
# verificaron renderizando directamente sus JMB/DIC EUR.
_EUR_JMB_FRENCH_INDEX_OVERRIDES = {
    'K7_0468_2010': 1015,  # 20101 · C'est verrouillé de l'autre côté
    'K7_0729_7710': 1742,  # 77102 · Balle d'âmes reçue / Coffre ouvert
    'K7_0741_7720': 1770,  # 77203 · grabado raro / Anillo de Fuego
    'K7_0750_7730': 1793,  # 77304 · Anillo / grabado / candado
    'K7_0753_7730': 1802,  # 77305 · aspersores / Anillo de Fuego
}


# v1.7.7.200 — catálogo autoritativo de JMB/DIC franceses retail.
#
# Los 118 bloques principales ya no se resuelven por heurística 3*k+1 durante
# la inyección. El paquete contiene las copias JMB/DIC (y 89 DAR espejo)
# extraídas de DIR_E.AFS retail y un manifest con índice/nombre/tamaño/SHA-256.
# La ISO de entrada debe coincidir byte por byte con esas anclas antes de
# sustituir ningún texto. Esto evita confundir variantes inglesas/alemanas o
# subvariantes numéricas como 77102/77203/77304/77305.
_EUR_FR_JMB_RETAIL_DIR = resource_path('resources', 'eur_base') / 'jmb_fr_retail'
_EUR_FR_JMB_RETAIL_MANIFEST = _EUR_FR_JMB_RETAIL_DIR / 'manifest.json'
_EUR_FR_JMB_RETAIL_CACHE = None

# v1.7.7.205 — familias PAL donde el DIC del mismo idioma está ANTES del JMB.
# La 204 catalogó por error el DIC siguiente (alemán) en estos nueve bloques.
# Mantener este guard explícito evita que una regeneración del manifest vuelva a
# introducir la asociación FR-JMB + DE-DIC que produce glifos aparentemente corruptos.
_EUR_FR_DIC_BEFORE_JMB_EXPECTED = {
    'K7_0286_Handso': (307, 306),
    'K7_0315_h_007': (528, 527),
    'K7_0317_h_007': (534, 533),
    'K7_0319_h_010': (540, 539),
    'K7_0321_h_010': (546, 545),
    'K7_0323_h_010': (552, 551),
    'K7_0325_h_020': (558, 557),
    'K7_0327_h_035': (564, 563),
    'K7_0329_h_055': (570, 569),
}


# v1.7.7.204 — payloads españoles recompilados SOBRE los JMB/DIC franceses retail.
# A diferencia del pipeline histórico, estos recursos conservan el layout PAL FR,
# sus escenas y el contenedor DIC francés. 77102/77304 siguen rutas in-place
# dedicadas porque ya están verificadas en juego; 55401/55403 se dejan retail.
_EUR_FR_ES_JMB_DIR = resource_path('resources', 'eur_base') / 'jmb_fr_es_all'
_EUR_FR_ES_JMB_MANIFEST = _EUR_FR_ES_JMB_DIR / 'manifest.json'
_EUR_FR_ES_JMB_CACHE = None

def _eur_fr_es_jmb_catalog() -> dict[str, dict]:
    global _EUR_FR_ES_JMB_CACHE
    if _EUR_FR_ES_JMB_CACHE is not None:
        return _EUR_FR_ES_JMB_CACHE
    try:
        doc = json.loads(_EUR_FR_ES_JMB_MANIFEST.read_text(encoding='utf-8'))
    except Exception as exc:
        raise K7Error(f'Base francesa: catálogo JMB FR→ES ausente o inválido: {exc}') from exc
    if doc.get('format') != 'killer7-eur-french-retail-spanish-precompiled' or int(doc.get('version', 0)) != 1:
        raise K7Error('Base francesa: formato de catálogo JMB FR→ES no compatible.')
    out = {}
    for rec in doc.get('blocks') or []:
        fid = str(rec.get('file_id') or '')
        if not fid or fid in out:
            raise K7Error(f'Base francesa: File ID duplicado/vacío en JMB FR→ES: {fid!r}.')
        for key in ('jmb_file', 'dic_file'):
            rel = str(rec.get(key) or '')
            fp = _EUR_FR_ES_JMB_DIR / rel
            if not rel or not fp.is_file():
                raise K7Error(f'Base francesa: payload {key} FR→ES ausente para {fid}: {rel!r}.')
        out[fid] = rec
    if len(out) != 114:
        raise K7Error(f'Base francesa: catálogo JMB FR→ES incompleto: {len(out)}/114 bloques.')
    _EUR_FR_ES_JMB_CACHE = out
    return out

def _eur_fr_jmb_retail_catalog() -> dict[str, dict]:
    global _EUR_FR_JMB_RETAIL_CACHE
    if _EUR_FR_JMB_RETAIL_CACHE is not None:
        return _EUR_FR_JMB_RETAIL_CACHE
    try:
        doc = json.loads(_EUR_FR_JMB_RETAIL_MANIFEST.read_text(encoding='utf-8'))
    except Exception as exc:
        raise K7Error(f'Base francesa: catálogo JMB retail ausente o inválido: {exc}') from exc
    if doc.get('format') != 'killer7-eur-french-jmb-retail-map' or int(doc.get('version', 0)) != 1:
        raise K7Error('Base francesa: formato de catálogo JMB retail no compatible.')
    blocks = doc.get('blocks') or []
    out = {}
    for rec in blocks:
        fid = str(rec.get('file_id') or '')
        if not fid or fid in out:
            raise K7Error(f'Base francesa: File ID duplicado/vacío en catálogo JMB retail: {fid!r}.')
        for key in ('jmb_file', 'dic_file'):
            rel = str(rec.get(key) or '')
            fp = _EUR_FR_JMB_RETAIL_DIR / rel
            if not rel or not fp.is_file():
                raise K7Error(f'Base francesa: recurso retail {key} ausente para {fid}: {rel!r}.')
        if rec.get('dar_index') is not None:
            rel = str(rec.get('dar_file') or '')
            fp = _EUR_FR_JMB_RETAIL_DIR / rel
            if not rel or not fp.is_file():
                raise K7Error(f'Base francesa: DAR retail ausente para {fid}: {rel!r}.')
        out[fid] = rec
    if len(out) != 118:
        raise K7Error(f'Base francesa: catálogo JMB retail incompleto: {len(out)}/118 bloques.')
    for fid, (expected_jmb, expected_dic) in _EUR_FR_DIC_BEFORE_JMB_EXPECTED.items():
        rec = out.get(fid)
        if rec is None or int(rec.get('jmb_index', -1)) != expected_jmb or int(rec.get('dic_index', -1)) != expected_dic:
            raise K7Error(
                f'Base francesa: asociación DIC-before-JMB regresó para {fid}; '
                f'esperado JMB #{expected_jmb} + DIC francés #{expected_dic}.'
            )
    _EUR_FR_JMB_RETAIL_CACHE = out
    return out

def _eur_validate_packaged_fr_resource(afs, raw_entries, names, rec: dict, kind: str) -> bytes:
    idx = int(rec[f'{kind}_index'])
    if not (0 <= idx < len(raw_entries)):
        raise K7Error(f'Base francesa: índice {kind.upper()} retail fuera de rango para {rec.get("file_id")}: #{idx}.')
    expected_name = str(rec.get(f'{kind}_name') or '')
    if names[idx] != expected_name:
        raise K7Error(
            f'Base francesa: nombre {kind.upper()} retail distinto para {rec.get("file_id")}: '
            f'AFS #{idx} es {names[idx]!r}, esperado {expected_name!r}.'
        )
    actual = _eur_read_entry(afs, raw_entries, idx)
    rel = str(rec[f'{kind}_file'])
    packaged = (_EUR_FR_JMB_RETAIL_DIR / rel).read_bytes()
    if actual != packaged:
        raise K7Error(
            f'Base francesa: {kind.upper()} retail #{idx} ({expected_name}) no coincide con '
            f'la copia francesa real empaquetada para {rec.get("file_id")}.'
        )
    expected_sha = str(rec.get(f'{kind}_sha256') or '')
    if expected_sha and sha256_bytes(actual) != expected_sha:
        raise K7Error(f'Base francesa: SHA-256 {kind.upper()} retail inválido para {rec.get("file_id")} #{idx}.')
    return actual

# v1.7.7.201 — correspondencia semántica real entre escenas PAL EN y FR.
# La mayoría de JMB conserva el mismo número/orden de escenas aunque cambien los
# saltos de línea. h_010 es la única excepción traducida encontrada: la rama FR
# omite por completo la escena EN 4 ("But I decided to put my life first.").
_EUR_FR_SCENE_REMAPS = {
    'K7_0319_h_010': (
        (0, 0), (1, 1), (2, 2), (3, 3),
        (5, 4), (6, 5), (7, 6), (8, 7), (9, 8), (10, 9), (11, 10),
    ),
}

# Estas dos unidades USA "Received tape" no tienen frase equivalente en sus
# JMB franceses 55401/55403. La variante PAL contiene sólo el recurso gráfico
# M2B; inyectar el JMB USA allí asociaba una traducción a una frase inexistente.
_EUR_FR_ABSENT_PAIR_TRANSLATIONS = frozenset({
    'K7_0669_5540',
    'K7_0684_5540',
})


def _eur_remap_compiled_jmb_scenes_to_french(file_id: str, compiled_jmb: bytes) -> tuple[bytes, dict] | None:
    """Reordena/elimina escenas del JMB español cuando la rama FR difiere.

    Sólo opera sobre bloques con un mapa explícito y auditado. Conserva intactos
    los records, char_data y fParams españoles de las escenas que sí existen en
    francés; no sintetiza ninguna traducción para una frase ausente.
    """
    pairs = _EUR_FR_SCENE_REMAPS.get(str(file_id))
    if not pairs:
        return None
    if len(compiled_jmb) < 16:
        raise K7Error(f'{file_id}: JMB español truncado al remapear escenas FR.')
    sn, cn, so, co, to = struct.unpack_from('<hhIII', compiled_jmb, 0)
    expected_src = sorted(int(src) for src, _dst in pairs)
    if any(src < 0 or src >= int(sn) for src in expected_src):
        raise K7Error(f'{file_id}: mapa de escenas FR referencia una escena fuente inexistente.')
    ordered = sorted((int(dst), int(src)) for src, dst in pairs)
    if [dst for dst, _src in ordered] != list(range(len(ordered))):
        raise K7Error(f'{file_id}: destinos FR no forman una secuencia 0..N-1.')
    new_sn = len(ordered)
    new_so = 16 + 4 * new_sn
    new_co = new_so + JMB_SCENE_SIZE * new_sn
    if int(co) != int(so) + JMB_SCENE_SIZE * int(sn):
        raise K7Error(f'{file_id}: layout JMB fuente inesperado al remapear escenas.')
    if int(co) + int(cn) * 8 > len(compiled_jmb):
        raise K7Error(f'{file_id}: fParams fuera de rango al remapear escenas.')

    # La tabla intermedia de 4 bytes/escena es parte del layout JMB. Se conserva
    # la entrada de la escena fuente correspondiente (en estos recursos es 0).
    table = b''.join(
        compiled_jmb[16 + src * 4:20 + src * 4]
        for _dst, src in ordered
    )
    scenes = b''.join(
        compiled_jmb[int(so) + src * JMB_SCENE_SIZE:int(so) + (src + 1) * JMB_SCENE_SIZE]
        for _dst, src in ordered
    )
    params = compiled_jmb[int(co):int(co) + int(cn) * 8]
    after = new_co + len(params)
    pad = 32 - (after % 32)
    new_to = after + pad
    head = bytearray(compiled_jmb[:16])
    struct.pack_into('<hhIII', head, 0, new_sn, int(cn), new_so, new_co, new_to)
    out = bytes(head) + table + scenes + params + (b'\x00' * pad)
    if len(out) != new_to:
        raise K7Error(f'{file_id}: tamaño JMB inconsistente después del remapeo FR.')

    # Guarda focalizada: K7_0319 pierde exclusivamente la escena fuente 4.
    omitted = sorted(set(range(int(sn))) - set(expected_src))
    return out, {
        'file_id': str(file_id),
        'source_scene_count': int(sn),
        'french_scene_count': int(new_sn),
        'scene_pairs': [[src, dst] for src, dst in pairs],
        'omitted_source_scenes': omitted,
    }


def _eur_build_replacements(afs_path: Path, patch_zip: Path, cinematic_targets: dict[str, str] | None = None, scene_selector_targets: dict[str, str] | None = None, sles_data: bytes | None = None) -> tuple[dict[int, bytes], dict]:
    """Map compiled USA Spanish payloads onto the verified French-language AFS slots."""
    import os
    import re
    from collections import Counter, defaultdict

    raw_entries, _name_off, _name_size, _name_table, names = _eur_parse_afs(afs_path)
    count = len(raw_entries)
    replacements: dict[int, bytes] = {}
    stats = Counter()
    mapping_notes = []

    # Scan only the structures needed for mapping. Small JMB/DIC/DAR headers are
    # enough for the first pass; K7P2 matching later reads complete candidate entries.
    jmb_indices = []
    dic_cache = {}
    dar_cache = {}
    with afs_path.open('rb') as afs:
        for i, (_off, size) in enumerate(raw_entries):
            if size <= 0:
                continue
            # JMBs are small; DIC/DAR signatures and DIC geometry live near the start.
            afs.seek(raw_entries[i][0])
            head = afs.read(min(size, 0x200))
            # JMB validation needs its final declared offset but not full body except len.
            # Re-read complete small candidate only when the header looks plausible.
            maybe_jmb = False
            if len(head) >= 16:
                try:
                    sn, cn, so, co, to = struct.unpack_from('<hhIII', head, 0)
                    maybe_jmb = 0 < sn < 100 and 0 < cn < 500 and so == 16 + 4 * sn and co - so == JMB_SCENE_SIZE * sn and co <= to <= size
                except struct.error:
                    pass
            if maybe_jmb:
                jmb_indices.append(i)
            if len(head) >= 4 and head[:4] == b'\x16\x00\x00\x00':
                dic_cache[i] = _eur_is_dic_blob(head + b'\0' * max(0, 0x90 - len(head)))
            if head[:4] == b'DAR\0':
                dar_cache[i] = True

        by_norm = defaultdict(list)
        for i in jmb_indices:
            by_norm[_eur_norm_name(names[i])].append(i)

        def is_dic(i: int) -> bool:
            if i < 0 or i >= count:
                return False
            if i in dic_cache:
                return bool(dic_cache[i])
            off, size = raw_entries[i]
            afs.seek(off)
            head = afs.read(min(size, 0x200))
            result = _eur_is_dic_blob(head + b'\0' * max(0, 0x90 - len(head)))
            dic_cache[i] = result
            return result

        def is_dar(i: int) -> bool:
            if i < 0 or i >= count:
                return False
            if i in dar_cache:
                return True
            off, size = raw_entries[i]
            afs.seek(off)
            result = afs.read(min(size, 4)) == b'DAR\0'
            dar_cache[i] = result
            return result

        def associated_dic(jmb_index: int):
            nm = names[jmb_index]
            # Algunas familias PAL (h_* y Handsom) están ordenadas DIC -> JMB.
            # El DIC inmediatamente anterior debe tener prioridad sobre el DIC
            # siguiente, que en esos tríos pertenece al idioma posterior.
            if jmb_index - 1 >= 0 and names[jmb_index - 1] == nm and is_dic(jmb_index - 1):
                return jmb_index - 1
            if jmb_index + 1 < count and names[jmb_index + 1] == nm and is_dic(jmb_index + 1):
                return jmb_index + 1
            if (jmb_index + 2 < count and names[jmb_index + 1] == nm and is_dar(jmb_index + 1)
                    and names[jmb_index + 2] == nm and is_dic(jmb_index + 2)):
                return jmb_index + 2
            for delta in range(2, 6):
                i = jmb_index - delta
                if i >= 0 and names[i] == nm and is_dic(i):
                    return i
            return None

        name_to_indices = defaultdict(list)
        for i, nm in enumerate(names):
            name_to_indices[nm.lower()].append(i)

        with zipfile.ZipFile(patch_zip, 'r') as patch:
            try:
                manifest = json.loads(patch.read('manifest.json').decode('utf-8'))
            except Exception as exc:
                raise K7Error(f'Base francesa: parche español sin manifest.json válido: {exc}') from exc
            if manifest.get('format') != PATCH_FORMAT:
                raise K7Error('Base francesa: el archivo compilado no es un parche Killer7 compatible.')
            rec_by = {(int(r['index']), r['kind']): r for r in manifest.get('entries', [])}

            # 1) Main JMB+DIC text pairs. v1.7.7.200 usa el catálogo retail
            # francés extraído del DIR_E.AFS real. No se deduce aquí ninguna
            # variante por orden EN/FR/DE: cada File ID tiene índices y bytes
            # franceses exactos, y la ISO debe coincidir con ellos.
            retail_map = _eur_fr_jmb_retail_catalog()
            pair_blocks = [b for b in manifest.get('blocks', []) if b.get('kind', 'pair') == 'pair']
            if len(pair_blocks) != len(retail_map):
                raise K7Error(
                    f'Base francesa: manifest español ({len(pair_blocks)} JMB) y catálogo retail '
                    f'({len(retail_map)} JMB) no coinciden.'
                )
            for block in pair_blocks:
                file_id = str(block.get('file_id') or '')
                retail = retail_map.get(file_id)
                if retail is None:
                    raise K7Error(f'Base francesa: falta JMB francés retail real para {file_id or block.get("name")}.')
                french_jmb = int(retail['jmb_index'])
                french_dic = int(retail['dic_index'])
                original_jmb = _eur_validate_packaged_fr_resource(afs, raw_entries, names, retail, 'jmb')
                original_dic = _eur_validate_packaged_fr_resource(afs, raw_entries, names, retail, 'dic')
                if french_jmb not in jmb_indices:
                    raise K7Error(f'Base francesa: el recurso retail #{french_jmb} de {file_id} ya no valida como JMB.')
                if not is_dic(french_dic):
                    raise K7Error(f'Base francesa: el recurso retail #{french_dic} de {file_id} ya no valida como DIC.')
                mapping_notes.append({
                    'jmb_fr_retail_exact': {
                        'file_id': file_id,
                        'afs_jmb_index': french_jmb,
                        'afs_dic_index': french_dic,
                        'afs_dar_index': retail.get('dar_index'),
                        'afs_name': names[french_jmb],
                        'jmb_sha256': retail.get('jmb_sha256'),
                        'dic_sha256': retail.get('dic_sha256'),
                        'source': 'packaged retail French JMB/DIC extracted from user DIR_E.AFS',
                    }
                })
                # Sólo se inyecta una traducción si la frase/evento existe en la
                # variante francesa. 55401/55403 contienen un recurso M2B y no
                # tienen el mensaje USA "Received tape"; se dejan retail.
                if file_id in _EUR_FR_ABSENT_PAIR_TRANSLATIONS:
                    stats['jmb_fr_phrase_absent_skipped'] += 1
                    mapping_notes.append({
                        'jmb_fr_phrase_absent': {
                            'file_id': file_id,
                            'afs_jmb_index': french_jmb,
                            'afs_dic_index': french_dic,
                            'reason': 'USA translated phrase has no corresponding French JMB scene',
                        }
                    })
                    continue
                precompiled_fr_es = _eur_fr_es_jmb_catalog().get(file_id)
                if precompiled_fr_es is not None:
                    new_jmb = (_EUR_FR_ES_JMB_DIR / str(precompiled_fr_es['jmb_file'])).read_bytes()
                    new_dic = (_EUR_FR_ES_JMB_DIR / str(precompiled_fr_es['dic_file'])).read_bytes()
                    if sha256_bytes(new_jmb) != str(precompiled_fr_es.get('jmb_sha256') or ''):
                        raise K7Error(f'Base francesa: SHA-256 JMB FR→ES inválido para {file_id}.')
                    if sha256_bytes(new_dic) != str(precompiled_fr_es.get('dic_sha256') or ''):
                        raise K7Error(f'Base francesa: SHA-256 DIC FR→ES inválido para {file_id}.')
                    stats['jmb_fr_es_precompiled'] += 1
                    mapping_notes.append({'jmb_fr_es_precompiled': {
                        'file_id': file_id, 'jmb_index': french_jmb, 'dic_index': french_dic,
                        'original_jmb_size': len(original_jmb), 'new_jmb_size': len(new_jmb),
                        'dic_size': len(new_dic), 'source': 'compiled directly on French retail JMB/DIC',
                    }})
                else:
                    # Sólo 77102/77304 llegan aquí; después se sobrescriben mediante
                    # sus rutas in-place verificadas. Se mantiene el payload histórico
                    # como fallback temporal dentro de esta fase.
                    try:
                        jrec = rec_by[(int(block['jmb_index']), 'jmb')]
                        drec = rec_by[(int(block['dic_index']), 'dic')]
                    except KeyError as exc:
                        raise K7Error(f'Base francesa: payload JMB/DIC español ausente para {file_id or block["name"]}.') from exc
                    new_jmb = patch.read(jrec['file'])
                    new_dic = patch.read(drec['file'])
                replacements[french_jmb] = new_jmb
                replacements[french_dic] = new_dic
                stats['jmb'] += 1
                stats['dic'] += 1
                stats['jmb_fr_retail_exact'] += 1

                # Los DAR espejo también proceden del catálogo retail real.
                mirror_value = retail.get('dar_index')
                if mirror_value is not None:
                    mirror_idx = int(mirror_value)
                    mirror_original = _eur_validate_packaged_fr_resource(afs, raw_entries, names, retail, 'dar')
                    if not is_dar(mirror_idx):
                        raise K7Error(f'Base francesa: el recurso retail #{mirror_idx} de {file_id} ya no valida como DAR.')
                    mirror_ranges = _eur_dar_child_ranges(mirror_original)
                    if len(mirror_ranges) != 2:
                        raise K7Error(f'Base francesa: DAR espejo retail inesperado para {file_id} en AFS #{mirror_idx}.')
                    m0, m1 = mirror_ranges
                    if (mirror_original[m0[0]:m0[0] + m0[1]] != original_jmb
                            or mirror_original[m1[0]:m1[0] + m1[1]] != original_dic):
                        raise K7Error(
                            f'Base francesa: DAR retail #{mirror_idx} no refleja exactamente '
                            f'JMB #{french_jmb} + DIC #{french_dic} de {file_id}.'
                        )
                    replacements[mirror_idx] = _eur_rebuild_jmb_dic_mirror_dar(
                        mirror_original, new_jmb, new_dic
                    )
                    stats['jmb_dar_mirror'] += 1
                    mapping_notes.append({
                        'jmb_dar_mirror': {
                            'file_id': file_id,
                            'afs_jmb_index': french_jmb,
                            'afs_dar_index': mirror_idx,
                            'afs_dic_index': french_dic,
                            'afs_name': names[french_jmb],
                            'source': 'exact retail French DAR mirror',
                        }
                    })

            # v1.7.7.170: 77102 se recompila sobre la estructura francesa original,
            # conservando exactamente tamaños/offsets. Esto permite además mantener
            # una copia compatible en el extent AFS original si el AFS completo se reubica.
            jmb_77102_inplace = _eur_patch_77102_inplace_runtime(
                afs, raw_entries, names, replacements
            )
            stats['jmb_77102_inplace_runtime'] += 1
            mapping_notes.append({'jmb_77102_inplace_runtime': jmb_77102_inplace})

            # v1.7.7.202: 77304/Fire Ring sigue la misma estrategia comprobada
            # que 77102: parche sobre JMB/DIC francés retail, same-size.
            jmb_77304_inplace = _eur_patch_77304_inplace_runtime(
                afs, raw_entries, names, replacements
            )
            stats['jmb_77304_inplace_runtime'] += 1
            mapping_notes.append({'jmb_77304_inplace_runtime': jmb_77304_inplace})

            if count > 1795 and names[1793:1796] == ['77304', '77304', '77304']:
                if any(idx not in replacements for idx in (1793, 1794, 1795)):
                    raise K7Error('Base EUR: 77304 no quedó parcheado en JMB + DAR espejo + DIC.')
                rr77304 = _eur_dar_child_ranges(replacements[1794])
                if (len(rr77304) != 2
                        or replacements[1794][rr77304[0][0]:rr77304[0][0] + rr77304[0][1]] != replacements[1793]
                        or replacements[1794][rr77304[1][0]:rr77304[1][0] + rr77304[1][1]] != replacements[1795]):
                    raise K7Error('Base EUR: guarda 77304 falló; el DAR #1794 no refleja #1793/#1795.')
                stats['jmb_77304_runtime_guard'] += 1

            # Guarda específica del caso observado en juego: 77102 debe quedar
            # parcheado tanto standalone (#1742/#1744) como dentro del DAR #1743.
            if count > 1744 and names[1742] == '77102' and names[1743] == '77102' and names[1744] == '77102':
                if 1742 not in replacements or 1744 not in replacements or 1743 not in replacements:
                    raise K7Error('Base EUR: 77102 no quedó parcheado en JMB + DAR espejo + DIC.')
                rr = _eur_dar_child_ranges(replacements[1743])
                if (len(rr) != 2
                        or replacements[1743][rr[0][0]:rr[0][0] + rr[0][1]] != replacements[1742]
                        or replacements[1743][rr[1][0]:rr[1][0] + rr[1][1]] != replacements[1744]):
                    raise K7Error('Base EUR: guarda 77102 falló; el DAR #1743 no refleja #1742/#1744.')
                stats['jmb_77102_runtime_guard'] += 1

            # 2) Subtitle .da resources. Keep the already compiled Spanish text/timing,
            # but rebuild its glyph atlas with official French EUR sprites. This removes
            # the old USA/English custom-font appearance from the French language branch.
            french_da_bank = _eur_da_build_french_glyph_bank(afs, raw_entries, names)
            master_da_files = _eur_da_master_files_by_name()
            da_fallback_chars = set()
            da_synthesized_chars = set()
            da_conflicts = 0
            for rec in [r for r in manifest.get('entries', []) if r.get('kind') == 'subtitle-da']:
                base = re.sub(r'\.da.*$', '', rec['name'], flags=re.I)
                candidates = name_to_indices.get((base + 'F.da').lower(), [])
                if not candidates:
                    candidates = name_to_indices.get((base + '.dat').lower(), [])
                if len(candidates) != 1:
                    raise K7Error(f'Base francesa: mapeo de subtítulo ambiguo para {rec["name"]}: {candidates}.')
                xlf_file = master_da_files.get(rec['name'].lower())
                if xlf_file is None:
                    raise K7Error(f'Base EUR: no se encontró {rec["name"]} en el XLIFF maestro español.')
                compiled_da = patch.read(rec['file'])
                revised_da, compile_info = _eur_recompile_spanish_da_from_master(
                    compiled_da, rec['name'], xlf_file, french_da_bank
                )
                french_styled_da, da_info = _eur_restyle_spanish_da_with_french(
                    revised_da, rec['name'], xlf_file, french_da_bank
                )
                da_info['recompile'] = compile_info
                idx = candidates[0]
                replacements[idx] = french_styled_da
                stats['subtitle_da'] += 1
                stats['subtitle_da_french_style'] += 1
                da_conflicts += int(da_info.get('conflict_glyphs', 0))
                da_fallback_chars.update(da_info.get('fallback_chars', []))
                da_synthesized_chars.update(da_info.get('synthesized_chars', []))
            stats['subtitle_da_glyph_conflicts_preserved'] = da_conflicts
            mapping_notes.append({
                'subtitle_da_style': 'French EUR official glyph sprites',
                'subtitle_da_synthesized_chars': sorted(da_synthesized_chars),
                'subtitle_da_fallback_chars': sorted(da_fallback_chars),
                'subtitle_da_glyph_conflicts_preserved': da_conflicts,
            })

            # 2b) Subtítulos cinematográficos DAR sin extensión.  Esta familia no
            # era visible en el proyecto histórico. Se cataloga completa y se aplican
            # únicamente las traducciones españolas ya verificadas.
            cinematic = _eur_patch_cinematic_subtitles(
                afs, raw_entries, names, replacements, french_da_bank, cinematic_targets
            )
            stats['cinematic_french_entries'] = int(cinematic['french_entries'])
            stats['cinematic_visible_lines'] = int(cinematic['visible_lines'])
            stats['cinematic_translated_lines'] = int(cinematic['translated_lines'])
            stats['cinematic_pending_lines'] = int(cinematic['pending_lines'])
            mapping_notes.append({'cinematic_subtitles': cinematic})

            # 3) Gráficos DIC de capítulos: sólo se detectan aquí.
            # La escritura definitiva sobre los `kan*_f.dic` franceses se hace
            # al FINAL del pipeline mediante `_eur_patch_graphic_dic_resources`.
            # Esto evita que un payload histórico compilado desde USA pueda
            # sobrescribir o enmascarar el redibujado francés directo.
            legacy_graphic_recs = [r for r in manifest.get('entries', []) if r.get('kind') == 'graphic-dic']
            stats['graphic_dic_detected'] = len(legacy_graphic_recs)
            stats['graphic_dic'] = 0

            # 4) K7P2: detectar la rama inglesa, pero NO modificarla.
            # Los standalone/child 0 son la referencia semántica EN que permite
            # localizar el child 2 francés por section+key. El parche se aplicará
            # exclusivamente en 4b.1 sobre el francés.
            scenario_recs = [r for r in manifest.get('entries', []) if r.get('kind') == 'scenario-k7p2']
            wanted_hashes = {r['original_sha256'] for r in scenario_recs}
            hash_hits = defaultdict(list)
            for i, (_off, size) in enumerate(raw_entries):
                if size <= 0 or size > 200000:
                    continue
                blob = _eur_read_entry(afs, raw_entries, i)
                digest = hashlib.sha256(blob).hexdigest()
                if digest in wanted_hashes and blob.startswith(b'K7P2'):
                    hash_hits[digest].append(i)
            missing_english = []
            exact_english_indices = set()
            for rec in scenario_recs:
                hits = hash_hits.get(rec['original_sha256'], [])
                if not hits:
                    missing_english.append({'index': int(rec['index']), 'name': rec['name']})
                exact_english_indices.update(int(i) for i in hits)
            if missing_english:
                raise K7Error(
                    'Base francesa: faltan equivalentes K7P2 ingleses necesarios para detectar '
                    f'{len(missing_english)} escenarios.'
                )
            stats['k7p2_english_exact_entries'] = len(exact_english_indices)
            mapping_notes.append({
                'k7p2_english_exact_detection': {
                    'mode': 'detect-only',
                    'entries': len(exact_english_indices),
                    'indices': sorted(exact_english_indices),
                    'note': 'Se detectan por hash; no se añaden a replacements.',
                }
            })

            # 4b) Catálogo completo EN de rótulos/localizadores, también de sólo lectura.
            k7p2_english = _eur_detect_all_k7p2_english_labels(afs, raw_entries, names)
            stats['k7p2_english_entries'] = int(k7p2_english['entries'])
            stats['k7p2_english_units'] = int(k7p2_english['units'])
            stats['k7p2_english_unique_labels'] = int(k7p2_english['unique_labels'])
            stats['k7p2_place_units'] = int(k7p2_english.get('place_units', 0))
            stats['k7p2_place_unique_labels'] = int(k7p2_english.get('place_unique_labels', 0))
            english_primary_indices = set(int(i) for i in k7p2_english.get('english_primary_indices', []))
            mapping_notes.append({'k7p2_english_detection': k7p2_english})

            # 4b.1) La edición PAL guarda la rama francesa en el child 2 del DAR
            # inmediato. Se empareja por section+key y se propaga el target español
            # ya compilado, sin asumir offsets ni longitudes iguales al inglés.
            k7p2_french = _eur_patch_french_k7p2_children(
                afs, raw_entries, names, replacements
            )
            stats['k7p2_french_entries'] += int(k7p2_french['entries'])
            stats['k7p2_french_units'] += int(k7p2_french['units'])
            stats['k7p2_french_matched_units'] += int(k7p2_french['matched_units'])
            stats['k7p2_french_unchanged_units'] += int(k7p2_french['unchanged_units'])
            stats['k7p2_french_overflow_units'] += int(k7p2_french['overflow_units'])
            stats['k7p2_french_dar_entries_seen'] += int(k7p2_french['dar_entries_seen'])
            mapping_notes.append({'k7p2_french_child2': k7p2_french})


            # 4b.1b) Guarda final de plantas numéricas. Se ejecuta sobre el DAR
            # ya modificado y fuerza las 23+ unidades `1st..5th Floor` del child
            # francés a `Planta 1..5`, usando el child inglés del mismo DAR como
            # referencia semántica. Así ninguna pantalla puede conservar «étage».
            numeric_floors = _eur_force_numeric_floor_labels(
                afs, raw_entries, names, replacements
            )
            stats['k7p2_numeric_floor_units'] += int(numeric_floors['units'])
            stats['k7p2_numeric_floor_verified'] += int(numeric_floors['verified_units'])
            stats['k7p2_numeric_floor_changed'] += int(numeric_floors['changed_units'])
            mapping_notes.append({'k7p2_numeric_floors': numeric_floors})


            # 4b.1c) Auditoría binaria final de toda la familia de plantas:
            # 23 numéricas + Top-floor + Upstairs/Downstairs = 37 unidades en
            # la base EUR verificada. Compara bytes MapFontF finales, no Latin-1.
            floor_family = _eur_verify_floor_family_labels(
                afs, raw_entries, names, replacements
            )
            stats['k7p2_floor_family_units'] += int(floor_family['units'])
            stats['k7p2_floor_family_verified'] += int(floor_family['verified_units'])
            mapping_notes.append({'k7p2_floor_family_guard': floor_family})

            # Garantía v1.7.7.130: ningún K7P2 primario inglés puede terminar en
            # la tabla de reemplazos. Si otra capa futura intenta tocarlo, abortar.
            touched_english = sorted(english_primary_indices.intersection(replacements.keys()))
            if touched_english:
                raise K7Error(
                    'Base EUR: una capa intentó modificar K7P2 inglés pese al modo FR-only: ' +
                    ', '.join(f'#{i}' for i in touched_english[:16])
                )
            stats['k7p2_english_entries_modified'] = 0

            # 4b.2) Fase 00: «Ange» -> «Ángel». El SLES usa el slot francés À
            # (0xC0) y titlefont convierte únicamente ese glifo À->Á. La A ASCII
            # queda intacta, así no contaminamos otros textos de la pantalla.
            phase00_angel_info = _eur_patch_phase00_angel_font(
                afs, raw_entries, names, replacements
            )
            stats['phase00_angel_font'] += 1
            mapping_notes.append({'phase00_angel_font': phase00_angel_info})

            # 4b.3) Objetivo Heaven Smile: esta pantalla usa st00Font, no TVFontF.
            # Se reutilizan slots del reducido repertorio francés y se conserva
            # la estructura/count de st00Font_f.IH.
            st00_mission_info = _eur_patch_st00fontf_mission33(
                afs, raw_entries, names, replacements
            )
            stats['st00font_heaven_smile'] += 1
            mapping_notes.append({'st00font_heaven_smile': st00_mission_info})

            # 4b.4) Resto de objetivos ORDER: st01Font..st12Font. Cada fase
            # recibe únicamente los glifos que exige su texto español.
            mission_fonts_info = _eur_patch_remaining_mission_fonts(
                afs, raw_entries, names, replacements
            )
            stats['mission_fonts_all'] += int(mission_fonts_info['patched_phase_count'])
            mapping_notes.append({'mission_fonts_all': mission_fonts_info})

            # 4c) Fuente de mapa/localizadores K7P2. Los rótulos de escenario se
            # dibujan con MapFontF (mstaticF.dic + MapFontF.IH), no con TVFontF.
            # Reutilizamos slots franceses para á/í/ó/ú/ñ y mayúsculas, sin cambiar
            # la tabla IHE ni el tamaño físico del recurso.
            mapf_dic_indices = name_to_indices.get('mstaticf.di', [])
            mapf_ihe_indices = name_to_indices.get('mapfontf.ih', [])
            mapg_dic_indices = name_to_indices.get('mstaticg.di', [])
            mapg_ihe_indices = name_to_indices.get('mapfontg.ih', [])
            if not all(len(x) == 1 for x in (mapf_dic_indices, mapf_ihe_indices, mapg_dic_indices, mapg_ihe_indices)):
                raise K7Error(
                    'Base EUR: fuentes MapFont F/G ambiguas o ausentes: '
                    f'Fdic={mapf_dic_indices} Fihe={mapf_ihe_indices} '
                    f'Gdic={mapg_dic_indices} Gihe={mapg_ihe_indices}.'
                )
            mapf_dic_idx, mapf_ihe_idx = mapf_dic_indices[0], mapf_ihe_indices[0]
            mapg_dic_idx, mapg_ihe_idx = mapg_dic_indices[0], mapg_ihe_indices[0]
            mapf_dic = _eur_read_entry(afs, raw_entries, mapf_dic_idx)
            mapf_ihe = _eur_read_entry(afs, raw_entries, mapf_ihe_idx)
            mapg_dic = _eur_read_entry(afs, raw_entries, mapg_dic_idx)
            mapg_ihe = _eur_read_entry(afs, raw_entries, mapg_ihe_idx)
            mapf_patched, mapf_info = _eur_patch_mapfontf_spanish(mapf_dic, mapf_ihe, mapg_dic, mapg_ihe)
            if len(mapf_patched) != len(mapf_dic):
                raise K7Error('Base EUR: mstaticF.dic cambió de tamaño total.')
            replacements[mapf_dic_idx] = mapf_patched
            stats['mapfontf_spanish'] += 1
            mapping_notes.append({'mapfontf_spanish': mapf_info})

            # 5) Fuente francesa de Opciones: añadir E y ó reales.  La edición FR
            # original no incluye E ASCII en option_f.dat (por eso ESTÉREO se veía
            # como STÉRO) ni ó.  Se amplía la tabla usando sólo sprites EUR.
            option_f_indices = name_to_indices.get('option_f.dat', [])
            if len(option_f_indices) != 1:
                raise K7Error(f'Base EUR: se esperaba un único option_f.dat: {option_f_indices}.')
            option_f_index = option_f_indices[0]
            option_f_original = _eur_read_entry(afs, raw_entries, option_f_index)
            option_f_patched, option_font_info = _eur_patch_option_f_font(option_f_original)
            if len(option_f_patched) != len(option_f_original):
                raise K7Error('Base EUR: option_f.dat cambió de tamaño total.')
            replacements[option_f_index] = option_f_patched
            stats['option_f_font'] += 1
            mapping_notes.append({'option_f_font': option_font_info})

            # 6) Fuente TV para las pantallas que realmente la usan. La rama francesa
            # no trae varios glifos españoles aunque DIRECTO sí acepte sus bytes.
            # Reutilizamos slots franceses dentro de TVFontF sin tocar TVFontF.IHE.
            tvf_dic_indices = name_to_indices.get('tvfontf.dic', [])
            tvf_ihe_indices = name_to_indices.get('tvfontf.ihe', [])
            tvg_dic_indices = name_to_indices.get('tvfontg.dic', [])
            tvg_ihe_indices = name_to_indices.get('tvfontg.ihe', [])
            if not all(len(x) == 1 for x in (tvf_dic_indices, tvf_ihe_indices, tvg_dic_indices, tvg_ihe_indices)):
                raise K7Error(
                    'Base EUR: fuentes TV F/G ambiguas o ausentes: '
                    f'Fdic={tvf_dic_indices} Fihe={tvf_ihe_indices} '
                    f'Gdic={tvg_dic_indices} Gihe={tvg_ihe_indices}.'
                )
            tvf_dic_idx, tvf_ihe_idx = tvf_dic_indices[0], tvf_ihe_indices[0]
            tvg_dic_idx, tvg_ihe_idx = tvg_dic_indices[0], tvg_ihe_indices[0]
            tvf_dic = _eur_read_entry(afs, raw_entries, tvf_dic_idx)
            tvf_ihe = _eur_read_entry(afs, raw_entries, tvf_ihe_idx)
            tvg_dic = _eur_read_entry(afs, raw_entries, tvg_dic_idx)
            tvg_ihe = _eur_read_entry(afs, raw_entries, tvg_ihe_idx)
            tvf_patched, tvf_info = _eur_patch_tvfontf_spanish(tvf_dic, tvf_ihe, tvg_dic, tvg_ihe)
            if len(tvf_patched) != len(tvf_dic):
                raise K7Error('Base EUR: TVFontF.dic cambió de tamaño total.')
            replacements[tvf_dic_idx] = tvf_patched
            stats['tvfontf_spanish'] += 1
            mapping_notes.append({'tvfontf_spanish': tvf_info})

            # 6a) Blood Room usa una fuente distinta: BloodFontF dentro de
            # mes_f.dic, descrita por el STRIMAGS child 0 de mes_f.dat. Los
            # mismos bytes donor del SLES se convierten aquí en ¿/¡/á/í/ó.
            bloodf_dat_indices = name_to_indices.get('mes_f.dat', [])
            bloodf_dic_indices = name_to_indices.get('mes_f.dic', [])
            if len(bloodf_dat_indices) != 1 or len(bloodf_dic_indices) != 1:
                raise K7Error(
                    'Base EUR: recursos BloodFontF ambiguos o ausentes: '
                    f'mes_f.dat={bloodf_dat_indices} mes_f.dic={bloodf_dic_indices}.'
                )
            bloodf_dat_idx = bloodf_dat_indices[0]
            bloodf_dic_idx = bloodf_dic_indices[0]
            bloodf_dat = _eur_read_entry(afs, raw_entries, bloodf_dat_idx)
            bloodf_dic = _eur_read_entry(afs, raw_entries, bloodf_dic_idx)

            # v1.7.7.182: el JMB global de mes_f.dat contiene una familia completa
            # de avisos cortos franceses. Se traducen in-place con su propia tabla
            # de 29 glifos, sin tocar textura, fParams, children ni offsets DAR.
            bloodf_dat_patched, mes_f_global_info = _eur_patch_mes_f_global_messages(bloodf_dat)
            if len(bloodf_dat_patched) != len(bloodf_dat):
                raise K7Error('Base EUR: mes_f.dat cambió de tamaño total.')
            replacements[bloodf_dat_idx] = bloodf_dat_patched
            stats['mes_f_global_messages'] += int(mes_f_global_info['patched_count'])
            mapping_notes.append({'mes_f_global_messages': mes_f_global_info})

            # v1.7.7.199: no se modifica SystemF. La reescritura de su DIC 4bpp
            # podía verse correcta al decodificarlo en CPU pero llegar invertida/
            # corrupta al GS en juego. Los avisos de anillos se limitan ahora al
            # repertorio retail ya presente en SystemF.
            bloodf_patched, bloodf_info = _eur_patch_bloodfontf_spanish(
                bloodf_dic, bloodf_dat_patched
            )
            _sys_before_start, _sys_before = _eur_dic_named_subresource(bloodf_dic, 'SystemF')
            _sys_after_start, _sys_after = _eur_dic_named_subresource(bloodf_patched, 'SystemF')
            if _sys_before_start != _sys_after_start or _sys_before != _sys_after:
                raise K7Error('Base EUR: SystemF cambió durante el parche; debe conservarse retail.')
            if len(bloodf_patched) != len(bloodf_dic):
                raise K7Error('Base EUR: mes_f.dic cambió de tamaño total.')
            replacements[bloodf_dic_idx] = bloodf_patched
            stats['bloodfontf_spanish'] += 1
            mapping_notes.append({'bloodfontf_spanish': bloodf_info})

            # 6b) Aviso inicial de contenido. Sustituye la textura francesa gulo_F
            # por el PNG español integrado, conservando la CLUT y el layout DIC 4bpp.
            adult_warning_info = _eur_patch_adult_warning_graphic(
                afs, raw_entries, name_to_indices, replacements
            )
            stats['adult_warning_graphic'] += 1
            stats['adult_warning_textures'] += 1
            mapping_notes.append({'adult_warning_graphic': adult_warning_info})

            # 6c) Atlas principal del menú francés (Sp_f_60.bin / Special_f.b).
            # Conserva retratos/colores y sustituye sólo los rótulos rasterizados.
            special_menu_info = _eur_patch_special_menu_graphics(
                afs, raw_entries, name_to_indices, replacements, sles_data
            )
            stats['special_menu_graphics'] += len(special_menu_info['resources'])
            stats['special_menu_labels'] += len(special_menu_info['labels'])
            mapping_notes.append({'special_menu_graphics': special_menu_info})

            charge_attack_info = _eur_patch_charge_attack_graphics(
                afs, raw_entries, name_to_indices, replacements
            )
            stats['charge_attack_graphics'] += len(charge_attack_info['resources'])
            mapping_notes.append({'charge_attack_graphics': charge_attack_info})

            # 7) Pantallas iniciales de selección de idioma y 50/60 Hz. Estos
            # rótulos están horneados en texturas, por eso no aparecen en DIRECTO.
            sellang_info = _eur_patch_sellang_graphics(
                afs, raw_entries, name_to_indices, replacements
            )
            stats['sellang_graphics'] += len(sellang_info['resources'])
            stats['sellang_textures'] += len(sellang_info['textures'])
            mapping_notes.append({'sellang_graphics': sellang_info})

            # 7b) Pantalla rasterizada de dificultad. Antes sólo se aplicaba desde
            # el botón separado «Imagenes Traducidas»; ahora forma parte del único
            # flujo «Inyectar Textos» y se reconstruye en el mismo DIR_E.AFS.
            difficulty_info = _eur_patch_difficulty_graphics(
                afs, raw_entries, name_to_indices, replacements
            )
            stats['difficulty_graphics'] += 1
            stats['difficulty_textures'] += len(difficulty_info['textures'])
            mapping_notes.append({'difficulty_graphics': difficulty_info})

            # 8) Selector de escenas EUR: CIBLE, fechas/estaciones y tarjeta Lion.
            scene_selector_info = _eur_patch_scene_selector_graphic(
                afs, raw_entries, name_to_indices, replacements, scene_selector_targets
            )
            stats['scene_selector_graphic'] += 1
            stats['scene_selector_units'] += len(EUR_SCENE_SELECTOR_ROWS)
            mapping_notes.append({'scene_selector': scene_selector_info})

            # 8b) Índice gráfico del tutorial (explan_f.dat / Tutorial).
            explan_tutorial_info = _eur_patch_explan_tutorial_graphic(
                afs, raw_entries, name_to_indices, replacements
            )
            stats['explan_tutorial_graphic'] += 1
            stats['explan_tutorial_labels'] += len(explan_tutorial_info['labels'])
            mapping_notes.append({'explan_tutorial_graphic': explan_tutorial_info})

            # 8b.1) Lista textual del menú de ayuda dentro del child 1 del mismo DAR.
            explan_menu_info = _eur_patch_explan_menu_labels(
                afs, raw_entries, name_to_indices, replacements
            )
            stats['explan_menu_labels'] += int(explan_menu_info['patched_count'])
            mapping_notes.append({'explan_menu_labels': explan_menu_info})

            # 8b.2) Rótulos del child 2 del mismo DAR (atlas exlog).
            explan_child2_info = _eur_patch_explan_child2_labels(
                afs, raw_entries, name_to_indices, replacements
            )
            stats['explan_child2_labels'] += int(explan_child2_info['patched_occurrences'])
            mapping_notes.append({'explan_child2_labels': explan_child2_info})

            # 8c) Tutorial EUR completo: todos los mensajes de controles y Sí/No.
            tutorial_info = _eur_patch_tutorial_graphics(
                afs, raw_entries, name_to_indices, replacements
            )
            stats['tutorial_graphics'] += 1
            stats['tutorial_textures'] += len(tutorial_info['textures'])
            stats['tutorial_units'] += len(EUR_TUTORIAL_ROWS)
            mapping_notes.append({'tutorial_graphics': tutorial_info})

            # 8d) Mapas EUR rasterizados: sustituye los rótulos/fechas horneados
            # en los 11 `*_a`. Los `*_n` se procesan en la pasada STRIMAGS siguiente.
            map_raster_info = _eur_patch_map_raster_spanish(
                afs, raw_entries, names, replacements
            )
            stats['map_raster_graphics'] += int(map_raster_info['count'])
            mapping_notes.append({'map_raster_graphics': map_raster_info})

            # v1.7.7.171: los nombres de planta tienen una segunda capa local.
            # Los STRIMAGS de cel_n/htl_n guardan secuencias de índices ya
            # precompiladas; se parchean junto con tres glifos donantes.
            map_floor_info = _eur_patch_map_floor_strimags(
                afs, raw_entries, names, replacements
            )
            stats['map_floor_strimags_fonts'] += int(map_floor_info['count'])
            stats['map_floor_strimags_sequences'] += sum(
                int(row.get('sequence_count', 0)) for row in map_floor_info['fonts']
            )
            mapping_notes.append({'map_floor_strimags': map_floor_info})

            # 9) ÚLTIMA escritura gráfica del AFS: tarjetas de capítulo/epílogo
            # francesas. Se fuerza al final para que ninguna otra capa pueda
            # volver a dejar `Ange`, `Coucher de Soleil`, etc.
            chapter_graphics_info = _eur_patch_graphic_dic_resources(
                manifest, patch, afs, raw_entries, names, replacements
            )
            chapter_count = int(chapter_graphics_info.get('count', 0))
            if chapter_count != len(_EUR_GRAPHIC_DIC_OVERRIDES):
                raise K7Error(
                    f'Base EUR: se esperaban {len(_EUR_GRAPHIC_DIC_OVERRIDES)} gráficos de capítulo, '
                    f'pero sólo se prepararon {chapter_count}.'
                )
            stats['chapter_graphic_dic'] = chapter_count
            stats['chapter_graphic_dic_verified'] = chapter_count
            mapping_notes.append({'chapter_graphic_dic': chapter_graphics_info})

            stats['compiled_blocks'] = len(manifest.get('blocks', []))
            stats['translated_units'] = int(manifest.get('translated_units', 0))
            stats['stable_direct_patches'] = len(manifest.get('iso_patches', []))

    return replacements, {
        'counts': dict(stats),
        'replacement_entries': len(replacements),
        'afs_entries': count,
        'mapping_notes': mapping_notes,
    }



# ---------------------------------------------------------------------------
# EUR cinematic subtitles hidden in extensionless DAR containers (v1.7.7.19)
# ---------------------------------------------------------------------------

# Traducciones que venían integradas en v1.7.7.18. Ahora sólo son valores por
# defecto: el editor EUR puede sustituir cualquier línea por texto del usuario.
_EUR_CINEMATIC_KNOWN_ES = {
    "Si j'étais toi, j'irais pas plus ": "En tu lugar, no seguiría",
    "loin. C'est dangereux.": "más. Es peligroso.",
    "Tous mes amis sont morts.": "Todos mis amigos están muertos.",
}

_EUR_CINEMATIC_FR_WORDS = {
    'je','tu','vous','nous','ils','elles','les','des','est','suis','pas','plus','que','qui',
    'un','une','de','du','le','la','ce','cet','cette','dans','pour','avec','sur','mon','mes',
    'ton','tes','son','ses','mais','tout','tous','mort','morts','danger','dangereux','bien',
    'encore','alors','comme','ici','là','être','été','fait','faire','avez','avait','aux','au',
}
_EUR_CINEMATIC_DE_WORDS = {
    'ich','du','sie','wir','der','die','das','ist','nicht','ein','eine','und','zu','mit','mein',
    'meine','dein','bitte','auf','aus','im','in','den','dem','des','alle','sind','hat','haben',
}

# Glifos descubiertos al revisar TODOS los DAR cinematográficos de SLES_533.66.
# Los índices AFS son estables para esta edición verificada. Además de completar la
# transcripción francesa, ü/Ü se toman de la rama alemana para mantener el estilo
# original de Killer7 cuando el usuario escriba español con diéresis.
#
# Algunos caracteres (3, 6, î) ya existían en el banco .da histórico, pero aquí se
# registran variantes de bitmap usadas por las cinemáticas para que el decodificador
# reconozca el 100 % de los glifos de los 80 contenedores franceses detectados.
_EUR_CINEMATIC_GLYPH_REFS = {
    '…': ((397, 42),),
    'è': ((415, 8),),
    'ê': ((415, 38),),
    'ç': ((399, 29),),
    'ô': ((419, 28),),
    'Ç': ((429, 41),),
    'ù': ((397, 37),),
    'â': ((441, 49),),
    'û': ((451, 35),),
    'œ': ((505, 13),),
    'È': ((455, 34),),
    'Ê': ((499, 0),),
    ';': ((443, 34),),
    'ï': ((493, 9),),
    '%': ((503, 35),),
    'ü': ((400, 31),),
    'Ü': ((436, 52),),
    # Variantes de la fuente cinematográfica.
    '3': ((417, 30),),
    '6': ((447, 21),),
    'î': ((583, 44),),
}


def _eur_cinematic_ref_glyph(afs, raw_entries, afs_index: int, glyph_index: int) -> Image.Image:
    from core import decode_da_ps2_atlas
    if not (0 <= afs_index < len(raw_entries)):
        raise K7Error(f'Cinemáticas EUR: referencia AFS fuera de rango: #{afs_index}.')
    blob = _eur_read_entry(afs, raw_entries, afs_index)
    meta = Killer7Project._parse_da_blob(blob)
    params = _eur_da_params(meta)
    if not (0 <= glyph_index < len(params)):
        raise K7Error(
            f'Cinemáticas EUR: referencia de glifo fuera de rango: '
            f'AFS #{afs_index} glifo #{glyph_index}.'
        )
    atlas = decode_da_ps2_atlas(meta['dic']).convert('L')
    x, y, w, h = params[glyph_index]
    return atlas.crop((x, y, x + w, y + h)).copy()


def _eur_cinematic_extended_bank(afs, raw_entries, bank: dict[str, Image.Image]) -> dict[str, Image.Image]:
    """Banco de sprites oficiales .da + glifos hallados en las propias cinemáticas."""
    out = {ch: im.copy() for ch, im in bank.items()}
    for ch, refs in _EUR_CINEMATIC_GLYPH_REFS.items():
        if ch in out:
            continue
        afs_index, glyph_index = refs[0]
        out[ch] = _eur_cinematic_ref_glyph(afs, raw_entries, afs_index, glyph_index)
    return out


def _eur_cinematic_signature_bank(bank: dict[str, Image.Image], afs=None, raw_entries=None) -> dict[tuple, str]:
    """Firma bitmap→carácter, incluyendo variantes cinematográficas verificadas."""
    out = {}
    for ch, im in bank.items():
        gray = im.convert('L')
        out.setdefault((gray.size, gray.tobytes()), ch)
    if afs is not None and raw_entries is not None:
        for ch, refs in _EUR_CINEMATIC_GLYPH_REFS.items():
            for afs_index, glyph_index in refs:
                try:
                    gray = _eur_cinematic_ref_glyph(
                        afs, raw_entries, afs_index, glyph_index
                    ).convert('L')
                except Exception:
                    continue
                out[(gray.size, gray.tobytes())] = ch
    return out


def _eur_cinematic_decode(meta: dict, sig_bank: dict[tuple, str]) -> tuple[list[str], dict[int, str], float]:
    from core import decode_da_ps2_atlas
    atlas = decode_da_ps2_atlas(meta['dic'])
    idx_to_char = {}
    known = total = 0
    for gi, (x, y, w, h) in enumerate(_eur_da_params(meta)):
        im = atlas.crop((x, y, x + w, y + h)).convert('L')
        ch = sig_bank.get((im.size, im.tobytes()))
        if ch is not None:
            idx_to_char[gi] = ch
    lines = []
    for line in range(meta['line_count']):
        out = []
        for code in _eur_da_line_codes(meta, line):
            if code == -4:
                out.append(' ')
            elif code == -3:
                out.append('\n')
            elif code >= 0:
                total += 1
                ch = idx_to_char.get(code)
                if ch is None:
                    out.append('�')
                else:
                    known += 1
                    out.append(ch)
            else:
                out.append(f'{{ctl:{code & 0xffff:04X}}}')
        lines.append(''.join(out))
    return lines, idx_to_char, known / max(1, total)


def _eur_cinematic_is_french(lines: list[str], coverage: float) -> bool:
    if coverage < 0.65:
        return False
    import re
    joined = ' '.join(lines).lower()
    toks = re.findall(r"[a-zàâäçéèêëîïôöùûüÿœ]+", joined)
    fr = sum(t in _EUR_CINEMATIC_FR_WORDS for t in toks)
    de = sum(t in _EUR_CINEMATIC_DE_WORDS for t in toks)
    fr += sum(joined.count(x) for x in ('é','è','à','ç',"j'","c'","qu'"))
    return fr >= 1 and fr > de


def _eur_cinematic_candidates(afs, raw_entries, names, french_bank):
    sig_bank = _eur_cinematic_signature_bank(french_bank, afs, raw_entries)
    for idx, (_off, size) in enumerate(raw_entries):
        name = names[idx]
        low = name.lower()
        # .da/.dat ya pertenecen al sistema de subtítulos conocido. Los DAR
        # cinematográficos descubiertos en EUR no llevan esas extensiones.
        if low.endswith(('.da', '.dat')) or size < 1000 or size > 2_000_000:
            continue
        blob = _eur_read_entry(afs, raw_entries, idx)
        if not blob.startswith(b'DAR\0'):
            continue
        try:
            meta = Killer7Project._parse_da_blob(blob)
        except Exception:
            continue
        lines, idx_to_char, coverage = _eur_cinematic_decode(meta, sig_bank)
        if not _eur_cinematic_is_french(lines, coverage):
            continue
        yield idx, name, blob, meta, lines, idx_to_char, coverage


def _eur_cinematic_target_for(
    afs_index: int,
    line: int,
    source: str,
    custom_targets: dict[str, str] | None,
) -> str:
    """Target efectivo. Una clave personalizada vacía desactiva el target integrado."""
    key = f'{int(afs_index)}:{int(line)}'
    if custom_targets is not None and key in custom_targets:
        return str(custom_targets[key])
    return _EUR_CINEMATIC_KNOWN_ES.get(source, '')


def _eur_cinematic_synth_glyph(ch: str, bank: dict[str, Image.Image], row_h: int) -> tuple[Image.Image | None, bool]:
    """Obtiene/sintetiza un sprite para texto libre de cinemáticas.

    Prioridad: sprite oficial EUR exacto -> composición española con cuerpos EUR ->
    signos invertidos -> un 8 derivado del cero. La fuente de apoyo se reserva para
    caracteres realmente ausentes del juego y se reporta como fallback.
    """
    if ch in bank:
        return _normalize_glyph(bank[ch].copy(), row_h), False

    if ch in SPANISH_COMPOSE:
        base_char, mark = SPANISH_COMPOSE[ch]
        base = bank.get(base_char)
        if base is None:
            return None, False
        base = _normalize_glyph(base.copy(), row_h)
        bg = _mode_level(base)
        return _draw_mark(base, mark, bg, base_char), True

    if ch == '¡' and '!' in bank:
        return _normalize_glyph(bank['!'].copy(), row_h).transpose(Image.Transpose.ROTATE_180), True
    if ch == '¿' and '?' in bank:
        return _normalize_glyph(bank['?'].copy(), row_h).transpose(Image.Transpose.ROTATE_180), True

    # El corpus EUR no usa el dígito 8 en las 168 tablas DAR inspeccionadas. Para no
    # dejar un agujero artificial en 0-9, se deriva del cero oficial: dos óvalos
    # comprimidos verticalmente, sin introducir una tipografía externa.
    if ch == '8' and '0' in bank:
        zero = _normalize_glyph(bank['0'].copy(), row_h).convert('L')
        bg = _mode_level(zero)
        half_h = max(7, (row_h - 2) // 2)
        resampling = getattr(Image, 'Resampling', Image)
        half = zero.resize((zero.width, half_h), resample=resampling.LANCZOS)
        out = Image.new('L', (zero.width, row_h), bg)
        out.paste(half, (0, 0))
        out.paste(half, (0, row_h - half_h))
        return out.point(lambda v: int(round(v / 17.0)) * 17), True

    return None, False


def _eur_encode_resized_da_dic(original_dic: bytes, atlas: Image.Image) -> bytes:
    """Codifica un atlas DA permitiendo ampliar 512x32 -> 64 -> 128.

    Killer7 EUR ya contiene de forma nativa los tres tamaños. Al crecer se preservan
    cabeceras/nombre/trailer y se actualizan los tamaños de bloques, altura lógica,
    TEX0, TRXREG y GIF IMAGE que varían exactamente entre los DIC nativos estudiados.
    """
    old_w, old_h, pixel_off, old_payload_size = _da_dic_layout(original_dic)
    width, height = atlas.size
    if width != old_w or width != 512 or height not in (32, 64, 128):
        raise K7Error(f'Cinemáticas EUR: tamaño DIC ampliado no soportado: {width}x{height}.')
    if height == old_h:
        return encode_da_ps2_atlas_into_dic(original_dic, atlas)
    if height < old_h:
        raise K7Error('Cinemáticas EUR: no se reduce la altura física del DIC.')

    name_len = struct.unpack_from('<I', original_dic, 0x40)[0]
    shift = int(name_len) - 8
    trailer = original_dic[pixel_off + old_payload_size:]
    new_payload_size = width * height // 2
    new_len = pixel_off + new_payload_size + len(trailer)

    head = bytearray(original_dic[:pixel_off])
    # Longitudes anidadas observadas en todos los DIC DA nativos (shift -4/0/+4).
    struct.pack_into('<I', head, 0x04, new_len - 12)
    struct.pack_into('<I', head, 0x20, new_len - 52)
    struct.pack_into('<I', head, 0x64 + shift, new_len - (148 + shift))
    struct.pack_into('<I', head, 0xBC + shift, new_payload_size + 256)

    # Dimensiones lógicas declaradas.
    struct.pack_into('<I', head, 0x7C + shift, height)

    # Campo de altura TEX0: 32/64/128 usan respectivamente 0x65/0xA5/0xE5
    # en el byte verificado de las cabeceras EUR.
    tex_h = {32: 0x65, 64: 0xA5, 128: 0xE5}[height]
    head[0x8B + shift] = tex_h
    # Segundo descriptor interno que conserva la altura explícita.
    head[0xA9 + shift] = height & 0xFF

    # TRXREG: transferencia PSMCT16 de 256 x (H/2).
    trx_off = 0xE4 + shift
    trx = struct.unpack_from('<Q', head, trx_off)[0]
    trx &= ~((0xFFF << 0) | (0xFFF << 32))
    trx |= (width // 2) | ((height // 2) << 32)
    struct.pack_into('<Q', head, trx_off, trx)

    # GIFtag IMAGE: NLOOP = bytes_de_payload / 16.
    image_off = 0x104 + shift
    image_tag = struct.unpack_from('<Q', head, image_off)[0]
    nloop = new_payload_size // 16
    image_tag = (image_tag & ~0x7FFF) | nloop
    struct.pack_into('<Q', head, image_off, image_tag)

    # Genera la transferencia GS desde los píxeles PSMT4 solicitados.
    gray = atlas.convert('L')
    px = bytearray(max(0, min(15, int(round(v / 17.0)))) for v in gray.getdata())
    vram = bytearray(4 * 1024 * 1024)
    for y in range(height):
        row = y * width
        for x in range(width):
            _da_write_t4(vram, width, x, y, px[row + x])
    payload = _da_read_ct16(vram, 4, width // 2, height // 2)
    if len(payload) != new_payload_size:
        raise K7Error('Cinemáticas EUR: tamaño inesperado al codificar el DIC ampliado.')

    out = bytes(head) + payload + trailer
    nw, nh, npo, nps = _da_dic_layout(out)
    if (nw, nh, npo, nps) != (width, height, pixel_off, new_payload_size):
        raise K7Error('Cinemáticas EUR: cabecera DIC ampliada no supera la verificación estructural.')
    # La misma ruta de decodificación que usa el editor debe recuperar exactamente
    # los niveles 4bpp pedidos.
    from core import decode_da_ps2_atlas
    check = decode_da_ps2_atlas(out).convert('L')
    expected = bytes(v * 17 for v in px)
    if check.tobytes() != expected:
        raise K7Error('Cinemáticas EUR: el DIC ampliado no hace round-trip exacto.')
    return out


def _eur_cinematic_pack_glyphs(
    atlas_size: tuple[int, int],
    glyphs: list[tuple[str, Image.Image]],
    bg: int,
) -> tuple[Image.Image, list[tuple[int, int, int, int]], dict[str, int], list[str]]:
    """Reempaqueta sólo los caracteres realmente usados por las líneas finales.

    El llamador prueba la altura nativa y, si hace falta, 512x64/512x128,
    tamaños que ya existen de forma nativa en los DIC de Killer7 EUR. Dentro de
    cada altura se puede comprimir horizontalmente de forma moderada los glifos
    más anchos (máx. 28 %) para evitar crecimiento innecesario.
    """
    import math

    width, height = atlas_size
    if not glyphs:
        return Image.new('L', atlas_size, bg), [], {}, []

    work = [(ch, im.convert('L').copy()) for ch, im in glyphs]
    condensed: set[str] = set()

    # Todos los glifos se normalizan a la altura local antes de llegar aquí.
    # Calculamos la capacidad disponible para la altura candidata que nos pasa el
    # llamador. Si no cabe, éste puede reintentar con 64 o 128 px de alto.
    max_h = max(im.height for _ch, im in work)
    rows_capacity = max(1, height // max_h)
    total_capacity = width * rows_capacity
    total_width = sum(im.width for _ch, im in work)

    if total_width > total_capacity:
        overflow = total_width - total_capacity
        # Sólo comprimimos forma real; cada glifo conserva al menos el 72 % de su
        # anchura original y nunca baja de 3 px. Priorizamos los glifos anchos.
        candidates = []
        for i, (ch, im) in enumerate(work):
            min_w = max(3, int(math.ceil(im.width * 0.72)))
            potential = im.width - min_w
            if potential > 0:
                candidates.append((im.width, potential, i, ch, min_w))
        candidates.sort(reverse=True)
        possible = sum(item[1] for item in candidates)
        if possible < overflow:
            raise K7Error(
                f'Cinemáticas EUR: el atlas {width}x{height} necesita {total_width} px '
                f'de glifos y sólo dispone de {total_capacity}. Ni comprimiendo hasta '
                'el límite seguro del 72 % cabe todo el repertorio de esta cinemática. '
                'Traduce más líneas de la misma escena para liberar caracteres franceses '
                'que ya no se usen, o reduce caracteres únicos muy excepcionales.'
            )

        remaining = overflow
        for _w, potential, i, ch, min_w in candidates:
            if remaining <= 0:
                break
            old = work[i][1]
            reduction = min(potential, remaining)
            new_w = old.width - reduction
            adjusted = _condense_da_glyph(old, new_w, bg, min_ratio=0.72)
            if adjusted is None:
                continue
            work[i] = (ch, adjusted)
            condensed.add(ch)
            remaining -= old.width - adjusted.width
        if remaining > 0:
            raise K7Error(
                f'Cinemáticas EUR: faltan {remaining} px para empaquetar el atlas '
                'después de la compresión horizontal segura.'
            )

    def _try_pack(items):
        # Orden por anchura decreciente reduce fragmentación en atlas de dos filas.
        ordered = list(enumerate(items))
        ordered.sort(key=lambda item: (-item[1][1].height, -item[1][1].width, item[0]))
        atlas = Image.new('L', atlas_size, bg)
        placements: dict[str, tuple[int, int, int, int]] = {}
        rows: list[dict] = []
        failed = None
        for _order, (ch, glyph) in ordered:
            gw, gh = glyph.size
            if gw <= 0 or gh <= 0 or gw > width or gh > height:
                raise K7Error(f'Cinemáticas EUR: glifo {ch!r} inválido ({gw}x{gh}).')
            best = None
            for ri, row in enumerate(rows):
                if gh <= row['h'] and row['x'] + gw <= width:
                    waste = width - (row['x'] + gw)
                    score = (waste, row['h'] - gh, ri)
                    if best is None or score < best[0]:
                        best = (score, ri)
            if best is None:
                y = sum(row['h'] for row in rows)
                if y + gh > height:
                    failed = (ch, gw, gh, len(placements))
                    break
                rows.append({'y': y, 'x': 0, 'h': gh})
                ri = len(rows) - 1
            else:
                ri = best[1]
            row = rows[ri]
            x, y = row['x'], row['y']
            atlas.paste(glyph, (x, y))
            placements[ch] = (x, y, gw, gh)
            row['x'] += gw
        return atlas, placements, failed

    atlas, placements, failed = _try_pack(work)

    # En un atlas de varias filas puede existir fragmentación aunque la suma total
    # quepa. Reintentamos reduciendo de uno en uno el glifo más ancho que aún pueda
    # comprimirse, siempre respetando el mismo límite del 72 %.
    guard = 0
    while failed is not None and guard < 512:
        guard += 1
        choices = []
        for i, (ch, im) in enumerate(work):
            min_w = max(3, int(math.ceil(glyphs[i][1].width * 0.72)))
            if im.width > min_w:
                choices.append((im.width, i, ch, min_w))
        if not choices:
            ch, gw, gh, used = failed
            raise K7Error(
                f'Cinemáticas EUR: el atlas {width}x{height} no tiene espacio para '
                f'{ch!r} ({gw}x{gh}) tras {used} glifos, incluso con compresión segura.'
            )
        _w, i, ch, _min_w = max(choices)
        old = work[i][1]
        adjusted = _condense_da_glyph(old, old.width - 1, bg, min_ratio=0.72)
        if adjusted is None or adjusted.width >= old.width:
            # Marca este candidato como agotado bajándolo directamente a su mínimo
            # si el redimensionado a -1 no fuese posible por redondeos.
            adjusted = _condense_da_glyph(old, _min_w, bg, min_ratio=0.72)
        if adjusted is None or adjusted.width >= old.width:
            chf, gw, gh, used = failed
            raise K7Error(
                f'Cinemáticas EUR: no se pudo reducir la fragmentación del atlas; '
                f'falló {chf!r} ({gw}x{gh}) tras {used} glifos.'
            )
        work[i] = (ch, adjusted)
        condensed.add(ch)
        atlas, placements, failed = _try_pack(work)

    if failed is not None:
        ch, gw, gh, used = failed
        raise K7Error(
            f'Cinemáticas EUR: el atlas {width}x{height} no tiene espacio para '
            f'{ch!r} ({gw}x{gh}) tras {used} glifos.'
        )

    # Los índices de glifo se asignan por orden de primera aparición del carácter,
    # independiente del orden físico usado para empaquetar la textura.
    params = []
    char_to_idx = {}
    for ch, _glyph in glyphs:
        char_to_idx[ch] = len(params)
        params.append(placements[ch])
    return atlas, params, char_to_idx, sorted(condensed)


def _eur_patch_cinematic_lines(
    original: bytes,
    meta: dict,
    lines: list[str],
    idx_to_char: dict[int, str],
    french_bank: dict[str, Image.Image],
    targets: dict[int, str],
) -> tuple[bytes, list[dict], dict]:
    """Recompila cualquier conjunto de líneas de un DAR cinematográfico.

    A diferencia de v1.7.7.18, no recicla slots por índice. Reconstruye el repertorio
    final del DAR, reempaqueta sus glifos y puede aumentar glyph_count. Si el AFS EUR
    resultante crece, el inyector ISO lo reubica al final sin desplazar otros extents.
    """
    from core import decode_da_ps2_atlas

    if not targets:
        return original, [], {'glyph_count': meta['glyph_count'], 'fallback_chars': [], 'synthesized_chars': []}
    if any(not (0 <= int(line) < meta['line_count']) for line in targets):
        raise K7Error('Cinemáticas EUR: índice de línea personalizado fuera de rango.')
    if any('�' in source for source in lines):
        raise K7Error(
            'Cinemáticas EUR: quedan glifos franceses sin identificar; no es seguro '
            'recompilar todas las líneas de este DAR.'
        )

    original_atlas = decode_da_ps2_atlas(meta['dic']).convert('L')
    original_params = _eur_da_params(meta)
    row_h = max((h for _x, _y, _w, h in original_params), default=24)
    bg = int(round(_mode_level(original_atlas) / 17.0)) * 17

    # Banco local: si el carácter ya existe en ESTA cinemática, su sprite tiene
    # prioridad absoluta para conservar el estilo/variante exactos de esa escena.
    local_bank: dict[str, Image.Image] = {}
    for gi, ch in idx_to_char.items():
        if ch in local_bank or not (0 <= gi < len(original_params)):
            continue
        x, y, w, h = original_params[gi]
        local_bank[ch] = original_atlas.crop((x, y, x + w, y + h)).copy()

    final_lines = list(lines)
    changes = []
    for line, target in sorted(targets.items()):
        target = str(target)
        if not target:
            continue
        final_lines[int(line)] = target
        if target != lines[int(line)]:
            changes.append({'line': int(line), 'source': lines[int(line)], 'target': target})
    if not changes:
        return original, [], {'glyph_count': meta['glyph_count'], 'fallback_chars': [], 'synthesized_chars': []}

    needed_chars: list[str] = []
    seen = set()
    for text in final_lines:
        for typ, value in _text_tokens(text):
            if typ != 'char' or value in (' ', '\u3000') or value in seen:
                continue
            seen.add(value)
            needed_chars.append(value)

    glyphs: list[tuple[str, Image.Image]] = []
    glyph_aliases: dict[str, str] = {}
    glyph_signature_owner: dict[tuple, str] = {}
    fallback_chars = []
    synthesized_chars = []
    for ch in needed_chars:
        glyph = local_bank.get(ch)
        synthesized = False
        if glyph is None:
            glyph, synthesized = _eur_cinematic_synth_glyph(ch, french_bank, row_h)
        if glyph is None:
            # Último recurso para texto verdaderamente libre. No se usa para el
            # alfabeto español normal porque éste se cubre con sprites EUR/síntesis.
            glyph = _render_fallback_glyph(ch, row_h, None)
            fallback_chars.append(ch)
        elif synthesized:
            synthesized_chars.append(ch)
        glyph = _normalize_glyph(glyph, row_h)
        glyph = _adapt_glyph_background(glyph, bg)
        glyph = glyph.point(lambda v: int(round(v / 17.0)) * 17)
        glyph = _trim_da_glyph_horizontal(glyph, bg, margin=0)

        # Killer7 no necesita dos entradas fParam si dos caracteres terminan usando
        # exactamente el mismo sprite. Compartir índice (p. ej. variantes idénticas
        # de I/l en algunos atlas) ahorra slots y ayuda a mantener el DAR in-place.
        sig = (glyph.size, glyph.tobytes())
        owner = glyph_signature_owner.get(sig)
        if owner is not None:
            glyph_aliases[ch] = owner
            continue
        glyph_signature_owner[sig] = ch
        glyphs.append((ch, glyph))

    # El límite estructural del formato son 256 fParams. Si la tabla resultante
    # hace crecer el DAR, el inyector EUR puede reconstruir DIR_E.AFS y reubicarlo
    # al final de la ISO sin desplazar ningún archivo existente. Así la libertad de
    # texto no depende del padding accidental que tuviera esta escena concreta.
    max_glyphs_structural = 256
    if len(glyphs) > max_glyphs_structural:
        raise K7Error(
            f'Cinemáticas EUR: esta escena necesita {len(glyphs)} sprites distintos; '
            'el formato DA sólo admite 256. Reduce caracteres únicos excepcionalmente '
            'raros o divide el texto entre líneas.'
        )

    # Primero intenta conservar la altura local. Si el repertorio no cabe, amplía
    # 32→64→128 usando tamaños DIC que ya existen de forma nativa en Killer7 EUR.
    atlas = params = char_to_idx = condensed_chars = None
    pack_errors = []
    start_h = original_atlas.height
    candidate_heights = [h for h in (32, 64, 128) if h >= start_h]
    for candidate_h in candidate_heights:
        try:
            atlas, params, char_to_idx, condensed_chars = _eur_cinematic_pack_glyphs(
                (original_atlas.width, candidate_h), glyphs, bg
            )
            break
        except K7Error as exc:
            pack_errors.append(str(exc))
    if atlas is None:
        raise K7Error(
            'Cinemáticas EUR: el repertorio no cabe ni ampliando el atlas hasta 512x128. '
            + (pack_errors[-1] if pack_errors else '')
        )
    for alias, owner in glyph_aliases.items():
        char_to_idx[alias] = char_to_idx[owner]
    if len(params) > 256:
        raise K7Error(f'Cinemáticas EUR: {len(params)} glifos > máximo estructural 256.')

    # Conserva cabecera, tiempos y campos de cada registro; reescribe char_data de
    # TODAS las líneas para que los nuevos índices densos sean coherentes.
    dat = bytearray(meta['dat'][:meta['param_offset']])
    struct.pack_into('<H', dat, 2, len(params))
    for line, text in enumerate(final_lines):
        codes = _encode_target(text, char_to_idx, max_codes=DA_MAX_CODES)
        off = meta['record_offset'] + line * DA_RECORD_SIZE + 8
        arr = codes + [-2] + [-1] * (DA_CODE_SLOTS - len(codes) - 1)
        struct.pack_into(f'<{DA_CODE_SLOTS}h', dat, off, *arr)
    dat.extend(b''.join(struct.pack('<4H', *p) for p in params))

    dic = _eur_encode_resized_da_dic(meta['dic'], atlas)
    rebuilt = _rebuild_da_container(meta['raw'], bytes(dat), dic)

    # Verificación estructural y de códigos sobre el propio resultado. Algunos
    # caracteres del juego (por ejemplo I/l en ciertos atlas) pueden compartir un
    # bitmap idéntico tras eliminar padding; por eso la prueba correcta es que cada
    # registro conserve exactamente los códigos que acabamos de generar.
    verify = Killer7Project._parse_da_blob(rebuilt)
    if verify['line_count'] != meta['line_count'] or verify['glyph_count'] != len(params):
        raise K7Error('Cinemáticas EUR: la estructura DA recompilada no coincide.')
    for line, text in enumerate(final_lines):
        expected_codes = _encode_target(text, char_to_idx, max_codes=DA_MAX_CODES)
        actual_codes = _eur_da_line_codes(verify, line)
        if actual_codes != expected_codes:
            raise K7Error(
                f'Cinemáticas EUR: verificación de códigos falló en línea {line}.'
            )

    info = {
        'glyph_count_before': meta['glyph_count'],
        'glyph_count': len(params),
        'fallback_chars': sorted(set(fallback_chars)),
        'synthesized_chars': sorted(set(synthesized_chars)),
        'condensed_chars': condensed_chars,
        'aliased_chars': dict(sorted(glyph_aliases.items())),
        'max_glyphs_structural': max_glyphs_structural,
        'atlas_size_before': list(original_atlas.size),
        'atlas_size_after': list(atlas.size),
        'atlas_expanded': atlas.size != original_atlas.size,
        'size_before': len(original),
        'size_after': len(rebuilt),
    }
    for item in changes:
        item['glyph_info'] = info
    return rebuilt, changes, info


def _eur_patch_cinematic_subtitles(
    afs,
    raw_entries,
    names,
    replacements,
    french_bank,
    cinematic_targets: dict[str, str] | None = None,
) -> dict:
    entries = lines_total = translated_lines = 0
    patched_entries = []
    visible = []
    fallback_chars = set()
    synthesized_chars = set()
    extended_bank = _eur_cinematic_extended_bank(afs, raw_entries, french_bank)

    for idx, name, original, meta, lines, idx_to_char, coverage in _eur_cinematic_candidates(
        afs, raw_entries, names, extended_bank
    ):
        entries += 1
        lines_total += len(lines)
        effective = {}
        rows = []
        for line_no, source in enumerate(lines):
            target = _eur_cinematic_target_for(
                idx, line_no, source, cinematic_targets
            )
            rows.append({'line': line_no, 'source': source, 'target': target})
            if target and target != source:
                effective[line_no] = target
        visible.append({
            'afs_index': idx,
            'name': name,
            'line_count': len(lines),
            'coverage': coverage,
            'translations': rows,
        })
        if not effective:
            continue

        base = replacements.get(idx, original)
        base_meta = Killer7Project._parse_da_blob(base)
        # Estos DAR no son modificados por otras capas, pero si en el futuro cambia
        # eso, sólo recompilamos cuando su estructura sigue coincidiendo.
        if base_meta['line_count'] != meta['line_count']:
            raise K7Error(f'Cinemáticas EUR: AFS #{idx} cambió de estructura antes del parche.')
        patched, changes, info = _eur_patch_cinematic_lines(
            base, base_meta, lines, idx_to_char, extended_bank, effective
        )
        if changes:
            replacements[idx] = patched
            translated_lines += len(changes)
            fallback_chars.update(info.get('fallback_chars', []))
            synthesized_chars.update(info.get('synthesized_chars', []))
            patched_entries.append({
                'afs_index': idx,
                'name': name,
                'changes': changes,
                'glyph_info': info,
            })

    return {
        'french_entries': entries,
        'visible_lines': lines_total,
        'translated_lines': translated_lines,
        'pending_lines': max(0, lines_total - translated_lines),
        'patched_entries': patched_entries,
        'fallback_chars': sorted(fallback_chars),
        'synthesized_chars': sorted(synthesized_chars),
        'catalog': visible,
    }


def scan_eur_cinematic_subtitles_from_iso(
    eur_iso: str | Path,
    cinematic_targets: dict[str, str] | None = None,
) -> list[dict]:
    """Catálogo editable de subtítulos cinematográficos franceses desde una ISO EUR."""
    eur_iso = Path(eur_iso).resolve()
    with ISO9660(eur_iso) as iso:
        if not is_compatible_eur_iso(iso):
            raise K7Error('El visor de cinemáticas requiere una ISO con estructura Killer7 EUR SLES_533.66 compatible.')
        afs_node = iso.find(['D_EU', 'DIR_E.AFS'])
        with tempfile.TemporaryDirectory(prefix='killer7_eur_cinema_view_') as td_raw:
            afs_path = Path(td_raw) / 'DIR_E.AFS'
            _eur_copy_iso_node(eur_iso, afs_node, afs_path)
            raw_entries, _no, _ns, _nt, names = _eur_parse_afs(afs_path)
            out = []
            with afs_path.open('rb') as afs:
                base_bank = _eur_da_build_french_glyph_bank(afs, raw_entries, names)
                bank = _eur_cinematic_extended_bank(afs, raw_entries, base_bank)
                for idx, name, _blob, meta, lines, _idx_to_char, coverage in _eur_cinematic_candidates(
                    afs, raw_entries, names, bank
                ):
                    rows = []
                    for line_no, source in enumerate(lines):
                        target = _eur_cinematic_target_for(
                            idx, line_no, source, cinematic_targets
                        )
                        rows.append({
                            'line': line_no,
                            'source': source,
                            'target': target,
                            'translated': bool(target and target != source),
                        })
                    out.append({
                        'afs_index': idx,
                        'name': name,
                        'line_count': meta['line_count'],
                        'glyph_count': meta['glyph_count'],
                        'atlas_size': [meta['width'], meta['height']],
                        'coverage': coverage,
                        'rows': rows,
                    })
            return out


def _eur_patch_mapfontf_spanish(
    french_dic: bytes,
    french_ihe: bytes,
    german_dic: bytes,
    german_ihe: bytes,
) -> tuple[bytes, dict]:
    """Añade el repertorio español a MapFontF reutilizando slots FR.

    MapFontF es la fuente usada por los nombres K7P2 (rutas/localizadores). La
    geometría y MapFontF.IH permanecen intactas: sólo se reemplazan los píxeles
    de caracteres franceses que no se usan en los rótulos españoles.
    """
    _f_start, f_sub = _eur_dic_named_subresource(french_dic, 'MapFontF')
    _g_start, g_sub = _eur_dic_named_subresource(german_dic, 'MapFontG')
    f_atlas = Killer7Project.decode_dic_texture(f_sub).convert('L')
    g_atlas = Killer7Project.decode_dic_texture(g_sub).convert('L')
    _frs, f_recs = _eur_font_ihe_records(french_ihe)
    _grs, g_recs = _eur_font_ihe_records(german_ihe)
    if f_atlas.size != (256, 256) or g_atlas.size != (256, 256):
        raise K7Error(f'MapFont EUR: geometría inesperada F={f_atlas.size} G={g_atlas.size}.')

    builds: dict[int, tuple[str, Image.Image]] = {}
    acute_specs = {
        ord('À'): ('Á', ord('A'), True), ord('Î'): ('Í', ord('I'), True),
        ord('Ô'): ('Ó', ord('O'), True), ord('Û'): ('Ú', ord('U'), True),
        ord('à'): ('á', ord('a'), False), ord('î'): ('í', ord('i'), False),
        ord('ô'): ('ó', ord('o'), False), ord('û'): ('ú', ord('u'), False),
    }
    for donor, (label, base, upper) in acute_specs.items():
        builds[donor] = (label, _eur_tvfont_add_acute(f_atlas, f_recs, base, donor, uppercase=upper))
    builds[ord('Â')] = ('Ñ', _eur_tvfont_add_tilde(f_atlas, f_recs, ord('N'), ord('Â')))
    builds[ord('â')] = ('ñ', _eur_tvfont_add_tilde(f_atlas, f_recs, ord('n'), ord('â')))
    # Ü/ü: copia de la fuente alemana oficial; no se usa tipografía externa.
    for donor, src_code, label in [(ord('Ù'), ord('Ü'), 'Ü'), (ord('ê'), ord('ü'), 'ü')]:
        drec = f_recs[donor]
        src = _eur_ihe_glyph(g_atlas, g_recs, src_code)
        builds[donor] = (label, _eur_tvfont_fit_glyph(src, (drec[3], drec[4])))

    patched_atlas = f_atlas.copy()
    report = []
    for donor, (label, glyph) in builds.items():
        rec = f_recs.get(donor)
        if rec is None:
            raise K7Error(f'MapFontF EUR: falta el slot donante 0x{donor:02X}.')
        _code, x, y, w, h, *_rest = rec
        if glyph.size != (w, h):
            glyph = _eur_tvfont_fit_glyph(glyph, (w, h))
        patched_atlas.paste(0, (x, y, x+w, y+h))
        patched_atlas.paste(glyph, (x, y))
        report.append({'spanish': label, 'encoded_as': chr(donor), 'code': donor, 'rect': [x, y, w, h]})

    patched_sub = _encode_atlas_into_dic(f_sub, patched_atlas)
    out = bytearray(french_dic)
    out[_f_start:_f_start + len(patched_sub)] = patched_sub
    if len(out) != len(french_dic):
        raise K7Error('MapFontF EUR: el DIC cambió de tamaño.')

    verify = Killer7Project.decode_dic_texture(bytes(out[_f_start:])).convert('L')
    for donor, (label, _glyph) in builds.items():
        rec = f_recs[donor]
        _code, x, y, w, h, *_rest = rec
        if verify.crop((x, y, x+w, y+h)).getbbox() is None:
            raise K7Error(f'MapFontF EUR: el glifo {label!r} quedó vacío tras el round-trip.')
    return bytes(out), {
        'font': 'MapFontF', 'atlas': list(f_atlas.size), 'patched_glyphs': report,
        'dic_size_unchanged': len(out), 'ihe_unchanged': True,
    }

def _eur_rebuild_afs(source_afs: Path, output_afs: Path, replacements: dict[int, bytes]) -> dict:
    """Reconstruye DIR_E.AFS con el empaquetado secuencial conservador de v1.7.7.172/175.

    Las entradas se escriben siempre en orden de índice y sus offsets físicos son
    monótonos. No se fijan islas ni offsets retail dentro del AFS reconstruido.
    Los loaders que necesiten posiciones físicas retail se atienden mediante el
    runtime shadow del extent original de la ISO, no deformando el AFS principal.
    """
    raw_entries, _old_name_off, name_size, name_table, _names = _eur_parse_afs(source_afs)
    count = len(raw_entries)
    header_size = 8 + 8 * count + 8
    first_data = _eur_align(header_size)

    new_entries: list[tuple[int, int]] = []
    pos = first_data
    for i in range(count):
        size = len(replacements[i]) if i in replacements else int(raw_entries[i][1])
        new_entries.append((pos, size))
        pos = _eur_align(pos + size)

    # La tabla de nombres queda después de todos los payloads, igual que en el
    # reconstructor secuencial previo al experimento stable/pinned offsets.
    new_name_off = _eur_align(pos)
    logical_size = new_name_off + name_size
    original_size = source_afs.stat().st_size
    output_physical_size = max(original_size, logical_size)

    # Guarda explícita v178: nunca volver a generar offsets no monótonos aquí.
    for i in range(1, count):
        prev_off, prev_size = new_entries[i - 1]
        off, _size = new_entries[i]
        if off < _eur_align(prev_off + prev_size):
            raise K7Error(f'Base EUR: AFS secuencial no monótono entre #{i-1} y #{i}.')

    with source_afs.open('rb') as src, output_afs.open('wb') as dst:
        dst.write(b'AFS\0')
        dst.write(struct.pack('<I', count))
        for off, size in new_entries:
            dst.write(struct.pack('<II', off, size))
        dst.write(struct.pack('<II', new_name_off, name_size))
        if dst.tell() < first_data:
            dst.write(b'\0' * (first_data - dst.tell()))

        for i, (off, size) in enumerate(new_entries):
            if dst.tell() < off:
                dst.write(b'\0' * (off - dst.tell()))
            elif dst.tell() != off:
                raise K7Error(f'Base EUR: posición secuencial inesperada al reconstruir AFS #{i}.')
            data = replacements[i] if i in replacements else _eur_read_entry(src, raw_entries, i)
            if len(data) != size:
                raise K7Error(f'Base francesa: tamaño inconsistente al reconstruir AFS #{i}.')
            dst.write(data)

        if dst.tell() < new_name_off:
            dst.write(b'\0' * (new_name_off - dst.tell()))
        dst.write(name_table)
        if dst.tell() < output_physical_size:
            dst.write(b'\0' * (output_physical_size - dst.tell()))

    # Readback estructural: cada entrada debe conservar orden físico y payload.
    vr_entries, *_ = _eur_parse_afs(output_afs)
    previous_end = first_data
    with output_afs.open('rb') as check, source_afs.open('rb') as original_check:
        for i, (off, size) in enumerate(vr_entries):
            if int(off) < int(previous_end):
                raise K7Error(f'Base EUR: AFS final perdió el orden secuencial en #{i}.')
            expected = replacements[i] if i in replacements else _eur_read_entry(original_check, raw_entries, i)
            got = _eur_read_entry(check, vr_entries, i)
            if got != expected:
                raise K7Error(f'Base EUR: readback secuencial falló en AFS #{i}.')
            previous_end = _eur_align(int(off) + int(size))

    return {
        'original_size': original_size,
        'logical_size': logical_size,
        'output_size': output_afs.stat().st_size,
        'grew_by': max(0, output_physical_size - original_size),
        'padding_after_logical': output_physical_size - logical_size,
        'name_table_offset': new_name_off,
        'layout': 'sequential-v172',
        'offsets_monotonic': True,
        'pinned_islands': [],
    }



# Fuente TV de la rama francesa EUR.
#
# Algunas pantallas TV cargan TVFontF. Los objetivos Heaven Smile comprobados en
# SLES_533.66 cargan st00Font y Blood Room usa BloodFontF; no deben confundirse.
# TVFontF y BloodFontF comparten varios códigos donor para acentos/signos.
# La fuente francesa trae ASCII + acentos franceses, pero no los caracteres
# españoles á í ó ú ñ ni ¿/¡. Escribir esos códigos literalmente deja huecos. Para no cambiar la estructura
# IHE (que contiene índices espaciales además de los registros), reutilizamos
# códigos franceses que ya tienen slots seguros y sustituimos sus bitmaps por
# glifos españoles. É/é ya existen y se conservan.
_EUR_TVFONT_ES_CODEMAP = {
    'Á': 'À', 'Í': 'Î', 'Ó': 'Ô', 'Ú': 'Û', 'Ñ': 'Â', 'Ü': 'Ù',
    'á': 'à', 'í': 'î', 'ó': 'ô', 'ú': 'û', 'ñ': 'â', 'ü': 'ê',
    '¿': 'Ç', '¡': 'È',
}

# DIRECTO EUR que necesita una redacción específica en español.
#
# El bloque 9001 corresponde a los mensajes de Blood Room y usa BloodFontF.
# Se mantiene fuera del manifiesto USA para no romper la compilación de la rama
# SLUS (slots/fuente distintos), pero «Inyectar Textos» EUR aplica estos targets
# sobre la columna francesa verificada.
# v1.7.7.135 — catálogo completo de textos de MAPA.
# El inglés es la referencia semántica, pero cada item se aplica únicamente a
# la columna/slot francés de SLES_533.66 o S01M-S07M. Se incluyen también los
# nombres cuyo español coincide con el inglés para impedir que sobreviva una
# localización francesa alternativa (p.ej. Philadelphie).
_EUR_MAP_DIRECT_PATCH_ITEMS = [{'unit_id': 'k7-9006-00-00', 'source': 'MAP', 'target': 'MAPA', 'iso_path': 'SLES_533.66', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9006-01-00', 'source': 'Overpass', 'target': 'Paso elevado', 'iso_path': 'SLES_533.66', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9006-02-00',
  'source': "Garcian's Trailerhouse",
  'target': 'Caravana de Garcian',
  'iso_path': 'SLES_533.66',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9006-03-00', 'source': 'Horizon Tower', 'target': 'Torre Horizon', 'iso_path': 'SLES_533.66', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9006-04-00',
  'source': 'Elementary School',
  'target': 'Escuela primaria',
  'iso_path': 'SLES_533.66',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9006-05-00', 'source': 'ISZK-LAND', 'target': 'ISZK-LAND', 'iso_path': 'SLES_533.66', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9006-06-00',
  'source': 'Blackburn Residence',
  'target': 'Residencia Blackburn',
  'iso_path': 'SLES_533.66',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9006-07-00',
  'source': 'Department of Defense',
  'target': 'Departamento de Defensa',
  'iso_path': 'SLES_533.66',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9006-08-00',
  'source': 'Restaurant Fukushima',
  'target': 'Restaurante Fukushima',
  'iso_path': 'SLES_533.66',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9006-09-00', 'source': 'FukusimaAtoti', 'target': 'FukusimaAtoti', 'iso_path': 'SLES_533.66', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9006-10-00', 'source': 'Coffee Shop', 'target': 'Cafetería', 'iso_path': 'SLES_533.66', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9006-11-00', 'source': 'KAKU Building', 'target': 'Edificio KAKU', 'iso_path': 'SLES_533.66', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9006-12-00', 'source': 'InterCity', 'target': 'InterCity', 'iso_path': 'SLES_533.66', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9006-13-00', 'source': 'Street', 'target': 'Calle', 'iso_path': 'SLES_533.66', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9006-14-00', 'source': 'Broadway', 'target': 'Broadway', 'iso_path': 'SLES_533.66', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9006-15-00', 'source': 'Union Hotel', 'target': 'Hotel Union', 'iso_path': 'SLES_533.66', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9006-16-00',
  'source': 'Battleship Isle',
  'target': 'Isla Battleship',
  'iso_path': 'SLES_533.66',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9006-17-00', 'source': 'Washington', 'target': 'Washington', 'iso_path': 'SLES_533.66', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9006-18-00', 'source': 'D.C.', 'target': 'D.C.', 'iso_path': 'SLES_533.66', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9006-19-00', 'source': 'Central Area', 'target': 'Zona central', 'iso_path': 'SLES_533.66', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9006-20-00', 'source': 'Dominican', 'target': 'Dominican', 'iso_path': 'SLES_533.66', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9006-21-00', 'source': 'Manhattan', 'target': 'Manhattan', 'iso_path': 'SLES_533.66', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9006-22-00', 'source': 'Philadelphia', 'target': 'Filadelfia', 'iso_path': 'SLES_533.66', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9006-23-00', 'source': 'World Map', 'target': 'Mapa mundial', 'iso_path': 'SLES_533.66', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9006-24-00',
  'source': 'Suburb, Seattle',
  'target': 'Afueras de Seattle',
  'iso_path': 'SLES_533.66',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9006-25-00', 'source': 'Main Area', 'target': 'Zona principal', 'iso_path': 'SLES_533.66', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9006-26-00',
  'source': 'Mt.Area, Seattle',
  'target': 'Zona montañosa, Seattle',
  'iso_path': 'SLES_533.66',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9006-27-00',
  'source': 'National Defense Sector',
  'target': 'Sector de Defensa Nacional',
  'iso_path': 'SLES_533.66',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9006-28-00',
  'source': 'City center, Philadelphia',
  'target': 'Centro de Filadelfia',
  'iso_path': 'SLES_533.66',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9006-29-00', 'source': 'United States', 'target': 'Estados Unidos', 'iso_path': 'SLES_533.66', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9006-30-00', 'source': 'Building', 'target': 'Edificio', 'iso_path': 'SLES_533.66', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9006-31-00', 'source': 'Fitness Club', 'target': 'Gimnasio', 'iso_path': 'SLES_533.66', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9006-32-00', 'source': 'NewYork', 'target': 'Nueva York', 'iso_path': 'SLES_533.66', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9006-33-00', 'source': 'Caribbean', 'target': 'Caribe', 'iso_path': 'SLES_533.66', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9006-34-00', 'source': 'Texas', 'target': 'Texas', 'iso_path': 'SLES_533.66', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9006-35-00', 'source': 'Northeast', 'target': 'Noreste', 'iso_path': 'SLES_533.66', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9006-36-00',
  'source': 'Urban Area, Seattle',
  'target': 'Zona urbana de Seattle',
  'iso_path': 'SLES_533.66',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9006-37-00', 'source': 'Shanghai', 'target': 'Shanghái', 'iso_path': 'SLES_533.66', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9101-00-00',
  'source': 'Main Gate',
  'target': 'Entrada principal',
  'iso_path': 'MODULES/BIN/S01M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9101-01-00',
  'source': 'Front of the foyer',
  'target': 'Ante vestíbulo',
  'iso_path': 'MODULES/BIN/S01M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9101-02-00', 'source': 'Foyer', 'target': 'Vestíbulo', 'iso_path': 'MODULES/BIN/S01M.BIN', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9101-03-00', 'source': 'Courtyard', 'target': 'Patio', 'iso_path': 'MODULES/BIN/S01M.BIN', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9101-04-00',
  'source': 'Courtyard roof',
  'target': 'Azotea del patio',
  'iso_path': 'MODULES/BIN/S01M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9101-05-00',
  'source': 'Room of two Deva kings',
  'target': 'Sala de los dos reyes Deva',
  'iso_path': 'MODULES/BIN/S01M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9101-06-00', 'source': 'Lobby', 'target': 'Vestíbulo', 'iso_path': 'MODULES/BIN/S01M.BIN', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9101-07-00',
  'source': 'TeaRoom Passage',
  'target': 'Paso salón té',
  'iso_path': 'MODULES/BIN/S01M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9101-08-00',
  'source': 'Waiting Room',
  'target': 'Sala de espera',
  'iso_path': 'MODULES/BIN/S01M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9101-09-00', 'source': 'Large hall', 'target': 'Gran salón', 'iso_path': 'MODULES/BIN/S01M.BIN', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9101-10-00',
  'source': 'Special Room',
  'target': 'Sala especial',
  'iso_path': 'MODULES/BIN/S01M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9101-11-00',
  'source': 'Instrument Room',
  'target': 'Sala instrum.',
  'iso_path': 'MODULES/BIN/S01M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9101-12-00',
  'source': 'Detached building',
  'target': 'Edificio anexo',
  'iso_path': 'MODULES/BIN/S01M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9101-13-00', 'source': 'East Room', 'target': 'Sala este', 'iso_path': 'MODULES/BIN/S01M.BIN', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9101-14-00', 'source': 'West Room', 'target': 'Sala oeste', 'iso_path': 'MODULES/BIN/S01M.BIN', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9101-15-00', 'source': 'South Room', 'target': 'Sala sur', 'iso_path': 'MODULES/BIN/S01M.BIN', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9101-16-00', 'source': 'North Room', 'target': 'Sala norte', 'iso_path': 'MODULES/BIN/S01M.BIN', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9101-17-00',
  'source': 'Art collection',
  'target': 'Colección de arte',
  'iso_path': 'MODULES/BIN/S01M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9101-18-00', 'source': 'Hallway', 'target': 'Pasillo', 'iso_path': 'MODULES/BIN/S01M.BIN', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9101-19-00',
  'source': 'GuestRoom Alley',
  'target': 'Pasillo de huéspedes',
  'iso_path': 'MODULES/BIN/S01M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9101-20-00',
  'source': 'Vinculum Gate',
  'target': 'Puerta Vinculum',
  'iso_path': 'MODULES/BIN/S01M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9101-21-00', 'source': 'Stairs', 'target': 'Escaleras', 'iso_path': 'MODULES/BIN/S01M.BIN', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9101-22-00', 'source': 'Rest Room', 'target': 'Aseo', 'iso_path': 'MODULES/BIN/S01M.BIN', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9101-23-00', 'source': 'Passage', 'target': 'Paso', 'iso_path': 'MODULES/BIN/S01M.BIN', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9101-24-00',
  'source': "Owner's room",
  'target': 'Sala del propietario',
  'iso_path': 'MODULES/BIN/S01M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9101-25-00',
  'source': 'Kaku bldg. Entrance',
  'target': 'Entrada edificio Kaku',
  'iso_path': 'MODULES/BIN/S01M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9101-26-00', 'source': '1F Hallway', 'target': 'Pasillo P1', 'iso_path': 'MODULES/BIN/S01M.BIN', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9101-27-00',
  'source': 'Building Manager Room',
  'target': 'Sala encargado',
  'iso_path': 'MODULES/BIN/S01M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9101-28-00', 'source': 'Basement', 'target': 'Sótano', 'iso_path': 'MODULES/BIN/S01M.BIN', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9101-29-00', 'source': '2F Hallway', 'target': 'Pasillo P2', 'iso_path': 'MODULES/BIN/S01M.BIN', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9101-30-00', 'source': '3F Hallway', 'target': 'Pasillo P3', 'iso_path': 'MODULES/BIN/S01M.BIN', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9101-31-00', 'source': '4F Hallway', 'target': 'Pasillo P4', 'iso_path': 'MODULES/BIN/S01M.BIN', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9101-32-00',
  'source': '4F Elevator Hall',
  'target': 'Ascensores planta 4',
  'iso_path': 'MODULES/BIN/S01M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9101-33-00',
  'source': 'Mah-jongg room',
  'target': 'Sala de mahjong',
  'iso_path': 'MODULES/BIN/S01M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9101-34-00', 'source': 'Roof', 'target': 'Azotea', 'iso_path': 'MODULES/BIN/S01M.BIN', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9101-35-00',
  'source': 'Board Room',
  'target': 'Sala de juntas',
  'iso_path': 'MODULES/BIN/S01M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9102-00-00',
  'source': 'Main Gate',
  'target': 'Entrada principal',
  'iso_path': 'MODULES/BIN/S02M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9102-01-00',
  'source': 'Central Road',
  'target': 'Calle central',
  'iso_path': 'MODULES/BIN/S02M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9102-02-00',
  'source': 'Diner Funcs',
  'target': 'Diner Funcs',
  'iso_path': 'MODULES/BIN/S02M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9102-03-00', 'source': 'Slope', 'target': 'Cuesta', 'iso_path': 'MODULES/BIN/S02M.BIN', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9102-04-00',
  'source': 'Firstlife Maingate',
  'target': 'Entrada de FirstLife',
  'iso_path': 'MODULES/BIN/S02M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9102-05-00', 'source': 'Wilderness', 'target': 'Páramo', 'iso_path': 'MODULES/BIN/S02M.BIN', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9102-06-00',
  'source': 'Emergency Vehicle',
  'target': 'Vehículo emerg.',
  'iso_path': 'MODULES/BIN/S02M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9102-07-00',
  'source': 'Housing Estate',
  'target': 'Urbanización',
  'iso_path': 'MODULES/BIN/S02M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9102-08-00', 'source': 'House', 'target': 'Casa', 'iso_path': 'MODULES/BIN/S02M.BIN', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9102-09-00', 'source': 'Shortcut', 'target': 'Atajo', 'iso_path': 'MODULES/BIN/S02M.BIN', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9103-00-00',
  'source': 'Main Entrance',
  'target': 'Entrada principal',
  'iso_path': 'MODULES/BIN/S03M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9103-01-00', 'source': 'Arcade', 'target': 'Galería', 'iso_path': 'MODULES/BIN/S03M.BIN', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9103-02-00',
  'source': 'ISZK String Quartet',
  'target': 'Cuarteto de cuerda ISZK',
  'iso_path': 'MODULES/BIN/S03M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9103-04-00', 'source': 'Cinema4', 'target': 'Cine 4', 'iso_path': 'MODULES/BIN/S03M.BIN', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9103-05-00', 'source': 'Cinema3', 'target': 'Cine 3', 'iso_path': 'MODULES/BIN/S03M.BIN', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9103-06-00', 'source': 'Cinema2', 'target': 'Cine 2', 'iso_path': 'MODULES/BIN/S03M.BIN', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9103-07-00', 'source': 'Cinema1', 'target': 'Cine 1', 'iso_path': 'MODULES/BIN/S03M.BIN', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9103-08-00',
  'source': 'Freaky Fun House',
  'target': 'Casa de los horrores',
  'iso_path': 'MODULES/BIN/S03M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9103-09-00',
  'source': 'Loop da Loop',
  'target': 'Loop da Loop',
  'iso_path': 'MODULES/BIN/S03M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9103-10-00',
  'source': "Squeaker's Attack!",
  'target': '¡Ataque de Squeaker!',
  'iso_path': 'MODULES/BIN/S03M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9103-11-00',
  'source': 'Burning Hot Hell!',
  'target': '¡Infierno abrasador!',
  'iso_path': 'MODULES/BIN/S03M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9103-12-00',
  'source': 'Spinny-Spinny',
  'target': 'Gira-Gira',
  'iso_path': 'MODULES/BIN/S03M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9103-13-00',
  'source': 'Killer Ted Mansion 1F',
  'target': 'Mansión Killer Ted planta 1',
  'iso_path': 'MODULES/BIN/S03M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9103-14-00',
  'source': 'Killer Ted Mansion 2F',
  'target': 'Mansión Killer Ted planta 2',
  'iso_path': 'MODULES/BIN/S03M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9103-15-00',
  'source': 'Killer Ted Mansion 3F',
  'target': 'Mansión Killer Ted planta 3',
  'iso_path': 'MODULES/BIN/S03M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9103-16-00',
  'source': 'Killer Ted Mansion TOP',
  'target': 'Azotea de Mansión Killer Ted',
  'iso_path': 'MODULES/BIN/S03M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9103-17-00', 'source': 'Passage', 'target': 'Paso', 'iso_path': 'MODULES/BIN/S03M.BIN', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9103-18-00',
  'source': 'Adventure Plaza',
  'target': 'Plaza Aventura',
  'iso_path': 'MODULES/BIN/S03M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9103-19-00',
  'source': 'Vinculum Gate',
  'target': 'Puerta Vinculum',
  'iso_path': 'MODULES/BIN/S03M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9103-20-00', 'source': 'Lobby', 'target': 'Vestíbulo', 'iso_path': 'MODULES/BIN/S03M.BIN', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9103-21-00',
  'source': 'Parking Lot',
  'target': 'Aparcamiento',
  'iso_path': 'MODULES/BIN/S03M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9103-22-00',
  'source': 'Under the Iron Tower',
  'target': 'Bajo la Torre de Hierro',
  'iso_path': 'MODULES/BIN/S03M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9103-23-00', 'source': 'Entrance', 'target': 'Entrada', 'iso_path': 'MODULES/BIN/S03M.BIN', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9103-24-00', 'source': 'Garden', 'target': 'Jardín', 'iso_path': 'MODULES/BIN/S03M.BIN', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9103-25-00', 'source': 'Garage', 'target': 'Garaje', 'iso_path': 'MODULES/BIN/S03M.BIN', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9103-26-00',
  'source': 'Main Room',
  'target': 'Sala principal',
  'iso_path': 'MODULES/BIN/S03M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9103-27-00',
  'source': 'Courtyard passage',
  'target': 'Pasillo del patio',
  'iso_path': 'MODULES/BIN/S03M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9103-28-00', 'source': 'Hallway', 'target': 'Pasillo', 'iso_path': 'MODULES/BIN/S03M.BIN', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9103-29-00', 'source': 'Bedroom', 'target': 'Dormitorio', 'iso_path': 'MODULES/BIN/S03M.BIN', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9103-30-00', 'source': 'Hall', 'target': 'Salón', 'iso_path': 'MODULES/BIN/S03M.BIN', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9103-31-00', 'source': 'Pool', 'target': 'Piscina', 'iso_path': 'MODULES/BIN/S03M.BIN', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9103-32-00',
  'source': 'Hidden passage',
  'target': 'Pasadizo oculto',
  'iso_path': 'MODULES/BIN/S03M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9103-33-00',
  'source': 'Stuffed Animal Room',
  'target': 'Sala de animales disecados',
  'iso_path': 'MODULES/BIN/S03M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9104-00-00', 'source': 'Campanile', 'target': 'Campanario', 'iso_path': 'MODULES/BIN/S04M.BIN', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9104-01-00',
  'source': 'Back of the Campanile',
  'target': 'Detrás del campanario',
  'iso_path': 'MODULES/BIN/S04M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9104-02-00',
  'source': 'Lost Town',
  'target': 'Pueblo perdido',
  'iso_path': 'MODULES/BIN/S04M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9104-03-00', 'source': 'Avenue', 'target': 'Avenida', 'iso_path': 'MODULES/BIN/S04M.BIN', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9104-04-00',
  'source': 'Housing Estate',
  'target': 'Urbanización',
  'iso_path': 'MODULES/BIN/S04M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9104-05-00',
  'source': '1F Shrine',
  'target': 'Santuario P1',
  'iso_path': 'MODULES/BIN/S04M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9104-06-00',
  'source': '2F Shrine',
  'target': 'Santuario P2',
  'iso_path': 'MODULES/BIN/S04M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9104-07-00',
  'source': 'Shrine Alley',
  'target': 'Calle santuario',
  'iso_path': 'MODULES/BIN/S04M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9104-08-00',
  'source': 'Old Shrine',
  'target': 'Santuario antiguo',
  'iso_path': 'MODULES/BIN/S04M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9104-09-00',
  'source': 'Waiting Room',
  'target': 'Sala de espera',
  'iso_path': 'MODULES/BIN/S04M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9104-10-00',
  'source': 'Grand Stairs',
  'target': 'Gran escalera',
  'iso_path': 'MODULES/BIN/S04M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9104-11-00',
  'source': 'Housing Street',
  'target': 'Calle residencial',
  'iso_path': 'MODULES/BIN/S04M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9104-12-00', 'source': 'Atelier', 'target': 'Taller', 'iso_path': 'MODULES/BIN/S04M.BIN', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9104-13-00', 'source': 'Stairs', 'target': 'Escaleras', 'iso_path': 'MODULES/BIN/S04M.BIN', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9104-14-00',
  'source': 'Windmill plaza',
  'target': 'Plaza del molino',
  'iso_path': 'MODULES/BIN/S04M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9104-15-00',
  'source': "Entrance to Trevor's home",
  'target': 'Entrada a casa de Trevor',
  'iso_path': 'MODULES/BIN/S04M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9104-16-00', 'source': 'Hill', 'target': 'Colina', 'iso_path': 'MODULES/BIN/S04M.BIN', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9104-17-00',
  'source': "Trevor's Corridor",
  'target': 'Pasillo de Trevor',
  'iso_path': 'MODULES/BIN/S04M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9104-18-00', 'source': 'BroadWay', 'target': 'BroadWay', 'iso_path': 'MODULES/BIN/S04M.BIN', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9104-19-00', 'source': 'New Stage', 'target': 'Nueva zona', 'iso_path': 'MODULES/BIN/S04M.BIN', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9105-00-00', 'source': 'Lobby', 'target': 'Vestíbulo', 'iso_path': 'MODULES/BIN/S05M.BIN', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9105-01-00', 'source': 'Front', 'target': 'Frente', 'iso_path': 'MODULES/BIN/S05M.BIN', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9105-02-00', 'source': '2F Hallway', 'target': 'Pasillo P2', 'iso_path': 'MODULES/BIN/S05M.BIN', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9105-03-00', 'source': '3F Hallway', 'target': 'Pasillo P3', 'iso_path': 'MODULES/BIN/S05M.BIN', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9105-04-00', 'source': '4F Hallway', 'target': 'Pasillo P4', 'iso_path': 'MODULES/BIN/S05M.BIN', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9105-05-00', 'source': '5F Hallway', 'target': 'Pasillo P5', 'iso_path': 'MODULES/BIN/S05M.BIN', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9105-06-00', 'source': '6F Hallway', 'target': 'Pasillo P6', 'iso_path': 'MODULES/BIN/S05M.BIN', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9105-07-00', 'source': '7F Hallway', 'target': 'Pasillo P7', 'iso_path': 'MODULES/BIN/S05M.BIN', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9105-08-00', 'source': 'Roof', 'target': 'Azotea', 'iso_path': 'MODULES/BIN/S05M.BIN', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9105-09-00', 'source': 'Suite', 'target': 'Suite', 'iso_path': 'MODULES/BIN/S05M.BIN', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9105-10-00',
  'source': 'Vinculum Gate',
  'target': 'Puerta Vinculum',
  'iso_path': 'MODULES/BIN/S05M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9105-11-00',
  'source': '2F GuestRoom',
  'target': 'Huéspedes planta 2',
  'iso_path': 'MODULES/BIN/S05M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9105-12-00',
  'source': '3F GuestRoom',
  'target': 'Huéspedes planta 3',
  'iso_path': 'MODULES/BIN/S05M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9105-13-00',
  'source': '4F GuestRoom',
  'target': 'Huéspedes planta 4',
  'iso_path': 'MODULES/BIN/S05M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9105-14-00',
  'source': '5F GuestRoom',
  'target': 'Huéspedes planta 5',
  'iso_path': 'MODULES/BIN/S05M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9105-15-00',
  'source': '6F GuestRoom',
  'target': 'Huéspedes planta 6',
  'iso_path': 'MODULES/BIN/S05M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9105-16-00', 'source': 'Entrance', 'target': 'Entrada', 'iso_path': 'MODULES/BIN/S05M.BIN', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9105-17-00', 'source': '1F Hallway', 'target': 'Pasillo P1', 'iso_path': 'MODULES/BIN/S05M.BIN', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9105-18-00',
  'source': '2F OpenSpace',
  'target': 'Espacio abierto planta 2',
  'iso_path': 'MODULES/BIN/S05M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9105-19-00', 'source': 'Courtyard', 'target': 'Patio', 'iso_path': 'MODULES/BIN/S05M.BIN', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9105-20-00', 'source': 'Gymnasium', 'target': 'Gimnasio', 'iso_path': 'MODULES/BIN/S05M.BIN', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9105-21-00',
  'source': 'L2F#Classroom',
  'target': 'L2F#Aula',
  'iso_path': 'MODULES/BIN/S05M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9105-22-00',
  'source': 'L3A#Classroom',
  'target': 'L3A#Aula',
  'iso_path': 'MODULES/BIN/S05M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9105-23-00',
  'source': 'L4A#Classroom',
  'target': 'L4A#Aula',
  'iso_path': 'MODULES/BIN/S05M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9105-24-00',
  'source': 'L3F#Classroom',
  'target': 'L3F#Aula',
  'iso_path': 'MODULES/BIN/S05M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9105-25-00',
  'source': 'L3D#Classroom',
  'target': 'L3D#Aula',
  'iso_path': 'MODULES/BIN/S05M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9105-26-00',
  'source': 'L4B#Classroom',
  'target': 'L4B#Aula',
  'iso_path': 'MODULES/BIN/S05M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9105-27-00',
  'source': 'L3C#Classroom',
  'target': 'L3C#Aula',
  'iso_path': 'MODULES/BIN/S05M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9105-28-00',
  'source': 'Data Room',
  'target': 'Sala de datos',
  'iso_path': 'MODULES/BIN/S05M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9105-29-00',
  'source': "Woman's Restroom",
  'target': 'Aseo de mujeres',
  'iso_path': 'MODULES/BIN/S05M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9105-30-00',
  'source': "Principal's Office",
  'target': 'Despacho del director',
  'iso_path': 'MODULES/BIN/S05M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9105-31-00',
  'source': "Chairman's office",
  'target': 'Despacho del presidente',
  'iso_path': 'MODULES/BIN/S05M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9105-32-00', 'source': 'Cafeteria', 'target': 'Cafetería', 'iso_path': 'MODULES/BIN/S05M.BIN', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9105-33-00', 'source': 'New Stage', 'target': 'Nueva zona', 'iso_path': 'MODULES/BIN/S05M.BIN', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9106-00-00', 'source': 'Entrance', 'target': 'Entrada', 'iso_path': 'MODULES/BIN/S06M.BIN', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9106-01-00', 'source': 'Apartment', 'target': 'Apartamento', 'iso_path': 'MODULES/BIN/S06M.BIN', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9106-02-00',
  'source': 'Open Space',
  'target': 'Espacio abierto',
  'iso_path': 'MODULES/BIN/S06M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9106-03-00', 'source': 'Stairs', 'target': 'Escaleras', 'iso_path': 'MODULES/BIN/S06M.BIN', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9106-04-00',
  'source': "Harman's Room",
  'target': 'Cuarto de Harman',
  'iso_path': 'MODULES/BIN/S06M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9106-05-00', 'source': 'Basement', 'target': 'Sótano', 'iso_path': 'MODULES/BIN/S06M.BIN', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9107-00-00', 'source': 'Lobby', 'target': 'Vestíbulo', 'iso_path': 'MODULES/BIN/S07M.BIN', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9107-01-00',
  'source': 'Elevator Hall',
  'target': 'Ascensores',
  'iso_path': 'MODULES/BIN/S07M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9107-02-00',
  'source': 'Parking Lot',
  'target': 'Aparcamiento',
  'iso_path': 'MODULES/BIN/S07M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9107-03-00', 'source': 'Entrance', 'target': 'Entrada', 'iso_path': 'MODULES/BIN/S07M.BIN', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9107-04-00', 'source': 'Tutorial', 'target': 'Tutorial', 'iso_path': 'MODULES/BIN/S07M.BIN', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9107-05-00',
  'source': '2F Stairs',
  'target': 'Escaleras P2',
  'iso_path': 'MODULES/BIN/S07M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9107-06-00', 'source': '2F Hallway', 'target': 'Pasillo P2', 'iso_path': 'MODULES/BIN/S07M.BIN', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9107-07-00',
  'source': 'Stairs For Residents',
  'target': 'Escaleras de residentes',
  'iso_path': 'MODULES/BIN/S07M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9107-08-00',
  'source': '3F Stairs',
  'target': 'Escaleras P3',
  'iso_path': 'MODULES/BIN/S07M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9107-09-00', 'source': 'Hall', 'target': 'Salón', 'iso_path': 'MODULES/BIN/S07M.BIN', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9107-10-00', 'source': 'Library', 'target': 'Biblioteca', 'iso_path': 'MODULES/BIN/S07M.BIN', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9107-11-00',
  'source': 'Laundry Room',
  'target': 'Lavandería',
  'iso_path': 'MODULES/BIN/S07M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9107-12-00', 'source': 'Toilet', 'target': 'Aseo', 'iso_path': 'MODULES/BIN/S07M.BIN', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9107-13-00',
  'source': '4F Stairs',
  'target': 'Escaleras P4',
  'iso_path': 'MODULES/BIN/S07M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9107-14-00',
  'source': 'Stairway Hall',
  'target': 'Rellano de escaleras',
  'iso_path': 'MODULES/BIN/S07M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9107-15-00', 'source': '4F Hallway', 'target': 'Pasillo P4', 'iso_path': 'MODULES/BIN/S07M.BIN', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9107-16-00', 'source': '5F Hallway', 'target': 'Pasillo P5', 'iso_path': 'MODULES/BIN/S07M.BIN', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9107-17-00',
  'source': 'Vinculum Gate',
  'target': 'Puerta Vinculum',
  'iso_path': 'MODULES/BIN/S07M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9107-18-00', 'source': 'Elevator', 'target': 'Ascensor', 'iso_path': 'MODULES/BIN/S07M.BIN', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9107-19-00', 'source': '6F Hallway', 'target': 'Pasillo P6', 'iso_path': 'MODULES/BIN/S07M.BIN', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9107-20-00',
  'source': 'Dance Hall',
  'target': 'Salón de baile',
  'iso_path': 'MODULES/BIN/S07M.BIN',
  'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9107-21-00', 'source': 'Passage', 'target': 'Paso', 'iso_path': 'MODULES/BIN/S07M.BIN', 'kind': 'eur-map-direct'},
 {'unit_id': 'k7-9107-22-00',
  'source': 'Top-floor',
  'target': 'Última planta',
  'iso_path': 'MODULES/BIN/S07M.BIN',
  'kind': 'eur-map-direct'}]
_EUR_MAP_DIRECT_TARGETS = {row['unit_id']: row['target'] for row in _EUR_MAP_DIRECT_PATCH_ITEMS}

_EUR_DIRECT_MISSION_TARGET_OVERRIDES = {
    'k7-9001-00-00': 'Línea de sangre',
    'k7-9001-01-00': '¡Ten sangre!',
    'k7-9001-02-00': '¡Tienes SANGRE!',
    'k7-9001-03-00': '¿Dónde está la sangre?',
    'k7-9001-04-00': '¿Tienes sangre?',
    'k7-9001-05-00': '¡Deliciosa, deliciosa sangre!',
    'k7-9001-06-00': '¡Sangrienta sea!',
    'k7-9001-07-00': 'Sangre y nada más',
    'k7-9005-30-00': 'alto cargo del Partido Demócrata.',
}

# v1.7.7.158 — octava línea real del bloque trilingüe de sangre. El extractor
# histórico la omitía porque `_direct_string_ok()` rechazaba cualquier texto
# que comenzase por `all`. Se añade también de forma sintética a la ruta EUR
# para que las instalaciones con el parche compilado 4759 previo la reciban sin
# tener que regenerar todos los payloads AFS.
_EUR_BLOOD_ROOM_MISSING_ITEM = {
    'unit_id': 'k7-9001-07-00',
    'source': 'all you need is Blood',
    'target': 'Sangre y nada más',
    'iso_path': 'SLUS_211.54',
    'kind': 'eur-blood-room-direct',
}
_EUR_BLOOD_ROOM_EXPECTED_SOURCES = (
    'Blood Line', 'Get blood!', 'You`ve got BLOOD!', 'Where`s the blood?',
    'Got Blood?', 'Tasty, tasty blood!', 'Bloody hell!', 'all you need is Blood',
)

def _eur_verify_blood_room_catalog() -> dict:
    if len(_EUR_BLOOD_ROOM_EXPECTED_SOURCES) != 8:
        raise K7Error('Blood Room EUR: el catálogo debe contener 8 mensajes.')
    if _EUR_BLOOD_ROOM_MISSING_ITEM['source'] != _EUR_BLOOD_ROOM_EXPECTED_SOURCES[-1]:
        raise K7Error('Blood Room EUR: la octava línea no coincide con la fuente verificada.')
    if _EUR_DIRECT_MISSION_TARGET_OVERRIDES.get('k7-9001-07-00') != 'Sangre y nada más':
        raise K7Error('Blood Room EUR: falta el target español de la octava línea.')
    return {
        'count': 8,
        'missing_unit': 'k7-9001-07-00',
        'source': 'all you need is Blood',
        'french': "Du sang et rien d'autre",
        'target': 'Sangre y nada más',
        'french_offset': 0x4F44C0,
        'french_pointer': 0x4B4028,
    }


def _eur_tvfont_encode_spanish(text: str) -> bytes:
    """Codifica español para TVFontF usando los slots franceses reutilizados."""
    remapped = ''.join(_EUR_TVFONT_ES_CODEMAP.get(ch, ch) for ch in str(text))
    try:
        return remapped.encode('latin-1')
    except UnicodeEncodeError as exc:
        raise K7Error(f'TVFontF EUR: carácter no soportado en {text!r}: {exc}') from exc



def _eur_st00font_encode_spanish(text: str) -> bytes:
    """Compatibilidad v1.7.7.160: codec específico de Heaven Smile/st00."""
    return _eur_mission_font_encode_spanish(('k7-9005-14-00',), text)


def _eur_direct_target_bytes(unit_ids, text: str) -> bytes:
    """Codificación de DIRECTO según la fuente/renderer real de cada unidad.

    Las órdenes ``k7-9005-14..30`` usan st00Font..st12Font y el SLES calcula
    ``strlen(texto) >> 1``: por eso se codifican con el mapa de SU fase y se
    rellenan a longitud par. Los textos 9005-00..13 no pertenecen a esta ruta
    de fuente de objetivos y conservan el codec histórico.
    """
    ids = tuple(str(x) for x in unit_ids)
    phase = _eur_mission_objective_phase(ids)
    if phase is not None:
        raw = _eur_mission_font_encode_spanish(ids, text)
        if len(raw) & 1:
            raw += b' '
        return raw

    # Blood Room (9001) usa BloodFontF. Los 9005 previos a las órdenes conservan
    # el comportamiento histórico: no son las stXXFont de la pantalla ORDER.
    if any(uid.startswith(('k7-9001-', 'k7-9005-')) for uid in ids):
        raw = _eur_tvfont_encode_spanish(text)
        if any(uid.startswith('k7-9005-') for uid in ids) and (len(raw) & 1):
            raw += b' '
        return raw
    # Los bloques 9006/9101-9107 son rótulos de MAPA y se renderizan con
    # MapFontF. Sus acentos españoles se codifican en los slots FR reutilizados.
    if any(uid.startswith(('k7-9006-', 'k7-9101-', 'k7-9102-', 'k7-9103-', 'k7-9104-', 'k7-9105-', 'k7-9106-', 'k7-9107-')) for uid in ids):
        return _eur_mapfont_encode_spanish(text)
    return str(text).encode('latin-1')

def _eur_verify_mission_pair_alignment() -> dict:
    """Guardia de release para el renderer de objetivos en pares de bytes."""
    _eur_verify_all_mission_font_codecs()
    checked = []
    for offset, _expected, target, unit_ids in _EUR_DIRECT_FIXED_SLES_SPECS:
        ids = tuple(str(x) for x in unit_ids)
        if not any(uid.startswith('k7-9005-') for uid in ids):
            continue
        raw = _eur_direct_target_bytes(ids, target)
        if len(raw) & 1:
            raise K7Error(
                f'Objetivos EUR: longitud impar tras codec en 0x{offset:X}: '
                f'{target!r} -> {len(raw)} bytes.'
            )
        checked.append((offset, target, len(raw)))
    # Casos que motivaron v1.7.7.154: deben quedar 28 y 24 bytes.
    a = _eur_direct_target_bytes(('k7-9005-14-00',), 'Arrasa la base Heaven Smile')
    b = _eur_direct_target_bytes(('k7-9005-15-00',), 'y captura vivo al jefe.')
    if a != b'Qrra\xe9a la Da\xe9e Heaven Smile ' or len(a) != 28:
        raise K7Error('Objetivos EUR: padding por pares incorrecto para misión 33 línea 1.')
    if b != b"h captura vivG al .efe' " or len(b) != 24:
        raise K7Error('Objetivos EUR: padding por pares incorrecto para misión 33 línea 2.')
    # Este slot ocupa 16 bytes incluyendo NUL. La traducción antigua
    # ``La orden final.`` necesitaba 17 al alinearse; mantener 14 bytes evita
    # desbordar el siguiente literal.
    c = _eur_direct_target_bytes(('k7-9005-25-00',), 'La orden final')
    if c != b'La orden final' or len(c) != 14:
        raise K7Error('Objetivos EUR: la traducción compacta de "La orden final" no cabe en su slot.')
    return {
        'checked_fixed_mission_lines': len(checked),
        'mission33_lengths': [len(a), len(b)],
        'tight_slot_length': len(c),
        'pair_aligned': True,
    }


def _eur_font_ihe_records(ihe: bytes) -> tuple[int, dict[int, tuple[int, ...]]]:
    if len(ihe) < 0x20 or ihe[:8] not in (b'STRIMAGE', b'STRIMAGS'):
        raise K7Error('TVFont EUR: IHE inesperado.')
    count = struct.unpack_from('<I', ihe, 0x18)[0]
    rec_start = len(ihe) - int(count) * 20
    if count <= 0 or rec_start < 0x20:
        raise K7Error('TVFont EUR: tabla IHE fuera de rango.')
    recs = {}
    for i in range(int(count)):
        rec = struct.unpack_from('<10H', ihe, rec_start + i * 20)
        if rec[0] != rec[9]:
            raise K7Error(f'TVFont EUR: registro IHE #{i} inconsistente.')
        recs[int(rec[0])] = tuple(int(x) for x in rec)
    return rec_start, recs


def _eur_dic_named_subresource(dic: bytes, name: str) -> tuple[int, bytes]:
    needle = name.encode('ascii') + b'\0'
    name_off = dic.find(needle)
    if name_off < 0:
        raise K7Error(f'TVFont EUR: no se encontró el recurso {name}.')
    ps2_off = dic.rfind(b'PS2\0', 0, name_off)
    if ps2_off < 0 or ps2_off < 0x34:
        raise K7Error(f'TVFont EUR: cabecera PS2 de {name} no localizada.')
    start = ps2_off - 0x34
    sub = dic[start:]
    info = Killer7Project._dic_texture_info(sub)
    if not info:
        raise K7Error(f'TVFont EUR: textura {name} no reconocida.')
    return start, sub


def _eur_ihe_glyph(atlas: Image.Image, recs: dict[int, tuple[int, ...]], code: int) -> Image.Image:
    rec = recs.get(int(code))
    if rec is None:
        raise K7Error(f'TVFont EUR: glifo 0x{code:02X} ausente.')
    _ch, x, y, w, h, *_rest = rec
    return atlas.crop((x, y, x + w, y + h)).copy()


def _eur_tvfont_compose_base(
    atlas: Image.Image,
    recs: dict[int, tuple[int, ...]],
    base_code: int,
    donor_code: int,
) -> Image.Image:
    donor = recs[donor_code]
    base = _eur_ihe_glyph(atlas, recs, base_code)
    w, h = donor[3], donor[4]
    canvas = Image.new('L', (w, h), 0)
    x = max(0, (w - base.width) // 2)
    y = max(0, h - base.height)
    canvas.paste(base, (x, y))
    return canvas


def _eur_tvfont_acute_mark(atlas: Image.Image, recs: dict[int, tuple[int, ...]], uppercase: bool) -> Image.Image:
    accent_code = ord('É') if uppercase else ord('é')
    base_code = ord('E') if uppercase else ord('e')
    accent = _eur_ihe_glyph(atlas, recs, accent_code)
    base = _eur_ihe_glyph(atlas, recs, base_code)
    top_h = max(1, accent.height - base.height)
    return accent.crop((0, 0, accent.width, top_h)).copy()


def _eur_tvfont_add_acute(
    atlas: Image.Image,
    recs: dict[int, tuple[int, ...]],
    base_code: int,
    donor_code: int,
    *, uppercase: bool,
) -> Image.Image:
    canvas = _eur_tvfont_compose_base(atlas, recs, base_code, donor_code)
    mark = _eur_tvfont_acute_mark(atlas, recs, uppercase)
    # Recorta el blanco lateral de la marca para centrarla sobre letras estrechas.
    bbox = mark.getbbox()
    if bbox:
        mark = mark.crop(bbox)
    x = max(0, min(canvas.width - mark.width, (canvas.width - mark.width) // 2 + 1))
    canvas.paste(mark, (x, 0), mark)
    return canvas


def _eur_tvfont_add_tilde(
    atlas: Image.Image,
    recs: dict[int, tuple[int, ...]],
    base_code: int,
    donor_code: int,
) -> Image.Image:
    canvas = _eur_tvfont_compose_base(atlas, recs, base_code, donor_code)
    draw = ImageDraw.Draw(canvas)
    # Onda de 1 px con dos niveles del propio atlas. Mantiene el aspecto pixelado.
    fg = 238
    mid = 153
    cx = canvas.width // 2
    pts = [(cx-4, 2), (cx-3, 1), (cx-2, 1), (cx-1, 2),
           (cx, 2), (cx+1, 1), (cx+2, 1), (cx+3, 2)]
    pts = [(x, y) for x, y in pts if 0 <= x < canvas.width and 0 <= y < canvas.height]
    for x, y in pts:
        draw.point((x, y), fill=fg)
        if y + 1 < canvas.height:
            draw.point((x, y + 1), fill=max(mid, canvas.getpixel((x, y + 1))))
    return canvas


def _eur_tvfont_fit_glyph(src: Image.Image, size: tuple[int, int]) -> Image.Image:
    w, h = size
    out = Image.new('L', (w, h), 0)
    if src.width > w or src.height > h:
        src = src.resize((min(w, src.width), min(h, src.height)), Image.Resampling.LANCZOS)
    out.paste(src, (max(0, (w-src.width)//2), max(0, h-src.height)))
    return out


def _eur_patch_tvfontf_spanish(
    french_dic: bytes,
    french_ihe: bytes,
    german_dic: bytes,
    german_ihe: bytes,
) -> tuple[bytes, dict]:
    """Convierte slots franceses de TVFontF en el repertorio español necesario.

    No crece ni reordena TVFontF.IHE: sólo cambia píxeles en slots existentes.
    Esto conserva intactos los índices espaciales internos de STRIMAGS.
    """
    _f_start, f_sub = _eur_dic_named_subresource(french_dic, 'TVFontF')
    _g_start, g_sub = _eur_dic_named_subresource(german_dic, 'TVFontG')
    f_atlas = Killer7Project.decode_dic_texture(f_sub).convert('L')
    g_atlas = Killer7Project.decode_dic_texture(g_sub).convert('L')
    _frs, f_recs = _eur_font_ihe_records(french_ihe)
    _grs, g_recs = _eur_font_ihe_records(german_ihe)
    if f_atlas.size != (256, 128) or g_atlas.size != (256, 128):
        raise K7Error(f'TVFont EUR: geometría inesperada F={f_atlas.size} G={g_atlas.size}.')

    # donor -> glifo español real que se dibujará en su rectángulo.
    builds: dict[int, tuple[str, Image.Image]] = {}
    acute_specs = {
        ord('À'): ('Á', ord('A'), True), ord('Î'): ('Í', ord('I'), True),
        ord('Ô'): ('Ó', ord('O'), True), ord('Û'): ('Ú', ord('U'), True),
        ord('à'): ('á', ord('a'), False), ord('î'): ('í', ord('i'), False),
        ord('ô'): ('ó', ord('o'), False), ord('û'): ('ú', ord('u'), False),
    }
    for donor, (label, base, upper) in acute_specs.items():
        builds[donor] = (label, _eur_tvfont_add_acute(f_atlas, f_recs, base, donor, uppercase=upper))

    builds[ord('Â')] = ('Ñ', _eur_tvfont_add_tilde(f_atlas, f_recs, ord('N'), ord('Â')))
    builds[ord('â')] = ('ñ', _eur_tvfont_add_tilde(f_atlas, f_recs, ord('n'), ord('â')))

    # Ü/ü existen en la fuente alemana oficial: se copian sin rasterizar tipografía externa.
    for donor, src_code, label in [(ord('Ù'), ord('Ü'), 'Ü'), (ord('ê'), ord('ü'), 'ü')]:
        drec = f_recs[donor]
        src = _eur_ihe_glyph(g_atlas, g_recs, src_code)
        builds[donor] = (label, _eur_tvfont_fit_glyph(src, (drec[3], drec[4])))

    # Signos de apertura: rotación exacta de los signos ASCII de la misma fuente.
    for donor, src_code, label in [(ord('Ç'), ord('?'), '¿'), (ord('È'), ord('!'), '¡')]:
        drec = f_recs[donor]
        src = _eur_ihe_glyph(f_atlas, f_recs, src_code).transpose(Image.Transpose.ROTATE_180)
        builds[donor] = (label, _eur_tvfont_fit_glyph(src, (drec[3], drec[4])))

    patched_atlas = f_atlas.copy()
    report = []
    for donor, (label, glyph) in builds.items():
        rec = f_recs[donor]
        _code, x, y, w, h, *_rest = rec
        if glyph.size != (w, h):
            glyph = _eur_tvfont_fit_glyph(glyph, (w, h))
        patched_atlas.paste(0, (x, y, x+w, y+h))
        patched_atlas.paste(glyph, (x, y))
        report.append({'spanish': label, 'encoded_as': chr(donor), 'code': donor, 'rect': [x,y,w,h]})

    patched_sub = _encode_atlas_into_dic(f_sub, patched_atlas)
    out = bytearray(french_dic)
    out[_f_start:_f_start + len(patched_sub)] = patched_sub

    # Verificación de round-trip y de que cada slot nuevo contiene píxeles.
    verify = Killer7Project.decode_dic_texture(bytes(out[_f_start:])).convert('L')
    for donor, (label, _glyph) in builds.items():
        rec = f_recs[donor]
        x, y, w, h = rec[1], rec[2], rec[3], rec[4]
        if verify.crop((x,y,x+w,y+h)).getbbox() is None:
            raise K7Error(f'TVFont EUR: el glifo {label} quedó vacío tras recompilar.')
    return bytes(out), {
        'font': 'TVFontF', 'atlas': list(f_atlas.size), 'patched_glyphs': report,
        'encoding_map': dict(_EUR_TVFONT_ES_CODEMAP), 'ihe_changed': False,
    }


# v1.7.7.159 — Blood Room no usa TVFontF: usa BloodFontF dentro de mes_f.dic.
# El STRIMAGS que describe sus glifos es el child 0 de mes_f.dat. Los códigos
# donor son los mismos que en TVFontF, así que las C-strings del SLES no cambian:
# à->á, î->í, ô->ó, Ç->¿ y È->¡. Sólo se sustituyen esos bitmaps del atlas.
def _eur_mes_font_ihe(mes_dat: bytes, expected_count: int | None = None) -> bytes:
    ranges = _eur_dar_child_ranges(mes_dat)
    if len(ranges) < 1:
        raise K7Error('BloodFont EUR: mes_*.dat no contiene un DAR válido.')
    off, size = ranges[0]
    ihe = mes_dat[off:off+size]
    if not ihe.startswith(b'STRIMAGS'):
        raise K7Error('BloodFont EUR: child 0 de mes_*.dat no es STRIMAGS.')
    count = struct.unpack_from('<I', ihe, 0x18)[0]
    if expected_count is not None and int(count) != int(expected_count):
        raise K7Error(
            f'BloodFont EUR: count STRIMAGS inesperado {count}; esperado {expected_count}.'
        )
    return ihe


def _eur_patch_bloodfontf_spanish(french_dic: bytes, french_dat: bytes) -> tuple[bytes, dict]:
    """Añade ¿/¡ y los acentos usados por los 8 mensajes de Blood Room.

    No se modifica mes_f.dat ni su tabla STRIMAGS: reutilizamos cinco slots
    franceses existentes y sólo cambiamos los píxeles de BloodFontF. Así se
    conserva exactamente la estructura, métricas y tamaño de los recursos EUR.
    """
    f_start, f_sub = _eur_dic_named_subresource(french_dic, 'BloodFontF')
    f_atlas = Killer7Project.decode_dic_texture(f_sub).convert('L')
    f_ihe = _eur_mes_font_ihe(french_dat, expected_count=107)
    _rs, f_recs = _eur_font_ihe_records(f_ihe)
    if f_atlas.size != (256, 256):
        raise K7Error(f'BloodFont EUR: geometría F inesperada {f_atlas.size}.')

    required = {
        ord('à'): ('á', ord('a'), 'acute'),
        ord('î'): ('í', ord('i'), 'acute'),
        ord('ô'): ('ó', ord('o'), 'acute'),
        ord('Ç'): ('¿', ord('?'), 'invert'),
        ord('È'): ('¡', ord('!'), 'invert'),
    }
    for donor in required:
        if donor not in f_recs:
            raise K7Error(f'BloodFont EUR: falta donor francés 0x{donor:02X}.')

    builds: dict[int, tuple[str, Image.Image]] = {}
    for donor, (label, base_code, mode) in required.items():
        if mode == 'acute':
            builds[donor] = (
                label,
                _eur_tvfont_add_acute(
                    f_atlas, f_recs, base_code, donor, uppercase=False
                ),
            )
        else:
            drec = f_recs[donor]
            src = _eur_ihe_glyph(f_atlas, f_recs, base_code).transpose(Image.Transpose.ROTATE_180)
            builds[donor] = (label, _eur_tvfont_fit_glyph(src, (drec[3], drec[4])))

    patched_atlas = f_atlas.copy()
    report = []
    for donor, (label, glyph) in builds.items():
        rec = f_recs[donor]
        _code, x, y, w, h, *_rest = rec
        if glyph.size != (w, h):
            glyph = _eur_tvfont_fit_glyph(glyph, (w, h))
        patched_atlas.paste(0, (x, y, x+w, y+h))
        patched_atlas.paste(glyph, (x, y))
        report.append({
            'spanish': label, 'encoded_as': chr(donor), 'code': donor,
            'rect': [x, y, w, h],
        })

    patched_sub = _encode_atlas_into_dic(f_sub, patched_atlas)
    if len(patched_sub) != len(f_sub):
        raise K7Error('BloodFont EUR: BloodFontF cambió de tamaño al recompilar.')
    out = bytearray(french_dic)
    out[f_start:f_start+len(patched_sub)] = patched_sub
    if len(out) != len(french_dic):
        raise K7Error('BloodFont EUR: mes_f.dic cambió de tamaño total.')

    verify = Killer7Project.decode_dic_texture(bytes(out[f_start:])).convert('L')
    for donor, (label, _glyph) in builds.items():
        rec = f_recs[donor]
        x, y, w, h = rec[1], rec[2], rec[3], rec[4]
        if verify.crop((x, y, x+w, y+h)).getbbox() is None:
            raise K7Error(f'BloodFont EUR: el glifo {label} quedó vacío tras recompilar.')

    return bytes(out), {
        'font': 'BloodFontF',
        'atlas': list(f_atlas.size),
        'strimags_count': 107,
        'patched_glyphs': report,
        'encoding_map': {'á':'à', 'í':'î', 'ó':'ô', '¿':'Ç', '¡':'È'},
        'dat_changed': False,
    }


def _eur_verify_bloodfontf_spanish_resources(french_dic: bytes, french_dat: bytes) -> dict:
    patched, info = _eur_patch_bloodfontf_spanish(french_dic, french_dat)
    if len(patched) != len(french_dic):
        raise K7Error('BloodFont EUR: guard de tamaño fallido.')
    if len(info.get('patched_glyphs', [])) != 5:
        raise K7Error('BloodFont EUR: se esperaban cinco glifos españoles.')
    return info


# v1.7.7.180 — Soul Shell real de mes_f.dat.
#
# El savestate s(9), creado desde un arranque limpio de la ISO v179, demuestra
# que el mensaje visible no sale del JMB standalone 77102F. En EE RAM aparece
# otra copia exacta de ``Balle d'âmes reçue`` en el child 2 de ``mes_f.dat``:
# un JMB global de 22 escenas cargado junto a STRIMAGS + MEP. Ese JMB usa su
# propia tabla de 29 glifos; los códigos de la frase se verificaron directamente
# en RAM en 0x01032950. El target español necesita exclusivamente glifos que ya
# existen en esa misma tabla, de modo que sólo hay que reescribir char_data.
_EUR_MES_F_SOUL_SOURCE = "Balle d'âmes reçue"
_EUR_MES_F_SOUL_TARGET = 'Soul Shell hallada'
_EUR_MES_F_SOUL_SOURCE_CODES = (
    20, 0, 17, 17, 4, -4, 18, 14, 21, 22, 4, 11, -4, 9, 4, 23, 7, 4,
)
_EUR_MES_F_SOUL_CHAR_CODES = {
    'S': 25, 'o': 2, 'u': 7, 'l': 17, 'h': 28, 'e': 4, 'a': 0, 'd': 18,
}
# Vecino observado en el mismo JMB; sirve de firma adicional para impedir que
# una revisión diferente de mes_f.dat sea parcheada por coincidencia parcial.
_EUR_MES_F_SCENE8_CODES = (
    20, 0, 9, 9, 12, 24, 9, 4, -4, 18, 16, 3, 9, 7, 12, 3, 4,
)  # ``Barrière détruite``


def _eur_patch_mes_f_soul_shell(french_dat: bytes) -> tuple[bytes, dict]:
    """Parchea ``Balle d'âmes reçue`` en el JMB global de ``mes_f.dat``.

    La operación es deliberadamente in-place: no cambia el tamaño del DAR, los
    offsets de sus children, el número de escenas, la tabla fParams ni ninguna
    textura. Sólo sustituye los 32 s16 de char_data de scene 7 / jimaku 0.
    """
    ranges = _eur_dar_child_ranges(french_dat)
    if len(ranges) != 3:
        raise K7Error(f'mes_f.dat EUR: DAR inesperado ({len(ranges)} children; esperados 3).')

    ihe_off, ihe_size = ranges[0]
    mep_off, mep_size = ranges[1]
    jmb_off, jmb_size = ranges[2]
    ihe = french_dat[ihe_off:ihe_off + ihe_size]
    mep = french_dat[mep_off:mep_off + mep_size]
    jmb = french_dat[jmb_off:jmb_off + jmb_size]

    if not ihe.startswith(b'STRIMAGS') or len(ihe) < 0x1C:
        raise K7Error('mes_f.dat EUR: child 0 no es STRIMAGS.')
    if struct.unpack_from('<I', ihe, 0x18)[0] != 107:
        raise K7Error('mes_f.dat EUR: STRIMAGS no contiene los 107 registros verificados.')
    if not mep.startswith(b'MEP\0'):
        raise K7Error('mes_f.dat EUR: child 1 no es MEP.')
    if len(jmb) < 16:
        raise K7Error('mes_f.dat EUR: JMB global truncado.')

    sn, cn, so, co, to = struct.unpack_from('<hhIII', jmb, 0)
    expected_meta = (22, 29, 104, 151024, 151264)
    if (int(sn), int(cn), int(so), int(co), int(to)) != expected_meta or int(to) != len(jmb):
        raise K7Error(
            'mes_f.dat EUR: layout JMB inesperado; '
            f'obtenido={(int(sn), int(cn), int(so), int(co), int(to), len(jmb))}.'
        )

    def unit_char_off(scene: int, jimaku: int = 0) -> int:
        return int(so) + int(scene) * JMB_SCENE_SIZE + 76 + int(jimaku) * JMB_RECORD_SIZE + 8

    soul_off = unit_char_off(7, 0)
    neighbor_off = unit_char_off(8, 0)
    source_slots = list(struct.unpack_from(f'<{JMB_CODE_SLOTS}h', jmb, soul_off))
    neighbor_slots = list(struct.unpack_from(f'<{JMB_CODE_SLOTS}h', jmb, neighbor_off))

    if -2 not in source_slots or -2 not in neighbor_slots:
        raise K7Error('mes_f.dat EUR: faltan terminadores JMB en las escenas 7/8.')
    source_active = tuple(source_slots[:source_slots.index(-2)])
    neighbor_active = tuple(neighbor_slots[:neighbor_slots.index(-2)])
    if source_active != _EUR_MES_F_SOUL_SOURCE_CODES:
        raise K7Error(
            'mes_f.dat EUR: la unidad Soul Shell no coincide con Balle d\'âmes reçue.'
        )
    if neighbor_active != _EUR_MES_F_SCENE8_CODES:
        raise K7Error('mes_f.dat EUR: la firma vecina Barrière détruite no coincide.')

    try:
        target_codes = [
            -4 if ch == ' ' else _EUR_MES_F_SOUL_CHAR_CODES[ch]
            for ch in _EUR_MES_F_SOUL_TARGET
        ]
    except KeyError as exc:
        raise K7Error(f'mes_f.dat EUR: falta glifo para {exc.args[0]!r}.') from exc
    if len(target_codes) > JMB_MAX_CODES:
        raise K7Error('mes_f.dat EUR: Soul Shell hallada excede el límite JMB.')

    target_slots = target_codes + [-2] + [-1] * (JMB_CODE_SLOTS - len(target_codes) - 1)
    out = bytearray(french_dat)
    abs_off = int(jmb_off) + soul_off
    before = bytes(out)
    struct.pack_into(f'<{JMB_CODE_SLOTS}h', out, abs_off, *target_slots)
    out = bytes(out)

    if len(out) != len(french_dat):
        raise K7Error('mes_f.dat EUR: el parche Soul Shell cambió el tamaño total.')
    # Sólo los 64 bytes de char_data pueden cambiar.
    span = JMB_CODE_SLOTS * 2
    if before[:abs_off] != out[:abs_off] or before[abs_off + span:] != out[abs_off + span:]:
        raise K7Error('mes_f.dat EUR: se modificaron bytes fuera de char_data.')
    verify = list(struct.unpack_from(f'<{JMB_CODE_SLOTS}h', out, abs_off))
    if verify[:verify.index(-2)] != target_codes:
        raise K7Error('mes_f.dat EUR: readback de Soul Shell hallada falló.')

    return out, {
        'resource': 'mes_f.dat',
        'dar_child': 2,
        'jmb_scene': 7,
        'jmb_unit': 0,
        'jmb_char_data_offset': int(jmb_off) + int(soul_off),
        'source': _EUR_MES_F_SOUL_SOURCE,
        'target': _EUR_MES_F_SOUL_TARGET,
        'source_codes': list(_EUR_MES_F_SOUL_SOURCE_CODES),
        'target_codes': list(target_codes),
        'same_size': True,
        'changed_bytes_span': span,
    }


# v1.7.7.192 — avisos globales y adquisición de anillos de mes_f.dat.
#
# El JMB global de ``mes_f.dat`` tiene 22 escenas. Las 16..21 comparten el
# source francés genérico ``Échantillons couleur obtenus``, pero el primer
# campo de su unidad es un selector escalado por 4800. Al dividirlo se obtienen
# exactamente los IDs 45..50 de la tabla de objetos del juego. Cruzados con la
# tabla consecutiva de nombres del ejecutable quedan así:
#   45 Power, 46 Stamina, 47 Wind, 48 Time, 49 Water, 50 Fire.
# El savestate del anillo rojo usa Icon012 y confirma el caso Fire (ID 50).
#
# Los selectores 45..50 demuestran que estas seis variantes están asociadas a
# objetos de anillo, pero el texto retail de TODAS ellas es literalmente
# ``Échantillons couleur obtenus``. No son el aviso visible de adquisición del
# Fire Ring: ese texto vive en 77304. Por tanto aquí se traduce la frase francesa
# real y SystemF se conserva sin donors ni cambios gráficos.
_EUR_MES_F_GLOBAL_CHAR_CODES = {
    'a': 0, 'N': 1, 'o': 2, 't': 3, 'e': 4, 'b': 5, 'n': 6, 'u': 7,
    'p': 8, 'r': 9, 'c': 10, 's': 11, 'i': 12, 'C': 13, "'": 14,
    'y': 15, 'é': 16, 'l': 17, 'd': 18, 'v': 19, 'B': 20, 'â': 21,
    'm': 22, 'ç': 23, 'è': 24, 'S': 25, 'g': 26, 'É': 27, 'h': 28,
}

_EUR_MES_F_RING_SCENE_SPECS = (
    # v1.7.7.201: estos IDs siguen validándose como selectores de objeto, pero
    # NO se usan para inventar el texto del aviso. Las seis escenas conservan
    # el significado literal francés: «Échantillons couleur obtenus».
    # scene, item_id, selector label, literal Spanish target
    (16, 48, 'Time Ring selector',    'muestras de color obtenidas'),
    (17, 47, 'Wind Ring selector',    'muestras de color obtenidas'),
    (18, 46, 'Stamina Ring selector', 'muestras de color obtenidas'),
    (19, 50, 'Fire Ring selector',    'muestras de color obtenidas'),
    (20, 49, 'Water Ring selector',   'muestras de color obtenidas'),
    (21, 45, 'Power Ring selector',   'muestras de color obtenidas'),
)
_EUR_MES_F_RING_SCENES = frozenset(x[0] for x in _EUR_MES_F_RING_SCENE_SPECS)
_EUR_MES_F_RING_BY_SCENE = {
    int(scene): {'item_id': int(item_id), 'ring': ring, 'target': target}
    for scene, item_id, ring, target in _EUR_MES_F_RING_SCENE_SPECS
}

# (scene, source FR retail, target ES)
# Las escenas 0/1/3/4/6/9/10/12/13/14 contienen sólo el placeholder ``a`` y
# se dejan byte por byte intactas.
_EUR_MES_F_GLOBAL_MESSAGE_SPECS = (
    (2, 'Note obtenue par coursier', 'Nota recibida por correo'),
    (5, "C'est un type spécial de verrou", 'Cerradura especial'),
    (7, "Balle d'âmes reçue", 'Soul Shell hallada'),
    (8, 'Barrière détruite', 'Barrera destruida'),
    (11, "C'est un type spécial de verrou", 'Cerradura especial'),
    (15, 'Sang absorbé', 'Sangre absorbida'),
    (16, 'Échantillons couleur obtenus', 'muestras de color obtenidas'),
    (17, 'Échantillons couleur obtenus', 'muestras de color obtenidas'),
    (18, 'Échantillons couleur obtenus', 'muestras de color obtenidas'),
    (19, 'Échantillons couleur obtenus', 'muestras de color obtenidas'),
    (20, 'Échantillons couleur obtenus', 'muestras de color obtenidas'),
    (21, 'Échantillons couleur obtenus', 'muestras de color obtenidas'),
)


def _eur_mes_f_encode_global_text(text: str, *, ring: bool = False) -> list[int]:
    """Codifica un aviso global con los 29 slots retail de su atlas.

    Desde v1.7.7.201 las escenas 16..21 se traducen según su frase francesa
    literal; todos los caracteres usados pertenecen al repertorio retail de SystemF.
    """
    out: list[int] = []
    for ch in text:
        if ch == ' ':
            out.append(-4)
            continue
        try:
            out.append(int(_EUR_MES_F_GLOBAL_CHAR_CODES[ch]))
        except KeyError as exc:
            raise K7Error(f'mes_f.dat EUR: falta glifo global para {ch!r} en {text!r}.') from exc
    if len(out) > JMB_MAX_CODES:
        raise K7Error(
            f'mes_f.dat EUR: target demasiado largo ({len(out)} > {JMB_MAX_CODES}): {text!r}.'
        )
    return out


def _eur_mes_f_jmb_fparams(french_dat: bytes) -> list[tuple[int, int, int, int]]:
    """Devuelve los 29 fParams del JMB global de mes_f.dat."""
    ranges = _eur_dar_child_ranges(french_dat)
    if len(ranges) != 3:
        raise K7Error(f'mes_f.dat EUR: DAR inesperado ({len(ranges)} children; esperados 3).')
    jmb_off, jmb_size = ranges[2]
    jmb = french_dat[jmb_off:jmb_off + jmb_size]
    if len(jmb) < 16:
        raise K7Error('mes_f.dat EUR: JMB global truncado al leer fParams.')
    sn, cn, so, co, to = struct.unpack_from('<hhIII', jmb, 0)
    if (int(sn), int(cn), int(so), int(co), int(to)) != (22, 29, 104, 151024, 151264):
        raise K7Error('mes_f.dat EUR: layout JMB inesperado al leer fParams.')
    if int(co) + int(cn) * 8 > len(jmb):
        raise K7Error('mes_f.dat EUR: tabla fParams fuera de rango.')
    return [tuple(int(x) for x in struct.unpack_from('<4H', jmb, int(co) + i * 8)) for i in range(int(cn))]


# v1.7.7.199 — SystemF se conserva byte por byte retail; no se añaden glifos.


def _eur_patch_mes_f_global_messages(french_dat: bytes) -> tuple[bytes, dict]:
    """Traduce todos los avisos confirmados del JMB global de ``mes_f.dat``.

    Se validan layout, STRIMAGS, MEP y cada secuencia francesa exacta antes de
    tocar nada. Cada sustitución ocupa los mismos 64 bytes de ``char_data``.
    Para escenas 16..21 también se valida el selector item_id*4800 observado en
    retail, pero el selector no se interpreta como texto: las seis contienen
    literalmente «Échantillons couleur obtenus».
    """
    ranges = _eur_dar_child_ranges(french_dat)
    if len(ranges) != 3:
        raise K7Error(f'mes_f.dat EUR: DAR inesperado ({len(ranges)} children; esperados 3).')

    ihe_off, ihe_size = ranges[0]
    mep_off, mep_size = ranges[1]
    jmb_off, jmb_size = ranges[2]
    ihe = french_dat[ihe_off:ihe_off + ihe_size]
    mep = french_dat[mep_off:mep_off + mep_size]
    jmb = french_dat[jmb_off:jmb_off + jmb_size]

    if not ihe.startswith(b'STRIMAGS') or len(ihe) < 0x1C:
        raise K7Error('mes_f.dat EUR: child 0 no es STRIMAGS.')
    if struct.unpack_from('<I', ihe, 0x18)[0] != 107:
        raise K7Error('mes_f.dat EUR: STRIMAGS no contiene los 107 registros verificados.')
    if not mep.startswith(b'MEP\0'):
        raise K7Error('mes_f.dat EUR: child 1 no es MEP.')
    if len(jmb) < 16:
        raise K7Error('mes_f.dat EUR: JMB global truncado.')

    sn, cn, so, co, to = struct.unpack_from('<hhIII', jmb, 0)
    expected_meta = (22, 29, 104, 151024, 151264)
    actual_meta = (int(sn), int(cn), int(so), int(co), int(to))
    if actual_meta != expected_meta or int(to) != len(jmb):
        raise K7Error(
            'mes_f.dat EUR: layout JMB inesperado; '
            f'obtenido={(actual_meta + (len(jmb),))}.'
        )

    def unit_char_off(scene: int, jimaku: int = 0) -> int:
        return int(so) + int(scene) * JMB_SCENE_SIZE + 76 + int(jimaku) * JMB_RECORD_SIZE + 8

    out = bytearray(french_dat)
    before = bytes(out)
    patches = []
    allowed_spans: list[tuple[int, int]] = []
    span = JMB_CODE_SLOTS * 2

    for scene, source, target in _EUR_MES_F_GLOBAL_MESSAGE_SPECS:
        rel_off = unit_char_off(int(scene), 0)
        slots = list(struct.unpack_from(f'<{JMB_CODE_SLOTS}h', jmb, rel_off))
        if -2 not in slots:
            raise K7Error(f'mes_f.dat EUR: scene {scene} no contiene terminador JMB.')
        active = slots[:slots.index(-2)]
        source_codes = _eur_mes_f_encode_global_text(source)
        if active != source_codes:
            raise K7Error(
                f'mes_f.dat EUR: scene {scene} no coincide con el source esperado {source!r}; '
                f'codes={active!r}.'
            )

        ring_meta = _EUR_MES_F_RING_BY_SCENE.get(int(scene))
        if ring_meta is not None:
            unit_start = int(rel_off) - 8
            selector, scale = struct.unpack_from('<II', jmb, unit_start)
            expected_selector = int(ring_meta['item_id']) * 4800
            if int(selector) != expected_selector or int(scale) != 4800:
                raise K7Error(
                    f"mes_f.dat EUR: scene {scene} no coincide con {ring_meta['ring']}; "
                    f"selector={selector} scale={scale}, esperado={expected_selector}/4800."
                )
            if target != ring_meta['target']:
                raise K7Error(f'mes_f.dat EUR: target de anillo inconsistente en scene {scene}.')

        target_codes = _eur_mes_f_encode_global_text(target, ring=(ring_meta is not None))
        target_slots = target_codes + [-2] + [-1] * (JMB_CODE_SLOTS - len(target_codes) - 1)
        abs_off = int(jmb_off) + int(rel_off)
        struct.pack_into(f'<{JMB_CODE_SLOTS}h', out, abs_off, *target_slots)
        allowed_spans.append((abs_off, abs_off + span))
        item = {
            'scene': int(scene),
            'jmb_unit': 0,
            'jmb_char_data_offset': abs_off,
            'source': source,
            'target': target,
            'source_codes': source_codes,
            'target_codes': target_codes,
        }
        if ring_meta is not None:
            item.update({'item_id': ring_meta['item_id'], 'ring': ring_meta['ring']})
        patches.append(item)

    result = bytes(out)
    if len(result) != len(french_dat):
        raise K7Error('mes_f.dat EUR: el parche global cambió el tamaño total.')

    allowed = bytearray(len(result))
    for a, b in allowed_spans:
        allowed[a:b] = b'\x01' * (b - a)
    for idx, (old_b, new_b) in enumerate(zip(before, result)):
        if old_b != new_b and not allowed[idx]:
            raise K7Error(f'mes_f.dat EUR: cambio fuera de char_data en 0x{idx:X}.')

    for item in patches:
        vals = list(struct.unpack_from(
            f'<{JMB_CODE_SLOTS}h', result, int(item['jmb_char_data_offset'])
        ))
        if -2 not in vals or vals[:vals.index(-2)] != item['target_codes']:
            raise K7Error(
                f"mes_f.dat EUR: readback falló en scene {item['scene']} / {item['target']!r}."
            )

    return result, {
        'resource': 'mes_f.dat',
        'dar_child': 2,
        'jmb_scene_count': int(sn),
        'jmb_glyph_count': int(cn),
        'patched_count': len(patches),
        'patched_scenes': [p['scene'] for p in patches],
        'ring_scenes': [
            {'scene': p['scene'], 'item_id': p['item_id'], 'ring': p['ring'], 'target': p['target']}
            for p in patches if 'ring' in p
        ],
        'ring_systemf_extra_codes': {},
        'ring_font_strategy': 'retail-SystemF-unchanged',
        'same_size': True,
        'changed_bytes_span_each': span,
        'patches': patches,
    }


# DIRECTO EUR: mapeo estructural de tablas trilingües EN -> FR -> DE.
# La edición europea conserva gran parte de las cadenas directas en tablas de
# tres punteros. Esta capa identifica la columna francesa por estructura binaria
# y aplica el target español sin depender de offsets USA.
_EUR_DIRECT_MANUAL_UNITS = {
    'k7-9000-00-00', 'k7-9000-01-00', 'k7-9000-02-00', 'k7-9000-03-00',
    'k7-9011-12-00', 'k7-9011-13-00', 'k7-9011-14-00', 'k7-9011-15-00',
    'k7-9011-16-00', 'k7-9011-17-00', 'k7-9011-18-00', 'k7-9011-19-00',
    'k7-9011-20-00', 'k7-9011-22-00', 'k7-9011-24-00',
}

# Casos EUR verificados que no usan una tabla EN/FR/DE simple. Se parchean por
# offset francés estable, validando primero el contenido original.
_EUR_DIRECT_FIXED_SLES_SPECS = [
    # Estadísticas de habilidades. La pantalla usa DOS cadenas por atributo:
    # una variante con nivel (NV%d ...) y otra etiqueta estática indentada.
    # Ambas deben llevar el mismo idioma; si sólo se parchea la segunda, el
    # juego dibuja francés y español superpuestos/adyacentes.
    (0x4F7D60, 'NV%d Invisibilité', 'NV%d Invisibilidad', ('k7-9002-09-00',)),
    (0x4F7D80, '       Invisibilité', '       Invisibilidad', ('k7-9002-09-00',)),
    (0x4F7E10, 'NV%d Onde de choc', 'NV%d Estabilidad', ('k7-9002-10-00',)),
    (0x4F7E30, '       Onde de choc', '       Estabilidad', ('k7-9002-10-00',)),
    (0x4F7E90, 'NV%d Portée', 'NV%d Alcance', ('k7-9002-11-00',)),
    (0x4F7EA0, '       Portée', '       Alcance', ('k7-9002-11-00',)),
    (0x4F7EE8, 'NV%d Critiques', 'NV%d Crítico', ('k7-9002-12-00',)),
    (0x4F7F00, '       Critiques', '       Crítico', ('k7-9002-12-00',)),
    (0x4F7CF0, 'NV%d Puissance', 'NV%d Potencia', ('k7-9002-13-00',)),
    (0x4F7D00, '       Puissance', '       Potencia', ('k7-9002-13-00',)),
    (0x4F7F58, 'NV%d Rapidité', 'NV%d Rapidez', ('k7-9002-14-00',)),
    (0x4F7F70, '       Rapidité', '       Rapidez', ('k7-9002-14-00',)),

    # Ayudas / tutoriales y etiquetas de atributos.
    (0x4FB800, 'Contre-attaque. Quand un Heaven Smile bondit vers toi, appuie sur le touche $ pour contre-attaquer.',
     'Contraataque. Si un Heaven Smile salta hacia ti, pulsa $ para contraatacar.', ('k7-9003-11-00','k7-9003-12-00')),
    (0x4FC688, 'PUISSANCE', 'POTENCIA', ('k7-9003-23-00',)),
    (0x4FC6A0, "Puissance d'attaque", 'Potencia de ataque', ('k7-9003-24-00',)),
    (0x4FC6B8, 'RAPIDITÉ', 'RAPIDEZ', ('k7-9003-25-00',)),
    (0x4FC6D0, "Vitesse d'attaque", 'Velocidad de ataque', ('k7-9003-26-00',)),
    (0x4FC6E8, 'ONDE DE CHOC', 'ESTABILIDAD', ('k7-9003-27-00',)),
    (0x4FC6F8, 'Cible bloquée', 'Blanco fijado', ('k7-9003-28-00',)),
    (0x4FC708, 'CRITIQUES', 'CRÍTICOS', ('k7-9003-29-00',)),
    (0x4FC718, 'Mort subite', 'Muerte directa', ('k7-9003-30-00',)),
    (0x4FC728, 'PORTÉE', 'ALCANCE', ('k7-9003-31-00',)),
    (0x4FC730, "Portée de l'explosion", 'Radio explosion', ('k7-9003-32-00',)),
    (0x4FC748, 'INVISIBILITÉ', 'INVISIBILIDAD', ('k7-9003-33-00',)),
    (0x4FC760, "Durée d'invisibilité", 'Tiempo invisible', ('k7-9003-34-00',)),

    (0x4FC250, 'Sélectionne la personnalité et appuie sur le touche &.',
     'Elige personalidad y pulsa & y sigue.', ('k7-9004-11-00','k7-9004-12-00')),
    (0x4FCFF0, 'Créez du sérum à partir du sang en appuyant sur le touche &.',
     'Crea suero con sangre pulsando & y sigue.', ('k7-9004-33-00','k7-9004-34-00')),
    (0x4FD410, 'AUCUNE', 'NINGUNO', ('k7-9004-37-00',)),
    (0x4FCD30, 'Appuie rapidement et plusieurs fois sur le touche & pour lui insuffler la vie.',
     'Pulsa & rapido para darle vida. Dale vida!', ('k7-9004-38-00','k7-9004-39-00')),
    (0x4FCDF0, 'Appuie rapidement et plusieurs fois sur', 'Pulsa & rapido ',
     ('k7-9004-42-00','k7-9004-43-00','k7-9004-44-00')),

    # Descripciones de capítulos/misiones (rama francesa EUR).
    (0x4FDA80, 'Combat en chacun pour soi dans le bâtiment polyvalent "Celte".',
     'Combate total en edificio "Celtic", instalación multiusos.', ('k7-9005-00-00',)),
    (0x4FDAC0, 'Combat décisif au resto japonais "Fukushima".',
     'Batalla en restaurante japonés "Fukushima".', ('k7-9005-01-00',)),
    (0x4FDAF0, 'Agitation au bâtiment "Kaku", Quartier Gouvernemental',
     'Caos en el edificio "Kaku", Distrito', ('k7-9005-02-00',)),
    (0x4FDB30, "des Échanges d'Infos Internationales.",
     'gubernamental de intercambio internacional.', ('k7-9005-03-00',)),
    (0x4FDB60, "Trouble à \"l'InterCité Ulmeyda\", la cité \"idéale\".",
     'Problemas en "Ulmeyda InterCity", ciudad "ideal".', ('k7-9005-04-00',)),
    (0x4FDBA0, "Infamie au parc d'attraction \"Ishizaka Land\".",
     'Crímenes en parque "Ishizaka Land".', ('k7-9005-05-00',)),
    (0x4FDBD0, 'Embuscade au "Manoir de Curtis"', 'Emboscada en casa Blackburn.', ('k7-9005-06-00',)),
    (0x4FDBF0, "Errer dans la république de lumière et d'ombre, \"Dominicaine\".",
     'Vagando por república de luz y sombra, "Dominican".', ('k7-9005-07-00',)),
    (0x4FDC30, "La Croisade à l'Hôtel Union.", 'La cruzada en Hotel Union.', ('k7-9005-08-00',)),
    (0x4FDC50, "Lutte acharnée à l'école primaire nationale de \"Coburn\"",
     'Lucha desesperada en escuela "Coburn".', ('k7-9005-09-00',)),
    (0x4FDC90, "Le combat Sanglant à l'Hôtel Union.", 'Batalla sangrienta en Hotel Union.', ('k7-9005-10-00',)),
    (0x4FDCC0, 'Confrontation armée dans "Le Gratte-ciel Broadway".',
     'Tensión militar en "Skyscraper Broadway".', ('k7-9005-11-00',)),
    (0x4FDD00, "La destruction de \"l'Île Battleship\"", 'Destruir "Battleship Island"', ('k7-9005-12-00',)),
    (0x4FDD30, 'dans le Nord Pacifique.', 'en el Pacífico Norte.', ('k7-9005-12-00',)),

    # Órdenes/objetivos.
    (0x4FE2A0, "Détruire le QG 'Heaven Smile' ", 'Arrasa la base Heaven Smile', ('k7-9005-14-00',)),
    (0x4FE2C0, 'et capturer le chef vivant. ', 'y captura vivo al jefe.', ('k7-9005-15-00',)),
    (0x4FE2E0, 'Se débarrasser du Gouverneur, Toru Fukushima. ', 'Elimina al gobernador Toru Fukushima.', ('k7-9005-16-00',)),
    (0x4FE310, "Se débarrasser de l'agent Jean DePaul.", 'Elimina al agente Jean DePaul.', ('k7-9005-17-00',)),
    (0x4FE340, 'Trouver Andrei Ulmeyda. ', 'Encuentra a Andrei Ulmeyda.', ('k7-9005-18-00',)),
    (0x4FE360, "Se débarrasser de l'assassin, ", 'Elimina al asesino', ('k7-9005-19-00',)),
    (0x4FE380, 'Curtis Blackburn. ', 'Curtis Blackburn.', ('k7-9005-19-00',)),
    (0x4FE3A0, 'Tuer le dessinateur de BD,', 'Mata al dibujante de cómics,', ('k7-9005-20-00',)),
    (0x4FE3C0, 'Trevor Pearlharbor en secret. ', 'Trevor Pearlharbor en secreto.', ('k7-9005-21-00',)),
    (0x4FE3E0, 'Réunion confidentielle de ', 'Reunión secreta de', ('k7-9005-22-00',)),
    (0x4FE400, 'Matsuoka Kenjiro avec les Nations Unies.', 'Matsuoka Kenjiro con las Naciones Unidas.', ('k7-9005-23-00',)),
    (0x4FE430, 'Contacter le Centre National. ', 'Contacta el Centro Nacional.', ('k7-9005-24-00',)),
    (0x4FE450, "L'ordre final ", 'La orden final', ('k7-9005-25-00',)),
    (0x4FE460, 'Combattre en duel avec Handsome Man : ', 'Duelo contra Handsome Man:', ('k7-9005-26-00',)),
    (0x4FE490, 'Les Rangers punisseurs', 'Los Punishing Rangers.', ('k7-9005-27-00',)),
    (0x4FE4B0, 'Épreuve de force. ', 'Duelo final.', ('k7-9005-28-00',)),

    (0x4F4DD0, 'Rechargement', 'Recargar', ('k7-9012-00-00',)),
    (0x509E30, 'Aucune donnée sauvegardée', 'Sin datos', ('k7-9009-07-00','k7-9011-07-00')),
    (0x50CE20, 'Aucune donnée sauvegardée', 'Sin datos', ('k7-9009-07-00','k7-9011-07-00')),
    (0x50D220, 'Aucune donnée sauvegardée', 'Sin datos', ('k7-9009-07-00','k7-9011-07-00')),

    # DIRECTO restantes: tutoriales/etiquetas compartidas no cubiertas por triadas.
    (0x4FB940, 'Attaque au sol. Achève un Heaven Smile mis à terre grâce à ce coup vers le bas.',
     'Ataque bajo. Remata al Heaven Smile caido con este golpe hacia abajo.', ('k7-9003-13-00',)),
    (0x4FF350, 'MAP', 'MAPA', ('k7-9006-00-00',)),
    (0x503EA8, 'New Stage', 'Nueva fase', ('k7-9013-00-00',)),
]

_EUR_DIRECT_FIXED_MODULE_SPECS = {
    'MODULES/BIN/S01M.BIN': [
        (0x2D9E0, 'Porte principale', 'Entrada principal', ('k7-9101-00-00',)),
        (0x2DA30, 'Devant du foyer', 'Ante vestíbulo', ('k7-9101-01-00',)),
    ],
    'MODULES/BIN/S02M.BIN': [
        (0x19F68, 'Ambulance', 'Vehículo emerg.', ('k7-9102-06-00',)),
    ],
    'MODULES/BIN/S04M.BIN': [
        (0x1A2D0, 'Arrière du campanile', 'Detrás del campanario', ('k7-9104-01-00',)),
        (0x1A458, 'Sanctuaire RDC', 'Santuario P1', ('k7-9104-05-00',)),
        (0x1A4C0, 'Sanctuaire 1er', 'Santuario P2', ('k7-9104-06-00',)),
        (0x1A8F8, 'New Stage', 'Nueva zona', ('k7-9104-19-00',)),
    ],
    'MODULES/BIN/S05M.BIN': [
        (0x298C0, 'Bureau du principal', 'Despacho del director', ('k7-9105-30-00',)),
        (0x28F38, 'Front', 'Frente', ('k7-9105-01-00',)),
        (0x29D88, 'Front', 'Frente', ('k7-9105-01-00',)),
        (0x29990, 'New Stage', 'Nueva zona', ('k7-9105-33-00',)),
    ],
}

_EUR_DIRECT_FIXED_UNITS = {
    uid
    for _off, _src, _dst, uids in _EUR_DIRECT_FIXED_SLES_SPECS
    for uid in uids
}
for _specs in _EUR_DIRECT_FIXED_MODULE_SPECS.values():
    _EUR_DIRECT_FIXED_UNITS.update(uid for _off, _src, _dst, uids in _specs for uid in uids)



# Bloque Memory Card EUR: la edición europea no usa aquí las mismas triadas
# regulares que el resto del ejecutable. Los textos franceses están en un
# bloque localizado y estable. Cada entrada se valida contra el francés original
# y se sustituye in-place por español, sin tocar las ramas EN/DE.
_EUR_DIRECT_MEMORY_CARD_SPECS = [
    (0x50A050, 'Memory card (PS2) introuvable dans la', 'No hay tarjeta de memoria (PS2) en la'),
    (0x50A080, 'fente pour MEMORY CARD (carte mémoire) N°1.', 'ranura 1 de MEMORY CARD.'),
    (0x50A0D0, "nécessite 63 KB d'espace libre.", 'necesita 63 KB libres.'),
    (0x50A0F0, 'Insérez une memory card (PS2)', 'Inserta una tarjeta (PS2)'),
    (0x50A110, "avec suffisamment d'espace libre", 'con suficiente espacio libre'),
    (0x50A140, 'ou vous ne pourrez pas', 'o no podras'),
    (0x50A160, 'sauvegarder les données.', 'guardar los datos.'),
    (0x50A180, 'Continuer sans sauvegarder ?', 'Continuar sin guardar?'),
    (0x50A460, "L'objet inséré dans le", 'El dispositivo de la'),
    (0x50A480, "fente pour MEMORY CARD (carte mémoire) N°1 n'est pas valide.", 'ranura 1 de MEMORY CARD no es valido.'),
    (0x50A4C0, 'Remplacez-le par une', 'Inserta una'),
    (0x50A4E0, 'memory card (PS2).', 'tarjeta de memoria (PS2).'),
    (0x50A500, 'Si vous continuez.', 'Si continuas.'),
    (0x50A630, 'La memory card (PS2) de la', 'La tarjeta (PS2) de la'),
    (0x50A650, 'fente pour MEMORY CARD (carte mémoire) N°1', 'ranura 1 de MEMORY CARD'),
    (0x50A680, "n'est pas formatée.", 'no tiene formato.'),
    (0x50A6A0, 'Voulez-vous la formater ?', 'Quieres formatearla?'),
    (0x50A7C0, 'Formater la Memory Card (carte', 'Formatear la tarjeta de memoria'),
    (0x50A7E0, 'mémoire) entraînera la perte de', 'borrara todos los datos'),
    (0x50A800, 'toutes les données', 'guardados'),
    (0x50A818, 'sauvegardées.', 'anteriormente.'),
    (0x50A830, 'Voulez-vous continuer le formatage?', 'Continuar con el formateo?'),
    (0x50A980, 'La Memory Card (carte mémoire)', 'La tarjeta de memoria'),
    (0x50A9A0, 'dans le Slot 1 est', 'de la ranura 1 esta'),
    (0x50A9C0, 'dans le Slot 2 est', 'de la ranura 2 esta'),
    (0x50A9E0, 'endommagée et ne peut pas être', 'danada y no se puede'),
    (0x50AA00, 'utilisée.', 'usar.'),
    (0x50AA10, 'Si vous continuez, vous ne', 'Si continuas, no'),
    (0x50AA30, 'pourrez pas sauvegarder.', 'podras guardar.'),
    (0x50AB80, 'Espace insuffisant sur la memory card (PS2) de la', 'No hay espacio libre en la tarjeta (PS2) de la'),
    (0x50AD40, 'Vérification de la memory card (PS2) de la', 'Comprobando la tarjeta de memoria (PS2) de la'),
    (0x50AD70, 'Ne pas retirer la memory card (PS2)', 'No saques la tarjeta de memoria (PS2)'),
    (0x50ADA0, 'ni la manette, ne pas éteindre ni', 'ni el mando; no apagues ni'),
    (0x50ADD0, 'réinitialiser la console.', 'reinicies la consola.'),
    (0x50AF10, 'Formatage en cours. Ne pas retirer', 'Formateando. No saques'),
    (0x50AF40, 'la memory card (PS2)', 'la tarjeta (PS2)'),
    (0x50AF58, 'ni la manette,', 'ni el mando,'),
    (0x50AF70, 'ne pas éteindre ni réinitialiser la', 'no apagues ni reinicies la'),
    (0x50AF98, 'console.', 'consola.'),
    (0x50B0D0, 'La memory card (PS2)', 'La tarjeta de memoria (PS2)'),
    (0x50B0F0, 'dans le Slot 1 ne peut', 'de la ranura 1 no'),
    (0x50B110, b'pas \xeatre utilis\x0e9e.', 'se puede usar.'),
    (0x50B1C0, 'Formatage terminé', 'Formato correcto'),
    (0x50B220, 'Echec du formatage !', 'Fallo de formato!'),
    (0x50B240, 'La memory card (PS2) dans le', 'La tarjeta (PS2) de la ranura 1'),
    (0x50B260, 'est endommagée et ne peut pas étre', 'esta danada y no se puede usar.'),
    (0x50B3B0, 'Voulez-vous la formater?', 'Quieres formatearla?'),
    (0x50B3D0, "L'objet inséré dans le Slot 1 n'est pas", 'El dispositivo de la ranura 1 no es'),
    (0x50B400, 'valide. Remplacez-le par une', 'valido. Inserta una tarjeta.'),
    (0x50B4E0, 'Vérification de la ', 'Comprobando la'),
    (0x50B500, 'memory card (PS2) de la', 'tarjeta de memoria (PS2) de la'),
    (0x50B520, 'Formatage en cours. Ne pas retirer la', 'Formateando. No saques la'),
    (0x50B550, 'memory card (PS2) ni la manette,', 'tarjeta (PS2) ni el mando,'),
    (0x50B640, 'Échec de la sauvegarde!', 'Error al guardar!'),
    (0x50B660, 'Échec du chargement!', 'Error al cargar!'),
    (0x50B680, 'dans le Slot 1 contient', 'la ranura 1 contiene'),
    (0x50B6A0, 'des données corrompues et a', 'datos danados y debe'),
    (0x50B6C0, "besoin d'être formatée.", 'formatearse.'),
    (0x50B7F0, 'La Memory Card (carte mémoire) dans le Slot 1', 'La tarjeta de memoria de la ranura 1'),
    (0x50B820, 'ne peut être utilisée.', 'no se puede usar.'),
    (0x50B880, 'Le fichier sur la memory card (PS2) dans le', 'Los datos de la tarjeta (PS2) de la ranura 1'),
    (0x50B8B0, 'est endommagée et ne peut pas être', 'estan danados y no se pueden usar.'),
    (0x50B950, 'Le fichier sauvegardé sur la', 'Los datos guardados de la'),
    (0x50B970, 'memory card (PS2) dans le', 'tarjeta (PS2) de la ranura 1'),
    (0x50B990, "n'est pas de killer8 et ne peut pas être chargé.", 'no son de killer8 y no se pueden cargar.'),
    (0x50BAA0, "n'est pas de hopper7", 'no son de hopper7'),
    (0x50BAC0, 'et ne peut pas être chargé.', 'y no se pueden cargar.'),
    (0x50BB50, 'Échec de la sauvegarde.', 'Error al guardar.'),
    (0x50BB70, 'Échec du chargement.', 'Error al cargar.'),
    (0x50BB88, 'dans le Slot 1', 'en la ranura 1'),
    (0x50BBA0, 'est endommagée et ne peut pas être utilisée.', 'esta danada y no se puede usar.'),
    (0x50BC80, 'Formater la memory card (PS2)', 'Formatear tarjeta de memoria'),
    (0x50BCA0, 'entraînera la perte de toutes', 'borrara todos los datos'),
    (0x50BCC0, 'les données', 'guardados.'),
    (0x50BD00, 'Espace insuffisant sur la', 'No hay espacio libre en la'),
    (0x50BD20, "hopper7 nécessite 63 KB d'espace libre.", 'hopper7 necesita 63 KB libres.'),
    (0x50BD50, "killer8 nécessite 63 KB d'espace libre.", 'killer8 necesita 63 KB libres.'),
    (0x50BD80, "killer7 nécessite 63 KB d'espace libre.", 'killer7 necesita 63 KB libres.'),
    (0x50BF10, 'contenant des données de hopper7', 'con datos de hopper7'),
    (0x50BF40, 'contenant des données de killer8', 'con datos de killer8'),
    (0x50BF70, 'contenant des données de killer7', 'con datos de killer7'),
    (0x50BFA0, 'dans la fente pour MEMORY CARD (carte mémoire) N°1.', 'en la ranura 1 de MEMORY CARD.'),
    (0x50C0E0, 'Échec du formatage!', 'Fallo de formato!'),
    (0x50C0F8, 'Effacer', 'BORRAR'),
    (0x50C110, 'Echec de la sauvegarde !', 'Error al guardar!'),
    (0x50C130, 'La memory card (PS2) dans le ', 'La tarjeta de memoria (PS2) en '),
    (0x50C168, 'REESSAYER', 'REINTENTAR'),
    (0x50C1E0, 'Brancher La memory card (PS2) dans le', 'Inserta la tarjeta de memoria (PS2) en la'),
    (0x50C260, 'FORMATER', 'FORMATEAR'),
    (0x50C270, 'sansformater', 'sin formatear'),
    (0x50C2E8, 'CHARGER', 'CARGAR'),
    (0x50C2F0, 'Ne pas charger', 'No cargar'),
    (0x50C300, 'SAUVEGARDER', 'GUARDAR'),
    (0x50C310, 'Ne pas sauvegarder', 'No guardar'),
    (0x50C390, 'Voulez-vous vraiment formater', 'Seguro que quieres formatear'),
    (0x50C3B0, 'la memory card (PS2) de la', 'la tarjeta (PS2) de la'),
    (0x50C3D0, 'fente pour MEMORY CARD (carte mémoire) N°1 ?', 'ranura 1 de MEMORY CARD?'),
    (0x50C400, 'Oui', 'SI'),
    (0x50C408, 'Non', 'NO'),
    (0x50C4E0, 'Voulez-vous créer un fichier', 'Quieres crear un archivo'),
    (0x50C500, 'de sauvegarde pour hopper7 ?', 'nuevo de hopper7?'),
    (0x50C520, 'de sauvegarde pour killer8 ?', 'nuevo de killer8?'),
    (0x50C540, 'de sauvegarde pour killer7 ?', 'nuevo de killer7?'),
    (0x50C660, 'Souhaitez-vous écraser le', 'Quieres sobrescribir el'),
    (0x50C680, 'fichier précédent?', 'archivo anterior?'),
    (0x50C710, 'Continuer sans sauvegarder?', 'Continuar sin guardar?'),
    (0x50C750, 'Sauvegarde terminée', 'Guardado correcto'),
    (0x50C7A0, 'Ne pas retirer la', 'No saques la'),
    (0x50C7C0, 'ni la manette,ne pas éteindre ni', 'ni el mando; no apagues ni'),
    (0x50C7F0, 'réinitialiser laconsole.', 'reinicies la consola.'),
    (0x50C850, 'Sauvegarde en cours. Ne pas retirer', 'Guardando. No saques'),
    (0x50C880, 'ne pas éteindre ni', 'no apagues ni'),
    (0x50C910, 'Chargement en cours. Ne pas retirer', 'Cargando. No saques'),
    (0x50C940, 'ni la manette, ne pas', 'ni el mando; no'),
    (0x50C960, 'éteindre ni réinitialiser la console.', 'apagues ni reinicies la consola.'),
    (0x50C9C0, 'Charger ce fichier?', 'Cargar archivo?'),
    (0x50CA10, 'Sauvegarder ce fichier?', 'Guardar datos?'),
    (0x50CA60, 'Formater?', 'Formatear?'),
    (0x50CA88, 'Effacer?', 'Borrar?'),
]


# Unidades compuestas del catálogo USA cuyo texto EUR está dividido en unidades
# más pequeñas que ya se parchean individualmente.
_EUR_DIRECT_COMPOSITE_ALIASES = {
    'k7-9004-23-00': ('k7-9004-24-00', 'k7-9004-25-00', 'k7-9004-26-00'),
}

# Tres textos de la edición EUR comparten literalmente la C-string inglesa entre
# idiomas. Para modificar sólo francés se reserva padding NUL creado por cadenas
# francesas que ya se acortan en _EUR_DIRECT_FIXED_SLES_SPECS, y se repunta
# exclusivamente la referencia francesa.
_EUR_DIRECT_SHARED_FR_RELOCS = [
    # fr_pointer_ref, expected_source_offset, storage_offset, storage_capacity,
    # target_es, unit_ids
    (0x4BB860, 0x4FDA50, 0x4FB84C, 0x24, 'Bala asesina en Horizon Tower', ('k7-9005-13-00',)),
    (0x4BC230, 0x4FE250, 0x4FCE00, 0x20, 'Elimina a Steve Thunderson,', ('k7-9005-29-00',)),
    (0x4BC234, 0x4FE270, 0x4FCD5B, 0x25, 'alto cargo del Partido Demócrata.', ('k7-9005-30-00',)),
]

def _eur_find_all(blob: bytes, needle: bytes) -> list[int]:
    if not needle:
        return []
    out = []
    pos = 0
    while True:
        pos = blob.find(needle, pos)
        if pos < 0:
            return out
        out.append(pos)
        pos += 1


def _eur_cstring_bytes(blob: bytes, offset: int, max_len: int = 512) -> bytes | None:
    if offset < 0 or offset >= len(blob):
        return None
    end = blob.find(b'\0', offset, min(len(blob), offset + max_len))
    if end < 0:
        return None
    raw = blob[offset:end]
    # Cadenas de interfaz: permitimos Latin-1 y controles de espacio habituales,
    # pero rechazamos punteros accidentales hacia datos binarios.
    if any(c < 0x09 or (0x0D < c < 0x20) for c in raw):
        return None
    return raw


def _eur_cstring_text(blob: bytes, offset: int) -> str | None:
    raw = _eur_cstring_bytes(blob, offset)
    if raw is None:
        return None
    return raw.decode('latin-1', errors='replace')


def _eur_cstring_slot_end(blob: bytes, offset: int) -> int:
    raw = _eur_cstring_bytes(blob, offset)
    if raw is None:
        return offset
    pos = offset + len(raw) + 1
    while pos < len(blob) and blob[pos] == 0:
        pos += 1
    return pos


def _eur_merge_spans(spans: list[tuple[int, int]]) -> list[list[int]]:
    src = sorted((a, b) for a, b in spans if b > a)
    out: list[list[int]] = []
    for a, b in src:
        if out and a <= out[-1][1]:
            out[-1][1] = max(out[-1][1], b)
        else:
            out.append([a, b])
    return out


def _eur_direct_patch_items_from_manifest() -> list[dict]:
    patch = current_eur_spanish_patch_path()
    with zipfile.ZipFile(patch, 'r') as z:
        manifest = json.loads(z.read('manifest.json').decode('utf-8'))
    return list(manifest.get('iso_patches', []))


def _eur_direct_path_key(iso_path: str) -> str:
    if iso_path == 'SLUS_211.54':
        return EUR_SUPPORTED_SERIAL
    return iso_path.replace('\\', '/')


def _eur_patch_trilingual_direct_file(
    original: bytes,
    items: list[dict],
    vaddr_delta: int,
    *,
    label: str,
    skip_units: set[str] | None = None,
) -> tuple[bytes, dict]:
    """Parchea DIRECTO usando las tablas EUR EN/FR/DE verificables.

    Sólo se considera una equivalencia cuando un puntero al source inglés ocupa la
    primera columna y los dos u32 siguientes resuelven a C-strings válidas. Para
    cadenas compartidas EN/FR, o targets que no caben en el slot FR, se reutiliza
    padding NUL inmediatamente posterior a cadenas de la misma tabla y se repunta
    únicamente la columna francesa. No se usa BSS ni huecos binarios arbitrarios.
    """
    skip_units = set(skip_units or ())
    blob = bytes(original)
    out = bytearray(blob)
    english_sources = {
        str(x.get('source', '')) for x in items
        if all(ord(c) <= 0xFF for c in str(x.get('source', '')))
    }
    contexts: dict[str, tuple[dict, list[tuple[int, list[int], list[str]]]]] = {}
    pending: list[dict] = []
    known_string_offsets: set[int] = set()

    for item in items:
        uid = str(item.get('unit_id', ''))
        if uid in skip_units:
            continue
        source = str(item.get('source', ''))
        try:
            source_raw = source.encode('latin-1') + b'\0'
        except UnicodeEncodeError:
            pending.append({'unit_id': uid, 'source': source, 'target': item.get('target', ''), 'reason': 'source-encoding'})
            continue
        source_positions = _eur_find_all(blob, source_raw)
        candidates: list[tuple[int, list[int], list[str]]] = []
        for source_off in source_positions:
            ptr_value = source_off + int(vaddr_delta)
            ptr_raw = struct.pack('<I', ptr_value)
            for ref in _eur_find_all(blob, ptr_raw):
                if ref + 12 > len(blob):
                    continue
                vals = list(struct.unpack_from('<III', blob, ref))
                offs = [v - int(vaddr_delta) for v in vals]
                texts = [_eur_cstring_text(blob, off) for off in offs]
                if texts[0] != source or texts[1] is None or texts[2] is None:
                    continue
                # Cuando EN y FR comparten literalmente el mismo puntero, la búsqueda
                # también encuentra la segunda columna como un falso comienzo de triplete.
                if ref >= 4 and struct.unpack_from('<I', blob, ref - 4)[0] == ptr_value:
                    continue
                # Otro falso comienzo frecuente es FR/DE/siguiente-EN.
                if texts[2] in english_sources and texts[2] != source:
                    continue
                candidates.append((ref, offs, [str(x) for x in texts]))
        # Deduplicar por ubicación del puntero francés (ref+4).
        dedup = {ref + 4: (ref, offs, texts) for ref, offs, texts in candidates}
        candidates = list(dedup.values())
        if not candidates:
            pending.append({
                'unit_id': uid, 'source': source, 'target': item.get('target', ''),
                'reason': 'source-missing' if not source_positions else 'no-triad-fr',
            })
            continue
        contexts[uid] = (item, candidates)
        for _ref, offs, _texts in candidates:
            known_string_offsets.update(offs)

    # Sólo padding asociado directamente a C-strings conocidas de las tablas.
    free_spans: list[tuple[int, int]] = []
    for off in known_string_offsets:
        raw = _eur_cstring_bytes(blob, off)
        if raw is None:
            continue
        start = off + len(raw) + 1
        end = _eur_cstring_slot_end(blob, off)
        if end - start >= 2:
            free_spans.append((start, end))

    changes: list[dict] = []
    reloc_jobs: list[tuple[str, dict, list[tuple[int, list[int], list[str]]], bytes, int, int, bool]] = []

    # Una misma C-string francesa puede estar compartida por dos conceptos que en
    # español necesitan targets distintos (p.ej. SKILL/SKILLS -> CAPACITÉS). En
    # ese caso nunca se sobrescribe la cadena compartida: se relocaliza por puntero.
    french_target_users: dict[int, set[str]] = defaultdict(set)
    for _uid, (item, candidates) in contexts.items():
        target = _EUR_MAP_DIRECT_TARGETS.get(_uid, _EUR_DIRECT_MISSION_TARGET_OVERRIDES.get(_uid, str(item.get('target', ''))))
        # Si la rama francesa ya contiene exactamente el target deseado no hay
        # nada que separar/relocalizar. Esto es importante para nombres propios
        # compartidos EN/FR como D.C., Washington o Manhattan.
        if all(str(texts[1]) == target for _ref, _offs, texts in candidates):
            continue
        for _ref, offs, _texts in candidates:
            french_target_users[offs[1]].add(target)

    for uid, (item, candidates) in contexts.items():
        target = _EUR_MAP_DIRECT_TARGETS.get(uid, _EUR_DIRECT_MISSION_TARGET_OVERRIDES.get(uid, str(item.get('target', ''))))
        if all(str(texts[1]) == target for _ref, _offs, texts in candidates):
            continue
        try:
            target_raw = _eur_direct_target_bytes((uid,), target) + b'\0'
        except UnicodeEncodeError:
            pending.append({'unit_id': uid, 'source': item.get('source', ''), 'target': target, 'reason': 'target-encoding'})
            continue

        by_french_offset: dict[int, list[tuple[int, list[int], list[str]]]] = defaultdict(list)
        for candidate in candidates:
            by_french_offset[candidate[1][1]].append(candidate)

        for french_off, group in by_french_offset.items():
            shared = (
                any(offs[0] == offs[1] for _ref, offs, _texts in group)
                or len(french_target_users.get(french_off, set())) > 1
            )
            slot_end = _eur_cstring_slot_end(blob, french_off)
            slot_size = slot_end - french_off
            french_texts = sorted({texts[1] for _ref, _offs, texts in group})
            if not shared and len(target_raw) <= slot_size:
                out[french_off:slot_end] = target_raw + b'\0' * (slot_size - len(target_raw))
                tail = french_off + len(target_raw)
                if slot_end - tail >= 2:
                    free_spans.append((tail, slot_end))
                changes.append({
                    'unit_id': uid, 'mode': 'in-place', 'source_en': item.get('source', ''),
                    'source_fr': french_texts, 'target_es': target, 'offset': french_off,
                    'slot_size': slot_size, 'pointer_count': len(group),
                })
            else:
                reloc_jobs.append((uid, item, group, target_raw, french_off, slot_size, shared))

    # Reconstruir el padding seguro DESPUÉS de las escrituras in-place.
    # El cálculo histórico se hacía sobre el blob original y podía considerar
    # libre una cola que una traducción española más larga acababa ocupando.
    # Eso permitía que una relocalización posterior pisara el final de otra
    # cadena de mapa. Recalcular sobre `out` elimina ese solapamiento.
    free_spans = []
    current_blob = bytes(out)
    for off in known_string_offsets:
        raw = _eur_cstring_bytes(current_blob, off)
        if raw is None:
            continue
        start = off + len(raw) + 1
        end = _eur_cstring_slot_end(current_blob, off)
        if end - start >= 2:
            free_spans.append((start, end))
    pools = _eur_merge_spans(free_spans)
    pools.sort(key=lambda ab: (ab[1] - ab[0]), reverse=True)
    for uid, item, group, target_raw, french_off, slot_size, shared in sorted(
        reloc_jobs, key=lambda row: len(row[3]), reverse=True
    ):
        chosen = None
        for span in pools:
            if span[1] - span[0] >= len(target_raw):
                chosen = span
                break
        if chosen is None:
            pending.append({
                'unit_id': uid, 'source': item.get('source', ''), 'target': item.get('target', ''),
                'reason': 'relocation-no-string-padding', 'bytes_needed': len(target_raw),
                'original_fr_slot': slot_size, 'shared_en_fr': shared,
            })
            continue
        new_off = chosen[0]
        out[new_off:new_off + len(target_raw)] = target_raw
        chosen[0] += len(target_raw)
        for ref, _offs, _texts in group:
            struct.pack_into('<I', out, ref + 4, new_off + int(vaddr_delta))
        changes.append({
            'unit_id': uid, 'mode': 'relocated-in-string-padding',
            'source_en': item.get('source', ''),
            'source_fr': sorted({texts[1] for _ref, _offs, texts in group}),
            'target_es': _EUR_MAP_DIRECT_TARGETS.get(uid, _EUR_DIRECT_MISSION_TARGET_OVERRIDES.get(uid, str(item.get('target', '')))), 'offset': new_off,
            'pointer_count': len(group), 'shared_en_fr': shared,
        })

    # Verificar cada cambio a través del puntero FR final cuando lo haya.
    final = bytes(out)
    verified = 0
    for change in changes:
        target_raw = _eur_direct_target_bytes((change['unit_id'],), str(change['target_es'])) + b'\0'
        if final[change['offset']:change['offset'] + len(target_raw)] != target_raw:
            raise K7Error(f'DIRECTO EUR {label}: fallo de verificación en {change["unit_id"]}.')
        verified += 1

    return final, {
        'file': label,
        'mapped_contexts': len(contexts),
        'changes': changes,
        'changed_contexts': len(changes),
        'changed_units': len({x['unit_id'] for x in changes}),
        'verified_contexts': verified,
        'pending': pending,
        'pending_units': len({x['unit_id'] for x in pending}),
        'modes': {
            'in_place': sum(1 for x in changes if x['mode'] == 'in-place'),
            'relocated': sum(1 for x in changes if x['mode'] != 'in-place'),
        },
    }



def _eur_patch_fixed_direct_strings(original: bytes, specs: list[tuple], *, label: str) -> tuple[bytes, dict]:
    """Aplica C-strings francesas de offset EUR verificado sin cambiar el tamaño."""
    out = bytearray(original)
    changes = []
    changed_units: set[str] = set()
    for offset, expected, target, unit_ids in specs:
        expected_raw = expected.encode('latin-1') + b'\0'
        if bytes(out[offset:offset + len(expected_raw)]) != expected_raw:
            got = _eur_cstring_text(bytes(out), offset)
            raise K7Error(
                f'DIRECTO EUR {label}: cadena francesa inesperada en 0x{offset:X}: '
                f'{got!r} != {expected!r}.'
            )
        slot_end = _eur_cstring_slot_end(bytes(out), offset)
        slot_size = slot_end - offset
        target_raw = _eur_direct_target_bytes(unit_ids, target) + b'\0'
        if len(target_raw) > slot_size:
            raise K7Error(
                f'DIRECTO EUR {label}: {target!r} no cabe en 0x{offset:X} '
                f'({len(target_raw)}>{slot_size}).'
            )
        out[offset:slot_end] = target_raw + b'\0' * (slot_size - len(target_raw))
        changed_units.update(unit_ids)
        changes.append({
            'unit_ids': list(unit_ids), 'offset': offset, 'source_fr': expected,
            'target_es': target, 'slot_size': slot_size, 'mode': 'fixed-fr-slot',
        })
    final = bytes(out)
    for ch in changes:
        raw = _eur_direct_target_bytes(ch['unit_ids'], ch['target_es']) + b'\0'
        if final[ch['offset']:ch['offset'] + len(raw)] != raw:
            raise K7Error(f'DIRECTO EUR {label}: verificación fija fallida en 0x{ch["offset"]:X}.')
    return final, {
        'file': label, 'changes': changes, 'changed_units': len(changed_units),
        'changed_unit_ids': sorted(changed_units), 'verified_contexts': len(changes),
    }


def _eur_raw_cstring_slot_end(blob: bytes, offset: int, max_len: int = 512) -> int:
    """Fin del slot C-string sin interpretar codificación/control bytes."""
    if offset < 0 or offset >= len(blob):
        return offset
    end = blob.find(b'\0', offset, min(len(blob), offset + max_len))
    if end < 0:
        return offset
    pos = end + 1
    while pos < len(blob) and blob[pos] == 0:
        pos += 1
    return pos


def _eur_patch_memory_card_french(original: bytes, unit_ids: set[str]) -> tuple[bytes, dict]:
    """Traduce in-place el bloque francés de Memory Card de SLES_533.66."""
    out = bytearray(original)
    changes = []
    for offset, expected, target in _EUR_DIRECT_MEMORY_CARD_SPECS:
        expected_raw = expected if isinstance(expected, bytes) else expected.encode('latin-1')
        if bytes(out[offset:offset + len(expected_raw)]) != expected_raw or out[offset + len(expected_raw)] != 0:
            got_end = bytes(out).find(b'\0', offset, min(len(out), offset + 128))
            got = bytes(out[offset:got_end if got_end >= 0 else offset + 64])
            raise K7Error(
                f'DIRECTO EUR Memory Card: texto francés inesperado en 0x{offset:X}: {got!r}'
            )
        slot_end = _eur_raw_cstring_slot_end(bytes(out), offset)
        if slot_end <= offset:
            raise K7Error(f'DIRECTO EUR Memory Card: slot inválido en 0x{offset:X}.')
        target_raw = _eur_direct_target_bytes(unit_ids, target) + b'\0'
        slot_size = slot_end - offset
        if len(target_raw) > slot_size:
            raise K7Error(
                f'DIRECTO EUR Memory Card: {target!r} no cabe en 0x{offset:X} '
                f'({len(target_raw)}>{slot_size}).'
            )
        out[offset:slot_end] = target_raw + b'\0' * (slot_size - len(target_raw))
        changes.append({
            # v1.7.7.167: conservar también los IDs asociados. La verificación
            # posterior necesita este contexto para elegir el codec DIRECTO y
            # las revisiones anteriores omitían la clave, provocando KeyError
            # ('unit_ids') al pulsar «Inyectar Textos».
            'unit_ids': sorted(str(x) for x in unit_ids),
            'offset': offset,
            'source_fr': expected.decode('latin-1', errors='replace') if isinstance(expected, bytes) else expected,
            'target_es': target,
            'slot_size': slot_size,
        })
    final = bytes(out)
    for ch in changes:
        ids = tuple(ch.get('unit_ids') or sorted(str(x) for x in unit_ids))
        raw = _eur_direct_target_bytes(ids, ch['target_es']) + b'\0'
        if final[ch['offset']:ch['offset'] + len(raw)] != raw:
            raise K7Error(f'DIRECTO EUR Memory Card: verificación fallida en 0x{ch["offset"]:X}.')
    return final, {
        'changes': changes,
        'changed_units': len(unit_ids),
        'changed_unit_ids': sorted(unit_ids),
        'verified_contexts': len(changes),
        'note': 'Bloque francés Memory Card parcheado in-place; EN/DE permanecen intactos.',
    }


def _eur_patch_blood_room_long_french(original: bytes) -> tuple[bytes, dict]:
    """Relocaliza el alemán de Tasty para ampliar sólo su almacenamiento francés.

    La tabla Blood Room guarda EN/FR/DE contiguos. El target español solicitado
    para ``Tasty, tasty blood!`` ocupa 30 bytes con NUL, mientras el slot FR tiene
    24. Tras acortar ``Get blood!`` a ``¡Ten sangre!``, su propio slot francés deja
    20 bytes NUL seguros. Movemos ahí *Leckeres Blut!* (sin cambiar su contenido),
    repuntamos únicamente la columna alemana de ese triplete y reutilizamos los
    antiguos slots FR+DE contiguos (40 bytes) para la cadena española.

    No se usa BSS ni padding binario arbitrario; todas las direcciones pertenecen
    a C-strings verificadas de la misma tabla trilingüe.
    """
    uid = 'k7-9001-05-00'
    delta = 0xFFE80
    tasty_ref = 0x4B400C
    expected_offsets = (0x4F4420, 0x4F4440, 0x4F4458)
    expected_texts = ('Tasty, tasty blood!', 'Du sang bien goûteux !', 'Leckeres Blut!')
    get_fr_off = 0x4F4310
    get_fr_slot_end = 0x4F4330
    expanded_end = 0x4F4468

    out = bytearray(original)
    vals = tuple(v - delta for v in struct.unpack_from('<III', out, tasty_ref))
    if vals != expected_offsets:
        raise K7Error(
            'DIRECTO EUR Blood Room: triplete Tasty inesperado: '
            f'{tuple(hex(x) for x in vals)} != {tuple(hex(x) for x in expected_offsets)}.'
        )
    got_texts = tuple(_eur_cstring_text(bytes(out), off) for off in expected_offsets)
    if got_texts != expected_texts:
        raise K7Error(
            f'DIRECTO EUR Blood Room: C-strings Tasty inesperadas: {got_texts!r}.'
        )

    # El paso genérico ya debe haber acortado la cadena francesa Get blood!.
    get_target = _EUR_DIRECT_MISSION_TARGET_OVERRIDES['k7-9001-01-00']
    get_raw = _eur_direct_target_bytes(('k7-9001-01-00',), get_target) + b'\0'
    if bytes(out[get_fr_off:get_fr_off + len(get_raw)]) != get_raw:
        raise K7Error('DIRECTO EUR Blood Room: Get blood! no estaba parcheado antes de relocalizar Tasty.')
    german_raw = expected_texts[2].encode('latin-1') + b'\0'
    german_new_off = get_fr_off + len(get_raw)
    if german_new_off + len(german_raw) > get_fr_slot_end:
        raise K7Error('DIRECTO EUR Blood Room: el tail de Get blood! no basta para preservar el alemán.')
    if any(out[german_new_off:get_fr_slot_end]):
        raise K7Error('DIRECTO EUR Blood Room: el tail reservado tras Get blood! dejó de estar vacío.')

    target = _EUR_DIRECT_MISSION_TARGET_OVERRIDES[uid]
    target_raw = _eur_direct_target_bytes((uid,), target) + b'\0'
    french_off, german_old_off = expected_offsets[1], expected_offsets[2]
    if french_off + len(target_raw) > expanded_end:
        raise K7Error('DIRECTO EUR Blood Room: target Tasty excede los slots FR+DE combinados.')

    # Preservar DE en el tail seguro, repuntar su columna y usar FR+antiguo-DE.
    out[german_new_off:german_new_off + len(german_raw)] = german_raw
    struct.pack_into('<I', out, tasty_ref + 8, german_new_off + delta)
    out[french_off:expanded_end] = target_raw + b'\0' * (expanded_end - french_off - len(target_raw))

    final = bytes(out)
    if _eur_cstring_text(final, french_off) is None or final[french_off:french_off + len(target_raw)] != target_raw:
        raise K7Error('DIRECTO EUR Blood Room: verificación del target Tasty fallida.')
    if _eur_cstring_text(final, german_new_off) != expected_texts[2]:
        raise K7Error('DIRECTO EUR Blood Room: el texto alemán Tasty no se preservó.')
    if struct.unpack_from('<I', final, tasty_ref + 8)[0] != german_new_off + delta:
        raise K7Error('DIRECTO EUR Blood Room: puntero alemán Tasty no quedó repuntado.')
    if struct.unpack_from('<I', final, tasty_ref + 4)[0] != french_off + delta:
        raise K7Error('DIRECTO EUR Blood Room: se alteró el puntero francés Tasty inesperadamente.')

    return final, {
        'changes': [{
            'unit_id': uid,
            'mode': 'expanded-fr-by-preserving-de-in-get-blood-tail',
            'source_en': expected_texts[0], 'source_fr': expected_texts[1],
            'target_es': target, 'offset': french_off,
            'german_old_offset': german_old_off, 'german_new_offset': german_new_off,
            'french_capacity': expanded_end - french_off,
        }],
        'changed_units': 1,
        'changed_unit_ids': [uid],
        'verified_contexts': 1,
        'note': 'DE conserva exactamente su texto; sólo cambia su puntero dentro de la misma tabla Blood Room.',
    }


def _eur_patch_shared_french_pointers(original: bytes) -> tuple[bytes, dict]:
    """Relocaliza C-strings compartidas y repunta sólo la referencia francesa."""
    out = bytearray(original)
    delta = 0xFFE80
    changes = []
    changed_units: set[str] = set()
    for ref, source_off, storage_off, capacity, target, unit_ids in _EUR_DIRECT_SHARED_FR_RELOCS:
        expected_ptr = source_off + delta
        got_ptr = struct.unpack_from('<I', out, ref)[0]
        if got_ptr != expected_ptr:
            raise K7Error(
                f'DIRECTO EUR compartido: puntero francés inesperado en 0x{ref:X}: '
                f'0x{got_ptr:X} != 0x{expected_ptr:X}.'
            )
        target_raw = target.encode('latin-1') + b'\0'
        if len(target_raw) > capacity:
            raise K7Error(f'DIRECTO EUR compartido: {target!r} excede reserva {capacity}.')
        if any(out[storage_off:storage_off + capacity]):
            raise K7Error(
                f'DIRECTO EUR compartido: padding de reserva no está vacío en 0x{storage_off:X}.'
            )
        out[storage_off:storage_off + capacity] = target_raw + b'\0' * (capacity - len(target_raw))
        struct.pack_into('<I', out, ref, storage_off + delta)
        changed_units.update(unit_ids)
        changes.append({
            'pointer_ref': ref,
            'source_offset_shared': source_off,
            'new_offset_fr': storage_off,
            'target_es': target,
            'unit_ids': list(unit_ids),
        })
    final = bytes(out)
    for ch in changes:
        raw = ch['target_es'].encode('latin-1') + b'\0'
        if final[ch['new_offset_fr']:ch['new_offset_fr'] + len(raw)] != raw:
            raise K7Error('DIRECTO EUR compartido: verificación de texto fallida.')
        if struct.unpack_from('<I', final, ch['pointer_ref'])[0] != ch['new_offset_fr'] + delta:
            raise K7Error('DIRECTO EUR compartido: verificación de puntero fallida.')
    return final, {
        'changes': changes,
        'changed_units': len(changed_units),
        'changed_unit_ids': sorted(changed_units),
        'verified_contexts': len(changes),
    }

def _eur_patch_all_direct_binaries(
    sles_original: bytes,
    module_originals: dict[str, bytes],
    scene_selector_targets: dict[str, str] | None = None,
) -> tuple[bytes, dict[str, bytes], dict]:
    """Aplica todos los DIRECTO EUR que tienen equivalencia francesa verificable.

    Los nombres de capítulo del selector comparten estas mismas tablas trilingües
    del SLES. En v1.7.7.28 sus targets EUR editables tienen prioridad sobre los
    targets integrados del manifiesto.
    """
    all_items = _eur_direct_patch_items_from_manifest()
    # v1.7.7.158: el parche integrado 4759 es anterior a la localización de la
    # octava línea del Blood Room. Inyectarla de forma sintética si aún no figura
    # en el manifiesto, sin alterar el paquete AFS histórico.
    if not any(str(x.get('unit_id', '')) == 'k7-9001-07-00' for x in all_items):
        all_items.append(dict(_EUR_BLOOD_ROOM_MISSING_ITEM))
    _eur_verify_blood_room_catalog()
    # MAPA v1.7.7.135: fuerza el catálogo completo, incluso targets que coinciden
    # con el inglés y por tanto no estaban presentes en el parche compilado USA.
    by_uid = {str(item.get('unit_id', '')): item for item in all_items}
    for spec in _EUR_MAP_DIRECT_PATCH_ITEMS:
        uid = str(spec['unit_id'])
        if uid in by_uid:
            by_uid[uid]['target'] = str(spec['target'])
        elif str(spec.get('target', '')) != str(spec.get('source', '')):
            # Si ES==EN y la unidad no existe en el parche compilado no forzamos
            # una relocalización inútil de un nombre propio compartido EN/FR.
            item = dict(spec)
            all_items.append(item)
            by_uid[uid] = item
    selector = _eur_scene_selector_targets(scene_selector_targets)
    chapter_targets = {
        source: selector[key]
        for key, source in _EUR_SCENE_SELECTOR_CHAPTER_EN.items()
    }
    present_sources = set()
    for item in all_items:
        source = str(item.get('source', ''))
        if source in chapter_targets:
            item['target'] = chapter_targets[source]
            present_sources.add(source)
    # Angel no estaba en el manifiesto porque EN==ES histórico, y Alter Ego sólo
    # necesita entrada sintética cuando el usuario lo cambia. La búsqueda genérica
    # sigue resolviendo exclusivamente la columna francesa de la tabla EN/FR/DE.
    for key, source in _EUR_SCENE_SELECTOR_CHAPTER_EN.items():
        if source in present_sources:
            continue
        target = chapter_targets[source]
        if source == 'Alter Ego' and target == source:
            continue
        all_items.append({
            'unit_id': f'eur-scene-{key}', 'source': source, 'target': target,
            'iso_path': EUR_SUPPORTED_SERIAL, 'kind': 'eur-scene-selector-chapter',
        })
    by_path: dict[str, list[dict]] = defaultdict(list)
    for item in all_items:
        by_path[_eur_direct_path_key(str(item.get('iso_path', '')))].append(item)

    # Excluir del detector genérico lo que tiene un mapeo francés fijo/manual,
    # el bloque Memory Card y las C-strings compartidas con relocalización propia.
    memory_unit_ids = {
        str(item.get('unit_id', '')) for item in by_path.get(EUR_SUPPORTED_SERIAL, [])
        if str(item.get('unit_id', '')).startswith('k7-9010-')
    }
    shared_unit_ids = {
        uid for _ref, _src, _dst, _cap, _target, uids in _EUR_DIRECT_SHARED_FR_RELOCS for uid in uids
    }
    blood_long_unit_ids = {'k7-9001-05-00'}
    sles_skip = set(_EUR_DIRECT_MANUAL_UNITS) | memory_unit_ids | shared_unit_ids | blood_long_unit_ids | {
        uid for uid in _EUR_DIRECT_FIXED_UNITS if uid.startswith('k7-90')
    }
    sles_generic, sles_info = _eur_patch_trilingual_direct_file(
        sles_original,
        by_path.get(EUR_SUPPORTED_SERIAL, []),
        0xFFE80,
        label=EUR_SUPPORTED_SERIAL,
        skip_units=sles_skip,
    )
    sles_blood, blood_info = _eur_patch_blood_room_long_french(sles_generic)
    sles_fixed, sles_fixed_info = _eur_patch_fixed_direct_strings(
        sles_blood, _EUR_DIRECT_FIXED_SLES_SPECS, label=EUR_SUPPORTED_SERIAL
    )
    sles_shared, shared_info = _eur_patch_shared_french_pointers(sles_fixed)
    sles_memory, memory_info = _eur_patch_memory_card_french(sles_shared, memory_unit_ids)
    # Menú principal/Opciones tienen relocalizaciones verificadas específicas y
    # acentos Latin-1. Después se aplica, como ÚLTIMA escritura del SLES, el codec
    # del selector de escenas para que Á/b/ó coincidan con los donors de SceSel_F.
    sles_manual, manual_info = _eur_patch_sles_french(sles_memory)
    sles_chapter_strings, scene_chapter_info = _eur_patch_scene_selector_chapter_strings(
        sles_manual, scene_selector_targets
    )
    # v1.7.7.150: las C-strings no controlan por sí solas el título grande.
    # Sincronizar también puntero, cinco registros y contador de chapter_00 FR.
    sles_angel, scene_sprite_info = _eur_patch_scene_selector_angel_sprite_records(
        sles_chapter_strings, scene_selector_targets
    )
    sles_final, scene_all_sprite_info = _eur_patch_scene_selector_remaining_sprite_records(
        sles_angel, scene_selector_targets
    )

    module_final: dict[str, bytes] = {}
    module_reports: dict[str, dict] = {}
    for rel_path, original in module_originals.items():
        if len(original) < 12 or original[:4] != b'MWo3':
            raise K7Error(f'DIRECTO EUR: módulo inesperado {rel_path}.')
        delta = struct.unpack_from('<I', original, 8)[0]
        fixed_specs = _EUR_DIRECT_FIXED_MODULE_SPECS.get(rel_path, [])
        fixed_ids = {uid for _o, _s, _t, uids in fixed_specs for uid in uids}
        patched, info = _eur_patch_trilingual_direct_file(
            original,
            by_path.get(rel_path, []),
            delta,
            label=rel_path,
            skip_units=fixed_ids,
        )
        fixed_info = {'changes': [], 'changed_unit_ids': [], 'changed_units': 0}
        if fixed_specs:
            patched, fixed_info = _eur_patch_fixed_direct_strings(patched, fixed_specs, label=rel_path)
        if len(patched) != len(original):
            raise K7Error(f'DIRECTO EUR: {rel_path} cambió de tamaño.')
        module_final[rel_path] = patched
        module_reports[rel_path] = {'generic': info, 'fixed': fixed_info}

    manifest_ids = {str(x.get('unit_id', '')) for x in all_items}
    changed_units = {x['unit_id'] for x in sles_info['changes']}
    changed_units.update(blood_info.get('changed_unit_ids', []))
    changed_units.update(sles_fixed_info.get('changed_unit_ids', []))
    changed_units.update(shared_info.get('changed_unit_ids', []))
    changed_units.update(memory_info.get('changed_unit_ids', []))
    changed_units.update(_EUR_DIRECT_MANUAL_UNITS)
    for info in module_reports.values():
        changed_units.update(x['unit_id'] for x in info['generic']['changes'])
        changed_units.update(info['fixed'].get('changed_unit_ids', []))
    for alias_uid, component_uids in _EUR_DIRECT_COMPOSITE_ALIASES.items():
        if all(uid in changed_units for uid in component_uids):
            changed_units.add(alias_uid)
    changed_units &= manifest_ids
    pending_units = manifest_ids - changed_units

    # Construir razones pendientes de forma informativa desde el detector genérico.
    reason_by_uid: dict[str, str] = {}
    for row in sles_info.get('pending', []):
        reason_by_uid[str(row.get('unit_id', ''))] = str(row.get('reason', 'unmapped'))
    for info in module_reports.values():
        for row in info['generic'].get('pending', []):
            reason_by_uid[str(row.get('unit_id', ''))] = str(row.get('reason', 'unmapped'))
    pending_detail = [
        {'unit_id': uid, 'reason': reason_by_uid.get(uid, 'sin-equivalente-fr-verificado')}
        for uid in sorted(pending_units)
    ]

    return sles_final, module_final, {
        'generic_sles': sles_info,
        'blood_room_sles': blood_info,
        'fixed_sles': sles_fixed_info,
        'shared_sles': shared_info,
        'memory_card_sles': memory_info,
        'manual_sles': manual_info,
        'scene_selector_chapter_codec': scene_chapter_info,
        'scene_selector_angel_sprite_table': scene_sprite_info,
        'scene_selector_all_sprite_tables': scene_all_sprite_info,
        'modules': module_reports,
        'changed_units': len(changed_units),
        'pending_units': len(pending_units),
        'changed_unit_ids': sorted(changed_units),
        'pending_unit_ids': sorted(pending_units),
        'pending': pending_detail,
        'total_manifest_direct': len(all_items),
        'note': (
            'DIRECTO aplicado exclusivamente a slots/punteros franceses EUR verificados '
            'en SLES_533.66 y S01M-S07M; nunca se escriben offsets USA.'
        ),
    }


def _eur_patch_sles_french(sles: bytes) -> tuple[bytes, dict]:
    """Sustituye menús franceses verificados por los targets españoles actuales.

    Se parchean offsets/punteros concretos de SLES_533.66 para no tocar las ramas
    inglesa o alemana cuando comparten una misma C-string (OPTIONS/Vibration).
    """
    out = bytearray(sles)
    changes = []
    VADDR_DELTA = 0xFFE80  # PT_LOAD principal: vaddr = file_offset + 0xFFE80

    def patch_slot(offset: int, source: str, target: str, slot_size: int, encoding: str = 'latin-1'):
        src = source.encode(encoding) + b'\0'
        tgt = target.encode(encoding) + b'\0'
        if bytes(out[offset:offset + len(src)]) != src:
            found = bytes(out[offset:offset + max(len(src), 32)])
            raise K7Error(
                f'Base EUR francesa: SLES inesperado en 0x{offset:X}; '
                f'se esperaba {source!r}, bytes={found[:len(src)].hex().upper()}.'
            )
        if len(tgt) > slot_size:
            raise K7Error(
                f'Base EUR francesa: {target!r} no cabe en slot 0x{offset:X} '
                f'({len(tgt)}>{slot_size} bytes incluyendo NUL).'
            )
        payload = tgt + b'\0' * (slot_size - len(tgt))
        out[offset:offset + slot_size] = payload
        changes.append({
            'kind': 'slot', 'offset': offset, 'source': source, 'target': target,
            'slot_size': slot_size, 'encoding': encoding,
        })

    def write_free(offset: int, target: str, slot_size: int, encoding: str = 'latin-1'):
        tgt = target.encode(encoding) + b'\0'
        if len(tgt) > slot_size:
            raise K7Error(f'Base EUR: almacenamiento auxiliar insuficiente para {target!r}.')
        current = bytes(out[offset:offset + slot_size])
        if any(current):
            raise K7Error(
                f'Base EUR: la zona auxiliar 0x{offset:X} ya no está libre: {current.hex().upper()}.'
            )
        out[offset:offset + slot_size] = tgt + b'\0' * (slot_size - len(tgt))
        changes.append({'kind': 'relocated-string', 'offset': offset, 'target': target, 'slot_size': slot_size})

    def patch_slot_fallback(offset: int, source: str, target: str, slot_size: int, encoding: str = 'latin-1'):
        """Parche fijo tolerante: acepta que el detector genérico ya haya traducido el slot."""
        src = source.encode(encoding) + b'\0'
        tgt = target.encode(encoding) + b'\0'
        current = bytes(out[offset:offset + slot_size])
        if current.startswith(tgt):
            return
        if not current.startswith(src):
            raise K7Error(
                f'Base EUR francesa: fallback inesperado en 0x{offset:X}; '
                f'se esperaba {source!r} o {target!r}, bytes={current.hex().upper()}.'
            )
        if len(tgt) > slot_size:
            raise K7Error(
                f'Base EUR francesa: {target!r} no cabe en fallback 0x{offset:X} '
                f'({len(tgt)}>{slot_size} bytes incluyendo NUL).'
            )
        out[offset:offset + slot_size] = tgt + b'\0' * (slot_size - len(tgt))
        changes.append({
            'kind': 'slot-fallback', 'offset': offset, 'source': source, 'target': target,
            'slot_size': slot_size, 'encoding': encoding,
        })

    def patch_pointer(offset: int, expected_file_offset: int, target_file_offset: int, label: str):
        expected = expected_file_offset + VADDR_DELTA
        target = target_file_offset + VADDR_DELTA
        current = struct.unpack_from('<I', out, offset)[0]
        if current != expected:
            raise K7Error(
                f'Base EUR: puntero francés {label} inesperado en 0x{offset:X}: '
                f'0x{current:08X} != 0x{expected:08X}.'
            )
        struct.pack_into('<I', out, offset, target)
        changes.append({
            'kind': 'pointer', 'offset': offset, 'label': label,
            'from_vaddr': expected, 'to_vaddr': target,
            'target_file_offset': target_file_offset,
        })

    # ---------------- Título de capítulo 00: Angel / Ange / Engel ----------------
    # v1.7.7.145: el titlefont francés real contiene À (0xC0) pero no Á. Reutilizamos
    # ese slot: el binario guarda «Àngel» y 00__f.dic/titlefont transforma À -> Á.
    # También normaliza el hotfix .144 (0xC1ngel) si se aplica sobre una ISO ya tocada.
    def patch_angel_donor(offset: int):
        slot_size=8
        current=bytes(out[offset:offset+slot_size])
        accepted=(b'Ange\0',b'\xC0ngel\0',b'\xC1ngel\0',b'Angel\0')
        if not any(current.startswith(x) for x in accepted):
            raise K7Error(
                f'Base EUR francesa: Angel/Ange inesperado en 0x{offset:X}; '
                f'bytes={current.hex().upper()}.'
            )
        target=b'\xC0ngel\0'
        if current.startswith(target):
            return
        out[offset:offset+slot_size]=target+b'\0'*(slot_size-len(target))
        changes.append({
            'kind':'slot-font-remap','offset':offset,'source':'Ange','target':'Ángel',
            'encoded_as':'Àngel','encoded_bytes':target.hex().upper(),
            'slot_size':slot_size,'encoding':'Latin-1 0xC0 + titlefont À→Á',
        })
    patch_angel_donor(0x509D48)
    patch_angel_donor(0x50CD38)

    # ---------------- Menú principal: tabla EN/FR/DE en 0x4B4720 ----------------
    # La cadena francesa de PRESS START tiene 32 bytes. Después de PULSA START
    # quedan 20 bytes libres; usamos 9 para OPCIONES y repuntamos SOLO la columna FR.
    patch_slot(0x4F4A40, 'APPUYER SUR TOUCHE START', 'PULSA START', 32)
    write_free(0x4F4A4C, 'OPCIONES', 9)
    patch_slot(0x4F4A90, 'NOUVELLE PARTIE', 'NUEVA PARTIDA', 16)
    patch_slot(0x4F4AC0, 'CONTINUER', 'CONTINUAR', 16)
    # OPTIONS inglés/francés comparten 0x4F4AD8. No se toca la cadena compartida:
    # sólo el puntero FR (segunda columna de la fila OPTIONS).
    patch_pointer(0x4B4754, 0x4F4AD8, 0x4F4A4C, 'Menú principal / OPCIONES')

    # Otro CONTINUER francés verificado (pantalla de continuación/reintento).
    patch_slot(0x50C158, 'CONTINUER', 'CONTINUAR', 16)

    # ---------------- Opciones: tabla EN/FR/DE en 0x4C6030 ----------------
    patch_slot(0x50CF70, 'Passer en Mode Inversé', 'Cambiar a mira invertida.', 32)
    patch_slot(
        0x50CFD0, 'Activer ou Désactiver la fonction de Vibration.',
        'Activar/desactivar vibración.', 48
    )
    # Aprovechamos el padding de ese slot francés largo para la etiqueta Vibración,
    # ya que "Vibration" es una C-string compartida por EN/FR/DE.
    write_free(0x50CFF0, 'Vibración', 16)
    patch_pointer(0x4C6070, 0x50D148, 0x50CFF0, 'Opciones / Vibración')

    patch_slot(0x50D050, 'Changer les options sonores', 'Cambiar opciones de sonido.', 32)
    patch_slot(0x50D0B0, "Retourner à l'écran Titre", 'Volver a pantalla de titulo.', 32)
    patch_slot(0x50D110, 'Commandes Inversées', 'Controles invertidos', 32)
    patch_slot(0x50D160, 'Son', 'Sonido', 16)
    patch_slot(0x50D190, "Retour à l'écran Titre", 'Volver al titulo', 24)

    # Estados franceses propios de la pantalla de opciones.
    patch_slot(0x50D1A8, 'OUI', 'SI', 8)
    patch_slot(0x50D1C0, 'NON', 'NO', 8)
    # La É es oficial EUR; option_f.dat se amplía además con E y ó del mismo estilo.
    patch_slot(0x50D1E0, 'STÉRÉO', 'ESTÉREO', 8)

    return bytes(out), {
        'changes': changes,
        'count': len(changes),
        'string_changes': sum(1 for x in changes if x.get('kind') in ('slot', 'relocated-string')),
        'pointer_changes': sum(1 for x in changes if x.get('kind') == 'pointer'),
        'encoding': 'Latin-1 nativo EUR',
        'note': (
            'Menú principal y pantalla de opciones parcheados mediante slots/punteros '
            'franceses verificados; las ramas EN/DE compartidas permanecen intactas.'
        ),
    }


def current_eur_spanish_patch_path() -> Path:
    """Materializa temporalmente los 4.759 payloads españoles integrados.

    El programa ya no distribuye ``Killer7_ES_4759_CURRENT.k7patch`` dentro de
    ``eur_base``. Los payloads activos se conservan desempaquetados en
    ``eur_base/compiled_es_4759`` y sólo se crea un contenedor temporal cuando
    una rutina heredada necesita la interfaz ZIP del parche compilado.
    """
    source_dir = resource_path('resources', 'eur_base') / 'compiled_es_4759'
    manifest_path = source_dir / 'manifest.json'
    if not manifest_path.is_file():
        raise K7Error(
            'Faltan los payloads españoles integrados: '
            f'{source_dir}'
        )
    manifest_hash = hashlib.sha256(manifest_path.read_bytes()).hexdigest()[:16]
    cache_dir = Path(tempfile.gettempdir()) / 'killer7_xliff_project'
    cache_dir.mkdir(parents=True, exist_ok=True)
    patch_path = cache_dir / f'Killer7_ES_4759_{manifest_hash}.k7patch'
    if patch_path.is_file():
        return patch_path

    tmp_path = patch_path.with_name(patch_path.name + '.tmp')
    if tmp_path.exists():
        tmp_path.unlink()
    try:
        with zipfile.ZipFile(tmp_path, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
            for file_path in sorted(source_dir.rglob('*')):
                if file_path.is_file():
                    z.write(file_path, file_path.relative_to(source_dir).as_posix())
        tmp_path.replace(patch_path)
    finally:
        if tmp_path.exists():
            tmp_path.unlink()
    return patch_path


def apply_current_spanish_to_eur_archive(eur_zip: str | Path, output_zip: str | Path, cinematic_targets: dict[str, str] | None = None, scene_selector_targets: dict[str, str] | None = None) -> dict:
    """Aplica el proyecto español integrado directamente sobre Killer7EUR.zip."""
    patch = current_eur_spanish_patch_path()
    if not patch.is_file():
        raise K7Error(f'Falta el paquete español integrado para EUR: {patch}')
    with zipfile.ZipFile(patch, 'r') as z:
        try:
            manifest = json.loads(z.read('manifest.json').decode('utf-8'))
        except Exception as exc:
            raise K7Error(f'Paquete español EUR integrado inválido: {exc}') from exc
    if int(manifest.get('translated_units', -1)) != 4759:
        raise K7Error(
            'El paquete español EUR integrado no contiene las 4.759 unidades esperadas; '
            'se cancela para no mezclar revisiones.'
        )
    return apply_spanish_patch_to_eur_archive(eur_zip, patch, output_zip, cinematic_targets=cinematic_targets, scene_selector_targets=scene_selector_targets)

def apply_spanish_patch_to_eur_archive(eur_zip: str | Path, patch_zip: str | Path, output_zip: str | Path, cinematic_targets: dict[str, str] | None = None, scene_selector_targets: dict[str, str] | None = None) -> dict:
    """Create an experimental EUR/French-base archive with the Spanish project transplanted.

    The stable USA compiler remains the source of truth for translated payloads. This
    function maps those compiled AFS payloads onto the verified French-language slots
    in D_EU/DIR_E.AFS from Killer7EUR.zip. It does not change the stable USA injector.

    v1.7.7.14 ports the compiled AFS layer to the French branch, rebuilds all translated
    .da atlases with official French EUR glyphs, and maps the verified main/options
    menu tables in SLES_533.66. Other direct SLES/module strings remain reported as
    pending until their EUR French slots are mapped unambiguously.
    """
    eur_zip = Path(eur_zip)
    patch_zip = Path(patch_zip)
    output_zip = Path(output_zip)
    if not eur_zip.is_file():
        raise K7Error(f'Base francesa: no existe el ZIP EUR: {eur_zip}')
    if not patch_zip.is_file():
        raise K7Error(f'Base francesa: no existe el parche español compilado: {patch_zip}')
    if output_zip.resolve() == eur_zip.resolve():
        raise K7Error('Base francesa: el ZIP EUR original no se puede sobrescribir.')

    tmp_output = output_zip.with_name(output_zip.name + '.tmp')
    if tmp_output.exists():
        tmp_output.unlink()

    with tempfile.TemporaryDirectory(prefix='killer7_eur_fr_base_') as td:
        td = Path(td)
        source_afs = td / 'DIR_E.AFS'
        rebuilt_afs = td / 'DIR_E_ES.AFS'

        with zipfile.ZipFile(eur_zip, 'r') as zin:
            members = zin.infolist()
            afs_members = [i for i in members if i.filename.replace('\\', '/').endswith('/D_EU/DIR_E.AFS')]
            sles_members = [i for i in members if i.filename.replace('\\', '/').endswith('/SLES_533.66')]
            module_paths = [f'MODULES/BIN/S0{i}M.BIN' for i in range(1, 8)]
            module_members = {
                rel: [i for i in members if i.filename.replace('\\', '/').endswith('/' + rel)]
                for rel in module_paths
            }
            if len(afs_members) != 1 or len(sles_members) != 1 or any(len(v) != 1 for v in module_members.values()):
                raise K7Error(
                    'Base francesa: el ZIP debe contener SLES_533.66, D_EU/DIR_E.AFS y MODULES/BIN/S01M-S07M.'
                )
            afs_info = afs_members[0]
            sles_info = sles_members[0]
            module_infos = {rel: rows[0] for rel, rows in module_members.items()}
            with zin.open(afs_info, 'r') as src, source_afs.open('wb') as dst:
                shutil.copyfileobj(src, dst, length=1024 * 1024)
            sles_original = zin.read(sles_info)
            module_originals = {rel: zin.read(info) for rel, info in module_infos.items()}

        replacements, mapping = _eur_build_replacements(source_afs, patch_zip, cinematic_targets, scene_selector_targets, sles_original)
        afs_build = _eur_rebuild_afs(source_afs, rebuilt_afs, replacements)
        sles_patched, module_patched, direct_fr = _eur_patch_all_direct_binaries(
            sles_original, module_originals, scene_selector_targets
        )
        sles_fr = direct_fr['manual_sles']

        # Deep structural verification before producing the user-facing archive.
        vr_entries, vr_name_off, vr_name_size, _vr_names_raw, _vr_names = _eur_parse_afs(rebuilt_afs)
        if len(vr_entries) != mapping['afs_entries']:
            raise K7Error('Base francesa: verificación AFS fallida (cambió el número de entradas).')
        if rebuilt_afs.stat().st_size < afs_build['logical_size']:
            raise K7Error('Base francesa: verificación AFS fallida (salida truncada).')
        with rebuilt_afs.open('rb') as check:
            # Verify every replaced payload, not just a sample.
            for idx, expected in replacements.items():
                got = _eur_read_entry(check, vr_entries, idx)
                if got != expected:
                    raise K7Error(f'Base francesa: verificación AFS fallida en entrada #{idx}.')

        report = {
            'format': 'killer7-eur-french-base-spanish-test',
            'version': 1,
            'source_archive': eur_zip.name,
            'source_archive_sha256': _eur_file_sha256(eur_zip),
            'compiled_patch': patch_zip.name,
            'compiled_patch_sha256': _eur_file_sha256(patch_zip),
            'afs': {**mapping, **afs_build},
            'sles_french_verified': sles_fr,
            'direct_strings': direct_fr,
            'usage': 'Base primaria: edición EUR. Ejecutar con idioma francés para activar los slots sustituidos por español.',
        }
        report_bytes = (json.dumps(report, ensure_ascii=False, indent=2) + '\n').encode('utf-8')

        with zipfile.ZipFile(eur_zip, 'r') as zin, zipfile.ZipFile(
            tmp_output, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9, allowZip64=True
        ) as zout:
            for info in zin.infolist():
                fn = info.filename
                if fn == afs_info.filename:
                    # Keep the original pathname, timestamp and external attributes.
                    new_info = zipfile.ZipInfo(fn, date_time=info.date_time)
                    new_info.compress_type = zipfile.ZIP_DEFLATED
                    new_info.external_attr = info.external_attr
                    new_info.create_system = info.create_system
                    with rebuilt_afs.open('rb') as src, zout.open(new_info, 'w', force_zip64=True) as dst:
                        shutil.copyfileobj(src, dst, length=1024 * 1024)
                elif fn == sles_info.filename:
                    new_info = zipfile.ZipInfo(fn, date_time=info.date_time)
                    new_info.compress_type = zipfile.ZIP_DEFLATED
                    new_info.external_attr = info.external_attr
                    new_info.create_system = info.create_system
                    zout.writestr(new_info, sles_patched)
                elif any(fn == mi.filename for mi in module_infos.values()):
                    rel = next(rel for rel, mi in module_infos.items() if fn == mi.filename)
                    new_info = zipfile.ZipInfo(fn, date_time=info.date_time)
                    new_info.compress_type = zipfile.ZIP_DEFLATED
                    new_info.external_attr = info.external_attr
                    new_info.create_system = info.create_system
                    zout.writestr(new_info, module_patched[rel])
                else:
                    if info.is_dir():
                        zout.writestr(info, b'')
                    else:
                        with zin.open(info, 'r') as src, zout.open(info, 'w', force_zip64=True) as dst:
                            shutil.copyfileobj(src, dst, length=1024 * 1024)
            root = afs_info.filename.split('/D_EU/DIR_E.AFS', 1)[0]
            report_name = (root + '/ES_NUEVA_PRUEBA_REPORT.json') if root else 'ES_NUEVA_PRUEBA_REPORT.json'
            zout.writestr(report_name, report_bytes)

        # Final ZIP readback: ensure both replacements are present and valid.
        with zipfile.ZipFile(tmp_output, 'r') as zcheck:
            if zcheck.testzip() is not None:
                raise K7Error('Base francesa: el ZIP EUR de salida no supera la verificación CRC.')
            scheck = zcheck.read(sles_info.filename)
            if b'EST\xC9REO\x00' not in scheck:
                raise K7Error('Base EUR francesa: ESTÉREO no aparece en el SLES de salida.')
            if b'Vibraci\xF3n\x00' not in scheck:
                raise K7Error('Base EUR francesa: Vibración no aparece en el SLES de salida.')
            for old in (b'APPUYER SUR TOUCHE START\x00', b'NOUVELLE PARTIE\x00', b'ST\xC9R\xC9O\x00'):
                if old in scheck:
                    raise K7Error('Base EUR francesa: quedó una cadena francesa verificada sin sustituir.')
            if direct_fr.get('changed_units') != direct_fr.get('total_manifest_direct') or direct_fr.get('pending_units') != 0:
                raise K7Error('Base EUR francesa: la cobertura DIRECTO no es 447/447.')
            for rel, info in module_infos.items():
                if zcheck.read(info.filename) != module_patched[rel]:
                    raise K7Error(f'Base EUR francesa: módulo {rel} no coincide con el verificado.')

        tmp_output.replace(output_zip)
        report['output_archive'] = output_zip.name
        report['output_archive_sha256'] = _eur_file_sha256(output_zip)
        return report


# ---------------------------------------------------------------------------
# EUR ISO primary workflow (v1.7.7.8)
# ---------------------------------------------------------------------------

EUR_SUPPORTED_SERIAL = 'SLES_533.66'


def _eur_copy_iso_node(iso_path: Path, node, output_path: Path) -> None:
    """Copy one ISO9660 file extent to disk without extracting the whole image."""
    remaining = int(node.size)
    offset = int(node.lba) * 2048
    with iso_path.open('rb') as src, output_path.open('wb') as dst:
        src.seek(offset)
        while remaining:
            chunk = src.read(min(1024 * 1024, remaining))
            if not chunk:
                raise K7Error(f'ISO EUR truncada al extraer {node.path}.')
            dst.write(chunk)
            remaining -= len(chunk)


def _eur_hash_iso_region(path: Path, absolute_offset: int, size: int) -> str:
    h = hashlib.sha256()
    remaining = int(size)
    with path.open('rb') as fh:
        fh.seek(int(absolute_offset))
        while remaining:
            chunk = fh.read(min(1024 * 1024, remaining))
            if not chunk:
                raise K7Error('ISO EUR truncada durante la verificación final.')
            h.update(chunk)
            remaining -= len(chunk)
    return h.hexdigest()


def _iso_find_directory_record_offset(
    iso_path: str | Path,
    parent_node,
    filename: str,
    expected_lba: int | None = None,
    expected_size: int | None = None,
) -> int:
    """Devuelve el offset absoluto del registro ISO9660 de un hijo.

    Se usa sólo para reubicar DIR_E.AFS cuando las cinemáticas hacen crecer el AFS.
    Valida los campos little/big endian antes de permitir cualquier escritura.
    """
    iso_path = Path(iso_path)
    base = int(parent_node.lba) * 2048
    with iso_path.open('rb') as fh:
        fh.seek(base)
        data = fh.read(int(parent_node.size))
    p = 0
    wanted = filename.upper().split(';', 1)[0]
    while p < len(data):
        ln = data[p]
        if ln == 0:
            p = ((p // 2048) + 1) * 2048
            continue
        rec = data[p:p + ln]
        if len(rec) < ln or len(rec) < 34:
            break
        nlen = rec[32]
        raw_name = rec[33:33 + nlen]
        if raw_name not in (b'\x00', b'\x01'):
            name = raw_name.decode('ascii', 'replace').split(';', 1)[0].upper()
            if name == wanted:
                lba_le = struct.unpack_from('<I', rec, 2)[0]
                lba_be = struct.unpack_from('>I', rec, 6)[0]
                size_le = struct.unpack_from('<I', rec, 10)[0]
                size_be = struct.unpack_from('>I', rec, 14)[0]
                if lba_le != lba_be or size_le != size_be:
                    raise K7Error('ISO EUR: registro ISO9660 con campos endian inconsistentes.')
                if expected_lba is not None and lba_le != int(expected_lba):
                    raise K7Error('ISO EUR: el registro DIR_E.AFS no apunta al extent esperado.')
                if expected_size is not None and size_le != int(expected_size):
                    raise K7Error('ISO EUR: el registro DIR_E.AFS no tiene el tamaño esperado.')
                return base + p
        p += ln
    raise K7Error(f'ISO EUR: no se encontró el registro ISO9660 de {filename}.')


def _iso_write_both_u32(fh, offset: int, value: int) -> None:
    if not (0 <= int(value) <= 0xFFFFFFFF):
        raise K7Error(f'ISO EUR: valor ISO9660 fuera de rango: {value}.')
    fh.seek(int(offset))
    fh.write(struct.pack('<I', int(value)))
    fh.write(struct.pack('>I', int(value)))


def _iso_update_volume_space_size(fh, total_sectors: int) -> int:
    """Actualiza Volume Space Size en PVD/SVD compatibles y devuelve cuántos tocó."""
    changed = 0
    for sector in range(16, 80):
        off = sector * 2048
        fh.seek(off)
        head = fh.read(7)
        if len(head) < 7:
            break
        dtype = head[0]
        if head[1:6] != b'CD001':
            continue
        if dtype in (1, 2):
            _iso_write_both_u32(fh, off + 80, total_sectors)
            changed += 1
        if dtype == 255:
            break
    if changed < 1:
        raise K7Error('ISO EUR: no se encontró el descriptor de volumen ISO9660 para ampliar la imagen.')
    return changed


def _iso_append_and_relocate_file(
    fh,
    source_file: Path,
    directory_record_offset: int,
) -> dict:
    """Añade un archivo al final de la ISO y redirige su registro sin mover otros extents."""
    file_size = source_file.stat().st_size
    fh.seek(0, 2)
    old_iso_size = fh.tell()
    new_lba = _eur_align(old_iso_size) // 2048
    new_off = new_lba * 2048
    if old_iso_size < new_off:
        fh.write(b'\0' * (new_off - old_iso_size))
    with source_file.open('rb') as src:
        shutil.copyfileobj(src, fh, length=1024 * 1024)
    end = fh.tell()
    padded_end = _eur_align(end)
    if end < padded_end:
        fh.write(b'\0' * (padded_end - end))

    # Directory Record: extent LBA y data length, ambos en formato 7.3.3 (LE+BE).
    _iso_write_both_u32(fh, int(directory_record_offset) + 2, new_lba)
    _iso_write_both_u32(fh, int(directory_record_offset) + 10, file_size)
    total_sectors = padded_end // 2048
    descriptors = _iso_update_volume_space_size(fh, total_sectors)
    fh.flush()
    return {
        'relocated': True,
        'old_iso_size': old_iso_size,
        'new_iso_size': padded_end,
        'lba': new_lba,
        'size': file_size,
        'volume_sectors': total_sectors,
        'volume_descriptors_updated': descriptors,
    }



def _eur_scan_exact_payload_positions(
    image_path: Path,
    payloads: dict[int, bytes],
    *,
    chunk_size: int = 32 * 1024 * 1024,
) -> dict[int, list[int]]:
    """Localiza todas las copias byte-a-byte de payloads en una imagen.

    v1.7.7.179: 77102 puede existir fuera de la ruta AFS que hemos catalogado.
    Buscar el recurso COMPLETO evita heurísticas por strings/offsets y permite
    reflejar cualquier espejo retail sin tocar datos que sólo se parezcan.
    """
    needles = {int(k): bytes(v) for k, v in payloads.items() if v}
    if not needles:
        return {}
    max_len = max(len(v) for v in needles.values())
    overlap_len = max(0, max_len - 1)
    hits: dict[int, set[int]] = {k: set() for k in needles}
    consumed = 0
    tail = b''
    with Path(image_path).open('rb') as fh:
        while True:
            chunk = fh.read(int(chunk_size))
            if not chunk:
                break
            data = tail + chunk
            base = consumed - len(tail)
            for key, needle in needles.items():
                start = 0
                while True:
                    pos = data.find(needle, start)
                    if pos < 0:
                        break
                    absolute = base + pos
                    if absolute >= 0:
                        hits[key].add(int(absolute))
                    start = pos + 1
            consumed += len(chunk)
            if overlap_len:
                tail = data[-overlap_len:]
            else:
                tail = b''
    return {k: sorted(v) for k, v in hits.items()}


def _eur_patch_exact_payload_positions(
    fh,
    positions: dict[int, list[int]],
    originals: dict[int, bytes],
    replacements: dict[int, bytes],
) -> dict:
    """Sustituye todos los espejos exactos de 77102 encontrados en la ISO retail."""
    patched = {}
    # Primero los contenedores grandes (DAR) para que sus hijos JMB/DIC
    # queden ya en estado `new` cuando se verifiquen las coincidencias anidadas.
    for idx in sorted(positions, key=lambda k: len(originals[int(k)]), reverse=True):
        old = originals[int(idx)]
        new = replacements[int(idx)]
        if len(old) != len(new):
            raise K7Error(
                f'ISO EUR 77102 global: #{idx} cambió de tamaño '
                f'({len(old)} -> {len(new)}); no es seguro parchear espejos exactos.'
            )
        rows = []
        for absolute in positions[idx]:
            fh.seek(int(absolute))
            before = fh.read(len(old))
            # La zona puede haber sido parcheada ya por runtime-shadow o por un
            # contenedor padre (DAR). Aceptamos ambos estados, nunca un tercero.
            if before not in (old, new):
                raise K7Error(
                    f'ISO EUR 77102 global: contenido inesperado en 0x{absolute:X} para #{idx}.'
                )
            if before == old:
                fh.seek(int(absolute))
                fh.write(new)
            rows.append(int(absolute))
        patched[str(idx)] = rows

    fh.flush()
    for idx_s, rows in patched.items():
        idx = int(idx_s)
        expected = replacements[idx]
        for absolute in rows:
            fh.seek(int(absolute))
            if fh.read(len(expected)) != expected:
                raise K7Error(
                    f'ISO EUR 77102 global: readback falló en 0x{absolute:X} para #{idx}.'
                )
    return {
        'enabled': True,
        'matches': patched,
        'match_counts': {k: len(v) for k, v in patched.items()},
        'note': 'Todas las copias byte-a-byte retail de JMB/DAR/DIC 77102 se reflejan con el payload parcheado.',
    }

def _eur_write_original_extent_shadow(
    fh,
    source_afs: Path,
    original_afs_absolute: int,
    replacements: dict[int, bytes],
) -> dict:
    """Escribe un shadow AFS compatible en el extent original cuando el AFS se reubica.

    Sólo se copian entradas cuyo tamaño final sea EXACTAMENTE el tamaño retail de
    esa entrada. Así la cabecera AFS original (offset+size) sigue siendo válida y
    no se toca ninguna entrada que necesite crecimiento/reempaquetado. Esto cubre
    77102 in-place y los K7P2 de plantas, además de otros recursos same-size.
    """
    raw_entries, _name_off, _name_size, _name_table, names = _eur_parse_afs(source_afs)
    applied = []
    skipped = []
    base = int(original_afs_absolute)
    for idx in sorted(replacements):
        if not (0 <= int(idx) < len(raw_entries)):
            continue
        off, old_size = raw_entries[int(idx)]
        payload = replacements[int(idx)]
        if len(payload) != int(old_size):
            skipped.append(int(idx))
            continue
        fh.seek(base + int(off))
        fh.write(payload)
        applied.append(int(idx))

    # Guardas específicas de los dos bugs observados en juego.
    critical = [1742, 1743, 1744]
    critical_floor_fonts = [345, 361, 365]
    for idx in [*critical, *critical_floor_fonts]:
        if idx not in applied:
            raise K7Error(
                f'ISO EUR runtime-shadow: la entrada crítica #{idx} ({names[idx]}) '
                'no conserva tamaño y no puede reflejarse en el extent original.'
            )
        off, old_size = raw_entries[idx]
        fh.seek(base + int(off))
        got = fh.read(int(old_size))
        if got != replacements[idx]:
            raise K7Error(f'ISO EUR runtime-shadow: readback fallido en AFS #{idx}.')

    # Los 23 rótulos numéricos aparecen como C-strings MapFontF en diez DAR.
    # El shadow debe eliminar TODOS los «Nth étage» del extent antiguo.
    floor_patterns = [
        b'1er \xb4tage\0', b'2e \xb4tage\0', b'3e \xb4tage\0',
        b'4e \xb4tage\0', b'5e \xb4tage\0',
    ]
    floor_remaining = []
    for idx in applied:
        off, old_size = raw_entries[idx]
        # Limita la lectura a entradas razonables; los DAR K7P2 son pequeños.
        if old_size > 200000:
            continue
        fh.seek(base + int(off))
        blob = fh.read(int(old_size))
        for pat in floor_patterns:
            if pat in blob:
                floor_remaining.append((idx, names[idx], pat[:-1].hex().upper()))
    if floor_remaining:
        sample = ', '.join(f'#{i} {n}' for i, n, _p in floor_remaining[:8])
        raise K7Error(f'ISO EUR runtime-shadow: siguen apareciendo rótulos étage: {sample}.')

    return {
        'enabled': True,
        'same_size_entries': len(applied),
        'skipped_resized_entries': len(skipped),
        'critical_77102': critical,
        'critical_floor_fonts': critical_floor_fonts,
        'floor_french_remaining': len(floor_remaining),
        'note': 'Copia compatible sobre el extent AFS original para loaders que no sigan la reubicación ISO9660.',
    }



def _eur_force_77102_final_afs(afs_path: Path, replacements: dict[int, bytes]) -> dict:
    """Reescribe y verifica 77102 sobre el AFS YA reconstruido.

    Esta pasada es deliberadamente posterior a `_eur_rebuild_afs`: evita que una
    futura capa de empaquetado pueda dejar el JMB francés aunque el payload
    preparado fuese correcto. Las tres entradas conservan el tamaño retail.
    """
    critical = (1742, 1743, 1744)
    for idx in critical:
        if idx not in replacements:
            raise K7Error(f'JMB EUR 77102 final: falta replacement #{idx}.')
    raw_entries, _no, _ns, _nt, names = _eur_parse_afs(afs_path)
    if len(raw_entries) <= 1744 or names[1742:1745] != ['77102', '77102', '77102']:
        raise K7Error('JMB EUR 77102 final: terna AFS final inesperada.')
    with Path(afs_path).open('r+b') as fh:
        for idx in critical:
            off, size = raw_entries[idx]
            payload = replacements[idx]
            if len(payload) != int(size):
                raise K7Error(
                    f'JMB EUR 77102 final: #{idx} mide {len(payload)}; slot final {size}.'
                )
            fh.seek(int(off))
            fh.write(payload)
        fh.flush()
    with Path(afs_path).open('rb') as fh:
        hashes = {}
        for idx in critical:
            got = _eur_read_entry(fh, raw_entries, idx)
            if got != replacements[idx]:
                raise K7Error(f'JMB EUR 77102 final: readback falló en #{idx}.')
            hashes[str(idx)] = hashlib.sha256(got).hexdigest()
    return {
        'indices': list(critical),
        'sizes': [len(replacements[i]) for i in critical],
        'sha256': hashes,
        'stage': 'post-rebuild AFS',
    }

def apply_current_spanish_to_eur_iso(eur_iso: str | Path, output_iso: str | Path, cinematic_targets: dict[str, str] | None = None, scene_selector_targets: dict[str, str] | None = None) -> dict:
    """Apply the current Spanish project directly to a Killer7 PAL/EUR ISO.

    The European ISO is the only game image used by this workflow.  Spanish
    payloads are mapped onto the verified French-language slots inside
    D_EU/DIR_E.AFS together with all integrated translated graphics, plus verified
    French strings in SLES_533.66. SLES/modules stay
    in place. If free-form cinematic glyph tables make DIR_E.AFS grow, the rebuilt
    AFS is appended on fresh sectors at the end of the ISO and only its ISO9660
    directory record is redirected; existing file extents are never shifted.
    """
    eur_iso = Path(eur_iso).resolve()
    output_iso = Path(output_iso).resolve()
    if not eur_iso.is_file():
        raise K7Error(f'No existe la ISO europea: {eur_iso}')
    if eur_iso == output_iso:
        raise K7Error('Por seguridad, la ISO EUR de salida debe ser distinta de la original.')

    patch = current_eur_spanish_patch_path()
    if not patch.is_file():
        raise K7Error(f'Falta el paquete español integrado para EUR: {patch}')
    with zipfile.ZipFile(patch, 'r') as z:
        try:
            manifest = json.loads(z.read('manifest.json').decode('utf-8'))
        except Exception as exc:
            raise K7Error(f'Paquete español EUR integrado inválido: {exc}') from exc
    if int(manifest.get('translated_units', -1)) != 4759:
        raise K7Error(
            'El paquete español EUR integrado no contiene las 4.759 unidades esperadas; '
            'se cancela para no mezclar revisiones.'
        )

    output_iso.parent.mkdir(parents=True, exist_ok=True)
    # Never use the final path as a work file.  A failed run cannot damage an
    # existing destination chosen by the user.
    tmp_output = output_iso.with_name(output_iso.name + '.k7eur.tmp')
    if tmp_output.exists():
        tmp_output.unlink()

    with ISO9660(eur_iso) as iso:
        ident = identify_killer7_iso(iso)
        if ident.get('edition') != 'EUR':
            reported = ident.get('reported_serial') or 'desconocido'
            raise K7Error(
                f'La imagen seleccionada no contiene una estructura Killer7 EUR compatible. '
                f'Serial de SYSTEM.CNF: {reported}; se requieren D_EU/DIR_E.AFS y {EUR_SUPPORTED_SERIAL}.'
            )
        module_paths = [f'MODULES/BIN/S0{i}M.BIN' for i in range(1, 8)]
        try:
            d_eu_node = iso.find(['D_EU'])
            afs_node = iso.find(['D_EU', 'DIR_E.AFS'])
            afs_record_offset = _iso_find_directory_record_offset(
                eur_iso, d_eu_node, 'DIR_E.AFS', afs_node.lba, afs_node.size
            )
            sles_node = iso.find([EUR_SUPPORTED_SERIAL])
            module_nodes = {
                rel: iso.find(rel.split('/'))
                for rel in module_paths
            }
        except Exception as exc:
            raise K7Error(
                'La ISO EUR no contiene la estructura esperada D_EU/DIR_E.AFS + '
                'SLES_533.66 + MODULES/BIN/S01M-S07M.'
            ) from exc
        sles_original = iso.read(sles_node)
        if len(sles_original) != sles_node.size:
            raise K7Error('No se pudo leer SLES_533.66 completo desde la ISO EUR.')
        module_originals = {rel: iso.read(node) for rel, node in module_nodes.items()}
        for rel, data in module_originals.items():
            if len(data) != module_nodes[rel].size:
                raise K7Error(f'No se pudo leer {rel} completo desde la ISO EUR.')

        with tempfile.TemporaryDirectory(prefix='killer7_eur_iso_es_') as td_raw:
            td = Path(td_raw)
            source_afs = td / 'DIR_E.AFS'
            rebuilt_afs = td / 'DIR_E_ES.AFS'
            _eur_copy_iso_node(eur_iso, afs_node, source_afs)
            if source_afs.stat().st_size != afs_node.size:
                raise K7Error('D_EU/DIR_E.AFS se extrajo con un tamaño inesperado.')

            replacements, mapping = _eur_build_replacements(source_afs, patch, cinematic_targets, scene_selector_targets, sles_original)
            afs_build = _eur_rebuild_afs(source_afs, rebuilt_afs, replacements)
            # v1.7.7.171: segunda pasada obligatoria sobre el AFS ya reconstruido
            # para el mensaje Soul Shell / 77102.
            soul_shell_final_afs = _eur_force_77102_final_afs(rebuilt_afs, replacements)
            afs_build['soul_shell_final_afs'] = soul_shell_final_afs
            sles_patched, module_patched, direct_fr = _eur_patch_all_direct_binaries(
                sles_original, module_originals, scene_selector_targets
            )
            sles_fr = direct_fr['manual_sles']

            rebuilt_afs_size = rebuilt_afs.stat().st_size
            # v1.7.7.178: DIR_E_ES.AFS siempre vive en un extent nuevo y mantiene
            # el layout secuencial. El extent retail original queda intacto como
            # shadow y recibe sólo replacements same-size (incluido 77102F).
            # Así no hace falta fijar offsets dentro del AFS principal.
            if len(sles_patched) != sles_node.size:
                raise K7Error(
                    'El SLES español no conserva el tamaño original; no es seguro insertarlo en la ISO.'
                )
            for rel, data in module_patched.items():
                if len(data) != module_nodes[rel].size:
                    raise K7Error(f'El módulo EUR {rel} cambió de tamaño; se cancela la inserción.')

            # Deep AFS verification before touching any output ISO.
            vr_entries, _vr_name_off, _vr_name_size, _vr_names_raw, _vr_names = _eur_parse_afs(rebuilt_afs)
            if len(vr_entries) != mapping['afs_entries']:
                raise K7Error('ISO EUR: verificación AFS fallida (cambió el número de entradas).')
            with rebuilt_afs.open('rb') as check:
                for idx, expected in replacements.items():
                    if _eur_read_entry(check, vr_entries, idx) != expected:
                        raise K7Error(f'ISO EUR: verificación AFS fallida en entrada #{idx}.')

            rebuilt_afs_sha = _eur_file_sha256(rebuilt_afs)
            sles_sha = hashlib.sha256(sles_patched).hexdigest()
            module_shas = {rel: hashlib.sha256(data).hexdigest() for rel, data in module_patched.items()}

            # v1.7.7.179: el savestate s(8) contiene en EE RAM el JMB #1742
            # parcheado exacto (ca122aa7...) mientras la pantalla aún muestra la
            # frase francesa. Eso prueba que existe una ruta/copia retail adicional
            # consumida antes de que el buffer observado quede con #1742. En vez de
            # adivinar otro índice u offset, localizamos en la ISO ORIGINAL todas
            # las copias byte-a-byte de la terna francesa y las reflejamos después.
            source_entries_179, _a179, _b179, _c179, _n179 = _eur_parse_afs(source_afs)
            with source_afs.open('rb') as src179:
                original_77102_payloads = {
                    idx: _eur_read_entry(src179, source_entries_179, idx)
                    for idx in (1742, 1743, 1744)
                }
            patched_77102_payloads = {idx: replacements[idx] for idx in (1742, 1743, 1744)}
            for idx in (1742, 1743, 1744):
                if len(original_77102_payloads[idx]) != len(patched_77102_payloads[idx]):
                    raise K7Error(f'ISO EUR 77102 global: #{idx} dejó de ser same-size.')
            global_77102_positions = _eur_scan_exact_payload_positions(
                eur_iso, original_77102_payloads
            )
            if any(not global_77102_positions.get(idx) for idx in (1742, 1743, 1744)):
                raise K7Error(
                    'ISO EUR 77102 global: no se localizaron todas las copias retail base de #1742/#1743/#1744.'
                )

            try:
                shutil.copyfile(eur_iso, tmp_output)
                if tmp_output.stat().st_size != eur_iso.stat().st_size:
                    raise K7Error('La copia temporal de la ISO EUR tiene un tamaño incorrecto.')

                afs_location = {
                    'relocated': False, 'lba': int(afs_node.lba),
                    'size': int(rebuilt_afs_size),
                }
                runtime_shadow = {
                    'enabled': False,
                    'reason': 'Pendiente de escribir el shadow del extent retail original.',
                }
                with tmp_output.open('r+b') as dst:
                    # v1.7.7.178: relocalización incondicional. El AFS español
                    # secuencial se publica por ISO9660 y el extent retail queda
                    # reservado exclusivamente para el runtime shadow compatible.
                    afs_location = _iso_append_and_relocate_file(
                        dst, rebuilt_afs, afs_record_offset
                    )
                    runtime_shadow = _eur_write_original_extent_shadow(
                        dst, source_afs, int(afs_node.lba) * 2048, replacements
                    )
                    dst.seek(int(sles_node.lba) * 2048)
                    dst.write(sles_patched)
                    for rel, data in module_patched.items():
                        dst.seek(int(module_nodes[rel].lba) * 2048)
                        dst.write(data)
                    # v1.7.7.179: refleja también cualquier copia exacta retail
                    # de 77102 encontrada fuera de las entradas AFS catalogadas.
                    global_77102_exact = _eur_patch_exact_payload_positions(
                        dst, global_77102_positions,
                        original_77102_payloads, patched_77102_payloads
                    )
                    dst.flush()

                # Verify the exact bytes as seen through the finished ISO file.
                afs_region_sha = _eur_hash_iso_region(
                    tmp_output, int(afs_location['lba']) * 2048, int(afs_location['size'])
                )
                sles_region_sha = _eur_hash_iso_region(
                    tmp_output, int(sles_node.lba) * 2048, int(sles_node.size)
                )
                if afs_region_sha != rebuilt_afs_sha:
                    raise K7Error('ISO EUR: el DIR_E.AFS insertado no coincide con el archivo verificado.')
                if sles_region_sha != sles_sha:
                    raise K7Error('ISO EUR: el SLES_533.66 insertado no coincide con el archivo verificado.')
                for rel, node in module_nodes.items():
                    region_sha = _eur_hash_iso_region(
                        tmp_output, int(node.lba) * 2048, int(node.size)
                    )
                    if region_sha != module_shas[rel]:
                        raise K7Error(f'ISO EUR: el módulo insertado {rel} no coincide con el verificado.')

                # v1.7.7.171: lectura directa de las entradas críticas tal como
                # quedan físicamente dentro del AFS final de la ISO, sin confiar
                # únicamente en el SHA del archivo completo.
                final_exact_indices = (1742, 1743, 1744, 345, 361, 365)
                final_afs_base = int(afs_location['lba']) * 2048
                with tmp_output.open('rb') as final_fh:
                    for idx in final_exact_indices:
                        off, size = vr_entries[idx]
                        expected = replacements.get(idx)
                        if expected is None or len(expected) != int(size):
                            raise K7Error(f'ISO EUR: falta payload final exacto para AFS #{idx}.')
                        final_fh.seek(final_afs_base + int(off))
                        got = final_fh.read(int(size))
                        if got != expected:
                            raise K7Error(f'ISO EUR: AFS #{idx} no coincide en la ISO final.')

                with ISO9660(tmp_output) as out_iso:
                    if not is_compatible_eur_iso(out_iso):
                        raise K7Error('ISO EUR: la ISO final dejó de conservar la estructura SLES_533.66 compatible.')
                    out_afs = out_iso.find(['D_EU', 'DIR_E.AFS'])
                    out_sles = out_iso.find([EUR_SUPPORTED_SERIAL])
                    if out_afs.lba != int(afs_location['lba']) or out_afs.size != int(afs_location['size']):
                        raise K7Error('ISO EUR: el registro ISO9660 final de DIR_E.AFS no coincide con la salida.')
                    if hashlib.sha256(out_iso.read(out_afs)).hexdigest() != rebuilt_afs_sha:
                        raise K7Error('ISO EUR: lectura final incorrecta de DIR_E.AFS.')
                    if out_sles.lba != sles_node.lba or out_sles.size != sles_node.size:
                        raise K7Error('ISO EUR: cambió el extent ISO9660 de SLES_533.66.')
                    for rel, old_node in module_nodes.items():
                        out_node = out_iso.find(rel.split('/'))
                        if out_node.lba != old_node.lba or out_node.size != old_node.size:
                            raise K7Error(f'ISO EUR: cambió el extent ISO9660 de {rel}.')
                        if hashlib.sha256(out_iso.read(out_node)).hexdigest() != module_shas[rel]:
                            raise K7Error(f'ISO EUR: lectura final incorrecta de {rel}.')
                    scheck = out_iso.read(out_sles)
                    if b'EST\xC9REO\x00' not in scheck:
                        raise K7Error('ISO EUR: ESTÉREO no aparece en el SLES final.')
                    if b'Vibraci\xF3n\x00' not in scheck:
                        raise K7Error('ISO EUR: Vibración no aparece en el SLES final.')
                    for old in (b'APPUYER SUR TOUCHE START\x00', b'NOUVELLE PARTIE\x00', b'ST\xC9R\xC9O\x00'):
                        if old in scheck:
                            raise K7Error('ISO EUR: quedó una cadena francesa verificada sin sustituir.')

                tmp_output.replace(output_iso)
            except Exception:
                try:
                    if tmp_output.exists():
                        tmp_output.unlink()
                except Exception:
                    pass
                raise

    report = {
        'format': 'killer7-eur-iso-french-to-spanish',
        'version': 1,
        'source_iso': eur_iso.name,
        'source_iso_sha256': _eur_file_sha256(eur_iso),
        'output_iso': output_iso.name,
        'output_iso_sha256': _eur_file_sha256(output_iso),
        'serial': EUR_SUPPORTED_SERIAL,
        'afs': {**mapping, **afs_build},
        'afs_iso_location': afs_location,
        'afs_runtime_shadow': runtime_shadow,
        'global_77102_exact_mirrors': global_77102_exact,
        'sles_french_verified': sles_fr,
        'direct_strings': direct_fr,
        'usage': 'Ejecutar la ISO PAL/EUR y seleccionar FRANCÉS; esa rama contiene los textos españoles portados.',
    }
    # A sidecar report does not modify the ISO filesystem and is useful for
    # reproducing/verifying exactly what the experimental button changed.
    report_path = output_iso.with_suffix(output_iso.suffix + '.ES_REPORT.json')
    try:
        report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
        report['report_file'] = report_path.name
    except Exception:
        report['report_file'] = None
    return report
