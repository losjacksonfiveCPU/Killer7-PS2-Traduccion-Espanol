from __future__ import annotations
from copy import deepcopy
from pathlib import Path
import re
import xml.etree.ElementTree as ET
from core import TextBlock, TextUnit, GRAPHIC_PATCH_SPECS

SUPPORTED_ELF_ORIGINAL = 'SLUS_211.54:title-menu'

XLIFF_NS = 'urn:oasis:names:tc:xliff:document:2.0'
NS = '{' + XLIFF_NS + '}'
ET.register_namespace('', XLIFF_NS)

SPANISH_SAFE = set(
    "abcdefghijklmnñopqrstuvwxyzABCDEFGHIJKLMNÑOPQRSTUVWXYZ"
    "áéíóúüÁÉÍÓÚÜ0123456789 .,;:!?¿¡'\"-—…()[]/%+&ºª€"
)
CONTROL_RE = re.compile(r'\{ctl:([0-9A-Fa-f]{4})\}')
TRUSTED_SOURCE_STATES = {'verified', 'trusted', 'transcribed', 'imported'}
SPECIAL_PREFIX = '⟦SPECIAL RESOURCE'


def E(tag: str, attrs: dict | None = None, text: str | None = None) -> ET.Element:
    el = ET.Element(NS + tag, attrs or {})
    if text is not None:
        el.text = str(text)
    return el


def S(parent: ET.Element, tag: str, attrs: dict | None = None, text: str | None = None) -> ET.Element:
    el = ET.SubElement(parent, NS + tag, attrs or {})
    if text is not None:
        el.text = str(text)
    return el


def _note(parent: ET.Element, category: str, text) -> ET.Element:
    return S(parent, 'note', {'category': category}, str(text))


def _notes_dict(parent: ET.Element | None) -> dict[str, list[str]]:
    out: dict[str, list[str]] = {}
    if parent is None:
        return out
    notes = parent.find(NS + 'notes')
    if notes is None:
        return out
    for n in notes.findall(NS + 'note'):
        out.setdefault(n.attrib.get('category', ''), []).append(n.text or '')
    return out


def _split_controls(unit: TextUnit, source_text: str):
    """Alinea source plano con los códigos K7 y produce text/ph.

    Un glifo o espacio del juego consume un carácter del source. Un FFxx es un
    control no textual y se serializa como <ph>. Si el source no encaja de forma
    determinista, devuelve None: nunca inventamos texto ni desplazamos controles.
    """
    tokens = []
    pos = 0
    buf: list[str] = []

    def flush():
        nonlocal buf
        if buf:
            tokens.append(('text', ''.join(buf)))
            buf = []

    for code in unit.codes:
        if code in (-4, -3):
            if pos >= len(source_text) or source_text[pos] not in (' ', '\u3000'):
                return None
            buf.append(' ')
            pos += 1
        elif (code & 0xffff) >= 0xff00:
            flush()
            value = code & 0xffff
            tokens.append(('ph', f'@{value:04X}', f'{{ctl:{value:04X}}}'))
        else:
            if pos >= len(source_text):
                return None
            buf.append(source_text[pos])
            pos += 1
    flush()
    if pos != len(source_text):
        return None
    return tokens


def _append_tokens(elem: ET.Element, tokens) -> None:
    last = None
    phid = 0
    for typ, *rest in tokens:
        if typ == 'text':
            text = rest[0]
            if last is None:
                elem.text = (elem.text or '') + text
            else:
                last.tail = (last.tail or '') + text
        else:
            equiv, disp = rest
            phid += 1
            last = S(elem, 'ph', {
                'id': str(phid), 'equiv': equiv, 'disp': disp,
                'canCopy': 'yes', 'canDelete': 'no'
            })


def _trusted_source(unit: TextUnit) -> bool:
    return bool(unit.source) and unit.source_state.lower() in TRUSTED_SOURCE_STATES


def _build_file(block: TextBlock, serial: str, image_name: str, image_sha256: str = '') -> ET.Element:
    if block.storage_kind == 'elf_strings':
        original = SUPPORTED_ELF_ORIGINAL
        fmt = 'elf-ascii-fixed-slot'
    elif block.storage_kind == 'iso_ascii':
        original = block.storage_path or block.name
        fmt = 'iso-ascii-fixed-slot'
    elif block.storage_kind == 'afs_graphic_ref':
        original = block.storage_path or block.name
        fmt = 'ps2-dic-baked-text-region-patch'
    elif block.storage_kind == 'afs_k7p2':
        original = block.storage_path or block.name
        fmt = 'ps2-k7p2-scenario-name-table'
    elif block.storage_kind == 'afs_da':
        original = block.storage_path or block.name
        fmt = 'ps2-dar-subtitle-da'
    else:
        original = f'D_US/DIR.AFS#{block.jmb_index:04d}:{block.name}'
        fmt = 'ps2-jmb-slus21154'
    f = E('file', {'id': block.id, 'original': original})
    notes = S(f, 'notes')
    _note(notes, 'killer7:format', fmt)
    _note(notes, 'killer7:serial', serial or 'unknown')
    _note(notes, 'killer7:image', image_name)
    if image_sha256:
        _note(notes, 'killer7:image_sha256', image_sha256)
    _note(notes, 'killer7:jmb_index', block.jmb_index)
    _note(notes, 'killer7:dic_index', block.dic_index)
    _note(notes, 'killer7:afs_name', block.name)
    _note(notes, 'killer7:sentence_num', block.sentence_num)
    _note(notes, 'killer7:char_num', block.char_num)
    _note(notes, 'killer7:max_codes_per_line', max((u.max_codes for u in block.units), default=31))
    _note(notes, 'killer7:storage_kind', block.storage_kind)
    _note(notes, 'killer7:context', block.context)
    _note(notes, 'killer7:display_label', block.label)
    if block.storage_path:
        _note(notes, 'killer7:storage_path', block.storage_path)

    for u in block.units:
        ue = S(f, 'unit', {'id': u.stable_id})
        un = S(ue, 'notes')
        _note(un, 'killer7:legacy_id', u.id)
        _note(un, 'killer7:sentence', u.sentence)
        _note(un, 'killer7:jimaku', u.jimaku)
        _note(un, 'killer7:wait', u.wait)
        _note(un, 'killer7:disp_time', u.disp_time)
        _note(un, 'killer7:codes', u.code_signature)
        _note(un, 'killer7:source_state', u.source_state)
        _note(un, 'killer7:max_codes', u.max_codes)
        if u.binary_path:
            _note(un, 'killer7:binary_path', u.binary_path)
            _note(un, 'killer7:binary_offset', f'0x{u.binary_offset:X}')
            _note(un, 'killer7:binary_slot', u.binary_slot)
            _note(un, 'killer7:binary_pad', u.binary_pad)
        if u.source_candidate:
            _note(un, 'killer7:source_candidate', u.source_candidate)
        if u.source_provenance:
            _note(un, 'killer7:source_provenance', u.source_provenance)
        if u.source_confidence is not None:
            _note(un, 'killer7:source_confidence', f'{u.source_confidence:.4f}')

        seg = S(ue, 'segment', {'id': '1', 'state': 'initial'})
        src = S(seg, 'source')
        tgt = S(seg, 'target')

        if u.source_state.lower() == 'special':
            src.text = f'⟦SPECIAL RESOURCE · {u.id} · {u.code_signature}⟧'
            tgt.text = ''
            continue

        if block.storage_kind == 'afs_graphic_ref':
            # Texto verificado visualmente dentro de una textura. Se inventaría una
            # capacidad que aún no existe si copiáramos el source al target: se deja
            # como referencia localizable, visible en el editor y no inyectable.
            src.text = u.source.strip('\r\n') if _trusted_source(u) else ''
            tgt.text = ''
            continue

        source = u.source.strip('\r\n') if _trusted_source(u) else ''
        tokens = _split_controls(u, source) if source else None
        if tokens is None:
            src.text = f'⟦SOURCE PENDING · {u.id} · {u.code_signature}⟧'
            tgt.text = ''
        else:
            _append_tokens(src, tokens)
            # Igual que Snatcher: al crear el XLIFF el target parte del source para
            # que una CAT pueda editarlo conservando los placeholders protegidos.
            tgt.text = src.text
            for child in src:
                tgt.append(deepcopy(child))
    return f


def build_xliff(block: TextBlock, serial: str, image_name: str = 'Killer 7.iso', image_sha256: str = '') -> ET.Element:
    root = E('xliff', {'version': '2.2', 'srcLang': 'en', 'trgLang': 'es'})
    root.append(_build_file(block, serial, image_name, image_sha256))
    return root


def build_project_xliff(blocks: list[TextBlock], serial: str, image_name: str, image_sha256: str = '') -> ET.Element:
    root = E('xliff', {'version': '2.2', 'srcLang': 'en', 'trgLang': 'es'})
    for block in blocks:
        root.append(_build_file(block, serial, image_name, image_sha256))
    return root


def pretty_bytes(root: ET.Element) -> bytes:
    root = deepcopy(root)
    ET.indent(root, space='  ')
    xml = ET.tostring(root, encoding='utf-8', xml_declaration=True)
    return xml + (b'\n' if not xml.endswith(b'\n') else b'')


def extract_text(elem: ET.Element | None) -> str:
    if elem is None:
        return ''
    out = []
    if elem.text:
        out.append(elem.text)
    for ch in elem:
        if ch.tag == NS + 'ph':
            out.append(ch.attrib.get('disp') or ch.attrib.get('equiv', ''))
        if ch.tail:
            out.append(ch.tail)
    return ''.join(out)


def extract_equiv(elem: ET.Element | None) -> list[str]:
    if elem is None:
        return []
    return [c.attrib.get('equiv', '') for c in elem if c.tag == NS + 'ph']


def visible_target_length(text: str) -> int:
    """Número de códigos que requerirá un target (placeholder = 1 código)."""
    n = 0
    p = 0
    for m in CONTROL_RE.finditer(text):
        n += len(text[p:m.start()]) + 1
        p = m.end()
    n += len(text[p:])
    return n


def text_controls(text: str) -> list[str]:
    return [f'@{m.group(1).upper()}' for m in CONTROL_RE.finditer(text)]


def set_target_text(target: ET.Element, text: str, expected_controls: list[str] | None = None) -> None:
    """Convierte los tokens visuales {ctl:FFxx} en <ph> reales.

    Si expected_controls se pasa, exige exactamente la misma secuencia de controles.
    Así la edición visual no puede destruir accidentalmente comandos del juego.
    """
    got = text_controls(text)
    if expected_controls is not None and got != expected_controls:
        raise ValueError(
            'Los controles protegidos cambiaron. Esperados: '
            + (', '.join(expected_controls) or '(ninguno)')
            + '; encontrados: ' + (', '.join(got) or '(ninguno)')
        )
    for c in list(target):
        target.remove(c)
    target.text = None
    last = None
    pos = 0
    phid = 0
    for m in CONTROL_RE.finditer(text):
        chunk = text[pos:m.start()]
        if last is None:
            target.text = (target.text or '') + chunk
        else:
            last.tail = (last.tail or '') + chunk
        phid += 1
        equiv = f'@{m.group(1).upper()}'
        last = S(target, 'ph', {
            'id': str(phid), 'equiv': equiv, 'disp': f'{{ctl:{m.group(1).upper()}}}',
            'canCopy': 'yes', 'canDelete': 'no'
        })
        pos = m.end()
    tail = text[pos:]
    if last is None:
        target.text = (target.text or '') + tail
    else:
        last.tail = (last.tail or '') + tail


def _parse_file(f: ET.Element) -> dict:
    units = []
    for ue in f.findall(NS + 'unit'):
        seg = ue.find(NS + 'segment')
        src = seg.find(NS + 'source') if seg is not None else None
        tgt = seg.find(NS + 'target') if seg is not None else None
        notes = _notes_dict(ue)
        units.append({
            'id': ue.attrib.get('id', ''),
            'source': extract_text(src),
            'target': extract_text(tgt),
            'source_ph': extract_equiv(src),
            'target_ph': extract_equiv(tgt),
            'segment_state': seg.attrib.get('state', 'initial') if seg is not None else 'initial',
            'notes': notes,
            'xml_unit': ue,
            'xml_segment': seg,
        })
    return {
        'file_id': f.attrib.get('id', ''),
        'original': f.attrib.get('original', ''),
        'notes': _notes_dict(f),
        'units': units,
        'xml_file': f,
    }


def parse_project_xliff(path_or_bytes) -> dict:
    if isinstance(path_or_bytes, ET.Element):
        root = path_or_bytes
    elif isinstance(path_or_bytes, (str, Path)):
        root = ET.parse(path_or_bytes).getroot()
    else:
        root = ET.fromstring(path_or_bytes)
    if root.tag != NS + 'xliff':
        raise ValueError('El documento no es XLIFF 2.x.')
    files = [_parse_file(f) for f in root.findall(NS + 'file')]
    if not files:
        raise ValueError('XLIFF sin <file>.')
    return {
        'root': root,
        'srcLang': root.attrib.get('srcLang', ''),
        'trgLang': root.attrib.get('trgLang', ''),
        'files': files,
    }


def parse_xliff(path_or_bytes) -> dict:
    p = parse_project_xliff(path_or_bytes)
    f = p['files'][0]
    return {'root': p['root'], **f}


def find_file(root: ET.Element, file_id: str) -> ET.Element | None:
    return next((f for f in root.findall(NS + 'file') if f.attrib.get('id') == file_id), None)


def set_targets(root: ET.Element, targets: dict[str, str]) -> ET.Element:
    for ue in root.iter(NS + 'unit'):
        uid = ue.attrib.get('id', '')
        if uid not in targets:
            continue
        seg = ue.find(NS + 'segment')
        if seg is None:
            continue
        src = seg.find(NS + 'source')
        tgt = seg.find(NS + 'target')
        if tgt is None:
            tgt = S(seg, 'target')
        set_target_text(tgt, targets[uid], extract_equiv(src))
        seg.set('state', 'translated' if targets[uid] != extract_text(src) else 'initial')
    return root


def _validate_file(parsed: dict, expected_block: TextBlock | None = None):
    issues = []
    expected = {u.stable_id: u for u in expected_block.units} if expected_block else {}
    if expected_block and parsed['file_id'] != expected_block.id:
        issues.append(('ERR', 'file', f"XLIFF pertenece a {parsed['file_id']}, se esperaba {expected_block.id}."))
    seen = set()
    for row in parsed['units']:
        uid = row['id']
        seen.add(uid)
        tgt = row['target'].strip('\r\n')
        if row['source'].startswith(SPECIAL_PREFIX) and tgt:
            issues.append(('ERR', uid, 'Un recurso especial debe conservarse sin target; no se inyecta como texto.'))
            continue
        if expected_block and expected_block.storage_kind == 'afs_graphic_ref' and tgt:
            if expected_block.jmb_index not in GRAPHIC_PATCH_SPECS:
                issues.append(('ERR', uid, 'Texto horneado en textura sin región de parche verificada.'))
                continue
            if len(tgt) > 80:
                issues.append(('ERR', uid, 'Target gráfico demasiado largo para una región fija.'))
                continue
        if row['source_ph'] != row['target_ph'] and tgt:
            issues.append(('ERR', uid, 'Los controles <ph> no coinciden con el original.'))
        if not tgt or tgt == row['source']:
            continue
        if '\n' in tgt or '\r' in tgt:
            issues.append(('ERR', uid, 'Una unidad binaria/JMB no puede contener saltos de línea directos.'))
        if expected_block and expected_block.storage_kind in ('elf_strings', 'iso_ascii', 'afs_k7p2'):
            if any(ord(ch) > 0x7f for ch in tgt):
                issues.append(('ERR', uid, 'Este bloque directo sólo admite ASCII en esta versión (sin acentos/ñ).'))
            src = row['source']
            if src.count('~') and tgt.count('~') != src.count('~'):
                issues.append(('ERR', uid, 'Debe conservarse el símbolo ~ usado por el juego como control/botón.'))
        n = visible_target_length(tgt)
        limit = expected.get(uid).max_codes if uid in expected else 31
        if n > limit:
            issues.append(('ERR', uid, f'{n} códigos/caracteres > {limit}; hay que acortar o redistribuir el texto.'))
        visible = CONTROL_RE.sub('', tgt)
        bad = sorted(set(ch for ch in visible if ch not in SPANISH_SAFE))
        if bad:
            issues.append(('WARN', uid, f'Caracteres fuera del repertorio español previsto: {bad}'))
        if uid in expected:
            original_controls = [f'@{c:04X}' for c in expected[uid].controls]
            if original_controls != row['target_ph']:
                issues.append(('ERR', uid, 'Los códigos de control del juego cambiaron.'))
    if expected_block:
        for uid in sorted(set(expected) - seen):
            issues.append(('ERR', uid, 'Unidad ausente del XLIFF.'))
        extra = sorted(seen - set(expected))
        for uid in extra:
            issues.append(('ERR', uid, 'Unidad extra no presente en el bloque de la ISO.'))
    return issues


def validate_xliff(path_or_bytes, expected_block: TextBlock | None = None):
    p = parse_xliff(path_or_bytes)
    return _validate_file(p, expected_block)


def validate_project_xliff(path_or_bytes, expected_blocks: list[TextBlock] | None = None):
    p = parse_project_xliff(path_or_bytes)
    issues = []
    expected_by_id = {b.id: b for b in expected_blocks or []}
    seen_files = set()
    for f in p['files']:
        fid = f['file_id']
        if fid in seen_files:
            issues.append(('ERR', fid, 'ID de <file> duplicado.'))
        seen_files.add(fid)
        issues.extend(_validate_file(f, expected_by_id.get(fid)))
        if expected_blocks is not None and fid not in expected_by_id:
            issues.append(('ERR', fid, 'Bloque XLIFF no existe en la ISO esperada.'))
    if expected_blocks is not None:
        for fid in sorted(set(expected_by_id) - seen_files):
            issues.append(('ERR', fid, 'Bloque de la ISO ausente del XLIFF maestro.'))
    return issues


def project_stats(path_or_bytes) -> dict:
    p = parse_project_xliff(path_or_bytes)
    files = len(p['files'])
    units = sum(len(f['units']) for f in p['files'])
    translated = 0
    pending_source = 0
    special_source = 0
    for f in p['files']:
        for u in f['units']:
            if u['source'].startswith('⟦SOURCE PENDING'):
                pending_source += 1
            elif u['source'].startswith(SPECIAL_PREFIX):
                special_source += 1
            if u['target'] and u['target'] != u['source']:
                translated += 1
    return {'files': files, 'units': units, 'translated': translated,
            'pending_source': pending_source, 'special_source': special_source}


def set_source_text(unit_elem: ET.Element, unit: TextUnit, source_text: str, source_state: str = 'verified', copy_to_empty_target: bool = True) -> None:
    """Actualiza el <source> de una unidad a partir de texto verificado y códigos reales."""
    seg = unit_elem.find(NS + 'segment')
    if seg is None:
        raise ValueError('Unidad XLIFF sin <segment>.')
    tokens = _split_controls(unit, source_text)
    if tokens is None:
        expected_visible = sum(1 for c in unit.codes if (c & 0xffff) < 0xff00)
        raise ValueError(
            f'El original no encaja con los códigos de la ISO: se esperaban '
            f'{expected_visible} caracteres/espacios visibles.'
        )
    src = seg.find(NS + 'source')
    if src is None:
        src = S(seg, 'source')
    for c in list(src):
        src.remove(c)
    src.text = None
    _append_tokens(src, tokens)

    # Actualiza source_state en notes sin cambiar metadatos binarios.
    notes = unit_elem.find(NS + 'notes')
    if notes is None:
        notes = ET.Element(NS + 'notes')
        unit_elem.insert(0, notes)
    state_note = next((n for n in notes.findall(NS + 'note') if n.attrib.get('category') == 'killer7:source_state'), None)
    if state_note is None:
        state_note = S(notes, 'note', {'category': 'killer7:source_state'})
    state_note.text = source_state

    tgt = seg.find(NS + 'target')
    if tgt is None:
        tgt = S(seg, 'target')
    current = extract_text(tgt)
    if copy_to_empty_target and (not current or current.startswith('⟦SOURCE PENDING')):
        for c in list(tgt):
            tgt.remove(c)
        tgt.text = src.text
        for child in src:
            tgt.append(deepcopy(child))
        seg.set('state', 'initial')
