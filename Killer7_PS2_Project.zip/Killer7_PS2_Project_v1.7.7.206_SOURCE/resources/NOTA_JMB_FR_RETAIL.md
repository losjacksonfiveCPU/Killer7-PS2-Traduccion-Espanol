# NOTA TÉCNICA — JMB / DAR / DIC FRANCESES RETAIL (PAL EUR)

Esta nota documenta el comportamiento comprobado de los textos JMB de Killer7 PS2 EUR.
Su objetivo es evitar volver a asociar una traducción por el nombre inglés o por la
posición de un recurso USA cuando el juego PAL utiliza una estructura francesa distinta.

## 1. Regla principal: partir siempre del recurso francés retail

En la rama EUR, un texto JMB debe localizarse por su FRASE FRANCESA REAL dentro de
DIR_E.AFS y por su terna JMB/DAR/DIC. No basta con que una etiqueta del XLIFF USA tenga
un nombre parecido.

Antes de modificar un bloque:

1. identificar el índice AFS francés exacto;
2. leer el JMB francés retail;
3. comprobar escena + jimaku + char_data;
4. identificar el DIC que contiene sus glifos;
5. comprobar si existe un DAR espejo;
6. sólo entonces asignar la traducción española correspondiente.

Las etiquetas inglesas son una ayuda de catálogo, NO una prueba del texto visible PAL.
Ejemplo comprobado: el catálogo USA llama a una unidad "Fire Ring returned", mientras
que el texto francés visible real es "Anneau de feu récupéré".

## 2. Cómo funciona un JMB

El texto no está almacenado como una cadena normal. Cada unidad contiene char_data:
una secuencia de índices s16 que seleccionan entradas fParams/glifos del JMB/DIC local.

- -2 termina la frase.
- -4 representa espacio en los casos comprobados.
- cada fParam describe la región de atlas usada por un glifo;
- el DIC contiene el atlas gráfico 4bpp;
- el renderer del juego utiliza conjuntamente char_data + fParams + textura DIC.

Por eso un JMB puede tener el texto correcto en memoria y, aun así, verse como bloques
blancos si se sustituye por una estructura/atlas incompatible.

## 3. Directriz crítica para PAL: parche in-place

Para JMB franceses sensibles, la estrategia más segura y ya comprobada en juego es:

- conservar la estructura francesa retail;
- conservar tamaños de JMB y DIC siempre que sea posible;
- NO sustituir el bloque por un JMB/DIC recompilado a partir de la versión USA;
- reutilizar un slot de glifo que ya no necesite ninguna otra escena;
- copiar el nuevo glifo desde una fuente francesa retail compatible;
- preferir una zona libre del atlas antes que reescribir todo el atlas;
- actualizar únicamente los fParams estrictamente necesarios;
- reconstruir el DAR espejo para que contenga exactamente el JMB/DIC parcheados;
- verificar después de escribir que los demás char_data no han cambiado.

Si un cambio produce cuadros/bloques blancos, volver al JMB/DIC francés retail y revisar
la estrategia. No intentar corregirlo modificando SystemF o el renderer sin haber agotado
primero el parche local in-place.

## 4. Caso verificado: 77102 — "Soul Shell hallada"

Este caso funciona en juego y es la referencia de cómo deben tratarse recursos de este tipo.

Recurso PAL francés: 77102 (JMB/DAR/DIC).
Texto francés relevante: "Balle d'âmes reçue".
Texto español: "Soul Shell hallada".

El parche reutiliza slots existentes en la fuente local, mantiene la estructura y evita
expandir innecesariamente el recurso. Los donors se validan contra las demás unidades del
mismo JMB para no destruir caracteres todavía utilizados.

Lección: si una frase JMB local funciona con cirugía in-place, debe preferirse ese método
a sustituir toda la fuente o a modificar una fuente global.

## 5. Caso verificado en juego: 77304 — Fire Ring

Ubicación PAL francesa real:

- DIR_E.AFS #1793 : 77304 JMB
- DIR_E.AFS #1794 : 77304 DAR espejo
- DIR_E.AFS #1795 : 77304 DIC

Texto francés retail:

    Anneau de feu récupéré

Texto español comprobado:

    Anillo de llama obtenido

El parche que funciona en juego se hace directamente sobre 77304 francés retail.
No utiliza SystemF, mes_f.dat ni un JMB generado desde USA.

Datos de la estrategia in-place:

- char_num permanece 37 -> 37;
- tamaño JMB permanece 27776 bytes;
- tamaño DAR permanece 61184 bytes;
- tamaño DIC permanece 33260 bytes;
- se reutiliza el slot 6, originalmente 'f', porque deja de ser necesario en la frase
  española y no lo necesitan las demás escenas de ese JMB;
- el slot 6 pasa a representar 'm';
- el glifo 'm' procede de una fuente francesa retail compatible: recurso 55101,
  JMB #1524 / DIC #1526, slot 20, tamaño 25x36;
- se comprobaron 21 glifos comunes idénticos píxel a píxel entre ambas familias antes
  de aceptar 55101 como donante;
- el bitmap 'm' se coloca en una zona libre del atlas: (x=0, y=72, w=25, h=36);
- sólo cambia el fParam del slot donor y el char_data de la escena traducida;
- las escenas restantes deben conservar su char_data exactamente;
- el DAR #1794 debe reconstruirse con el JMB y DIC finales.

Este método se mostró correctamente en juego. Las variantes anteriores que sustituían
SystemF, redirigían a BloodFontF o introducían un JMB recompilado desde la estructura USA
produjeron rectángulos blancos y deben considerarse métodos descartados para este caso.

## 6. mes_f.dat NO es el Fire Ring de 77304

Las escenas 16-21 de mes_f.dat contienen literalmente:

    Échantillons couleur obtenus

No deben asociarse a "Anneau de feu récupéré" ni utilizarse para resolver el Fire Ring.
Son otro conjunto de avisos. Mantener esta separación evita modificar SystemF por error.

## 7. Selección de un donor de glifo

Antes de reciclar un slot:

1. comprobar todos los char_data del JMB;
2. demostrar que el slot donor no se usa en ninguna unidad que deba permanecer;
3. preferir un carácter que desaparezca de la traducción española;
4. obtener el nuevo bitmap de un recurso francés retail de la misma familia;
5. comparar varios glifos comunes píxel a píxel para confirmar compatibilidad;
6. conservar geometría/tamaño del recurso cuando sea posible;
7. si se cambia el fParam, permitir únicamente ese índice en el guard de diferencias.

Nunca asumir que dos fuentes son compatibles sólo porque visualmente se parecen.

## 8. Guards mínimos que debe aplicar el compilador

Para un parche JMB/DIC francés in-place:

- comprobar SHA-256/tamaño del recurso francés retail esperado;
- comprobar nombre e índice AFS;
- comprobar número de escenas y glifos;
- comprobar que el donor no aparece en escenas preservadas;
- comprobar que las escenas no objetivo mantienen char_data idéntico;
- comprobar que sólo cambian los fParams autorizados;
- comprobar que el nuevo bitmap cabe y no pisa píxeles ocupados;
- comprobar tamaño final JMB/DIC/DAR cuando la estrategia sea size-preserving;
- releer el AFS final y comparar los payloads escritos;
- si existe DAR espejo, comprobar que contiene exactamente los JMB/DIC finales.

## 9. Diagnóstico rápido de fallos

Texto correcto pero cuadros blancos:
- sospechar incompatibilidad del atlas/layout GS o sustitución de una fuente equivocada;
- confirmar que se está usando la terna francesa retail correcta;
- evitar reconstrucciones globales del DIC;
- comparar con una ruta in-place conocida como 77102/77304.

Texto equivocado pero fuente visible:
- revisar asociación frase francesa -> target español;
- revisar escena/jimaku y no confiar en la etiqueta inglesa del catálogo USA.

Sólo un carácter incorrecto:
- revisar índice char_data, donor y fParam de ese slot;
- no tocar el resto del atlas.

## 10. Principio de trabajo para futuras traducciones JMB EUR

"Primero ubicar la frase francesa real; después traducir el mismo recurso francés;
y modificar el mínimo número posible de bytes."

Esta regla tiene prioridad sobre equivalencias USA históricas o heurísticas de posición.


## v1.7.7.204 — regla general para todos los JMB de texto

Para la rama PAL/EUR, el recurso base debe ser siempre el **JMB/DIC francés retail real**. No se debe inyectar un JMB recompilado sobre la estructura USA en el slot francés. La 204 contiene 114 pares JMB/DIC españoles recompilados directamente sobre retail FR y dos rutas in-place especiales (`77102`, `77304`).

Reglas de validación:
1. conservar `scene_offset` y `char_data` de recursos especiales no traducibles;
2. conservar tamaño y metadatos del DIC francés; sólo puede cambiar su payload de píxeles;
3. reconstruir el DAR espejo desde el JMB/DIC franceses modificados;
4. cuando el repertorio no cabe en el `char_num` original, ampliar únicamente fParams/`tex_offset` dentro del formato JMB, nunca sustituir el contenedor por uno USA;
5. si una frase no existe en francés (`55401`/`55403`, recurso M2B), no asociar por posición una traducción USA;
6. `77102` y `77304` son referencias de funcionamiento comprobado en juego y deben conservarse como pruebas de regresión.


## v1.7.7.205 — atención a las familias `DIC -> JMB`

La asociación correcta no siempre es `JMB -> DIC`. Se verificó contra `DIR_E.AFS` PAL/EUR y el ejecutable que nueve bloques usan el DIC inmediatamente **anterior** al JMB. La v1.7.7.204 tomó por error el DIC siguiente, que pertenece al alemán en esos tríos EN/FR/DE.

Mapeo fijado por regresión:

- `K7_0286_Handso`: JMB #307 + DIC FR #306.
- `K7_0315_h_007`: JMB #528 + DIC FR #527.
- `K7_0317_h_007`: JMB #534 + DIC FR #533.
- `K7_0319_h_010`: JMB #540 + DIC FR #539.
- `K7_0321_h_010`: JMB #546 + DIC FR #545.
- `K7_0323_h_010`: JMB #552 + DIC FR #551.
- `K7_0325_h_020`: JMB #558 + DIC FR #557.
- `K7_0327_h_035`: JMB #564 + DIC FR #563.
- `K7_0329_h_055`: JMB #570 + DIC FR #569.

Para estos recursos no se debe trasplantar el contenedor DIC alemán. Se conserva el DIC francés retail completo y sólo se reescribe su payload de atlas con los glifos españoles.
