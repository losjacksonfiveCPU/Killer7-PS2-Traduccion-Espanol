from __future__ import annotations
import json
import tempfile
import threading
import tkinter as tk
from pathlib import Path
from types import SimpleNamespace
from tkinter import filedialog, messagebox, simpledialog, ttk
from copy import deepcopy
from datetime import datetime
import xml.etree.ElementTree as ET

from core import (Killer7Project, ISO9660, TextUnit, load_source_catalog, save_source_catalog, K7Error,
                  SUPPORTED_SERIAL, EUR_SUPPORTED_SERIAL, identify_killer7_iso, block_format_policy, _unswizzle8)
from xliff_io import (
    NS, build_project_xliff, build_xliff, pretty_bytes, parse_project_xliff,
    validate_project_xliff, validate_xliff, find_file, extract_text,
    set_target_text, set_source_text, visible_target_length, text_controls,
    project_stats, CONTROL_RE,
)
from glyph_memory import propagate_candidates
from compiler import (build_patch_zip, apply_patch_to_iso, preflight_project,
                      apply_current_spanish_to_eur_archive, apply_current_spanish_to_eur_iso,
                      scan_eur_cinematic_subtitles_from_iso, EUR_SCENE_SELECTOR_ROWS,
                      eur_scene_selector_default_targets, eur_k7p2_is_place_label,
                      apply_eur_difficulty_texture_to_iso,
                      apply_eur_translated_images_to_iso,
                      load_eur_text_image_previews, apply_eur_text_image_replacements_to_iso)
from platform_paths import editable_path, resource_path, resource_root, user_data_root

try:
    from PIL import Image, ImageDraw, ImageFont, ImageOps, ImageTk
except Exception:
    ImageTk = None

APP_TITLE = 'Killer7 PS2 Project'
EUR_JMB_NOTE_FILE = 'NOTA_JMB_FR_RETAIL.md'



# v1.7.7.126 — vistas individuales de los títulos del selector en «Texto Imágenes».
# Los capítulos 00–05 son C-strings del SLES y el 06 además aparece rasterizado
# en SceSel_F. Estas filas son vistas visuales individuales: no inventan una
# textura independiente donde el juego no la tiene.
_TEXT_IMAGE_CHAPTER_TITLES = {
    'en': {
        'chapter_00': 'Angel', 'chapter_01': 'Sunset', 'chapter_02': 'Cloudman',
        'chapter_03': 'Encounter', 'chapter_04': 'Alter Ego', 'chapter_05': 'Smile',
        'chapter_06': 'Lion',
    },
    'fr': {
        'chapter_00': 'Ange', 'chapter_01': 'Coucher de Soleil', 'chapter_02': 'Homme Nuage',
        'chapter_03': 'Rencontre', 'chapter_04': 'Alter Ego', 'chapter_05': 'Sourire',
        'chapter_06': 'Lion',
    },
    'de': {
        'chapter_00': 'Engel', 'chapter_01': 'Sonnenuntergang', 'chapter_02': 'Wolkenmann',
        'chapter_03': 'Begegnung', 'chapter_04': 'Alter Ego', 'chapter_05': 'Lächeln',
        'chapter_06': 'Löwe',
    },
}

TRANSLATION_CRITERIA = "CRITERIOS TÉCNICOS DE TRADUCCIÓN — SLUS_211.54\n\nEstas reglas se basan en el formato real de los archivos y en la lectura del\nejecutable MIPS de Killer7 PS2 USA. Distinguen LÍMITES DEL MOTOR de límites\nconservadores del recompilador actual.\n\nREGLAS COMUNES\n1. SOURCE PENDING no se traduce por contexto: primero se verifica el inglés.\n2. Conservar exactamente controles <ph> / {ctl:FFxx}, IDs y estructura del bloque.\n3. Mantener terminología coherente, pero nunca a costa de corromper el formato.\n4. Una tanda sólo se integra con Validar proyecto + Preflight completo = 0 errores.\n5. La ISO original no se sobrescribe.\n\nSUBTÍTULOS .da (DAR/DIC)\n• Estructura confirmada en SLUS_211.54: cada registro mide 264 bytes:\n  start u32 + end u32 + 128 valores s16.\n• El ejecutable calcula línea*264 y limita el recorrido a 0x80 = 128 códigos.\n  Como -2 termina la frase, el máximo seguro es 127 códigos por registro.\n• El número de registros se lee del propio DAT: NO existe evidencia de un límite\n  de 64 líneas. El antiguo <=64 era sólo una heurística del editor y se ha retirado.\n• Esta versión todavía conserva el número de registros y los tiempos originales.\n  Si una traducción supera 127 códigos, NO se mutila: queda pendiente para el\n  futuro divisor de subtítulos/creación de registros adicionales.\n• Cada .da tiene atlas DIC local 4bpp. Se permiten á é í ó ú ñ ü ¿ ¡ sólo cuando\n  el compilador puede reutilizar/sintetizar glifos reales y el preflight pasa.\n• No acortar a 31: ese límite pertenece a JMB, no a .da.\n\nJMB + DIC\n• Cada escena ocupa 6860 bytes = stInfo(76) + 16 registros stJimaku de 424 bytes.\n• El ejecutable recorre exactamente 16 registros por escena (comparación 0x10).\n• char_data ocupa 32 s16 desde +0x08 a +0x47; después empiezan otros campos del\n  registro. Con -2 como final, máximo seguro: 31 códigos por unidad.\n• No añadir una unidad 17 ni dividir una frase en otra unidad sin parchear motor/\n  estructura. Reformular si supera 31.\n• -2, -3, -4 y los flags 0x7000/0x8000 tienen semántica del motor. Los controles\n  y flags del original se preservan; las unidades con flags no soportados por el\n  recompilador no se fuerzan.\n• El número de glifos/fParams es dinámico, pero la textura DIC tiene tamaño físico\n  fijo: los glifos nuevos sólo son válidos si el repaquetado/preflight demuestra\n  que caben.\n\nDIRECTO EN SLUS_211.54\n• Son C-strings/fragmentos ASCII dentro del segmento cargado del ejecutable.\n• La auditoría localizó referencias absolutas o LUI+ADDIU/ORI para 328 de las 349\n  cadenas DIRECTO+menú analizadas. Las restantes incluyen fragmentos separados por\n  controles/iconos o accesos por base; por ello NO existe una relocalización global\n  segura demostrada.\n• Criterio actual: ASCII estricto, mismo slot binario, conservar '~' y fragmentos\n  de control. Si no cabe, usar una formulación/abreviatura natural.\n• Guardado/opciones: Save, Option y option son claves internas verificadas en MIPS y\n  NO se traducen. Los mensajes Memory Card con SJIS 81 A0 (□) se recompilan como\n  una sola C-string y el padding se añade sólo al final, nunca antes del símbolo.\n• Una futura expansión debe clasificarse por grupo y repuntar TODAS sus referencias;\n  no se activa sólo porque una cadena tenga un puntero.\n\nDIRECTO EN MÓDULOS S01M–S07M\n• Los módulos usan cabecera MWo3 y base de carga 0x00642300.\n• Las 160 cadenas de zona localizadas tienen referencias absolutas dentro de sus\n  módulos. Esto hace viable investigar una bolsa de texto expandida, pero aún hay\n  que actualizar referencias y límites/cabecera del módulo de forma verificada.\n• Hasta entonces: ASCII estricto + slot original. No ampliar el módulo a ciegas.\n\nMENÚ PRINCIPAL\n• PRESS START/NEW GAME/CONTINUE/OPTIONS están en SLUS y usan titlefont.png.\n• Se tratan como C-strings ASCII de slot fijo. No introducir bytes >7F hasta\n  documentar la tabla de caracteres del renderer.\n\nGRÁFICOS DIC\n• Angel/Complete/Sunset/etc. están horneados como píxeles en texturas DIC 4bpp:\n  NO son cadenas. Se traducen mediante parche gráfico, conservando dimensiones,\n  formato/layout GS y fondo. La v1.7.6.7 conserva el parche por regiones verificadas: conserva dimensiones, 4bpp/layout GS y sólo sustituye el rótulo dentro de su caja fija. Todo cambio debe pasar preflight.\n\nEVIDENCIA EJECUTABLE (resumen)\n• JIMAKU: cadena en VA ~0x005A6890; rutina de .da ~0x002492B8.\n• .da: stride 264 (32*índice + índice, luego *8) y cap 0x80.\n• JMB: rutina ~0x002E4F30; stride 0x1A8 (424), 16 registros, escena 0x1ACC (6860).\n• JMB reconoce -4/-3/-2 y máscaras 0x7000/0x8000.\n• SubTitle: cadena en VA ~0x005ABE18; titlefont/st%02d%02d aparecen junto a ella.\n\nLa investigación detallada queda en ANALISIS_FORMATOS_TEXTO_SLUS_21154.md.\n"



class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(APP_TITLE)
        self.geometry('1280x850')
        self.minsize(980, 680)

        self.project: Killer7Project | None = None
        # En modo EUR no se usa Killer7Project (que sigue siendo el lector estable USA).
        # Guardamos la ISO PAL seleccionada para la ruta experimental francés -> español.
        self.eur_iso_path: Path | None = None
        self.eur_view_mode = False
        self.eur_view_blocks = []
        # Targets escritos por el usuario para los DAR cinematográficos EUR.
        # Clave estable: "AFS_INDEX:LINEA" (p.ej. "399:0").
        self.eur_cinematic_targets: dict[str, str] = {}
        # v1.7.7.28: nombres de capítulos + fechas/estaciones del selector EUR.
        self.eur_scene_selector_targets: dict[str, str] = eur_scene_selector_default_targets()
        self.eur_cinematic_project_path: Path | None = None
        self.block = None
        self.master_root: ET.Element | None = None
        self.rows = []
        self.current = -1
        self.dirty = False
        # v1.7.7.166: instantánea del último estado guardado. Permite que
        # «Guardar Proyecto» registre únicamente los cambios de texto realizados
        # desde el guardado anterior, con su bloque y ruta binaria.
        self.project_saved_snapshot: dict[str, dict] = {}
        self.project_log_path = user_data_root() / 'CAMBIOS_PROYECTO.log'
        self.preview_photo = None
        self.image_scan_window = None
        self.image_scan_resources: list[dict] = []
        self.image_scan_resource_map: dict[str, dict] = {}
        self.image_scan_marks: dict[str, str] = {}
        self.image_scan_photo = None
        self.image_scan_current: dict | None = None
        self.image_scan_mode = 'usa'
        self.source_catalog: dict = {}
        self.catalog_path = editable_path('resources', 'source_catalog.json')
        # v1.7.7.33: catálogo visual de texturas con texto y reemplazos PNG pendientes.
        self.text_image_records: list[dict] = []
        self.text_image_overrides: dict[str, str] = {}
        self.text_image_photo = None
        self.text_image_current_id: str | None = None
        # v1.7.7.51: idioma activo de la pestaña Texto Imágenes.
        self.text_image_language_code = 'fr'
        # v1.7.7.164: categorías funcionales para filtrar el selector de bloques.
        # El filtro es sólo de interfaz: no duplica ni altera unidades/inyección.
        self.text_category_specs = [
            ('all', 'Todos'),
            ('objectives', 'Objetivos'),
            ('jmb', 'Diálogos / JMB'),
            ('subtitles', 'Subtítulos'),
            ('cinematics', 'Cinemáticas'),
            ('map', 'Mapa / lugares'),
            ('interface', 'Menú / interfaz'),
            ('selector', 'Selector escenas'),
            ('direct', 'Directos'),
            ('graphics', 'Gráficos'),
        ]
        self.text_category_id = 'all'
        self.text_category_frames: dict[str, ttk.Frame] = {}
        self._category_tab_guard = False
        self.launcher_frame = None
        self.launcher_photo = None
        self.launcher_canvas = None
        self.launcher_loading_items: list[int] = []
        self.launcher_select_button = None
        self.launcher_translate_button = None
        self.launcher_editor_button = None
        self.launcher_status_var = tk.StringVar(value='')
        self.main_menu = None
        self._build()
        self._show_launcher()
        self.protocol('WM_DELETE_WINDOW', self._on_close)

    # ---------- UI ----------
    def _build(self):
        self._build_menu()
        notebook = ttk.Notebook(self)
        notebook.pack(fill=tk.BOTH, expand=True)
        translation_frame = ttk.Frame(notebook, padding=8)
        text_images_frame = ttk.Frame(notebook, padding=12)
        info_frame = ttk.Frame(notebook, padding=12)
        criteria_frame = ttk.Frame(notebook, padding=12)
        eur_jmb_frame = ttk.Frame(notebook, padding=12)
        self.main_notebook = notebook
        self.eur_jmb_frame = eur_jmb_frame
        notebook.add(translation_frame, text='Traducción')
        notebook.add(text_images_frame, text='Texto Imágenes')
        notebook.add(info_frame, text='Información')
        notebook.add(criteria_frame, text='Criterios')
        notebook.add(eur_jmb_frame, text='JMB EUR')
        self._build_text_images_tab(text_images_frame)

        body = ttk.Frame(translation_frame)
        body.pack(fill=tk.BOTH, expand=True, padx=12, pady=12)

        source = ttk.LabelFrame(body, text='Imagen del juego', padding=10)
        source.pack(fill=tk.X, pady=(0, 10))
        ttk.Button(source, text='Seleccionar ISO…', command=self.open_iso).pack(side=tk.LEFT)
        # v1.7.7.166: el acceso principal a la inyección ocupa el antiguo hueco
        # del catálogo de gráficos franceses. El escáner permanece disponible
        # internamente para no romper las rutas de código existentes, pero ya
        # no se muestra como botón en esta cabecera.
        self.inject_texts_button = ttk.Button(
            source, text='Inyectar Textos', command=self.inject_texts, state=tk.NORMAL
        )
        self.inject_texts_button.pack(side=tk.LEFT, padx=(8, 0))
        self.image_scan_button = ttk.Button(
            source, text='Escanear imágenes…', command=self.open_image_scanner, state=tk.DISABLED
        )
        self.iso_label = ttk.Label(source, text='Ninguna imagen seleccionada.', anchor='w')
        self.iso_label.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=(12, 0))

        # v1.7.7.164: pestañas de categoría justo encima del editor. La pestaña
        # activa limita exclusivamente el contenido del desplegable "Bloque del
        # DIR.AFS"; el árbol inferior sigue mostrando sólo el bloque seleccionado.
        self.category_notebook = ttk.Notebook(body)
        self.category_notebook.pack(fill=tk.X, pady=(0, 6))
        for category_id, category_label in self.text_category_specs:
            frame = ttk.Frame(self.category_notebook, height=1)
            self.category_notebook.add(frame, text=category_label)
            self.text_category_frames[category_id] = frame
        self.category_notebook.bind('<<NotebookTabChanged>>', self._on_text_category_changed)

        box = ttk.LabelFrame(body, text='Editor visual XLIFF', padding=10)
        box.pack(fill=tk.BOTH, expand=True)

        editor_source = ttk.Frame(box)
        editor_source.pack(fill=tk.X, pady=(0, 7))
        ttk.Label(editor_source, text='Bloque del DIR.AFS:').pack(side=tk.LEFT)
        self.block_var = tk.StringVar()
        self.combo = ttk.Combobox(editor_source, textvariable=self.block_var, state='disabled', width=88)
        self.combo.pack(side=tk.LEFT, padx=(6, 6))
        self.load_block_button = ttk.Button(editor_source, text='Cargar bloque', command=self.load_block, state=tk.DISABLED)
        self.load_block_button.pack(side=tk.LEFT)
        # v1.7.7.166: se eliminan los subtextos auxiliares visibles bajo
        # «Bloque del DIR.AFS». Conservamos los objetos/variables porque otras
        # rutas actualizan su contenido y forman parte del estado del editor.
        self.file_label = ttk.Label(editor_source, text='Selecciona primero una imagen.', anchor='w')
        self.format_policy_var = tk.StringVar(
            value='Formato: — · Selecciona un bloque para ver sus límites reales.'
        )

        editor_actions = ttk.Frame(box)
        editor_actions.pack(fill=tk.X, pady=(0, 7))
        # v1.7.7.166: un único guardado persistente del proyecto. Los antiguos
        # botones de importar XLIFF / guardar bloque / guardar maestro dejan de
        # formar parte de la interfaz para evitar estados de proyecto paralelos.
        self.save_project_button = ttk.Button(
            editor_actions, text='Guardar Proyecto', command=self.save_project, state=tk.DISABLED
        )
        self.save_project_button.pack(side=tk.LEFT)
        self.prev = ttk.Button(editor_actions, text='◀ Anterior', command=lambda: self.step(-1), state=tk.DISABLED)
        self.prev.pack(side=tk.LEFT, padx=(20, 0))
        self.next = ttk.Button(editor_actions, text='Siguiente ▶', command=lambda: self.step(1), state=tk.DISABLED)
        self.next.pack(side=tk.LEFT, padx=(6, 0))
        self.progress = tk.StringVar(value='')
        ttk.Label(editor_actions, textvariable=self.progress).pack(side=tk.LEFT, padx=(12, 0))

        # Variables de estado conservadas sin etiquetas auxiliares visibles.
        self.translation_status_var = tk.StringVar(value='Modo EUR: «Inyectar Textos» aplica textos, subtítulos y todas las imágenes traducidas sobre una ISO europea SLES_533.66.')

        source_actions = ttk.Frame(box)
        source_actions.pack(fill=tk.X, pady=(0, 7))
        self.source_state_var = tk.StringVar(value='')
        self.raw_da_preview_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(
            source_actions, text='Vista gráfica DA', variable=self.raw_da_preview_var,
            command=self._refresh_current_preview,
        ).pack(side=tk.RIGHT, padx=(8, 0))

        list_wrap = ttk.Frame(box)
        list_wrap.pack(fill=tk.X, pady=(0, 8))
        self.tree = ttk.Treeview(
            list_wrap,
            columns=('idx', 'scene', 'line', 'preview', 'state'),
            show='headings', selectmode='browse', height=7,
        )
        cols = [
            ('idx', '#', 55, False, 'e'),
            ('scene', 'Escena', 75, False, 'center'),
            ('line', 'Línea', 65, False, 'center'),
            ('preview', 'Original inglés', 720, True, 'w'),
            ('state', 'Estado', 150, False, 'center'),
        ]
        for c, title, width, stretch, anchor in cols:
            self.tree.heading(c, text=title)
            self.tree.column(c, width=width, minwidth=min(width, 60), anchor=anchor, stretch=stretch)
        tree_y = ttk.Scrollbar(list_wrap, orient=tk.VERTICAL, command=self.tree.yview)
        self.tree.configure(yscrollcommand=tree_y.set)
        self.tree.grid(row=0, column=0, sticky='nsew')
        tree_y.grid(row=0, column=1, sticky='ns')
        list_wrap.columnconfigure(0, weight=1)
        self.tree.bind('<<TreeviewSelect>>', self.on_select)

        text_pair = ttk.Panedwindow(box, orient=tk.HORIZONTAL)
        text_pair.pack(fill=tk.BOTH, expand=True)
        self.source_text_frame = ttk.LabelFrame(text_pair, text='Original inglés — solo lectura', padding=6)
        self.target_text_frame = ttk.LabelFrame(text_pair, text='Traducción (target)', padding=6)
        left = self.source_text_frame
        right = self.target_text_frame
        text_pair.add(left, weight=1)
        text_pair.add(right, weight=1)

        self.preview = ttk.Label(left, text='Vista de glifos del juego', anchor='center')
        self.preview.pack(fill=tk.X, pady=(0, 6))
        self.src_text = tk.Text(left, wrap=tk.WORD, height=9, font=('TkDefaultFont', 11), cursor='xterm', takefocus=True)
        self.src_text.pack(fill=tk.BOTH, expand=True)
        self.src_text.configure(state=tk.DISABLED)

        self.tgt_text = tk.Text(right, wrap=tk.WORD, height=9, font=('TkDefaultFont', 11), undo=True, maxundo=200)
        self.tgt_text.pack(fill=tk.BOTH, expand=True)
        self.tgt_text.configure(state=tk.DISABLED)
        self.tgt_text.bind('<FocusOut>', lambda _e: self.commit())
        self.tgt_text.bind('<KeyRelease>', lambda _e: self.metrics())
        self.bind_all('<Control-s>', self._ctrl_save)

        self.info = tk.StringVar(value=f'Selecciona la ISO de Killer7 ({SUPPORTED_SERIAL}) para comenzar.')
        ttk.Label(box, textvariable=self.info, anchor='w', justify=tk.LEFT).pack(fill=tk.X, pady=(7, 0))
        self._build_info_tab(info_frame)
        self._build_criteria_tab(criteria_frame)
        self._build_eur_jmb_note_tab(eur_jmb_frame)

    def _build_text_images_tab(self, frame):
        """Construye el gestor visual de las texturas con texto de la edición EUR."""
        intro = ttk.LabelFrame(frame, text='Texturas con texto · EUR', padding=10)
        intro.pack(fill=tk.X, pady=(0, 10))
        self.text_images_status_var = tk.StringVar(
            value='Selecciona una ISO EUR SLES_533.66 para cargar las imágenes localizadas.'
        )
        ttk.Label(
            intro,
            textvariable=self.text_images_status_var,
            anchor='w', justify=tk.LEFT,
        ).pack(side=tk.LEFT, fill=tk.X, expand=True)

        top_controls = ttk.Frame(intro)
        top_controls.pack(side=tk.RIGHT, padx=(12, 0))
        lang_box = ttk.LabelFrame(top_controls, text='Idioma de las imágenes', padding=(8, 4))
        lang_box.pack(side=tk.LEFT, padx=(0, 10))
        self.text_image_language_var = tk.StringVar(value=self.text_image_language_code)
        for code, label in (('en', 'Inglés'), ('fr', 'Francés'), ('de', 'Alemán')):
            ttk.Radiobutton(
                lang_box, text=label, value=code, variable=self.text_image_language_var,
                command=lambda c=code: self._change_text_image_language(c),
            ).pack(side=tk.LEFT, padx=4)

        self.text_image_reload_button = ttk.Button(
            top_controls, text='Recargar desde ISO', command=self._reload_text_images_from_iso,
            state=tk.DISABLED,
        )
        self.text_image_reload_button.pack(side=tk.LEFT)

        body = ttk.Panedwindow(frame, orient=tk.HORIZONTAL)
        body.pack(fill=tk.BOTH, expand=True)

        left = ttk.LabelFrame(body, text='Imágenes localizadas', padding=8)
        right = ttk.LabelFrame(body, text='Previsualización / reemplazo', padding=8)
        body.add(left, weight=2)
        body.add(right, weight=3)

        tree_wrap = ttk.Frame(left)
        tree_wrap.pack(fill=tk.BOTH, expand=True)
        self.text_images_tree = ttk.Treeview(
            tree_wrap,
            columns=('group', 'resource', 'texture', 'size', 'state'),
            show='headings', selectmode='browse', height=17,
        )
        columns = [
            ('group', 'Pantalla', 145, False, 'w'),
            ('resource', 'AFS / recurso', 175, False, 'w'),
            ('texture', 'Textura', 155, True, 'w'),
            ('size', 'Tamaño', 75, False, 'center'),
            ('state', 'Estado', 125, False, 'center'),
        ]
        for col, title, width, stretch, anchor in columns:
            self.text_images_tree.heading(col, text=title)
            self.text_images_tree.column(
                col, width=width, minwidth=min(width, 60), stretch=stretch, anchor=anchor
            )
        sy = ttk.Scrollbar(tree_wrap, orient=tk.VERTICAL, command=self.text_images_tree.yview)
        self.text_images_tree.configure(yscrollcommand=sy.set)
        self.text_images_tree.grid(row=0, column=0, sticky='nsew')
        sy.grid(row=0, column=1, sticky='ns')
        tree_wrap.rowconfigure(0, weight=1)
        tree_wrap.columnconfigure(0, weight=1)
        self.text_images_tree.bind('<<TreeviewSelect>>', self._on_text_image_select)

        # v1.7.7.58: el panel derecho usa grid y un viewport de preview con tamaño
        # controlado. Antes una PhotoImage grande (especialmente sub 1024x512) podía
        # imponer su tamaño solicitado al packer y expulsar los botones fuera de una
        # ventana 980x680. Grid + propagate(False) reserva siempre espacio para controles.
        right.columnconfigure(0, weight=1)
        right.rowconfigure(1, weight=1, minsize=220)
        self.text_image_detail_var = tk.StringVar(
            value='Selecciona una textura para ver su ubicación y previsualización.'
        )
        self.text_image_detail_label = ttk.Label(
            right, textvariable=self.text_image_detail_var, anchor='w', justify=tk.LEFT,
            wraplength=620,
        )
        self.text_image_detail_label.grid(row=0, column=0, sticky='ew', pady=(0, 8))

        self.text_image_preview_box = ttk.Frame(
            right, relief=tk.SUNKEN, borderwidth=1, width=620, height=320
        )
        self.text_image_preview_box.grid(row=1, column=0, sticky='nsew')
        self.text_image_preview_box.grid_propagate(False)
        self.text_image_preview_label = ttk.Label(
            self.text_image_preview_box, text='Sin imagen', anchor='center', justify=tk.CENTER
        )
        self.text_image_preview_label.place(relx=0.5, rely=0.5, anchor='center')

        # Dos filas: los cinco botones quedan visibles incluso con el ancho mínimo
        # soportado de la aplicación y no dependen del tamaño de la textura seleccionada.
        controls = ttk.Frame(right)
        controls.grid(row=2, column=0, sticky='ew', pady=(8, 0))
        controls.columnconfigure(0, weight=1)
        controls.columnconfigure(1, weight=1)
        controls.columnconfigure(2, weight=1)
        self.text_image_extract_button = ttk.Button(
            controls, text='Extraer PNG', command=self._extract_text_image_png,
            state=tk.DISABLED,
        )
        self.text_image_extract_button.grid(row=0, column=0, sticky='ew', padx=(0, 4), pady=(0, 4))
        self.text_image_replace_button = ttk.Button(
            controls, text='Reemplazar por PNG…', command=self._replace_text_image,
            state=tk.DISABLED,
        )
        self.text_image_replace_button.grid(row=0, column=1, sticky='ew', padx=4, pady=(0, 4))
        self.text_image_clear_button = ttk.Button(
            controls, text='Quitar reemplazo', command=self._clear_text_image_override,
            state=tk.DISABLED,
        )
        self.text_image_clear_button.grid(row=0, column=2, sticky='ew', padx=(4, 0), pady=(0, 4))
        self.text_image_extract_all_button = ttk.Button(
            controls, text='Extraer Todos', command=self._extract_all_text_images,
            state=tk.DISABLED,
        )
        self.text_image_extract_all_button.grid(row=1, column=0, sticky='ew', padx=(0, 4))
        self.text_image_save_button = ttk.Button(
            controls, text='Guardar ISO con reemplazos…', command=self._save_text_image_replacements,
            state=tk.DISABLED,
        )
        self.text_image_save_button.grid(row=1, column=1, columnspan=2, sticky='ew', padx=(4, 0))

        self.text_image_help_label = ttk.Label(
            right,
            text=(
                'PNG de reemplazo: mismas dimensiones. Los siete títulos de capítulo aparecen como vistas '
                'individuales; 00–05 son texto SLES (se editan en Traducción) y 06 también se rasteriza en SceSel_F. '
                'En Special se muestran sólo los rótulos de texto localizados desde SLES_533.66. '
                'Si el LZ crece, DIR_E.AFS se reconstruye y relocaliza.'
            ),
            anchor='w', justify=tk.LEFT, wraplength=620,
        )
        self.text_image_help_label.grid(row=3, column=0, sticky='ew', pady=(7, 0))

    @staticmethod
    def _text_image_language_name(code: str) -> str:
        return {'en': 'Inglés', 'fr': 'Francés', 'de': 'Alemán'}.get(str(code), str(code))

    def _change_text_image_language(self, code: str):
        """Cambia la rama EN/FR/DE mostrada en Texto Imágenes."""
        code = str(code).lower()
        old = getattr(self, 'text_image_language_code', 'fr')
        if code == old:
            return
        if self.text_image_overrides:
            if not messagebox.askyesno(
                'Texto Imágenes · cambiar idioma',
                f'Hay {len(self.text_image_overrides)} reemplazo(s) PNG pendientes en '
                f'{self._text_image_language_name(old)}.\n\n'
                f'¿Descartarlos y mostrar las imágenes de {self._text_image_language_name(code)}?',
                parent=self,
            ):
                self.text_image_language_var.set(old)
                return
        self.text_image_language_code = code
        self.text_image_language_var.set(code)
        try:
            if self.eur_view_mode and self.eur_iso_path and self.eur_iso_path.exists():
                self._load_text_images_from_iso(clear_overrides=True)
            else:
                self._clear_text_images_tab(clear_overrides=True)
                self.text_images_status_var.set(
                    f'Idioma: {self._text_image_language_name(code)}. '
                    'Selecciona una ISO EUR SLES_533.66 para cargar sus imágenes.'
                )
        except Exception as exc:
            self.text_image_language_code = old
            self.text_image_language_var.set(old)
            messagebox.showerror('Texto Imágenes', str(exc), parent=self)

    def _clear_text_images_tab(self, *, clear_overrides=True):
        if not hasattr(self, 'text_images_tree'):
            return
        for iid in self.text_images_tree.get_children():
            self.text_images_tree.delete(iid)
        self.text_image_records = []
        self.text_image_current_id = None
        self.text_image_photo = None
        if clear_overrides:
            self.text_image_overrides = {}
        self.text_image_preview_label.configure(image='', text='Sin imagen')
        self.text_image_detail_var.set(
            'Selecciona una ISO EUR SLES_533.66 para cargar las imágenes localizadas.'
        )
        self.text_images_status_var.set(
            'Selecciona una ISO EUR SLES_533.66 para cargar las imágenes localizadas.'
        )
        self.text_image_extract_button.config(state=tk.DISABLED)
        self.text_image_extract_all_button.config(state=tk.DISABLED)
        self.text_image_replace_button.config(state=tk.DISABLED)
        self.text_image_clear_button.config(state=tk.DISABLED)
        self.text_image_save_button.config(state=tk.DISABLED)
        self.text_image_reload_button.config(state=tk.DISABLED)

    @staticmethod
    def _text_image_white_bbox(image: Image.Image, rect: tuple[int, int, int, int]):
        """BBox de texto claro dentro de una región RGBA, sin OCR.

        Se usa sólo para montar la vista de juego de los atlas Sp/Special. Los
        rótulos son blancos/grises sobre fondo transparente, por lo que basta
        detectar sus píxeles claros y poco saturados.
        """
        rgba = image.convert('RGBA')
        x1, y1, x2, y2 = [int(v) for v in rect]
        x1 = max(0, min(rgba.width, x1)); x2 = max(x1, min(rgba.width, x2))
        y1 = max(0, min(rgba.height, y1)); y2 = max(y1, min(rgba.height, y2))
        px = rgba.load()
        min_x = min_y = None
        max_x = max_y = None
        for y in range(y1, y2):
            for x in range(x1, x2):
                r, g, b, a = px[x, y]
                if a <= 32:
                    continue
                hi, lo = max(r, g, b), min(r, g, b)
                if ((int(r) + int(g) + int(b)) // 3) < 110 or (hi - lo) >= 120:
                    continue
                min_x = x if min_x is None else min(min_x, x)
                max_x = x if max_x is None else max(max_x, x)
                min_y = y if min_y is None else min(min_y, y)
                max_y = y if max_y is None else max(max_y, y)
        if min_x is None:
            return None
        return (min_x, min_y, max_x + 1, max_y + 1)

    @classmethod
    def _text_image_crop_word(cls, image: Image.Image, rect, pad=1):
        bbox = cls._text_image_white_bbox(image, rect)
        if bbox is None:
            return None
        x1, y1, x2, y2 = bbox
        rgba = image.convert('RGBA')
        return rgba.crop((
            max(0, x1 - pad), max(0, y1 - pad),
            min(rgba.width, x2 + pad), min(rgba.height, y2 + pad),
        ))

    @classmethod
    def _text_image_paste_word(cls, image: Image.Image, target_rect, piece: Image.Image | None):
        if piece is None:
            return image.convert('RGBA').copy()
        out = image.convert('RGBA').copy()
        target_bbox = cls._text_image_white_bbox(out, target_rect)
        anchor_x = int(target_bbox[0]) if target_bbox else int(target_rect[0])
        center_y = (int(target_rect[1]) + int(target_rect[3])) // 2
        target_y = center_y - piece.height // 2
        draw = ImageDraw.Draw(out)
        draw.rectangle(tuple(int(v) for v in target_rect), fill=(0, 0, 0, 0))
        out.alpha_composite(piece, (anchor_x, target_y))
        return out

    @classmethod
    def _compose_special_menu_game_previews(cls, records: list[dict], language: str):
        """Monta la vista que el juego compone a partir de los atlas Sp/Special.

        El PNG bruto contiene algunos rótulos separados en varias zonas. El SLES
        no muestra el atlas plano: utiliza recortes de `sub`. Para la GUI usamos
        copias intactas de esos mismos rótulos presentes en Special/lower menu.
        `row['image']` queda intacto como atlas bruto leído de la ISO. La GUI puede
        exportar y reimportar la vista compuesta (`preview_image`) para estos atlas.
        """
        by_id = {str(row.get('id')): row for row in records}
        sp = by_id.get('special_menu_sp60')
        special = by_id.get('special_menu_special')
        if not sp or not special:
            return
        sp_raw = sp.get('image')
        special_raw = special.get('image')
        if sp_raw is None or special_raw is None:
            return

        # En Special_* Blood/Sang/Blut y Pigeon/Taube están completos.
        blood = cls._text_image_crop_word(special_raw, (840, 0, 950, 60), pad=0)
        pigeon = cls._text_image_crop_word(special_raw, (840, 60, 950, 120), pad=0)
        # El rótulo Items/Objets/Objekte aparece completo en el bloque inferior.
        lower_items_region = {
            'en': (790, 440, 970, 465),
            'fr': (790, 470, 970, 508),
            'de': (790, 450, 970, 490),
        }.get(str(language), (790, 470, 970, 508))
        items = cls._text_image_crop_word(special_raw, lower_items_region)

        sp_view = sp_raw.convert('RGBA').copy()
        sp_view = cls._text_image_paste_word(sp_view, (840, 50, 995, 110), blood)
        sp_view = cls._text_image_paste_word(sp_view, (795, 160, 965, 203), pigeon)
        sp_view = cls._text_image_paste_word(sp_view, (795, 273, 995, 311), items)

        special_view = special_raw.convert('RGBA').copy()
        special_view = cls._text_image_paste_word(
            special_view, (785, 245, 995, 286), items
        )
        sp['preview_image'] = sp_view
        special['preview_image'] = special_view
        sp['game_composed_preview'] = True
        special['game_composed_preview'] = True
        sp['export_preview_image'] = True
        special['export_preview_image'] = True

    @staticmethod
    def _chapter_title_text_image(text: str, *, width: int = 512, height: int = 96) -> Image.Image:
        """Genera una vista individual legible para un título de capítulo.

        Es una previsualización de la C-string que usa el selector, no una textura
        separada del disco. Se dibuja sobre transparencia para que el panel de
        Texto Imágenes la monte sobre negro igual que las texturas reales.
        """
        text = ' '.join(str(text or '').split())
        canvas = Image.new('RGBA', (width, height), (0, 0, 0, 0))
        if not text:
            return canvas
        draw = ImageDraw.Draw(canvas)
        candidates = (
            'DejaVuSerif.ttf', 'LiberationSerif-Regular.ttf', 'Georgia.ttf',
            'Times New Roman.ttf', 'times.ttf',
        )
        font = None
        for size in range(48, 15, -1):
            for candidate in candidates:
                try:
                    trial = ImageFont.truetype(candidate, size)
                except Exception:
                    continue
                bb = draw.textbbox((0, 0), text, font=trial)
                if bb[2] - bb[0] <= width - 20 and bb[3] - bb[1] <= height - 12:
                    font = trial
                    break
            if font is not None:
                break
        if font is None:
            try:
                font = ImageFont.load_default(size=24)
            except TypeError:
                font = ImageFont.load_default()
        bb = draw.textbbox((0, 0), text, font=font)
        tw, th = bb[2] - bb[0], bb[3] - bb[1]
        x = max(4, (width - tw) // 2 - bb[0])
        y = max(2, (height - th) // 2 - bb[1])
        draw.text((x, y), text, font=font, fill=(255, 255, 255, 255))
        return canvas

    def _individual_chapter_title_records(self, language: str) -> list[dict]:
        """Construye siete filas individuales para «Texto Imágenes».

        En la rama francesa se muestra el target español activo del proyecto; en
        inglés/alemán se muestra la C-string original de esa rama. Las filas son
        de sólo lectura PNG porque 00–05 se almacenan como texto en SLES_533.66.
        """
        code = str(language or 'fr').lower()
        originals = _TEXT_IMAGE_CHAPTER_TITLES.get(code, _TEXT_IMAGE_CHAPTER_TITLES['fr'])
        lang_name = self._text_image_language_name(code)
        rows = []
        for chapter in range(7):
            key = f'chapter_{chapter:02d}'
            source = str(originals[key])
            if code == 'fr':
                shown = str(self.eur_scene_selector_targets.get(key, source) or source)
                label = f'Capítulo {chapter:02d} · {source} → {shown}'
                state = 'Título SLES · español'
            else:
                shown = source
                label = f'Capítulo {chapter:02d} · {shown}'
                state = f'Título SLES · {lang_name.lower()}'
            image = self._chapter_title_text_image(shown)
            rows.append({
                'id': f'scene_chapter_title_{chapter:02d}',
                'group': 'Selector · Títulos de capítulos',
                'afs_index': 3891 if code == 'fr' else (3890 if code == 'en' else 3892),
                'afs_name': 'SLES_533.66',
                'resource_label': 'SLES_533.66 · tabla de capítulos',
                'resource_display': 'SLES_533.66 · C-string del selector de escenas',
                'texture': f'Capítulo {chapter:02d} · {shown}',
                'label': label,
                'width': image.width, 'height': image.height, 'bpp': 0,
                'format': 'sles_chapter_title',
                'image': image, 'preview_image': image.copy(),
                'export_preview_image': True,
                'language': code, 'language_name': lang_name,
                'read_only_visual': True,
                'chapter_key': key,
                'chapter_number': f'{chapter:02d}',
                'source_text': source,
                'target_text': shown,
                'state_label': state,
                'entry_offset': 0, 'entry_absolute': 0, 'entry_size': 0,
                'subresource_offset': 0, 'sha256_entry': '',
                'compressed': False, 'packed_size': None, 'unpacked_size': None,
                'export_filename': f'{code.upper()}_CAPITULO_{chapter:02d}_{shown}.png',
            })
        return rows

    def _refresh_individual_chapter_title_records(self):
        """Las vistas de capítulos reflejan la ISO real y no se falsean al editar targets."""
        return

    def _load_text_images_from_iso(self, *, clear_overrides=True):
        if not self.eur_view_mode or not self.eur_iso_path or not self.eur_iso_path.exists():
            self._clear_text_images_tab(clear_overrides=clear_overrides)
            return
        if clear_overrides:
            self.text_image_overrides = {}
        lang_code = getattr(self, 'text_image_language_code', 'fr')
        lang_name = self._text_image_language_name(lang_code)
        self.text_images_status_var.set(f'Cargando texturas {lang_name.lower()} desde la ISO EUR…')
        self.update_idletasks()
        records = load_eur_text_image_previews(self.eur_iso_path, language=lang_code)
        self._compose_special_menu_game_previews(records, lang_code)
        self.text_image_records = records
        for iid in self.text_images_tree.get_children():
            self.text_images_tree.delete(iid)
        for row in records:
            sid = str(row['id'])
            status = (
                'Reemplazo pendiente' if sid in self.text_image_overrides else
                (row.get('state_label') or
                 ('Texto localizado SLES' if row.get('format') == 'atlas_region' else 'ISO seleccionada'))
            )
            resource = row.get('resource_label') or f"#{row['afs_index']} {row['afs_name']}"
            self.text_images_tree.insert(
                '', tk.END, iid=sid,
                values=(
                    row['group'], resource, row['texture'],
                    f"{row['width']}×{row['height']}", status,
                ),
            )
        self.text_images_status_var.set(
            f'{len(records)} elementos visuales de {lang_name} localizados en {self.eur_iso_path.name}. '
            'Selecciona una para previsualizarla o sustituirla.'
        )
        self.text_image_reload_button.config(state=tk.NORMAL)
        self.text_image_extract_all_button.config(
            state=(tk.NORMAL if records else tk.DISABLED)
        )
        self.text_image_save_button.config(
            state=(tk.NORMAL if self.text_image_overrides else tk.DISABLED)
        )
        if records:
            first = str(records[0]['id'])
            self.text_images_tree.selection_set(first)
            self.text_images_tree.focus(first)
            self._on_text_image_select()

    def _reload_text_images_from_iso(self):
        if self.text_image_overrides:
            if not messagebox.askyesno(
                'Texto Imágenes',
                'Hay reemplazos PNG pendientes. ¿Descartarlos y volver a leer la ISO?',
                parent=self,
            ):
                return
        try:
            self._load_text_images_from_iso(clear_overrides=True)
        except Exception as exc:
            messagebox.showerror('Texto Imágenes', str(exc), parent=self)

    def _text_image_record(self, spec_id: str | None):
        if not spec_id:
            return None
        for row in self.text_image_records:
            if str(row.get('id')) == str(spec_id):
                return row
        return None

    @staticmethod
    def _scene_selector_preview_rgba(image: Image.Image) -> Image.Image:
        """Monta los sprites reales que SLES_533.66 toma de SceSel_E/F/G.

        SceSel_E/F/G es un atlas PSMT8 de 512x512, no una pantalla completa. Las
        coordenadas de aquí proceden de la tabla UV del ejecutable europeo:
        seis fechas 160x16, CIBLE 86x16 y la tarjeta Lion 60x410 almacenada
        girada. Se conserva la CLUT/alpha real; no se aplica autocontraste.
        """
        rgba = image.convert('RGBA')
        date_boxes = [
            (0,   96, 160, 112), (160, 96, 320, 112),
            (0,  112, 160, 128), (160,112, 320, 128),
            (0,  128, 160, 144), (160,128, 320, 144),
        ]
        label_box = (320, 96, 406, 112)
        lion_box = (452, 0, 512, 410)
        resampling = getattr(Image, 'Resampling', Image)

        # Las fechas son muy bajas (16 px). Se amplían 2x sólo para el visor,
        # siempre con NEAREST para no inventar píxeles ni suavizar el bitmap.
        date_tiles = []
        for box in date_boxes:
            tile = rgba.crop(box)
            tile = tile.resize((tile.width * 2, tile.height * 2), resampling.NEAREST)
            date_tiles.append(tile)
        label = rgba.crop(label_box)
        label = label.resize((label.width * 2, label.height * 2), resampling.NEAREST)

        lion = rgba.crop(lion_box).rotate(270, expand=True)
        # 410x60 -> 615x90: suficiente para leerlo sin superar el ancho del panel.
        lion = lion.resize((615, 90), resampling.NEAREST)

        margin = 10
        gap = 10
        title_h = 24
        col_w = 320
        rows_h = 3 * 32 + 2 * 6
        content_w = col_w * 2 + gap
        label_y = title_h + rows_h + 8
        lion_y = label_y + 32 + 10
        canvas_w = max(content_w, lion.width) + margin * 2
        canvas_h = lion_y + lion.height + margin
        canvas = Image.new('RGBA', (canvas_w, canvas_h), (0, 0, 0, 255))
        draw = ImageDraw.Draw(canvas)
        try:
            font = ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf', 14)
        except Exception:
            font = None
        draw.text((margin, 4), 'Fechas, CIBLE y tarjeta Lion · UV reales del juego',
                  font=font, fill=(220, 220, 220, 255))

        for i, tile in enumerate(date_tiles):
            col = i % 2
            row = i // 2
            x = margin + col * (col_w + gap)
            y = title_h + row * (32 + 6)
            canvas.alpha_composite(tile, (x, y))
        canvas.alpha_composite(label, (margin, label_y))
        canvas.alpha_composite(lion, (margin, lion_y))
        return canvas


    def _on_text_image_select(self, _event=None):
        if not hasattr(self, 'text_images_tree'):
            return
        sel = self.text_images_tree.selection()
        if not sel:
            return
        spec_id = str(sel[0])
        row = self._text_image_record(spec_id)
        if not row:
            return
        self.text_image_current_id = spec_id
        override = self.text_image_overrides.get(spec_id)
        try:
            if override:
                with Image.open(override) as src:
                    image = src.convert('RGBA')
                source_note = f'Reemplazo pendiente: {Path(override).name}'
                display_source = (
                    self._scene_selector_preview_rgba(image)
                    if row.get('id') == 'scene_selector' else image
                )
            else:
                image = row['image'].copy()
                source_note = 'Vista extraída de la ISO seleccionada'
                display_source = row.get('preview_image')
                if display_source is None and row.get('id') == 'scene_selector':
                    display_source = self._scene_selector_preview_rgba(image)
                elif display_source is None:
                    display_source = image
                else:
                    display_source = display_source.copy()

            # Fondo negro para representar cómo se ven estas texturas transparentes en juego.
            display = Image.new('RGBA', display_source.size, (0, 0, 0, 255))
            display.alpha_composite(display_source)
            # Ajustar al viewport real, no a un ancho fijo mayor que el panel. Para
            # tutoriales 1024x1024, NEAREST al reducir eliminaba trazos finos de la
            # tipografía; LANCZOS conserva la lectura. Para ampliar seguimos usando
            # NEAREST para no inventar bordes en los bitmaps del juego.
            self.update_idletasks()
            box_w = int(getattr(self, 'text_image_preview_box', self).winfo_width())
            box_h = int(getattr(self, 'text_image_preview_box', self).winfo_height())
            max_w = max(180, box_w - 18) if box_w > 80 else 600
            max_h = max(160, box_h - 18) if box_h > 80 else 300
            if display.width > max_w or display.height > max_h:
                shrink_filter = (
                    Image.Resampling.LANCZOS
                    if str(row.get('id') or '').startswith('tutorial_')
                    else Image.Resampling.BOX
                )
                display.thumbnail((max_w, max_h), shrink_filter)
            else:
                sx = max(1, max_w // max(1, display.width))
                sy = max(1, max_h // max(1, display.height))
                scale = max(1, min(4, sx, sy))
                if scale > 1:
                    display = display.resize(
                        (display.width * scale, display.height * scale), Image.Resampling.NEAREST
                    )
            if ImageTk is not None:
                self.text_image_photo = ImageTk.PhotoImage(display)
                self.text_image_preview_label.configure(image=self.text_image_photo, text='')
            else:
                self.text_image_preview_label.configure(
                    image='', text=f'{row["texture"]} · {row["width"]}×{row["height"]}'
                )
            extra_note = ''
            if row.get('format') == 'atlas_region':
                x1, y1, x2, y2 = [int(v) for v in row.get('atlas_rect', (0, 0, 0, 0))]
                if row.get('is_portrait'):
                    variants = row.get('runtime_variants') or []
                    variant_note = ''
                    if len(variants) >= 2:
                        a = tuple(int(v) for v in variants[0])
                        b = tuple(int(v) for v in variants[1])
                        variant_note = (
                            f' Variantes runtime: A {a[2]-a[0]}×{a[3]-a[1]} y '
                            f'B {b[2]-b[0]}×{b[3]-b[1]} sobre la misma celda.'
                        )
                    extra_note = (
                        f'\nRetrato localizado desde SLES_533.66: '
                        f'x={x1}, y={y1}, {x2-x1}×{y2-y1}. '
                        f'Evidencia SLES 0x{int(row.get("source_sles_offset", 0)):X}. '
                        'Al reemplazarlo sólo se modifica esta celda del atlas Special/sub.'
                        f'{variant_note}'
                    )
                else:
                    extra_note = (
                        f'\nRótulo localizado desde la geometría de render de SLES_533.66: '
                        f'x={x1}, y={y1}, {x2-x1}×{y2-y1}. '
                        f'Evidencia SLES 0x{int(row.get("source_sles_offset", 0)):X}. '
                        'Al reemplazarlo sólo se modifica esta zona de texto dentro de Special/sub.'
                    )
            elif row.get('format') == 'chapter_graphic_iso':
                extra_note = (
                    '\nVista leída byte a byte de la ISO seleccionada. No usa el target español del editor. '
                    'Si aquí aparece «Ange», esa ISO todavía contiene la tarjeta francesa; si aparece '
                    '«Ángel», la imagen ya está realmente parcheada.'
                )
            elif row.get('id') == 'scene_selector':
                extra_note = '\nPrevisualización resumida: la textura completa incluye atlas auxiliar y por eso no se muestra entera aquí.'
            elif str(row.get('id') or '').startswith('tutorial_'):
                extra_note = (
                    '\nAtlas de tutorial 1024×1024: la vista se reduce con antialiasing sólo para '
                    'hacer legibles los trazos finos.'
                )
                if row.get('id') == 'tutorial_yes_no' and row.get('display_roll_x'):
                    extra_note += (
                        f' Satu usa wrap horizontal: la vista y Extraer PNG desplazan circularmente '
                        f'{int(row.get("display_roll_x"))} px para unir los glifos que cruzan los bordes; '
                        'al reemplazar, el programa invierte el desplazamiento antes de escribir la textura.'
                    )
                else:
                    extra_note += ' Extraer PNG conserva la imagen original completa.'
            elif str(row.get('format') or '').startswith('compressed_'):
                extra_note = (
                    f'\nRecurso LZ: {row.get("packed_size", "?")} → {row.get("unpacked_size", "?")} bytes; '
                    f'{row.get("texture", "textura")} descomprimida +0x{int(row.get("subresource_offset", 0)):X}. '
                    'Se recompone y recomprime automáticamente al guardar.'
                )
                if row.get('linked_ids'):
                    extra_note += ' La copia equivalente del mismo idioma se actualiza automáticamente.'
                if row.get('format') == 'compressed_psmct32_alias_t8':
                    extra_note += f' Este atlas contiene retratos y numerosos rótulos de {row.get("language_name", "la rama activa")} del menú.'
                    if row.get('game_composed_preview'):
                        extra_note += (
                            ' Vista compuesta como la usa el juego: algunos rótulos del atlas bruto están '
                            'separados en varios recortes. Extraer PNG usa esta misma vista compuesta para que puedas editarla y reimportarla tal cual.'
                        )
                    if row.get('id') in ('special_menu_sp60', 'special_menu_special'):
                        extra_note += ' La vista, Extraer PNG y Reemplazar por PNG usan la misma lógica compuesta para estos atlas.'
            resource_display = row.get('resource_display') or f'AFS #{row["afs_index"]} · {row["afs_name"]}'
            format_display = f'{row.get("bpp", 4)} bpp'
            self.text_image_detail_var.set(
                f'{row["label"]}\n'
                f'Idioma: {row.get("language_name", self._text_image_language_name(self.text_image_language_code))} · '
                f'{resource_display} · {row["texture"]} · '
                f'{row["width"]}×{row["height"]} · {format_display}\n{source_note}{extra_note}'
            )
            self.text_image_extract_button.config(state=tk.NORMAL)
            can_replace = not bool(row.get('read_only_visual'))
            self.text_image_replace_button.config(state=(tk.NORMAL if can_replace else tk.DISABLED))
            self.text_image_clear_button.config(
                state=(tk.NORMAL if override and can_replace else tk.DISABLED)
            )
        except Exception as exc:
            self.text_image_preview_label.configure(image='', text='No se pudo mostrar la imagen')
            self.text_image_detail_var.set(str(exc))

    @staticmethod
    def _text_image_export_filename(row: dict) -> str:
        """Nombre PNG estable y sin caracteres problemáticos para exportación."""
        custom = str(row.get('export_filename') or '').strip()
        if custom:
            raw = custom[:-4] if custom.lower().endswith('.png') else custom
            safe = ''.join(ch if ch.isalnum() or ch in ('-', '_', '.') else '_' for ch in raw)
            while '__' in safe:
                safe = safe.replace('__', '_')
            return safe.strip('._') + '.png'
        texture = str(row['texture'])
        if texture.lower().endswith('.png'):
            texture = texture[:-4]
        lang = str(row.get('language') or 'fr').upper()
        raw = f"{lang}_AFS_{int(row['afs_index']):04d}_{row['afs_name']}_{texture}"
        safe = ''.join(ch if ch.isalnum() or ch in ('-', '_', '.') else '_' for ch in raw)
        while '__' in safe:
            safe = safe.replace('__', '_')
        return safe.strip('._') + '.png'

    @staticmethod
    def _killer7_pngs_desktop_folder() -> Path:
        """Devuelve Escritorio/Killer7PNGS, respetando Desktop/Escritorio habituales."""
        home = Path.home()
        desktop = None
        # Linux puede guardar la ruta localizada en user-dirs.dirs.
        user_dirs = home / '.config' / 'user-dirs.dirs'
        if user_dirs.is_file():
            try:
                for line in user_dirs.read_text(encoding='utf-8', errors='ignore').splitlines():
                    if not line.startswith('XDG_DESKTOP_DIR='):
                        continue
                    value = line.split('=', 1)[1].strip().strip('"')
                    value = value.replace('$HOME', str(home))
                    candidate = Path(value).expanduser()
                    if candidate:
                        desktop = candidate
                        break
            except Exception:
                desktop = None
        if desktop is None:
            for candidate in (home / 'Desktop', home / 'Escritorio'):
                if candidate.exists():
                    desktop = candidate
                    break
        if desktop is None:
            desktop = home / 'Desktop'
        out_dir = desktop / 'Killer7PNGS'
        out_dir.mkdir(parents=True, exist_ok=True)
        return out_dir

    def _extract_text_image_png(self):
        """Extrae a PNG la textura seleccionada tal como se leyó de la ISO."""
        row = self._text_image_record(self.text_image_current_id)
        if not row:
            messagebox.showinfo('Texto Imágenes', 'Selecciona primero una imagen.', parent=self)
            return
        suggested = self._text_image_export_filename(row)
        out = filedialog.asksaveasfilename(
            title=f'Extraer {row["texture"]} como PNG',
            defaultextension='.png',
            initialfile=suggested,
            filetypes=[('Imagen PNG', '*.png'), ('Todos', '*.*')],
        )
        if not out:
            return
        try:
            outp = Path(out).resolve()
            outp.parent.mkdir(parents=True, exist_ok=True)
            export_image = row.get('preview_image') if row.get('export_preview_image') else row['image']
            export_image.copy().save(outp, format='PNG')
            messagebox.showinfo(
                'Texto Imágenes',
                f'PNG extraído correctamente:\n{outp}',
                parent=self,
            )
        except Exception as exc:
            messagebox.showerror('Extraer PNG', str(exc), parent=self)

    def _extract_all_text_images(self):
        """Exporta todas las texturas cargadas a Escritorio/Killer7PNGS."""
        if not self.text_image_records:
            messagebox.showinfo(
                'Texto Imágenes', 'No hay imágenes cargadas para extraer.', parent=self
            )
            return
        try:
            out_dir = self._killer7_pngs_desktop_folder()
            exported = []
            for row in self.text_image_records:
                filename = self._text_image_export_filename(row)
                outp = out_dir / filename
                export_image = row.get('preview_image') if row.get('export_preview_image') else row['image']
                export_image.copy().save(outp, format='PNG')
                exported.append(outp)
            self.text_images_status_var.set(
                f'{len(exported)} PNG extraídos en {out_dir}.'
            )
            messagebox.showinfo(
                'Texto Imágenes · Extraer Todos',
                f'Se han extraído {len(exported)} imágenes PNG.\n\nCarpeta:\n{out_dir}',
                parent=self,
            )
        except Exception as exc:
            messagebox.showerror('Extraer Todos', str(exc), parent=self)

    def _replace_text_image(self):
        row = self._text_image_record(self.text_image_current_id)
        if not row:
            return
        if row.get('read_only_visual'):
            messagebox.showinfo(
                'Texto Imágenes',
                'Este título es una C-string de SLES_533.66, no una textura PNG independiente.\n\n'
                'Edítalo en «Traducción → Selector de escenas»; «Inyectar Textos» aplicará el cambio.',
                parent=self,
            )
            return
        path = filedialog.askopenfilename(
            title=f'Reemplazar {row["texture"]}',
            filetypes=[('Imagen PNG', '*.png'), ('Todos', '*.*')],
        )
        if not path:
            return
        try:
            with Image.open(path) as im:
                if im.size != (int(row['width']), int(row['height'])):
                    raise K7Error(
                        f'{Path(path).name} mide {im.width}×{im.height}.\n\n'
                        f'{row["texture"]} requiere exactamente '
                        f'{row["width"]}×{row["height"]} píxeles.'
                    )
                im.verify()
            self.text_image_overrides[str(row['id'])] = str(Path(path).resolve())
            self.text_images_tree.set(str(row['id']), 'state', 'Reemplazo pendiente')
            self.text_image_clear_button.config(state=tk.NORMAL)
            self.text_image_save_button.config(state=tk.NORMAL)
            self.text_images_status_var.set(
                f'{len(self.text_image_overrides)} reemplazo(s) pendiente(s). '
                'Usa «Guardar ISO con reemplazos…» para aplicarlos.'
            )
            self._on_text_image_select()
        except Exception as exc:
            messagebox.showerror('Reemplazar imagen', str(exc), parent=self)

    def _clear_text_image_override(self):
        spec_id = self.text_image_current_id
        if not spec_id or spec_id not in self.text_image_overrides:
            return
        self.text_image_overrides.pop(spec_id, None)
        if self.text_images_tree.exists(spec_id):
            row = self._text_image_record(spec_id)
            base_state = 'Texto localizado SLES' if row and row.get('format') == 'atlas_region' else 'ISO seleccionada'
            self.text_images_tree.set(spec_id, 'state', base_state)
        self.text_image_clear_button.config(state=tk.DISABLED)
        self.text_image_save_button.config(
            state=(tk.NORMAL if self.text_image_overrides else tk.DISABLED)
        )
        self.text_images_status_var.set(
            f'{len(self.text_image_overrides)} reemplazo(s) pendiente(s).'
            if self.text_image_overrides else
            f'{len(self.text_image_records)} texturas cargadas desde la ISO.'
        )
        self._on_text_image_select()

    def _save_text_image_replacements(self):
        if not self.eur_view_mode or not self.eur_iso_path or not self.eur_iso_path.exists():
            messagebox.showerror('Texto Imágenes', 'Selecciona primero una ISO EUR.', parent=self)
            return
        if not self.text_image_overrides:
            messagebox.showinfo('Texto Imágenes', 'No hay reemplazos PNG pendientes.', parent=self)
            return
        eurp = self.eur_iso_path.resolve()
        lang_code = getattr(self, 'text_image_language_code', 'fr')
        lang_name = self._text_image_language_name(lang_code)
        out = filedialog.asksaveasfilename(
            title=f'Guardar ISO EUR con reemplazos de Texto Imágenes · {lang_name}',
            defaultextension='.iso', initialdir=str(eurp.parent),
            initialfile=eurp.stem + f'_IMAGENES_{lang_code.upper()}_PERSONALIZADAS.iso',
            filetypes=[('Imagen ISO de PlayStation 2', '*.iso'), ('Todos', '*.*')],
        )
        if not out:
            return
        outp = Path(out).resolve()
        if outp == eurp:
            messagebox.showerror(
                'Texto Imágenes', 'La ISO original nunca se sobrescribe.', parent=self
            )
            return
        lines = []
        for spec_id, png in self.text_image_overrides.items():
            row = self._text_image_record(spec_id)
            if row:
                lines.append(f'• {row["texture"]} ← {Path(png).name}')
        if not messagebox.askyesno(
            'Texto Imágenes · aplicar reemplazos',
            f'Entrada:\n{eurp}\n\nSalida:\n{outp}\n\n'
            f'Idioma de destino: {lang_name}\n\n'
            f'Se aplicarán {len(lines)} reemplazo(s):\n' + '\n'.join(lines) +
            '\n\nSe conservarán dimensiones, CLUT, formato PSMT4/PSMT8, compresión LZ cuando corresponda y tamaño AFS. ¿Continuar?',
            parent=self,
        ):
            return

        progress = tk.Toplevel(self)
        progress.title('Texto Imágenes · recompilando')
        progress.transient(self)
        progress.grab_set()
        progress.resizable(False, False)
        ttk.Label(
            progress,
            text='Recompilando PNG y verificando la ISO de salida…',
            padding=14,
        ).pack(fill=tk.X)
        bar = ttk.Progressbar(progress, mode='indeterminate', length=520)
        bar.pack(fill=tk.X, padx=14, pady=(0, 14))
        bar.start(10)
        overrides = dict(self.text_image_overrides)

        def worker():
            try:
                report = apply_eur_text_image_replacements_to_iso(
                    str(eurp), str(outp), overrides, language=lang_code
                )
                self.after(0, lambda: finish_ok(report))
            except Exception as exc:
                self.after(0, lambda exc=exc: finish_error(exc))

        def finish_ok(report):
            try:
                bar.stop()
                progress.grab_release()
                progress.destroy()
            except Exception:
                pass
            messagebox.showinfo(
                'Texto Imágenes',
                f'ISO creada correctamente:\n{outp}\n\n'
                f'Idioma: {report.get("language_name", lang_name)}\n'
                f'Imágenes reemplazadas: {report.get("image_count", 0)}\n'
                f'Recursos AFS modificados: {report.get("resource_count", 0)}\n\n'
                'La ISO original no se ha modificado.',
                parent=self,
            )

        def finish_error(exc):
            try:
                bar.stop()
                progress.grab_release()
                progress.destroy()
            except Exception:
                pass
            messagebox.showerror('Texto Imágenes', str(exc), parent=self)

        threading.Thread(target=worker, daemon=True).start()

    def _build_menu(self):
        menu = tk.Menu(self)
        file_menu = tk.Menu(menu, tearoff=False)
        file_menu.add_command(label='Seleccionar ISO…', command=self.open_iso)
        file_menu.add_command(label='Guardar Proyecto', command=self.save_project)
        file_menu.add_separator()
        file_menu.add_command(label='Inyectar Textos', command=self.inject_texts)
        file_menu.add_separator()
        file_menu.add_command(label='Salir', command=self._on_close)
        menu.add_cascade(label='Archivo', menu=file_menu)

        tools_menu = tk.Menu(menu, tearoff=False)
        tools_menu.add_command(label='Escanear imágenes del juego…', command=self.open_image_scanner)
        menu.add_cascade(label='Herramientas', menu=tools_menu)

        help_menu = tk.Menu(menu, tearoff=False)
        help_menu.add_command(label='Nota técnica JMB francés…', command=self._show_eur_jmb_note)
        menu.add_cascade(label='Ayuda', menu=help_menu)
        self.main_menu = menu
        self.config(menu=menu)

    # ---------- Pantalla inicial ----------
    def _show_launcher(self):
        """Muestra la portada de acceso rápido sin inicializar otra instancia del editor."""
        if self.launcher_frame is not None:
            try:
                self.launcher_frame.destroy()
            except Exception:
                pass

        # La portada suministrada es 824x450. Mantenerla 1:1 evita recortes y
        # conserva libre la gran zona roja de la izquierda para los botones.
        self.config(menu='')
        self.resizable(False, False)
        self.minsize(824, 450)
        self.geometry('824x450')

        frame = tk.Frame(self, bg='#aa1e1e', bd=0, highlightthickness=0)
        frame.place(x=0, y=0, relwidth=1, relheight=1)
        frame.lift()
        self.launcher_frame = frame

        canvas = tk.Canvas(
            frame, width=824, height=450, bg='#aa1e1e',
            bd=0, highlightthickness=0, relief=tk.FLAT,
        )
        canvas.pack(fill=tk.BOTH, expand=True)
        self.launcher_canvas = canvas

        image_path = self._program_root() / 'resources' / 'launcher_background.jpg'
        if ImageTk is not None and image_path.exists():
            try:
                image = Image.open(image_path).convert('RGB')
                if image.size != (824, 450):
                    image = image.resize((824, 450), Image.Resampling.LANCZOS)
                self.launcher_photo = ImageTk.PhotoImage(image)
                canvas.create_image(0, 0, image=self.launcher_photo, anchor='nw')
            except Exception:
                self.launcher_photo = None

        def add_button(text, y, command):
            button = tk.Button(
                canvas, text=text, command=command,
                width=20, height=1,
                font=('TkDefaultFont', 12, 'bold'),
                fg='white', bg='#151515', activeforeground='white',
                activebackground='#3b0d0d', relief=tk.FLAT, bd=0,
                highlightthickness=0, cursor='hand2', padx=10, pady=7,
            )
            canvas.create_window(58, y, window=button, anchor='nw', width=220, height=42)
            return button

        # v1.7.7.188: indicador de preparación de la ISO. Se dibuja directamente
        # sobre la portada para no añadir recursos externos y permanece oculto
        # hasta que el usuario confirma un archivo en el selector.
        loading_items = [
            canvas.create_line(70, 132, 88, 132, fill='white', width=2, state='hidden'),
            canvas.create_line(70, 150, 88, 150, fill='white', width=2, state='hidden'),
            canvas.create_line(72, 134, 86, 148, fill='white', width=2, state='hidden'),
            canvas.create_line(86, 134, 72, 148, fill='white', width=2, state='hidden'),
            canvas.create_text(
                100, 141, text='Cargando...', anchor='w', fill='white',
                font=('TkDefaultFont', 11, 'bold'), state='hidden',
            ),
        ]
        self.launcher_loading_items = loading_items

        self.launcher_select_button = add_button('Seleccionar ISO', 176, self._launcher_open_iso)
        self.launcher_translate_button = add_button('Traducir al Español', 228, self.inject_texts)
        self.launcher_editor_button = add_button('Editor de Textos', 280, self._show_text_editor)
        # No permitir traducir hasta disponer de una ISO preparada.
        if not (self.eur_iso_path or self.project):
            self.launcher_translate_button.config(state=tk.DISABLED)

        # v1.7.7.183: sin cuarto elemento visual bajo los tres botones del launcher.

    def _set_launcher_loading(self, loading: bool) -> None:
        """Muestra/oculta el indicador de carga de la portada y protege los botones."""
        canvas = self.launcher_canvas
        if canvas is None or self.launcher_frame is None:
            return
        item_state = 'normal' if loading else 'hidden'
        for item in self.launcher_loading_items:
            try:
                canvas.itemconfigure(item, state=item_state)
            except Exception:
                pass
        if self.launcher_select_button is not None:
            self.launcher_select_button.config(state=tk.DISABLED if loading else tk.NORMAL)
        if self.launcher_translate_button is not None:
            ready = bool(self.eur_iso_path or self.project)
            self.launcher_translate_button.config(
                state=tk.DISABLED if loading or not ready else tk.NORMAL
            )
        # Fuerza el pintado antes de iniciar el análisis síncrono de la ISO.
        # Así el usuario ve «Cargando...» durante la preparación pesada.
        try:
            self.update_idletasks()
        except Exception:
            pass

    def _launcher_open_iso(self):
        self.open_iso()
        if self.eur_iso_path:
            self.launcher_status_var.set(f'ISO: {self.eur_iso_path.name}')
        elif self.project:
            self.launcher_status_var.set(f'ISO: {self.project.iso_path.name}')

    def _show_text_editor(self):
        """Abre la interfaz completa existente conservando la ISO ya seleccionada."""
        if self.launcher_frame is not None:
            try:
                self.launcher_frame.destroy()
            except Exception:
                pass
            self.launcher_frame = None
        self.launcher_photo = None
        self.launcher_canvas = None
        self.launcher_loading_items = []
        self.launcher_select_button = None
        self.launcher_translate_button = None
        self.launcher_editor_button = None
        if self.main_menu is not None:
            self.config(menu=self.main_menu)
        self.resizable(True, True)
        self.minsize(980, 680)
        self.geometry('1280x850')
        self.update_idletasks()

    def _build_info_tab(self, parent):
        title = ttk.Label(parent, text='Killer7 PS2 · Traducción XLIFF', font=('TkDefaultFont', 16, 'bold'))
        title.pack(anchor='w', pady=(4, 12))
        text = (
            'Flujo inspirado en la pestaña de Traducción del proyecto Snatcher PSX:\n\n'
            '1. Pulsa «Seleccionar ISO…». Se detectan automáticamente USA (SLUS_211.54) y EUR (SLES_533.66).\n'
            '2. En EUR, la ISO queda activa sin buscar D_US; «Inyectar Textos» sustituye la rama francesa por español.\n'
            '3. Compara «Original inglés» y «Traducción (target)» lado a lado.\n'
            '4. Edita los targets disponibles y pulsa «Guardar Proyecto» para conservar los cambios dentro del programa y registrarlos en CAMBIOS_PROYECTO.log.\n'
            '5. «Herramientas > Escanear imágenes del juego…» inventaría las texturas DIC del DIR.AFS, '
            'permite revisarlas visualmente, marcarlas y exportarlas como PNG.\n'
            '6. «Inyectar Textos» crea una ISO NUEVA con textos, subtítulos, imágenes traducidas, selector de escenas y cadenas directas EUR en una sola operación.\n\n'
            'La ISO original nunca se sobrescribe. Los controles {ctl:FFxx} están protegidos y la '
            'inyección se bloquea si el XLIFF no pasa la validación.'
        )
        ttk.Label(parent, text=text, justify=tk.LEFT, anchor='nw', wraplength=980).pack(fill=tk.X, anchor='w')

    def _build_criteria_tab(self, parent):
        ttk.Label(
            parent, text='Nota de criterios técnicos del proyecto',
            font=('TkDefaultFont', 12, 'bold'), anchor='w'
        ).pack(fill=tk.X, pady=(0, 8))
        frame = ttk.Frame(parent)
        frame.pack(fill=tk.BOTH, expand=True)
        text = tk.Text(frame, wrap=tk.WORD, padx=12, pady=12, font=('TkDefaultFont', 10))
        scroll = ttk.Scrollbar(frame, orient=tk.VERTICAL, command=text.yview)
        text.configure(yscrollcommand=scroll.set)
        text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scroll.pack(side=tk.RIGHT, fill=tk.Y)
        text.insert('1.0', TRANSLATION_CRITERIA)
        text.configure(state=tk.DISABLED)

    def _load_eur_jmb_note(self) -> str:
        """Carga la nota técnica que documenta los JMB/DIC franceses retail.

        Se mantiene como archivo externo para que la guía también pueda leerse sin
        arrancar la interfaz y para que futuras builds puedan actualizarla sin
        duplicar el texto en varias zonas del código.
        """
        path = resource_path('resources', EUR_JMB_NOTE_FILE)
        try:
            return path.read_text(encoding='utf-8')
        except Exception as exc:
            return (
                'No se pudo cargar la nota técnica JMB EUR.\n\n'
                f'Ruta esperada: {path}\nError: {exc}'
            )

    def _build_eur_jmb_note_tab(self, parent):
        ttk.Label(
            parent,
            text='JMB/DIC francés retail · guía de parcheo',
            font=('TkDefaultFont', 12, 'bold'),
            anchor='w',
        ).pack(fill=tk.X, pady=(0, 8))
        ttk.Label(
            parent,
            text=(
                'Estas directrices proceden de recursos PAL franceses reales y de '
                'casos comprobados en juego. Úsalas antes de recompilar o mover un JMB.'
            ),
            anchor='w', justify=tk.LEFT, wraplength=980,
        ).pack(fill=tk.X, pady=(0, 8))
        frame = ttk.Frame(parent)
        frame.pack(fill=tk.BOTH, expand=True)
        text = tk.Text(frame, wrap=tk.WORD, padx=12, pady=12, font=('TkDefaultFont', 10))
        scroll = ttk.Scrollbar(frame, orient=tk.VERTICAL, command=text.yview)
        text.configure(yscrollcommand=scroll.set)
        text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scroll.pack(side=tk.RIGHT, fill=tk.Y)
        text.insert('1.0', self._load_eur_jmb_note())
        text.configure(state=tk.DISABLED)
        self.eur_jmb_note_text = text

    def _show_eur_jmb_note(self):
        """Abre la nota técnica en una ventana independiente desde Ayuda."""
        win = tk.Toplevel(self)
        win.title('Nota técnica · JMB francés retail')
        win.geometry('900x700')
        win.minsize(700, 500)
        frame = ttk.Frame(win, padding=10)
        frame.pack(fill=tk.BOTH, expand=True)
        text = tk.Text(frame, wrap=tk.WORD, padx=12, pady=12, font=('TkDefaultFont', 10))
        scroll = ttk.Scrollbar(frame, orient=tk.VERTICAL, command=text.yview)
        text.configure(yscrollcommand=scroll.set)
        text.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scroll.pack(side=tk.RIGHT, fill=tk.Y)
        text.insert('1.0', self._load_eur_jmb_note())
        text.configure(state=tk.DISABLED)

    def _on_close(self):
        if (self.project or self.eur_view_mode) and not self._confirm_discard():
            return
        try:
            if self.project:
                self.project.close()
        finally:
            self.destroy()

    def _set_enabled(self, enabled: bool):
        state = tk.NORMAL if enabled else tk.DISABLED
        self.load_block_button.config(state=state)
        self.save_project_button.config(state=state)
        self.inject_texts_button.config(state=tk.NORMAL)
        self.image_scan_button.config(state=state)
        if enabled:
            self.combo.config(state='readonly')
        else:
            self.combo.config(state='disabled')

    # ---------- Text category tabs ----------
    def _all_text_blocks(self):
        """Devuelve los bloques visibles de la edición activa, sin filtrar."""
        if self.eur_view_mode:
            return list(self.eur_view_blocks)
        if self.project:
            return list(self.project.all_blocks)
        return []

    @staticmethod
    def _text_category_for_block(block) -> str:
        """Clasificación funcional de un bloque para el editor visual.

        La clasificación prioriza el uso que ve el jugador sobre el contenedor
        técnico. Por ejemplo, K7P2 e ISO ASCII de mapa van a «Mapa / lugares», y
        los JMB de interfaz no se mezclan con los diálogos narrativos.
        """
        block_id = str(getattr(block, 'id', '') or '')
        storage_kind = str(getattr(block, 'storage_kind', '') or '')
        context = str(getattr(block, 'context', '') or '')
        name = str(getattr(block, 'name', '') or '')
        hay = f'{block_id} {context} {name}'.casefold()

        if block_id == 'K7_9005_Misiones' or context.strip().casefold() in ('misiones', 'objetivos'):
            return 'objectives'
        if storage_kind == 'afs_cinematic_da' or block_id.startswith('EUR_CINEMA_'):
            return 'cinematics'
        if storage_kind == 'eur_scene_selector' or block_id == 'EUR_SCENE_SELECTOR':
            return 'selector'
        if storage_kind == 'afs_da':
            return 'subtitles'
        if (storage_kind in ('afs_k7p2', 'afs_k7p2_eur') or
                block_id == 'EUR_MAP_MISSION_LOCATIONS' or
                'mapa' in hay or 'localizador' in hay or 'rutas' in hay or
                'zonas · escenario' in hay):
            return 'map'
        if storage_kind == 'afs_graphic_ref':
            return 'graphics'
        if (storage_kind == 'elf_strings' or 'interfaz' in hay or 'menú' in hay or
                'menu' in hay or 'blood room' in hay or 'guardado' in hay or
                'opciones' in hay or 'selección / descifrado' in hay):
            return 'interface'
        if storage_kind == 'afs_pair':
            return 'jmb'
        return 'direct'

    def _blocks_for_active_category(self):
        blocks = self._all_text_blocks()
        if self.text_category_id == 'all':
            return blocks
        return [b for b in blocks if self._text_category_for_block(b) == self.text_category_id]

    def _category_id_from_selected_tab(self) -> str:
        if not hasattr(self, 'category_notebook'):
            return 'all'
        selected = self.category_notebook.select()
        for category_id, frame in self.text_category_frames.items():
            if str(frame) == selected:
                return category_id
        return 'all'

    def _select_category_tab(self, category_id: str) -> None:
        frame = self.text_category_frames.get(category_id) or self.text_category_frames.get('all')
        if frame is None:
            return
        self._category_tab_guard = True
        try:
            self.category_notebook.select(frame)
        finally:
            self._category_tab_guard = False
        self.text_category_id = category_id if category_id in self.text_category_frames else 'all'

    def _refresh_category_tab_states(self) -> None:
        """Deshabilita pestañas sin contenido en la edición activa."""
        all_blocks = self._all_text_blocks()
        counts = {category_id: 0 for category_id, _label in self.text_category_specs}
        counts['all'] = len(all_blocks)
        for block in all_blocks:
            counts[self._text_category_for_block(block)] += 1
        for category_id, _label in self.text_category_specs:
            frame = self.text_category_frames.get(category_id)
            if frame is None:
                continue
            state = 'normal' if counts.get(category_id, 0) else 'disabled'
            # La pestaña Todos queda disponible siempre que haya algún proyecto.
            if category_id == 'all' and (self.project or self.eur_view_mode):
                state = 'normal'
            self.category_notebook.tab(frame, state=state)

    def _clear_block_editor_view(self) -> None:
        self.block = None
        self.rows = []
        self.current = -1
        for item in self.tree.get_children():
            self.tree.delete(item)
        self.src_text.config(state=tk.NORMAL)
        self.src_text.delete('1.0', tk.END)
        self.src_text.config(state=tk.DISABLED)
        self.tgt_text.config(state=tk.NORMAL)
        self.tgt_text.delete('1.0', tk.END)
        self.tgt_text.config(state=tk.DISABLED if self.eur_view_mode else tk.NORMAL)
        self.preview_photo = None
        self.preview.config(image='', text='No hay textos en esta categoría.')
        self.progress.set('0 / 0')
        self.file_label.config(text='No hay bloques disponibles en esta categoría.')
        self.format_policy_var.set('Formato: — · No hay bloques en esta categoría.')

    def _refresh_block_category_filter(self, *, load_first: bool = False, preserve_label: str = '') -> None:
        """Actualiza el combo para que sólo contenga bloques de la categoría activa."""
        self._refresh_category_tab_states()
        blocks = self._blocks_for_active_category()
        values = [b.label for b in blocks]
        old_label = preserve_label or self.block_var.get()
        self.combo.config(values=values)

        if old_label in values:
            chosen = old_label
        else:
            chosen = values[0] if values else ''
        self.block_var.set(chosen)

        has_project = bool(self.project or self.eur_view_mode)
        self.combo.config(state='readonly' if has_project and values else 'disabled')
        self.load_block_button.config(state=tk.NORMAL if has_project and values else tk.DISABLED)

        if not values:
            self._clear_block_editor_view()
        elif load_first and chosen:
            self.load_block(force=True)

    def _on_text_category_changed(self, _event=None):
        if self._category_tab_guard:
            return
        new_category = self._category_id_from_selected_tab()
        if new_category == self.text_category_id:
            return
        old_category = self.text_category_id
        # Antes de ocultar el bloque actual, conservar cualquier edición en curso.
        if not self.commit():
            self._select_category_tab(old_category)
            return
        self.text_category_id = new_category
        current_label = self.block.label if self.block is not None else self.block_var.get()
        self._refresh_block_category_filter(load_first=True, preserve_label=current_label)

    def _show_block_in_its_category(self, block) -> None:
        """Selecciona la pestaña propietaria de un bloque y refresca el combo."""
        category_id = self._text_category_for_block(block)
        self._select_category_tab(category_id)
        self._refresh_block_category_filter(load_first=False, preserve_label=block.label)

    # ---------- Project ----------
    @staticmethod
    def _note_first(notes: dict, key: str, default=''):
        value = notes.get(key, [default])
        if isinstance(value, list):
            return value[0] if value else default
        return value if value is not None else default

    @staticmethod
    def _note_int(notes: dict, key: str, default=0) -> int:
        raw = App._note_first(notes, key, default)
        try:
            return int(str(raw), 0)
        except Exception:
            return int(default)

    def _build_eur_view_from_master(self):
        """Construye un visor de sólo lectura para una ISO EUR seleccionada."""
        master_path = editable_path('resources', 'master', 'Killer7_SLUS-21154_master_ES_started.xlf')
        if not master_path.is_file():
            raise K7Error(f'Falta el catálogo maestro de textos: {master_path.name}')
        root = ET.parse(master_path).getroot()
        parsed = parse_project_xliff(root)
        blocks = []
        total_units = 0
        for pf in parsed['files']:
            fn = pf.get('notes', {})
            storage_kind = str(self._note_first(fn, 'killer7:storage_kind', 'unknown'))
            # El maestro USA sólo exponía Hallway/Parking/Iwazaru/Travis. En modo
            # EUR se sustituye por el catálogo real de 2.565 rótulos SLES_533.66.
            if storage_kind == 'afs_k7p2':
                continue
            jmb_index = self._note_int(fn, 'killer7:jmb_index', 0)
            dic_index = self._note_int(fn, 'killer7:dic_index', -1)
            afs_name = str(self._note_first(fn, 'killer7:afs_name', pf.get('file_id', '')))
            context = str(self._note_first(fn, 'killer7:context', afs_name))
            display_label = str(self._note_first(fn, 'killer7:display_label', pf.get('file_id', '')))
            storage_path = str(self._note_first(fn, 'killer7:storage_path', pf.get('original', '')))
            storage_path = storage_path.replace('D_US/DIR.AFS', 'D_EU/DIR_E.AFS').replace('SLUS_211.54', 'SLES_533.66')
            units = []
            for seq, row in enumerate(pf.get('units', [])):
                un = row.get('notes', {})
                sentence = self._note_int(un, 'killer7:sentence', seq)
                jimaku = self._note_int(un, 'killer7:jimaku', 0)
                wait = self._note_int(un, 'killer7:wait', 0)
                disp = self._note_int(un, 'killer7:disp_time', 0)
                codes = []
                for token in str(self._note_first(un, 'killer7:codes', '')).split():
                    try:
                        v = int(token, 16)
                        codes.append(v - 0x10000 if v >= 0x8000 else v)
                    except Exception:
                        pass
                src = row.get('source', '') or ''
                max_codes = self._note_int(un, 'killer7:max_codes', max(1, len(codes), len(src)))
                binary_path = str(self._note_first(un, 'killer7:binary_path', storage_path))
                binary_path = binary_path.replace('D_US/DIR.AFS', 'D_EU/DIR_E.AFS').replace('SLUS_211.54', 'SLES_533.66')
                units.append(TextUnit(
                    str(row.get('id', f'eur-{jmb_index:04d}-{seq:03d}')),
                    jmb_index, dic_index, afs_name, sentence, jimaku, wait, disp, codes,
                    src, str(self._note_first(un, 'killer7:source_state', 'verified')),
                    '', str(self._note_first(un, 'killer7:source_provenance', 'master-view')),
                    None, max_codes, binary_path,
                    self._note_int(un, 'killer7:binary_offset', 0),
                    self._note_int(un, 'killer7:binary_slot', 0),
                    str(self._note_first(un, 'killer7:binary_pad', 'nul')),
                ))
            if not units:
                continue
            if storage_kind == 'afs_pair':
                display_label = f'JMB · {context} · {afs_name} · {len(units)} textos'
            elif storage_kind == 'afs_da':
                display_label = f'SUBTÍTULOS · {context} · {afs_name} · {len(units)} líneas'
            elif storage_kind == 'afs_k7p2':
                display_label = f'K7P2 · {context} · {len(units)} nombres'
            elif storage_kind == 'afs_graphic_ref':
                display_label = f'GRÁFICO · {context} · {len(units)} textos'
            elif storage_kind == 'elf_strings':
                display_label = f'MENÚ · {context} · {len(units)} textos'
            elif storage_kind == 'iso_ascii':
                # v1.7.7.131: el bloque 9006 y las tablas de zonas S01M-S07M
                # pertenecen a la interfaz de mapa. Se conservan sus fuentes y
                # rutas binarias; sólo se añade una etiqueta visual coherente.
                if str(pf.get('file_id', '')) == 'K7_9006_Mapa' or context.strip().casefold() == 'mapa':
                    display_label = f'MAPA · Interfaz / ubicaciones · {len(units)} textos'
                elif context.casefold().startswith('zonas · escenario'):
                    display_label = f'MAPA · {context} · {len(units)} zonas'
                else:
                    display_label = f'DIRECTO · {context} · {len(units)} textos'
            blocks.append(SimpleNamespace(
                id=pf['file_id'], jmb_index=jmb_index, dic_index=dic_index,
                name=afs_name, sentence_num=self._note_int(fn, 'killer7:sentence_num', len(units)),
                char_num=self._note_int(fn, 'killer7:char_num', 0), units=units,
                storage_kind=storage_kind, storage_path=storage_path,
                context=context, label=display_label,
            ))
            # v1.7.7.131: las primeras 14 entradas de Misiones son descripciones
            # de localización (Celtic, Fukushima, Kaku, InterCity, Hotel Union,
            # Horizon Tower, etc.). Algunas cadenas/fragmentos se reutilizan en
            # cabeceras de mapa. Se exponen también bajo MAPA como una vista alias
            # de sólo lectura, sin duplicar ni alterar la inyección.
            if str(pf.get('file_id', '')) == 'K7_9005_Misiones' and len(units) >= 14:
                alias_rows = [dict(r) for r in pf.get('units', [])[:14]]
                blocks.append(SimpleNamespace(
                    id='EUR_MAP_MISSION_LOCATIONS', jmb_index=jmb_index, dic_index=dic_index,
                    name=afs_name, sentence_num=14, char_num=0, units=units[:14],
                    storage_kind=storage_kind, storage_path=storage_path,
                    context='Mapa · cabeceras / localizaciones de misión',
                    label='MAPA · Cabeceras / localizaciones de misión · 14 referencias EN',
                    viewer_rows=alias_rows,
                ))
            total_units += len(units)
        self.master_root = root
        self.eur_view_blocks = blocks
        return len(blocks), total_units

    def _append_eur_k7p2_view(self) -> tuple[int, int]:
        """Añade los 2.565 rótulos K7P2 reales de la edición EUR al visor.

        El catálogo está ligado a SLES_533.66 y se genera desde DIR_E.AFS. Es de
        sólo lectura: la inyección usa la misma tabla integrada en compiler.py.
        """
        catalog_path = resource_path('Killer7EUR_K7P2_ES.json')
        if not catalog_path.is_file():
            return 0, 0
        data = json.loads(catalog_path.read_text(encoding='utf-8'))
        if data.get('format') != 'killer7-eur-k7p2-label-catalog' or data.get('serial') != 'SLES_533.66':
            raise K7Error('El catálogo K7P2 EUR incluido no es compatible.')
        blocks = []
        total = 0

        # v1.7.7.47: vista resumida de todos los localizadores K7P2 únicos.
        # Las revisiones antiguas hacían visibles sobre todo Hallway/Parking/
        # Iwazaru/Travis; el catálogo EUR real contiene 250 textos distintos.
        unique = {}
        for group in data.get('groups', []):
            idx = int(group.get('afs_index', -1))
            name = str(group.get('name', ''))
            for item in group.get('rows', []):
                src = str(item.get('source', ''))
                if not src:
                    continue
                row = unique.setdefault(src, {
                    'source': src,
                    'target': str(item.get('target', src)),
                    'count': 0,
                    'afs_index': idx,
                    'afs_name': name,
                    'section': str(item.get('section', '')),
                    'sections': set(),
                    'key': str(item.get('key', '')),
                    'offset': int(item.get('offset', 0)),
                    'slot': int(item.get('slot', max(1, len(src)+1))),
                    'kind': str(item.get('kind', 'rótulo K7P2')),
                })
                row['count'] += 1
                row['sections'].add(str(item.get('section', '')))

        # v1.7.7.47: categoría explícita de lugares/zonas. Incluye todas las
        # rutas NurbsPathName y los localizadores cuyo rótulo describe un espacio
        # físico (Room/House/Hall/Gate/etc.). Los objetos/personajes quedan fuera.
        place_items = [
            item for item in unique.values()
            if any(eur_k7p2_is_place_label(str(item['source']), sec)
                   for sec in item.get('sections', {str(item['section'])}))
        ]
        place_units = []
        place_rows = []
        for seq, item in enumerate(sorted(place_items, key=lambda r: r['source'].casefold())):
            src = item['source']
            tgt = item['target']
            uid = f'eur-k7p2-place-{seq:03d}'
            place_rows.append({
                'id': uid, 'source': src, 'target': tgt,
                'source_ph': [], 'target_ph': [],
                'segment_state': 'translated' if tgt != src else 'final',
            })
            place_units.append(TextUnit(
                uid, int(item['afs_index']), -1, str(item['afs_name']), seq,
                0, 0, 0, [ord(ch) for ch in src], src, 'verified', '',
                f"k7p2-place:{item['section']}; key={item['key']}; apariciones={item['count']}; {item['kind']}",
                None, max(1, int(item['slot'])-1),
                f"D_EU/DIR_E.AFS#{int(item['afs_index'])}", int(item['offset']), int(item['slot']), 'nul'
            ))
        if place_units:
            changed_places = sum(1 for r in place_rows if r['target'] != r['source'])
            blocks.append(SimpleNamespace(
                id='EUR_K7P2_LUGARES_ZONAS', jmb_index=-1, dic_index=-1,
                name='Lugares y zonas K7P2 EUR', sentence_num=len(place_units), char_num=0,
                units=place_units, storage_kind='afs_k7p2_eur',
                storage_path='D_EU/DIR_E.AFS · NurbsPathName + localizadores de zona',
                context='Mapa · lugares / salas / rutas / plantas / accesos · K7P2',
                label=f'MAPA · K7P2 · {len(place_units)} rótulos físicos únicos · fuente EN · ES {changed_places}/{len(place_units)}',
                viewer_rows=place_rows,
            ))

        unique_units = []
        unique_rows = []
        for seq, item in enumerate(sorted(unique.values(), key=lambda r: r['source'].casefold())):
            src = item['source']
            tgt = item['target']
            uid = f'eur-k7p2-unique-{seq:03d}'
            unique_rows.append({
                'id': uid, 'source': src, 'target': tgt,
                'source_ph': [], 'target_ph': [],
                'segment_state': 'translated' if tgt != src else 'final',
            })
            unique_units.append(TextUnit(
                uid, int(item['afs_index']), -1, str(item['afs_name']), seq,
                0, 0, 0, [ord(ch) for ch in src], src, 'verified', '',
                f"k7p2-eur:{item['section']}; key={item['key']}; apariciones={item['count']}; {item['kind']}",
                None, max(1, int(item['slot'])-1),
                f"D_EU/DIR_E.AFS#{int(item['afs_index'])}", int(item['offset']), int(item['slot']), 'nul'
            ))
        if unique_units:
            changed = sum(1 for r in unique_rows if r['target'] != r['source'])
            blocks.append(SimpleNamespace(
                id='EUR_K7P2_LOCALIZADORES_UNICOS', jmb_index=-1, dic_index=-1,
                name='Localizadores K7P2 EUR', sentence_num=len(unique_units), char_num=0,
                units=unique_units, storage_kind='afs_k7p2_eur',
                storage_path='D_EU/DIR_E.AFS · 241 recursos K7P2',
                context='Lugares / rutas / personajes / objetos · localizadores K7P2 únicos',
                label=f'LOCALIZADORES K7P2 · fuente EN detectada · {len(unique_units)} rótulos únicos · ES {changed}/{len(unique_units)}',
                viewer_rows=unique_rows,
            ))

        for group in data.get('groups', []):
            idx = int(group.get('afs_index', -1))
            name = str(group.get('name', ''))
            units = []
            rows = []
            for seq, item in enumerate(group.get('rows', [])):
                src = str(item.get('source', ''))
                tgt = str(item.get('target', src))
                section = str(item.get('section', ''))
                key = str(item.get('key', ''))
                off = int(item.get('offset', 0))
                slot = int(item.get('slot', max(1, len(src)+1)))
                uid = f'eur-k7p2-{idx:04d}-{seq:03d}'
                role = str(item.get('kind', 'rótulo K7P2'))
                rows.append({
                    'id': uid, 'source': src, 'target': tgt,
                    'source_ph': [], 'target_ph': [],
                    'segment_state': 'translated' if tgt != src else 'final',
                })
                units.append(TextUnit(
                    uid, idx, -1, name, seq, 0, 0, 0, [ord(ch) for ch in src],
                    src, 'verified', '', f'k7p2-eur:{section}; key={key}; {role}', None,
                    max(1, slot-1), f'D_EU/DIR_E.AFS#{idx}', off, slot, 'nul'
                ))
            if not units:
                continue
            changed = sum(1 for r in rows if r['target'] != r['source'])
            label = f'K7P2 EUR · AFS #{idx:04d} · {name} · {len(units)} rótulos · ES {changed}/{len(units)}'
            blocks.append(SimpleNamespace(
                id=f'EUR_K7P2_{idx:04d}', jmb_index=idx, dic_index=-1,
                name=name, sentence_num=len(units), char_num=0, units=units,
                storage_kind='afs_k7p2_eur', storage_path=f'D_EU/DIR_E.AFS#{idx}',
                context='Mapa / rutas / localizadores K7P2', label=label, viewer_rows=rows,
            ))
            total += len(units)
        self.eur_view_blocks.extend(blocks)
        return len(blocks), total

    def _append_eur_scene_selector_view(self) -> tuple[int, int]:
        """Añade el selector de escenas EUR como bloque realmente editable.

        Los nombres 00-06 se escriben en las tablas francesas del SLES y las
        fechas/estaciones se recompilan en SceSel_F (sce_F.dat, PSMT8).
        """
        rows = []
        units = []
        for seq, spec in enumerate(EUR_SCENE_SELECTOR_ROWS):
            key = str(spec['key'])
            source = str(spec['source'])
            target = str(self.eur_scene_selector_targets.get(key, spec.get('target', source)))
            chapter = str(spec.get('chapter', ''))
            kind = str(spec.get('kind', 'selector'))
            uid = f'eur-scene-selector-{key}'
            if kind == 'chapter':
                binary_path = 'SLES_533.66 · tabla EN/FR/DE de capítulos'
                provenance = f'eur-scene-selector:chapter:{chapter}'
            else:
                binary_path = 'D_EU/DIR_E.AFS#3891:sce_F.dat / SceSel_F'
                provenance = f'eur-scene-selector:raster:{chapter or "label"}'
            rows.append({
                'id': uid, 'selector_key': key, 'source': source, 'target': target,
                'source_ph': [], 'target_ph': [],
                'segment_state': 'translated' if target and target != source else 'initial',
            })
            units.append(TextUnit(
                uid, 3891, 3891, 'sce_F.dat', seq, 0, 0, 0, [],
                source, 'verified', '', provenance, 1.0, 80, binary_path,
                0, 0, 'nul'
            ))
        block = SimpleNamespace(
            id='EUR_SCENE_SELECTOR', jmb_index=3891, dic_index=3891,
            name='sce_F.dat', sentence_num=len(units), char_num=0, units=units,
            storage_kind='eur_scene_selector',
            storage_path='SLES_533.66 + D_EU/DIR_E.AFS#3891:sce_F.dat / SceSel_F',
            context='Selector de escenas · capítulos y fechas',
            label=f'SELECTOR DE ESCENAS · capítulos + fechas · {len(units)} textos editables',
            viewer_rows=rows,
        )
        self.eur_view_blocks.append(block)
        return 1, len(units)

    def _append_eur_cinematic_view(self, eurp: Path) -> tuple[int, int]:
        """Añade al visor los DAR cinematográficos franceses ocultos en DIR_E.AFS."""
        catalog = scan_eur_cinematic_subtitles_from_iso(eurp, self.eur_cinematic_targets)
        blocks = []
        units_total = 0
        for rec in catalog:
            rows = []
            units = []
            idx = int(rec['afs_index'])
            for item in rec.get('rows', []):
                line = int(item['line'])
                src = str(item.get('source', ''))
                tgt = str(item.get('target', ''))
                rows.append({
                    'id': f'k7-cinema-{idx:04d}-{line:03d}',
                    'cinema_key': f'{idx}:{line}',
                    'source': src,
                    'target': tgt,
                    'source_ph': [],
                    'target_ph': [],
                    'segment_state': 'translated' if tgt and tgt != src else 'initial',
                })
                units.append(TextUnit(
                    f'k7-cinema-{idx:04d}-{line:03d}', idx, -1, str(rec['name']), line,
                    0, 0, 0, [], src, 'verified', '', 'eur-cinematic-dar', None,
                    127, f'D_EU/DIR_E.AFS#{idx}', 0, 0, 'nul'
                ))
            if not units:
                continue
            translated = sum(1 for r in rows if r['target'])
            label = (
                f'SUBTÍTULOS CINEMÁTICAS · AFS #{idx:04d} · {rec["name"]} · '
                f'{len(units)} líneas · ES {translated}/{len(units)}'
            )
            blocks.append(SimpleNamespace(
                id=f'EUR_CINEMA_{idx:04d}', jmb_index=idx, dic_index=-1,
                name=str(rec['name']), sentence_num=len(units), char_num=0,
                units=units, storage_kind='afs_cinematic_da',
                storage_path=f'D_EU/DIR_E.AFS#{idx}', context='Cinemática / diálogo',
                label=label, viewer_rows=rows,
            ))
            units_total += len(units)
        self.eur_view_blocks.extend(blocks)
        return len(blocks), units_total

    def _eur_cinema_default_sidecar(self, eurp: Path) -> Path:
        return eurp.with_name(eurp.stem + '_cinematicas_es.json')

    def _bundled_eur_cinema_project(self) -> Path:
        """Proyecto ES-ES incluido con la aplicación.

        El sidecar junto a la ISO siempre tiene prioridad; este archivo sólo es el
        valor predeterminado para que las 1.625 líneas traducidas estén disponibles
        nada más seleccionar una ISO EUR. Guardar sigue escribiendo al lado de la
        ISO y nunca sobrescribe el proyecto incluido.
        """
        return editable_path('Killer7EUR_cinematicas_es.json')

    def _read_eur_cinematic_file(self, path: Path) -> dict[str, str]:
        data = json.loads(path.read_text(encoding='utf-8'))
        if data.get('format') != 'killer7-eur-cinematic-translations':
            raise K7Error('El JSON no es un proyecto de cinemáticas Killer7 EUR compatible.')
        if data.get('serial') not in (None, '', 'SLES_533.66'):
            raise K7Error(f'El JSON pertenece a otra edición: {data.get("serial")}.')
        raw = data.get('translations', {})
        if not isinstance(raw, dict):
            raise K7Error('El JSON de cinemáticas no contiene un objeto translations válido.')
        out = {}
        for key, value in raw.items():
            if not isinstance(key, str) or ':' not in key:
                continue
            out[key] = '' if value is None else str(value)

        # v1.7.7.155: wording update requested for two duplicated cinematic lines.
        # Apply only to the exact legacy bundled values so a deliberately customised
        # sidecar is never overwritten. 399/401 are duplicate resource variants.
        legacy_wording = {
            ('399:5', 'Me han elegido.'): 'He sido ELEGIDO',
            ('401:5', 'Me han elegido.'): 'He sido ELEGIDO',
            ('399:6', 'Joder. Hay más de 14.'): 'Mierda. Son mas de 14',
            ('401:6', 'Joder. Hay más de 14.'): 'Mierda. Son mas de 14',
        }
        for (key, old), new in legacy_wording.items():
            if out.get(key) == old:
                out[key] = new
        return out

    def _read_eur_scene_selector_file(self, path: Path) -> dict[str, str]:
        data = json.loads(path.read_text(encoding='utf-8'))
        out = eur_scene_selector_default_targets()
        raw = data.get('scene_selector', {})
        if raw is None:
            return out
        if not isinstance(raw, dict):
            raise K7Error('El JSON EUR contiene scene_selector inválido.')
        for key, value in raw.items():
            if key in out and value is not None:
                out[key] = str(value)
        return out

    def _write_eur_cinematic_file(self, path: Path) -> None:
        payload = {
            'format': 'killer7-eur-cinematic-translations',
            'version': 2,
            'serial': 'SLES_533.66',
            'source_iso': self.eur_iso_path.name if self.eur_iso_path else '',
            'translations': dict(sorted(self.eur_cinematic_targets.items())),
            'scene_selector': dict(sorted(self.eur_scene_selector_targets.items())),
        }
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')

    def save_eur_cinematic_translations(self):
        if not self.eur_view_mode or not self.eur_iso_path:
            return False
        if not self.commit():
            return False
        path = self.eur_cinematic_project_path or self._eur_cinema_default_sidecar(self.eur_iso_path)
        try:
            self._write_eur_cinematic_file(path)
        except Exception as exc:
            messagebox.showerror('Guardar proyecto EUR', str(exc), parent=self)
            return False
        self.eur_cinematic_project_path = path
        self.dirty = False
        messagebox.showinfo(
            'Proyecto EUR',
            f'Proyecto EUR guardado:\n{path}\n\n'
            f'{sum(1 for v in self.eur_cinematic_targets.values() if v)} líneas cinematográficas y '
            f'{len(self.eur_scene_selector_targets)} textos del selector guardados.',
            parent=self,
        )
        return True

    def load_eur_cinematic_translations(self):
        if not self.eur_view_mode or not self.eur_iso_path:
            return False
        if self.dirty and not self._confirm_discard():
            return False
        p = filedialog.askopenfilename(
            title='Cargar proyecto EUR',
            initialdir=str(self.eur_iso_path.parent),
            filetypes=[('Killer7 proyecto EUR JSON', '*.json'), ('Todos', '*.*')],
        )
        if not p:
            return False
        try:
            targets = self._read_eur_cinematic_file(Path(p))
            self.eur_cinematic_targets = targets
            self.eur_scene_selector_targets = self._read_eur_scene_selector_file(Path(p))
            self.eur_cinematic_project_path = Path(p)
            # Reconstruir sólo el catálogo/visor; la ISO permanece seleccionada.
            self.eur_view_blocks = []
            block_count, unit_count = self._build_eur_view_from_master()
            k7p2_blocks, k7p2_units = self._append_eur_k7p2_view()
            block_count += k7p2_blocks
            unit_count += k7p2_units
            selector_blocks, selector_units = self._append_eur_scene_selector_view()
            block_count += selector_blocks
            unit_count += selector_units
            cinema_blocks, cinema_units = self._append_eur_cinematic_view(self.eur_iso_path)
            block_count += cinema_blocks
            unit_count += cinema_units
            self._refresh_block_category_filter(load_first=False)
            vals = list(self.combo.cget('values'))
            self.dirty = False
            if vals:
                self.load_block(force=True)
            self.translation_status_var.set(
                f'Proyecto EUR cargado: {Path(p).name} · {selector_units} textos del selector · {cinema_units} líneas cinematográficas.'
            )
            return True
        except Exception as exc:
            messagebox.showerror('Cargar proyecto EUR', str(exc), parent=self)
            return False

    def _activate_eur_iso(self, p: str, serial: str) -> None:
        """Activa una ISO PAL/EUR sin pasar por el escáner D_US de la edición USA.

        El editor histórico sigue dependiendo del modelo USA y por eso se deshabilita
        aquí de forma explícita. La ISO EUR queda seleccionada como entrada directa de
        «Inyectar Textos», que trabaja sobre D_EU/DIR_E.AFS y SLES_533.66.
        """
        eurp = Path(p).resolve()
        # Validación temprana: si el botón Seleccionar ISO la acepta, sabemos ya que
        # contiene exactamente los dos recursos que necesita el inyector EUR.
        with ISO9660(eurp) as iso:
            afs = iso.find(['D_EU', 'DIR_E.AFS'])
            exe = iso.find(['SLES_533.66'])
            if afs.size <= 0 or exe.size <= 0:
                raise K7Error('La ISO EUR contiene entradas vacías para DIR_E.AFS o SLES_533.66.')

        if self.project:
            self.project.close()
        self.project = None
        self.eur_iso_path = eurp
        self.eur_view_mode = True
        self.eur_cinematic_targets = {}
        self.eur_scene_selector_targets = eur_scene_selector_default_targets()
        self.eur_cinematic_project_path = self._eur_cinema_default_sidecar(eurp)
        cinema_source = 'sin traducción cinematográfica cargada'
        if self.eur_cinematic_project_path.is_file():
            self.eur_cinematic_targets = self._read_eur_cinematic_file(self.eur_cinematic_project_path)
            self.eur_scene_selector_targets = self._read_eur_scene_selector_file(self.eur_cinematic_project_path)
            cinema_source = f'proyecto junto a la ISO: {self.eur_cinematic_project_path.name}'
        else:
            bundled_cinema = self._bundled_eur_cinema_project()
            if bundled_cinema.is_file():
                self.eur_cinematic_targets = self._read_eur_cinematic_file(bundled_cinema)
                self.eur_scene_selector_targets = self._read_eur_scene_selector_file(bundled_cinema)
                cinema_source = f'traducción ES-ES incluida: {bundled_cinema.name}'
        self.block = None
        self.rows = []
        self.current = -1
        self.dirty = False

        block_count, unit_count = self._build_eur_view_from_master()
        k7p2_blocks, k7p2_units = self._append_eur_k7p2_view()
        block_count += k7p2_blocks
        unit_count += k7p2_units
        selector_blocks, selector_units = self._append_eur_scene_selector_view()
        block_count += selector_blocks
        unit_count += selector_units
        cinema_blocks, cinema_units = self._append_eur_cinematic_view(eurp)
        block_count += cinema_blocks
        unit_count += cinema_units
        self._set_enabled(False)
        self.combo.config(state='readonly')
        self.load_block_button.config(state=tk.NORMAL)
        self.inject_texts_button.config(state=tk.NORMAL)
        self.save_project_button.config(state=tk.NORMAL)
        self.image_scan_button.config(state=tk.NORMAL, text='Gráficos franceses…')
        self._refresh_block_category_filter(load_first=False)
        vals = list(self.combo.cget('values'))
        self.source_text_frame.config(text='Inglés detectado / referencia — solo lectura · inyección sólo francés')
        self.target_text_frame.config(text='Español · editable en SELECTOR DE ESCENAS y SUBTÍTULOS CINEMÁTICAS')
        self.iso_label.config(
            text=f'{eurp.name} · {serial} · MODO EUR · {block_count} bloques · {unit_count} textos visibles'
        )
        cinema_loaded = sum(1 for v in self.eur_cinematic_targets.values() if v)
        self.translation_status_var.set(
            f'Modo EUR: {unit_count} textos visibles · Cinemáticas ES cargadas: {cinema_loaded}/1625 · {cinema_source}.'
        )
        self.info.set(
            'ISO europea cargada. El inglés se usa como fuente de detección/referencia y el inyector modifica únicamente la rama francesa. El visor incluye el selector de escenas (capítulos + fechas), los 2.565 rótulos K7P2, las 1.625 líneas de cinemáticas ES y un localizador de 230 gráficos con texto francés. '
            'Puedes editarlas y pulsar «Guardar Proyecto» para conservar los cambios en el proyecto interno y dejar trazabilidad en CAMBIOS_PROYECTO.log (máx. 127 códigos por línea).'
        )
        if vals:
            self.load_block(force=True)
        self._reset_project_save_snapshot()
        try:
            self._load_text_images_from_iso(clear_overrides=True)
        except Exception as exc:
            self.text_images_status_var.set(f'No se pudieron cargar las texturas: {exc}')

    def open_iso(self):
        if (self.project or self.eur_view_mode) and not self._confirm_discard():
            return
        p = filedialog.askopenfilename(
            title='Seleccionar ISO de Killer7 PS2 · USA o EUR',
            filetypes=[('ISO de PlayStation 2', '*.iso'), ('Todos', '*.*')],
        )
        if not p:
            return
        launcher_loading = self.launcher_frame is not None
        if launcher_loading:
            self._set_launcher_loading(True)
        try:
            # Detectar la edición por serial o, si SYSTEM.CNF fue modificado por
            # un mod/rebuilder, por la estructura característica de Killer7. No se
            # exige que la ISO coincida byte a byte con el dump original.
            with ISO9660(p) as probe:
                ident = identify_killer7_iso(probe)

            if ident.get('edition') == 'EUR':
                shown_serial = EUR_SUPPORTED_SERIAL
                self._activate_eur_iso(p, shown_serial)
                if ident.get('inferred'):
                    reported = ident.get('reported_serial') or 'no disponible'
                    self.iso_label.config(text=self.iso_label.cget('text') + ' · ISO MODIFICADA COMPATIBLE')
                    self.translation_status_var.set(
                        f'ISO EUR modificada aceptada por estructura compatible · '
                        f'SYSTEM.CNF: {reported} · base detectada: {EUR_SUPPORTED_SERIAL}.'
                    )
                return

            if ident.get('edition') != 'USA':
                reported = ident.get('reported_serial') or 'desconocido'
                raise K7Error(
                    'No se ha podido identificar esta imagen como Killer7 compatible.\n\n'
                    f'Serial de SYSTEM.CNF: {reported}.\n'
                    'Para EUR deben existir D_EU/DIR_E.AFS y SLES_533.66; '
                    'para USA, D_US/DIR.AFS y SLUS_211.54.'
                )

            # Ruta estable USA. También admite una ISO modificada si conserva
            # D_US/DIR.AFS y SLUS_211.54 aunque SYSTEM.CNF haya cambiado.
            self.eur_iso_path = None
            self.eur_view_mode = False
            self.eur_view_blocks = []
            self._clear_text_images_tab(clear_overrides=True)
            self.eur_cinematic_targets = {}
            self.eur_cinematic_project_path = None
            self.source_text_frame.config(text='Original inglés — solo lectura')
            self.target_text_frame.config(text='Traducción (target)')
            if self.project:
                self.project.close()
            self.source_catalog = load_source_catalog(self.catalog_path)
            self.project = Killer7Project(p, self.source_catalog)
            self.master_root = build_project_xliff(
                self.project.all_blocks, self.project.serial, self.project.iso_path.name
            )
            loaded = self._merge_bundled_translation()
            count = sum(len(b.units) for b in self.project.all_blocks)
            self.iso_label.config(
                text=f'{Path(p).name} · {self.project.serial or "serial desconocido"} · '
                     f'{len(self.project.all_blocks)} bloques/recursos · {count} unidades'
            )
            if getattr(self.project, 'serial_inferred', False):
                reported = getattr(self.project, 'reported_serial', '') or 'no disponible'
                self.iso_label.config(text=self.iso_label.cget('text') + ' · ISO MODIFICADA COMPATIBLE')
                self.translation_status_var.set(
                    f'XLIFF incluido: {loaded} traducciones · ISO USA modificada aceptada por estructura · '
                    f'SYSTEM.CNF: {reported} · base: {SUPPORTED_SERIAL}.'
                )
            else:
                self.translation_status_var.set(
                    f'XLIFF incluido cargado: {loaded} traducciones · la ISO original está en solo lectura.'
                )
            self._set_enabled(bool(self.project.all_blocks))
            self._refresh_block_category_filter(load_first=False)
            vals = list(self.combo.cget('values'))
            self.image_scan_button.config(text='Escanear imágenes…')
            self.info.set(
                'ISO USA cargada. Elige un bloque o navega por las unidades; la ruta estable permanece separada.'
            )
            self.dirty = False
            if vals:
                self.load_block(force=True)
            self._reset_project_save_snapshot()
        except Exception as exc:
            self.project = None
            self.eur_iso_path = None
            self.eur_view_mode = False
            self.eur_view_blocks = []
            self._clear_text_images_tab(clear_overrides=True)
            self.eur_cinematic_targets = {}
            self.eur_cinematic_project_path = None
            self.master_root = None
            self._set_enabled(False)
            messagebox.showerror('Seleccionar ISO', str(exc), parent=self)
        finally:
            if launcher_loading:
                self._set_launcher_loading(False)

    def _merge_bundled_translation(self) -> int:
        """Mezcla los targets del maestro incluido sobre un XLIFF fresco de la ISO elegida.

        De este modo las notas de identidad/estructura proceden siempre de la ISO seleccionada,
        mientras que la traducción incluida se usa sólo como contenido editable.
        """
        if self.master_root is None:
            return 0
        bundled = editable_path('resources', 'master', 'Killer7_SLUS-21154_master_ES_started.xlf')
        if not bundled.exists():
            return 0
        parsed_old = parse_project_xliff(bundled)
        old_by_id = {}
        for pf in parsed_old['files']:
            for unit in pf['units']:
                old_by_id[unit['id']] = unit
        parsed_new = parse_project_xliff(self.master_root)
        loaded = 0
        skipped = 0
        for pf in parsed_new['files']:
            for unit in pf['units']:
                old = old_by_id.get(unit['id'])
                if not old:
                    continue
                target_text = old.get('target', '') or ''
                source_old = old.get('source', '') or ''
                translated = old.get('segment_state') == 'translated' or (target_text and target_text != source_old)
                if not translated:
                    continue
                try:
                    tgt = unit['xml_segment'].find(NS + 'target')
                    set_target_text(tgt, target_text, unit['source_ph'])
                    unit['xml_segment'].set('state', 'translated')
                    loaded += 1
                except Exception:
                    skipped += 1
        if skipped:
            self.after(0, lambda: messagebox.showwarning(
                'XLIFF incluido',
                f'Se cargaron {loaded} traducciones; {skipped} se omitieron porque sus controles ya no '
                'coinciden con la estructura detectada en la ISO.', parent=self
            ))
        return loaded

    def _confirm_discard(self) -> bool:
        if self.text_image_overrides:
            if not messagebox.askyesno(
                'Reemplazos de imágenes pendientes',
                f'Hay {len(self.text_image_overrides)} reemplazo(s) PNG pendientes en «Texto Imágenes».\n\n'
                'Si continúas sin crear una ISO, esos reemplazos se descartarán.\n\n'
                '¿Descartarlos y continuar?',
                parent=self,
            ):
                return False
        if not self.dirty:
            return True
        msg = ('Hay cambios de texto sin guardar.\n\n'
               '¿Quieres guardarlos en el proyecto antes de continuar?')
        ans = messagebox.askyesnocancel('Cambios sin guardar', msg, parent=self)
        if ans is None:
            return False
        if ans:
            return bool(self.save_project())
        return True

    def load_block(self, force: bool = False):
        if self.master_root is None:
            return
        if not self.project and not self.eur_view_mode:
            return
        if not force:
            self.commit()
        label = self.block_var.get()
        candidates = self._blocks_for_active_category()
        block = next((b for b in candidates if b.label == label), None)
        if not block:
            return
        self.block = block
        self._refresh_rows()
        self._populate()
        if block.storage_kind == 'elf_strings':
            self.file_label.config(text=f'{block.context} · {SUPPORTED_SERIAL} · menú principal · {block.id}')
        elif block.storage_kind == 'iso_ascii':
            self.file_label.config(text=f'{block.context} · {block.storage_path} · DIRECTO · {block.id}')
        elif block.storage_kind == 'afs_graphic_ref':
            self.file_label.config(text=f'{block.context} · {block.storage_path} · gráfico DIC · {block.id}')
        elif block.storage_kind == 'afs_k7p2':
            self.file_label.config(text=f'{block.context} · {block.storage_path} · K7P2 + DAR espejo · {block.id}')
        elif block.storage_kind == 'afs_k7p2_eur':
            self.file_label.config(text=f'{block.context} · {block.storage_path} · K7P2 EUR + MapFontF ES · {block.id}')
        elif block.storage_kind == 'afs_da':
            self.file_label.config(text=f'{block.context} · {block.storage_path} · subtítulos DAR/DIC · {block.id}')
        elif block.storage_kind == 'afs_cinematic_da':
            self.file_label.config(text=f'{block.context} · {block.storage_path} · SUBTÍTULOS CINEMÁTICAS · {block.id}')
        else:
            self.file_label.config(text=f'{block.context} · AFS #{block.jmb_index} + DIC #{block.dic_index} · {block.id}')
        if self.eur_view_mode:
            self.file_label.config(text=f'{block.context} · EUR/FR · {block.storage_kind} · {block.storage_path}')
        policy = block_format_policy(block)
        self.format_policy_var.set(
            f"Formato: {policy['name']} · Límite: {policy['limit']} · {policy['rule']}"
        )
        self.prev.config(state=tk.NORMAL)
        self.next.config(state=tk.NORMAL)

    def _refresh_rows(self):
        if self.master_root is None or self.block is None:
            self.rows = []
            return
        if self.eur_view_mode and hasattr(self.block, 'viewer_rows'):
            self.rows = list(self.block.viewer_rows)
            return
        parsed = parse_project_xliff(self.master_root)
        f = next((x for x in parsed['files'] if x['file_id'] == self.block.id), None)
        if not f:
            raise K7Error(f'El XLIFF maestro no contiene {self.block.id}.')
        self.rows = f['units']

    def _replace_master_file(self, new_file: ET.Element):
        assert self.master_root is not None
        fid = new_file.attrib.get('id', '')
        files = list(self.master_root.findall(NS + 'file'))
        for i, old in enumerate(files):
            if old.attrib.get('id') == fid:
                # ElementTree no expone index de forma cómoda; preservar orden manualmente.
                children = list(self.master_root)
                pos = children.index(old)
                self.master_root.remove(old)
                self.master_root.insert(pos, deepcopy(new_file))
                return
        self.master_root.append(deepcopy(new_file))

    # ---------- Rows / editor ----------
    def _status_for(self, row, unit):
        if row['source'].startswith('⟦SPECIAL RESOURCE'):
            return 'recurso especial'
        if row['source'].startswith('⟦SOURCE PENDING'):
            return 'original pendiente'
        if row['target'] and row['target'] != row['source']:
            return 'traducido'
        return 'sin traducir'

    def _populate(self):
        for x in self.tree.get_children():
            self.tree.delete(x)
        for i, (row, u) in enumerate(zip(self.rows, self.block.units), 1):
            src = row['source']
            preview = (u.source_candidate if src.startswith('⟦SOURCE PENDING') and u.source_candidate else src)
            if self.eur_view_mode and row.get('target'):
                preview = row['target']
            preview = preview.replace('\n', ' ')[:120]
            self.tree.insert('', tk.END, iid=str(i-1), values=(i, u.sentence, u.jimaku, preview, self._status_for(row, u)))
        if self.rows:
            self.tree.selection_set('0')
            self.tree.focus('0')
            self.tree.see('0')
            self.show(0)
        else:
            self.current = -1

    def on_select(self, _event=None):
        sel = self.tree.selection()
        if not sel:
            return
        idx = int(sel[0])
        if idx != self.current:
            if not self.commit():
                self.tree.selection_set(str(self.current))
                return
            self.show(idx)

    def _refresh_current_preview(self):
        if self.current >= 0 and self.rows and self.block is not None:
            self.show(self.current)

    @staticmethod
    def _wrap_preview_text(draw, text: str, font, max_width: int) -> list[str]:
        """Ajusta texto por anchura de píxel para la vista segura DA."""
        lines: list[str] = []
        for paragraph in (text or '').splitlines() or ['']:
            words = paragraph.split(' ')
            cur = ''
            for word in words:
                trial = word if not cur else cur + ' ' + word
                box = draw.textbbox((0, 0), trial, font=font)
                if cur and box[2] - box[0] > max_width:
                    lines.append(cur)
                    cur = word
                else:
                    cur = trial
            lines.append(cur)
        return lines or ['']

    def _render_da_safe_preview(self, row, unit):
        """Vista legible de subtítulos DA sin interpretar el atlas PS2.

        El decodificador gráfico DA todavía no reproduce de forma fiable la
        disposición que usa el GS de PS2. Mostrar esa imagen como si fuese una
        previsualización fiel resultaba engañoso. Esta vista usa exclusivamente
        la transcripción verificada/candidata y no toca datos del juego.
        """
        if ImageTk is None:
            return None, 'Vista textual DA no disponible (Pillow no cargado).'
        source = row.get('source', '')
        pending = source.startswith('⟦SOURCE PENDING')
        if pending and unit.source_candidate:
            title = 'CANDIDATO — NO VERIFICADO'
            body = unit.source_candidate
        elif pending:
            title = 'ORIGINAL TODAVÍA SIN TRANSCRIBIR'
            body = 'La vista gráfica DA se ha desactivado por defecto porque el atlas PS2 aún no se decodifica con fidelidad.'
        else:
            title = 'ORIGINAL VERIFICADO'
            body = source

        width = 560
        pad = 12
        try:
            title_font = ImageFont.load_default(size=14)
            body_font = ImageFont.load_default(size=21)
        except TypeError:
            title_font = ImageFont.load_default()
            body_font = title_font
        probe = Image.new('L', (width, 32), 0)
        draw = ImageDraw.Draw(probe)
        wrapped = self._wrap_preview_text(draw, body, body_font, width - pad * 2)
        title_box = draw.textbbox((0, 0), title, font=title_font)
        title_h = max(14, title_box[3] - title_box[1])
        body_boxes = [draw.textbbox((0, 0), line or ' ', font=body_font) for line in wrapped]
        line_h = max([b[3] - b[1] for b in body_boxes] + [20]) + 5
        height = pad + title_h + 10 + line_h * len(wrapped) + pad
        im = Image.new('L', (width, max(64, height)), 0)
        draw = ImageDraw.Draw(im)
        draw.text((pad, pad), title, fill=175, font=title_font)
        y = pad + title_h + 10
        for line in wrapped:
            draw.text((pad, y), line, fill=255, font=body_font)
            y += line_h
        return im, ''

    def show(self, idx: int):
        if not (0 <= idx < len(self.rows)):
            return
        self.current = idx
        row = self.rows[idx]
        u = self.block.units[idx]

        self.src_text.config(state=tk.NORMAL)
        self.src_text.delete('1.0', tk.END)
        if row['source'].startswith('⟦SOURCE PENDING') and u.source_candidate:
            self.src_text.insert('1.0', f'[CANDIDATO — no verificado]\n{u.source_candidate}\n\n{row["source"]}')
        else:
            self.src_text.insert('1.0', row['source'])
        self.src_text.config(state=tk.DISABLED)

        is_special = row['source'].startswith('⟦SPECIAL RESOURCE')
        is_graphic_ref = self.block.storage_kind == 'afs_graphic_ref'
        is_internal_key = u.source_provenance.startswith('internal-key')
        is_k7p2_proper_name = u.source_provenance.startswith('k7p2-proper-name')
        self.tgt_text.config(state=tk.NORMAL)
        self.tgt_text.delete('1.0', tk.END)
        if is_special:
            self.tgt_text.insert('1.0', '[Recurso especial: se conserva exactamente como en la ISO]')
            self.tgt_text.config(state=tk.DISABLED)
        elif is_internal_key or is_k7p2_proper_name:
            self.tgt_text.insert('1.0', row['target'] or row['source'])
            self.tgt_text.config(state=tk.DISABLED)
        elif is_graphic_ref:
            self.tgt_text.insert('1.0', row['target'])
        else:
            self.tgt_text.insert('1.0', row['target'])

        if self.eur_view_mode:
            if self.block.storage_kind in ('afs_cinematic_da', 'eur_scene_selector'):
                self.tgt_text.config(state=tk.NORMAL)
            else:
                self.tgt_text.config(state=tk.DISABLED)

        try:
            if self.eur_view_mode:
                self.preview_photo = None
                if self.block.storage_kind == 'afs_cinematic_da':
                    self.preview.config(image='', text='Cinemática EUR · target editable · glifos se recompilan automáticamente')
                elif self.block.storage_kind == 'eur_scene_selector':
                    self.preview.config(image='', text='Selector EUR · target editable · capítulos en SLES + fechas en SceSel_F PSMT8')
                else:
                    self.preview.config(image='', text='Visor EUR · español integrado · sólo lectura')
            elif ImageTk and self.project and self.block.storage_kind == 'afs_graphic_ref':
                im = self.project.decode_atlas(self.block)
                # Las texturas se muestran completas: varias contienen más de una frase.
                maxw, maxh = 560, 250
                ratio = min(maxw / max(1, im.width), maxh / max(1, im.height), 1.0)
                if ratio != 1.0:
                    im = im.resize((max(1, int(im.width*ratio)), max(1, int(im.height*ratio))))
                self.preview_photo = ImageTk.PhotoImage(im)
                self.preview.config(image=self.preview_photo, text='')
            elif ImageTk and self.project and self.block.storage_kind == 'afs_da':
                if self.raw_da_preview_var.get():
                    im = self.project.render_unit(self.block, u, scale=2)
                    maxw = 560
                    if im.width > maxw:
                        im = im.resize((maxw, max(1, int(im.height * maxw / im.width))))
                    self.preview_photo = ImageTk.PhotoImage(im)
                    self.preview.config(image=self.preview_photo, text='Vista gráfica DA · decodificación GS PSMCT16→PSMT4', compound=tk.TOP)
                else:
                    im, msg = self._render_da_safe_preview(row, u)
                    if im is not None:
                        self.preview_photo = ImageTk.PhotoImage(im)
                        self.preview.config(image=self.preview_photo, text='')
                    else:
                        self.preview_photo = None
                        self.preview.config(image='', text=msg)
            elif ImageTk and self.project and self.block.storage_kind == 'afs_pair':
                im = self.project.render_unit(self.block, u, scale=2)
                maxw = 560
                if im.width > maxw:
                    im = im.resize((maxw, max(1, int(im.height * maxw / im.width))))
                self.preview_photo = ImageTk.PhotoImage(im)
                self.preview.config(image=self.preview_photo, text='')
            elif self.block.storage_kind == 'elf_strings':
                self.preview_photo = None
                current = (' · ISO actual: ' + u.source_candidate) if u.source_candidate else ''
                self.preview.config(image='', text='Menú principal · renderizado por titlefont.png' + current)
            elif self.block.storage_kind == 'iso_ascii':
                self.preview_photo = None
                pad = 'relleno con espacios' if u.binary_pad == 'space' else 'slot NUL'
                self.preview.config(
                    image='',
                    text=f'{u.binary_path} + 0x{u.binary_offset:X} · {u.binary_slot} bytes · {pad} · ASCII directo'
                )
            elif self.block.storage_kind == 'afs_k7p2':
                self.preview_photo = None
                self.preview.config(
                    image='',
                    text=(f'{u.binary_path} + 0x{u.binary_offset:X} · {u.binary_slot} bytes · '
                          f'K7P2 ASCII · espejo DAR AFS #{self.block.dic_index:04d}')
                )
            elif self.block.storage_kind == 'afs_k7p2_eur':
                self.preview_photo = None
                self.preview.config(
                    image='',
                    text=(f'{u.binary_path} + 0x{u.binary_offset:X} · {u.binary_slot} bytes · '
                          'K7P2 EUR · MapFontF español · sólo lectura')
                )
        except Exception as exc:
            self.preview.config(image='', text=f'Vista no disponible: {exc}')

        state = u.source_state
        if u.source_candidate and state == 'pending':
            state += ' · hay candidato'
        self.source_state_var.set(f'Original: {state}' + (f' · {u.source_provenance}' if u.source_provenance else ''))
        self.progress.set(f'{idx+1} / {len(self.rows)}')
        self.metrics()

    def commit(self) -> bool:
        if self.eur_view_mode:
            if self.current < 0 or not self.rows or self.block is None:
                return True
            if self.block.storage_kind not in ('afs_cinematic_da', 'eur_scene_selector'):
                return True
            row = self.rows[self.current]
            txt = self.tgt_text.get('1.0', 'end-1c')
            if self.block.storage_kind == 'afs_cinematic_da':
                # Cada carácter visible/espacio/salto ocupa un s16; {ctl:FFxx} ocupa uno.
                code_count = len(CONTROL_RE.sub('§', txt))
                if code_count > 127:
                    messagebox.showwarning(
                        'Cinemática demasiado larga',
                        f'Esta línea necesita {code_count} códigos; el motor admite como máximo 127.',
                        parent=self,
                    )
                    return False
                key = row.get('cinema_key') or f'{self.block.jmb_index}:{self.current}'
                target_map = self.eur_cinematic_targets
            else:
                if len(txt) > 80:
                    messagebox.showwarning(
                        'Texto del selector demasiado largo',
                        'El selector admite como máximo 80 caracteres por unidad en el editor.',
                        parent=self,
                    )
                    return False
                key = row.get('selector_key')
                if not key:
                    return True
                target_map = self.eur_scene_selector_targets
            old = row.get('target', '')
            if txt == old:
                return True
            target_map[str(key)] = txt
            row['target'] = txt
            row['segment_state'] = 'translated' if txt and txt != row.get('source', '') else 'initial'
            if self.block.storage_kind == 'eur_scene_selector' and str(key).startswith('chapter_'):
                self._refresh_individual_chapter_title_records()
            self.dirty = True
            self.tree.set(str(self.current), 'preview', (txt or row.get('source', '')).replace('\n', ' ')[:120])
            self.tree.set(str(self.current), 'state', self._status_for(row, self.block.units[self.current]))
            self.metrics()
            return True
        if self.current < 0 or not self.rows:
            return True
        row = self.rows[self.current]
        u = self.block.units[self.current]
        if row['source'].startswith('⟦SPECIAL RESOURCE') or u.source_provenance.startswith('internal-key'):
            return True
        txt = self.tgt_text.get('1.0', 'end-1c')
        seg = row['xml_segment']
        tgt = seg.find(NS + 'target')
        old = extract_text(tgt)
        if txt == old:
            return True
        try:
            set_target_text(tgt, txt, row['source_ph'])
        except Exception as exc:
            messagebox.showwarning('Controles protegidos', str(exc), parent=self)
            return False
        seg.set('state', 'translated' if txt and txt != row['source'] else 'initial')
        row['target'] = txt
        row['target_ph'] = text_controls(txt)
        self.dirty = True
        self.tree.set(str(self.current), 'state', self._status_for(row, self.block.units[self.current]))
        self.metrics()
        return True

    def metrics(self):
        if self.current < 0 or not self.rows:
            return
        if self.eur_view_mode:
            row = self.rows[self.current]
            u = self.block.units[self.current]
            if self.block.storage_kind == 'afs_cinematic_da':
                target = self.tgt_text.get('1.0', 'end-1c')
                codes = len(CONTROL_RE.sub('§', target))
                state = 'OK' if codes <= 127 else 'SUPERA 127'
                self.info.set(
                    f'Cinemática editable · línea {self.current+1}/{len(self.rows)} · '
                    f'{codes}/127 códigos · {state} · AFS #{self.block.jmb_index:04d}. '
                    'Los glifos se obtienen del EUR, se sintetizan o se rasterizan sólo si faltan.'
                )
            elif self.block.storage_kind == 'eur_scene_selector':
                target = self.tgt_text.get('1.0', 'end-1c')
                key = row.get('selector_key', '')
                self.info.set(
                    f'Selector de escenas editable · {key} · texto {self.current+1}/{len(self.rows)} · '
                    f'{len(target)} caracteres. Capítulos: SLES_533.66; fechas/rótulos: sce_F.dat / SceSel_F 8bpp.'
                )
            else:
                target = row.get('target', '') or ''
                self.info.set(
                    f'Visor EUR · {self.block.storage_kind} · texto {self.current+1}/{len(self.rows)} · '
                    f'original {len(row.get("source", ""))} caracteres · español {len(target)} caracteres · '
                    f'{u.binary_path or self.block.storage_path}'
                )
            return
        if self.block and self.block.storage_kind == 'afs_graphic_ref':
            u = self.block.units[self.current]
            txt = self.tgt_text.get('1.0', 'end-1c')
            self.info.set(
                f'{u.stable_id} · región gráfica fija · AFS DIC #{self.block.dic_index:04d} · '
                f'target: {len(txt)} caracteres · preflight gráfico obligatorio'
            )
            return
        txt = self.tgt_text.get('1.0', 'end-1c')
        n = visible_target_length(txt)
        u = self.block.units[self.current]
        limit = u.max_codes
        status = 'compatible ✓' if n <= limit else 'demasiado largo ✗'
        expected_controls = self.rows[self.current]['source_ph']
        got_controls = text_controls(txt)
        ctl = 'controles ✓' if expected_controls == got_controls else 'controles modificados ✗'
        self.info.set(
            f'{u.stable_id} · original: {len(u.codes)} códigos · target: {n}/{limit} · {status} · {ctl} · '
            f'wait={u.wait} · disp={u.disp_time}'
        )

    def step(self, delta: int):
        if not self.rows:
            return
        if not self.commit():
            return
        i = max(0, min(len(self.rows)-1, self.current + delta))
        self.tree.selection_set(str(i))
        self.tree.focus(str(i))
        self.tree.see(str(i))
        self.show(i)


    # ---------- Escáner visual de imágenes ----------
    def open_image_scanner(self):
        if not self.project and not (self.eur_view_mode and self.eur_iso_path):
            messagebox.showinfo(
                'Escáner de imágenes',
                'Selecciona primero una ISO de Killer7.',
                parent=self,
            )
            return
        self.image_scan_mode = 'eur_fr' if (self.eur_view_mode and self.eur_iso_path) else 'usa'
        if ImageTk is None:
            messagebox.showerror(
                'Escáner de imágenes',
                'Pillow/ImageTk no está disponible en este runtime.',
                parent=self,
            )
            return
        try:
            if self.image_scan_window is not None and self.image_scan_window.winfo_exists():
                self.image_scan_window.deiconify()
                self.image_scan_window.lift()
                return
        except Exception:
            self.image_scan_window = None

        win = tk.Toplevel(self)
        self.image_scan_window = win
        win.title('Killer7 · Gráficos franceses localizados' if self.image_scan_mode == 'eur_fr' else 'Killer7 · Escáner visual de imágenes DIC')
        win.geometry('1320x820')
        win.minsize(980, 620)
        win.transient(self)

        top = ttk.Frame(win, padding=(10, 10, 10, 6))
        top.pack(fill=tk.X)
        ttk.Label(top, text='Buscar:').pack(side=tk.LEFT)
        self.image_scan_filter_var = tk.StringVar()
        search = ttk.Entry(top, textvariable=self.image_scan_filter_var, width=28)
        search.pack(side=tk.LEFT, padx=(6, 12))

        ttk.Label(top, text='Marca:').pack(side=tk.LEFT)
        self.image_scan_state_var = tk.StringVar(value='Todas')
        state_values = (
            ('Todas', 'PENDIENTE', 'REVISAR', 'YA_CUBIERTO', 'TRADUCIDO')
            if self.image_scan_mode == 'eur_fr'
            else ('Todas', 'Tiene texto', 'Sin texto', 'Revisar', 'Sin marcar')
        )
        state_box = ttk.Combobox(
            top, textvariable=self.image_scan_state_var, state='readonly', width=14,
            values=state_values,
        )
        state_box.pack(side=tk.LEFT, padx=(6, 12))

        self.image_scan_include_da_var = tk.BooleanVar(value=False)
        include_da = ttk.Checkbutton(
            top, text=('Catálogo FR integrado' if self.image_scan_mode == 'eur_fr' else 'Incluir atlas de subtítulos'),
            variable=self.image_scan_include_da_var,
            command=lambda: self._image_scanner_scan(True),
        )
        include_da.pack(side=tk.LEFT)
        if self.image_scan_mode == 'eur_fr':
            include_da.config(state=tk.DISABLED)
        ttk.Button(
            top, text='Reescanear', command=lambda: self._image_scanner_scan(True)
        ).pack(side=tk.LEFT, padx=(10, 0))

        self.image_scan_status_var = tk.StringVar(value='Preparando escáner…')
        ttk.Label(top, textvariable=self.image_scan_status_var, anchor='e').pack(
            side=tk.RIGHT, fill=tk.X, expand=True, padx=(12, 0)
        )

        paned = ttk.Panedwindow(win, orient=tk.HORIZONTAL)
        paned.pack(fill=tk.BOTH, expand=True, padx=10, pady=(0, 8))

        left = ttk.Frame(paned)
        right = ttk.Frame(paned)
        paned.add(left, weight=3)
        paned.add(right, weight=5)

        tree_frame = ttk.Frame(left)
        tree_frame.pack(fill=tk.BOTH, expand=True)
        cols = ('afs', 'name', 'dims', 'hint', 'mark')
        tree = ttk.Treeview(tree_frame, columns=cols, show='headings', selectmode='browse')
        self.image_scan_tree = tree
        headings = {
            'afs': 'AFS', 'name': ('Recurso / textura' if self.image_scan_mode == 'eur_fr' else 'Recurso'), 'dims': 'Dimensiones',
            'hint': ('Tipo' if self.image_scan_mode == 'eur_fr' else 'Pista'), 'mark': ('Estado' if self.image_scan_mode == 'eur_fr' else 'Marca'),
        }
        widths = {'afs': 55, 'name': 155, 'dims': 95, 'hint': 135, 'mark': 90}
        for col in cols:
            tree.heading(col, text=headings[col])
            tree.column(col, width=widths[col], minwidth=50, stretch=(col in ('name', 'hint')))
        yscroll = ttk.Scrollbar(tree_frame, orient=tk.VERTICAL, command=tree.yview)
        tree.configure(yscrollcommand=yscroll.set)
        tree.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        yscroll.pack(side=tk.RIGHT, fill=tk.Y)

        preview_box = ttk.LabelFrame(right, text='Vista previa', padding=8)
        preview_box.pack(fill=tk.BOTH, expand=True)
        self.image_scan_preview = ttk.Label(
            preview_box, text='Selecciona una textura.', anchor='center', justify=tk.CENTER
        )
        self.image_scan_preview.pack(fill=tk.BOTH, expand=True)

        self.image_scan_detail_var = tk.StringVar(value='')
        ttk.Label(
            right, textvariable=self.image_scan_detail_var, justify=tk.LEFT,
            anchor='w', wraplength=720,
        ).pack(fill=tk.X, pady=(8, 0))

        actions = ttk.Frame(win, padding=(10, 0, 10, 10))
        actions.pack(fill=tk.X)
        if self.image_scan_mode == 'eur_fr':
            ttk.Button(actions, text='Exportar PNG…', command=self._image_scanner_export_png).pack(side=tk.LEFT)
            ttk.Button(actions, text='Copiar ubicación', command=self._image_scanner_copy_location).pack(side=tk.LEFT, padx=(6, 0))
            ttk.Label(
                actions,
                text='Catálogo ligado a SLES_533.66 · sólo lectura · muestra la textura original francesa de tu ISO',
                anchor='e',
            ).pack(side=tk.RIGHT, fill=tk.X, expand=True)
        else:
            ttk.Button(
                actions, text='✓ Tiene texto',
                command=lambda: self._image_scanner_mark('Tiene texto'),
            ).pack(side=tk.LEFT)
            ttk.Button(
                actions, text='✗ Sin texto',
                command=lambda: self._image_scanner_mark('Sin texto'),
            ).pack(side=tk.LEFT, padx=(6, 0))
            ttk.Button(
                actions, text='? Revisar',
                command=lambda: self._image_scanner_mark('Revisar'),
            ).pack(side=tk.LEFT, padx=(6, 0))
            ttk.Button(
                actions, text='Limpiar marca',
                command=lambda: self._image_scanner_mark(''),
            ).pack(side=tk.LEFT, padx=(6, 0))
            ttk.Separator(actions, orient=tk.VERTICAL).pack(side=tk.LEFT, fill=tk.Y, padx=10)
            ttk.Button(actions, text='Exportar PNG…', command=self._image_scanner_export_png).pack(side=tk.LEFT)
            ttk.Button(
                actions, text='Exportar marcadas con texto…',
                command=self._image_scanner_export_marked,
            ).pack(side=tk.LEFT, padx=(6, 0))
            ttk.Button(
                actions, text='Guardar informe…', command=self._image_scanner_save_report
            ).pack(side=tk.RIGHT)
            ttk.Button(
                actions, text='Cargar informe…', command=self._image_scanner_load_report
            ).pack(side=tk.RIGHT, padx=(0, 6))

        tree.bind('<<TreeviewSelect>>', self._image_scanner_on_select)
        self.image_scan_filter_var.trace_add('write', lambda *_: self._image_scanner_apply_filter())
        self.image_scan_state_var.trace_add('write', lambda *_: self._image_scanner_apply_filter())
        win.protocol('WM_DELETE_WINDOW', self._image_scanner_close)
        search.focus_set()
        self._image_scanner_scan(True)

    def _image_scanner_close(self):
        try:
            if self.image_scan_window is not None:
                self.image_scan_window.destroy()
        finally:
            self.image_scan_window = None
            self.image_scan_photo = None
            self.image_scan_current = None

    def _eur_graphics_catalog_path(self) -> Path:
        return resource_path('Killer7EUR_GRAFICOS_FR.json')

    def _load_eur_graphics_catalog(self) -> list[dict]:
        path = self._eur_graphics_catalog_path()
        if not path.is_file():
            raise K7Error(f'Falta el catálogo de gráficos franceses: {path.name}')
        data = json.loads(path.read_text(encoding='utf-8'))
        if data.get('format') != 'killer7-eur-french-raster-graphics-catalog' or data.get('serial') != 'SLES_533.66':
            raise K7Error('El catálogo de gráficos franceses EUR no es compatible.')
        out = []
        for row in data.get('rows', []):
            idx = int(row['afs_index'])
            tex = str(row.get('texture_name', ''))
            afs_name = str(row.get('afs_name', ''))
            status = str(row.get('status', 'PENDIENTE'))
            category = str(row.get('category', 'gráfico'))
            off = int(row.get('texture_offset', 0))
            out.append({
                'id': f'eurfr:{idx:04d}:{off:08X}',
                'kind': 'eur_french_graphic',
                'afs_index': idx,
                'name': f'{afs_name} · {tex}',
                'resource_name': afs_name,
                'texture_name': tex,
                'entry_offset': int(row.get('entry_offset', 0)),
                'entry_size': int(row.get('entry_size', 0)),
                'texture_offset': off,
                'pixel_offset': int(row.get('pixel_offset', 0)),
                'width': int(row.get('width', 0)),
                'height': int(row.get('height', 0)),
                'bpp': int(row.get('bpp', 0)),
                'size': int(row.get('entry_size', 0)),
                'hint': category,
                'catalog_status': status,
                'notes': str(row.get('notes', '')),
                'path': f'D_EU/DIR_E.AFS#{idx:04d}:{afs_name} / {tex} @ +0x{off:X}',
            })
        return out

    def _decode_eur_graphic_resource(self, resource: dict):
        if not self.eur_iso_path:
            raise K7Error('No hay una ISO EUR activa.')
        with ISO9660(self.eur_iso_path) as iso:
            node = iso.find(['D_EU', 'DIR_E.AFS'])
            entry = iso.read(node, int(resource['entry_offset']), int(resource['entry_size']))
        off = int(resource.get('texture_offset', 0))
        if off < 0 or off >= len(entry):
            raise K7Error('Offset de textura fuera de la entrada AFS.')
        dic = entry[off:]
        bpp = int(resource.get('bpp', 0))
        if bpp == 4:
            return Killer7Project.decode_dic_texture_preview(dic)
        if bpp == 8:
            width = int(resource['width']); height = int(resource['height'])
            po = int(resource.get('pixel_offset', 0))
            size = width * height
            raw = dic[po:po+size]
            if len(raw) != size:
                raise K7Error('Payload 8bpp incompleto.')
            px = _unswizzle8(raw, width, height)
            im = Image.new('L', (width, height))
            im.putdata(px)
            return im
        raise K7Error(f'BPP gráfico no soportado: {bpp}.')

    def _image_scanner_scan(self, rescan: bool = False):
        if self.image_scan_window is None:
            return
        try:
            if self.image_scan_mode == 'eur_fr':
                self.image_scan_resources = self._load_eur_graphics_catalog()
                self.image_scan_resource_map = {r['id']: r for r in self.image_scan_resources}
                self._image_scanner_apply_filter()
                pending = sum(1 for r in self.image_scan_resources if r.get('catalog_status') == 'PENDIENTE')
                review = sum(1 for r in self.image_scan_resources if r.get('catalog_status') == 'REVISAR')
                self.image_scan_status_var.set(
                    f'{len(self.image_scan_resources)} gráficos FR localizados · {pending} pendientes · {review} por revisar'
                )
            else:
                if not self.project:
                    return
                include_da = bool(self.image_scan_include_da_var.get())
                self.image_scan_resources = self.project.scan_image_resources(include_da)
                self.image_scan_resource_map = {r['id']: r for r in self.image_scan_resources}
                self._image_scanner_apply_filter()
                known = sum(1 for r in self.image_scan_resources if r.get('hint') == 'Texto conocido')
                self.image_scan_status_var.set(
                    f'{len(self.image_scan_resources)} imágenes detectadas · {known} con texto ya conocido'
                )
        except Exception as exc:
            messagebox.showerror('Escáner de imágenes', str(exc), parent=self.image_scan_window)

    def _image_scanner_apply_filter(self):
        tree = getattr(self, 'image_scan_tree', None)
        if tree is None:
            return
        query = (self.image_scan_filter_var.get() if hasattr(self, 'image_scan_filter_var') else '').strip().lower()
        state = self.image_scan_state_var.get() if hasattr(self, 'image_scan_state_var') else 'Todas'
        current_id = self.image_scan_current.get('id') if self.image_scan_current else None
        for iid in tree.get_children():
            tree.delete(iid)
        shown = 0
        for row in self.image_scan_resources:
            mark = self.image_scan_marks.get(row['id'], '')
            catalog_status = row.get('catalog_status', '')
            haystack = ' '.join([
                row.get('name', ''), row.get('path', ''), row.get('hint', ''), row.get('notes', ''),
                str(row.get('afs_index', '')), mark, catalog_status,
            ]).lower()
            if query and query not in haystack:
                continue
            if self.image_scan_mode == 'eur_fr':
                if state != 'Todas':
                    if state == 'TRADUCIDO':
                        if not catalog_status.startswith('TRADUCIDO'):
                            continue
                    elif catalog_status != state:
                        continue
            else:
                if state == 'Sin marcar' and mark:
                    continue
                if state not in ('Todas', 'Sin marcar') and mark != state:
                    continue
            iid = row['id']
            tree.insert('', tk.END, iid=iid, values=(
                f"{row['afs_index']:04d}",
                row.get('name', ''),
                f"{row.get('width', '?')}×{row.get('height', '?')} · {row.get('bpp', '?')}bpp",
                row.get('hint', ''),
                catalog_status if self.image_scan_mode == 'eur_fr' else (mark or '—'),
            ))
            shown += 1
        if current_id and tree.exists(current_id):
            tree.selection_set(current_id)
            tree.see(current_id)
        if hasattr(self, 'image_scan_status_var'):
            if self.image_scan_mode == 'eur_fr':
                self.image_scan_status_var.set(f'{shown}/{len(self.image_scan_resources)} gráficos franceses visibles')
            else:
                marked = sum(1 for value in self.image_scan_marks.values() if value == 'Tiene texto')
                self.image_scan_status_var.set(
                    f'{shown}/{len(self.image_scan_resources)} visibles · {marked} marcadas con texto'
                )

    def _image_scanner_on_select(self, _event=None):
        tree = getattr(self, 'image_scan_tree', None)
        if tree is None or (not self.project and self.image_scan_mode != 'eur_fr'):
            return
        sel = tree.selection()
        if not sel:
            return
        resource = self.image_scan_resource_map.get(sel[0])
        if not resource:
            return
        self.image_scan_current = resource
        try:
            image = self._decode_eur_graphic_resource(resource) if self.image_scan_mode == 'eur_fr' else self.project.decode_image_resource(resource)
            if self.image_scan_mode == 'eur_fr' and image.mode == 'RGBA':
                # Tk puede mostrar RGBA, pero componer sobre negro reproduce mejor
                # cómo se perciben la mayoría de rótulos/transparencias del juego.
                preview = Image.new('RGBA', image.size, (0, 0, 0, 255))
                preview.alpha_composite(image)
                preview = preview.convert('RGB')
            else:
                preview = image.convert('L')
            max_w, max_h = 760, 590
            ratio = min(max_w / max(1, preview.width), max_h / max(1, preview.height))
            if ratio > 1.0:
                ratio = min(ratio, 4.0)
                resampling = getattr(Image, 'Resampling', Image)
                preview = preview.resize(
                    (max(1, int(preview.width * ratio)), max(1, int(preview.height * ratio))),
                    resampling.NEAREST,
                )
            elif ratio < 1.0:
                resampling = getattr(Image, 'Resampling', Image)
                preview = preview.resize(
                    (max(1, int(preview.width * ratio)), max(1, int(preview.height * ratio))),
                    resampling.LANCZOS,
                )
            self.image_scan_photo = ImageTk.PhotoImage(preview)
            self.image_scan_preview.config(image=self.image_scan_photo, text='')
            mark = self.image_scan_marks.get(resource['id'], '') or 'Sin marcar'
            self.image_scan_detail_var.set(
                f"{resource['path']}\n"
                f"{resource['width']}×{resource['height']} · {resource['bpp']}bpp · "
                f"{resource['size']:,} bytes · {resource['hint']} · {mark}"
            )
        except Exception as exc:
            self.image_scan_photo = None
            self.image_scan_preview.config(image='', text=f'No se pudo decodificar:\n{exc}')
            self.image_scan_detail_var.set(resource.get('path', ''))

    def _image_scanner_mark(self, value: str):
        if self.image_scan_mode == 'eur_fr':
            messagebox.showinfo('Gráficos franceses', 'Este catálogo ya está clasificado. Usa Buscar para localizar recurso, textura, categoría o índice AFS.', parent=self.image_scan_window)
            return
        if not self.image_scan_current:
            return
        rid = self.image_scan_current['id']
        if value:
            self.image_scan_marks[rid] = value
        else:
            self.image_scan_marks.pop(rid, None)
        self._image_scanner_apply_filter()
        tree = getattr(self, 'image_scan_tree', None)
        if tree is not None and tree.exists(rid):
            tree.selection_set(rid)
            tree.focus(rid)
            tree.see(rid)
        self._image_scanner_on_select()

    def _image_scanner_copy_location(self):
        if not self.image_scan_current:
            return
        r = self.image_scan_current
        text = (
            f"AFS #{int(r.get('afs_index', 0)):04d} · {r.get('resource_name', r.get('name',''))} · "
            f"{r.get('texture_name','')} · entrada +0x{int(r.get('entry_offset',0)):X} · "
            f"textura +0x{int(r.get('texture_offset',0)):X}"
        )
        self.clipboard_clear()
        self.clipboard_append(text)
        self.update_idletasks()
        self.image_scan_detail_var.set(self.image_scan_detail_var.get() + '\nUbicación copiada al portapapeles.')

    @staticmethod
    def _image_export_name(resource: dict) -> str:
        import re
        safe = re.sub(r'[^A-Za-z0-9._-]+', '_', resource.get('name', 'image')).strip('._') or 'image'
        suffix = '_atlas' if resource.get('kind') == 'da_atlas' else ''
        return f"AFS_{int(resource.get('afs_index', 0)):04d}_{safe}{suffix}.png"

    def _image_scanner_export_png(self):
        if (not self.project and self.image_scan_mode != 'eur_fr') or not self.image_scan_current:
            return
        resource = self.image_scan_current
        p = filedialog.asksaveasfilename(
            title='Exportar textura como PNG',
            defaultextension='.png',
            initialfile=self._image_export_name(resource),
            filetypes=[('PNG', '*.png'), ('Todos', '*.*')],
            parent=self.image_scan_window,
        )
        if not p:
            return
        try:
            (self._decode_eur_graphic_resource(resource) if self.image_scan_mode == 'eur_fr' else self.project.decode_image_resource(resource)).save(p)
            messagebox.showinfo('Escáner de imágenes', f'PNG exportado:\n{p}', parent=self.image_scan_window)
        except Exception as exc:
            messagebox.showerror('Escáner de imágenes', str(exc), parent=self.image_scan_window)

    def _image_scanner_export_marked(self):
        if self.image_scan_mode == 'eur_fr':
            messagebox.showinfo('Gráficos franceses', 'Selecciona una textura y usa «Exportar PNG…».', parent=self.image_scan_window)
            return
        if not self.project:
            return
        selected = [
            r for r in self.image_scan_resources
            if self.image_scan_marks.get(r['id']) == 'Tiene texto'
        ]
        if not selected:
            messagebox.showinfo(
                'Escáner de imágenes',
                'Todavía no has marcado ninguna imagen como «Tiene texto».',
                parent=self.image_scan_window,
            )
            return
        folder = filedialog.askdirectory(
            title='Carpeta para exportar imágenes con texto',
            parent=self.image_scan_window,
        )
        if not folder:
            return
        folder = Path(folder)
        failures = []
        for resource in selected:
            try:
                self.project.decode_image_resource(resource).save(
                    folder / self._image_export_name(resource)
                )
            except Exception as exc:
                failures.append(f"{resource['id']}: {exc}")
        if failures:
            messagebox.showwarning(
                'Escáner de imágenes',
                f'Se exportaron {len(selected) - len(failures)}/{len(selected)} imágenes.\n\n'
                + '\n'.join(failures[:8]),
                parent=self.image_scan_window,
            )
        else:
            messagebox.showinfo(
                'Escáner de imágenes',
                f'Se exportaron {len(selected)} imágenes:\n{folder}',
                parent=self.image_scan_window,
            )

    def _image_scanner_save_report(self):
        if self.image_scan_mode == 'eur_fr':
            messagebox.showinfo('Gráficos franceses', 'El catálogo integrado ya conserva las ubicaciones; no necesita informe manual.', parent=self.image_scan_window)
            return
        if not self.project:
            return
        p = filedialog.asksaveasfilename(
            title='Guardar informe del escáner',
            defaultextension='.json',
            initialfile='Killer7_image_scan.json',
            filetypes=[('JSON', '*.json'), ('Todos', '*.*')],
            parent=self.image_scan_window,
        )
        if not p:
            return
        rows = []
        for resource in self.image_scan_resources:
            mark = self.image_scan_marks.get(resource['id'], '')
            if not mark:
                continue
            rows.append({
                'id': resource['id'],
                'afs_index': resource['afs_index'],
                'name': resource['name'],
                'path': resource['path'],
                'width': resource['width'],
                'height': resource['height'],
                'hint': resource['hint'],
                'mark': mark,
            })
        report = {
            'format': 'killer7-image-scan',
            'format_version': 1,
            'serial': self.project.serial,
            'image_name': self.project.iso_path.name,
            'resource_count': len(self.image_scan_resources),
            'marks': rows,
        }
        Path(p).write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
        messagebox.showinfo(
            'Escáner de imágenes',
            f'Informe guardado con {len(rows)} marcas:\n{p}',
            parent=self.image_scan_window,
        )

    def _image_scanner_load_report(self):
        if self.image_scan_mode == 'eur_fr':
            messagebox.showinfo('Gráficos franceses', 'El catálogo de la edición EUR se carga automáticamente.', parent=self.image_scan_window)
            return
        if not self.project:
            return
        p = filedialog.askopenfilename(
            title='Cargar informe del escáner',
            filetypes=[('JSON', '*.json'), ('Todos', '*.*')],
            parent=self.image_scan_window,
        )
        if not p:
            return
        try:
            report = json.loads(Path(p).read_text(encoding='utf-8'))
            if report.get('format') != 'killer7-image-scan':
                raise ValueError('El JSON no es un informe del escáner de Killer7.')
            serial = report.get('serial')
            if serial and serial != self.project.serial:
                raise ValueError(f'El informe es para {serial}; la ISO cargada es {self.project.serial}.')
            valid = {'Tiene texto', 'Sin texto', 'Revisar'}
            loaded = 0
            for row in report.get('marks', []):
                rid = str(row.get('id', ''))
                mark = str(row.get('mark', ''))
                if rid and mark in valid:
                    self.image_scan_marks[rid] = mark
                    loaded += 1
            self._image_scanner_apply_filter()
            messagebox.showinfo(
                'Escáner de imágenes',
                f'Se cargaron {loaded} marcas.',
                parent=self.image_scan_window,
            )
        except Exception as exc:
            messagebox.showerror('Escáner de imágenes', str(exc), parent=self.image_scan_window)

    # ---------- Source catalog ----------
    def verify_source(self):
        if self.current < 0 or not self.block:
            return
        if self.block.storage_kind not in ('afs_pair', 'afs_da'):
            messagebox.showinfo('Original', 'Este bloque no usa transcripción por glifos: el texto se lee directamente o se ha verificado visualmente en la textura.', parent=self)
            return
        self.commit()
        u = self.block.units[self.current]
        initial = u.source or u.source_candidate
        value = simpledialog.askstring(
            'Original inglés verificado',
            'Escribe exactamente el texto que muestran los glifos.\n'
            'Los espacios cuentan como códigos; los controles FFxx se insertan automáticamente.',
            initialvalue=initial,
            parent=self,
        )
        if value is None:
            return
        value = value.strip('\r\n')
        if not value:
            messagebox.showwarning('Original', 'El original no puede quedar vacío.', parent=self)
            return
        row = self.rows[self.current]
        try:
            set_source_text(row['xml_unit'], u, value, 'verified', copy_to_empty_target=True)
        except Exception as exc:
            messagebox.showerror('Original', str(exc), parent=self)
            return

        u.source = value
        u.source_state = 'verified'
        u.source_provenance = 'manual-verified'
        entry = dict(self.source_catalog.get(u.id, {})) if isinstance(self.source_catalog.get(u.id), dict) else {}
        entry.update({'text': value, 'state': 'verified', 'provenance': 'manual-verified'})
        self.source_catalog[u.id] = entry
        try:
            save_source_catalog(self.catalog_path, self.source_catalog, {'serial': self.project.serial if self.project else ''})
        except Exception as exc:
            messagebox.showwarning('Catálogo', f'El XLIFF se actualizó, pero no se pudo guardar el catálogo interno:\n{exc}', parent=self)
        self.dirty = True
        self._refresh_rows()
        self._populate()
        self.tree.selection_set(str(self.current))
        self.show(self.current)


    def propagate_sources(self):
        if not self.project:
            return
        try:
            info = propagate_candidates(self.project, self.source_catalog, 0.01)
            save_source_catalog(self.catalog_path, self.source_catalog, {'serial': self.project.serial})
            # Los candidatos viven en TextUnit; reconstruir el XLIFF no cambia sources
            # pendientes, pero sus notas se incorporarán al volver a abrir la ISO.
            self._populate()
            messagebox.showinfo(
                'Memoria de glifos',
                f"{info['seeded_units']} unidades verificadas alimentan la memoria.\n"
                f"{info['memory_glyphs']} glifos inequívocos · {info['conflicts']} conflictos descartados.\n"
                f"{info['updated_units']} unidades recibieron candidato ({info['full_candidates']} completos).",
                parent=self,
            )
        except Exception as exc:
            messagebox.showerror('Memoria de glifos', str(exc), parent=self)

    def save_catalog_as(self):
        if not self.project:
            return False
        p = filedialog.asksaveasfilename(
            title='Guardar catálogo fuente',
            defaultextension='.json',
            initialfile='killer7_source_catalog.json',
            filetypes=[('JSON', '*.json'), ('Todos', '*.*')],
        )
        if not p:
            return False
        save_source_catalog(p, self.source_catalog, {
            'serial': self.project.serial,
            'image_name': self.project.iso_path.name,
        })
        messagebox.showinfo('Catálogo', f'Guardado:\n{p}', parent=self)
        return True

    # ---------- Persistent project save / change log ----------
    def _program_root(self) -> Path:
        return resource_root()

    def _snapshot_project_texts(self) -> dict[str, dict]:
        """Devuelve los textos editables actuales con contexto suficiente para el log."""
        snap: dict[str, dict] = {}
        if self.eur_view_mode:
            for block in self.eur_view_blocks:
                if block.storage_kind not in ('afs_cinematic_da', 'eur_scene_selector'):
                    continue
                rows = list(getattr(block, 'viewer_rows', []) or [])
                for idx, row in enumerate(rows):
                    if block.storage_kind == 'afs_cinematic_da':
                        map_key = str(row.get('cinema_key') or f'{block.jmb_index}:{idx}')
                        target = str(self.eur_cinematic_targets.get(map_key, row.get('target', '') or ''))
                    else:
                        map_key = str(row.get('selector_key') or row.get('id') or idx)
                        target = str(self.eur_scene_selector_targets.get(map_key, row.get('target', '') or ''))
                    uid = str(row.get('id') or map_key)
                    key = f'{block.id}:{uid}'
                    snap[key] = {
                        'unit_id': uid,
                        'category': self._text_category_for_block(block),
                        'block_id': str(block.id),
                        'block_label': str(block.label),
                        'directory': str(block.storage_path),
                        'source': str(row.get('source', '') or ''),
                        'target': target,
                    }
            return snap

        if self.master_root is None:
            return snap
        block_map = {str(b.id): b for b in (self.project.all_blocks if self.project else [])}
        parsed = parse_project_xliff(self.master_root)
        for pf in parsed.get('files', []):
            fid = str(pf.get('file_id', ''))
            block = block_map.get(fid)
            category = self._text_category_for_block(block) if block is not None else 'unknown'
            label = str(getattr(block, 'label', fid))
            directory = str(getattr(block, 'storage_path', pf.get('original', '') or ''))
            for unit in pf.get('units', []):
                uid = str(unit.get('id', ''))
                snap[f'{fid}:{uid}'] = {
                    'unit_id': uid,
                    'category': category,
                    'block_id': fid,
                    'block_label': label,
                    'directory': directory,
                    'source': str(unit.get('source', '') or ''),
                    'target': str(unit.get('target', '') or ''),
                }
        return snap

    def _reset_project_save_snapshot(self) -> None:
        self.project_saved_snapshot = self._snapshot_project_texts()

    @staticmethod
    def _project_text_differences(before: dict[str, dict], after: dict[str, dict]) -> list[dict]:
        changes = []
        for key in sorted(set(before) | set(after)):
            old = before.get(key, {})
            new = after.get(key, {})
            old_target = str(old.get('target', '') or '')
            new_target = str(new.get('target', '') or '')
            if old_target == new_target:
                continue
            meta = dict(new or old)
            meta['key'] = key
            meta['before'] = old_target
            meta['after'] = new_target
            changes.append(meta)
        return changes

    def _append_project_change_log(self, changes: list[dict], saved_files: list[Path]) -> None:
        if not changes:
            return
        path = self.project_log_path
        path.parent.mkdir(parents=True, exist_ok=True)
        first = not path.exists() or path.stat().st_size == 0
        stamp = datetime.now().astimezone().isoformat(timespec='seconds')
        edition = 'EUR / SLES_533.66' if self.eur_view_mode else (
            f'USA / {self.project.serial}' if self.project else 'desconocida'
        )
        iso_name = self.eur_iso_path.name if self.eur_view_mode and self.eur_iso_path else (
            self.project.iso_path.name if self.project else ''
        )
        category_labels = dict(self.text_category_specs)
        lines = []
        if first:
            lines.extend([
                'KILLER7 XLIFF PROJECT - HISTORIAL DE CAMBIOS DE TEXTO',
                '=====================================================',
                '',
            ])
        lines.extend([
            f'[{stamp}]',
            f'Edición: {edition}',
            f'ISO: {iso_name}',
            'Archivos de proyecto guardados: ' + ', '.join(str(x.relative_to(self._program_root())) if x.is_relative_to(self._program_root()) else str(x) for x in saved_files),
            f'Cambios: {len(changes)}',
            '',
        ])
        for i, change in enumerate(changes, 1):
            category = category_labels.get(str(change.get('category', '')), str(change.get('category', '')))
            lines.extend([
                f'{i}. Categoría: {category}',
                f'   Bloque: {change.get("block_label") or change.get("block_id")}',
                f'   ID bloque: {change.get("block_id", "")}',
                f'   Directorio/recurso: {change.get("directory", "")}',
                f'   Unidad: {change.get("unit_id", "")}',
                '   Original: ' + json.dumps(str(change.get('source', '') or ''), ensure_ascii=False),
                '   Antes:    ' + json.dumps(str(change.get('before', '') or ''), ensure_ascii=False),
                '   Después:  ' + json.dumps(str(change.get('after', '') or ''), ensure_ascii=False),
                '',
            ])
        lines.append('')
        with path.open('a', encoding='utf-8', newline='\n') as fh:
            fh.write('\n'.join(lines))

    def save_project(self):
        """Guarda los cambios de texto en los archivos internos reutilizados por la app."""
        if not (self.project or self.eur_view_mode):
            messagebox.showinfo('Guardar Proyecto', 'Selecciona primero una ISO.', parent=self)
            return False
        if not self.commit():
            return False

        before = dict(self.project_saved_snapshot)
        after = self._snapshot_project_texts()
        changes = self._project_text_differences(before, after)
        saved_files: list[Path] = []
        warnings = []
        try:
            if self.eur_view_mode:
                bundled = self._bundled_eur_cinema_project()
                self._write_eur_cinematic_file(bundled)
                saved_files.append(bundled)
                # Si existía un proyecto lateral junto a la ISO, mantenerlo
                # sincronizado para que no tenga prioridad con datos antiguos.
                sidecar = self.eur_cinematic_project_path
                if sidecar and sidecar.resolve() != bundled.resolve() and sidecar.exists():
                    try:
                        self._write_eur_cinematic_file(sidecar)
                        saved_files.append(sidecar)
                    except Exception as exc:
                        warnings.append(f'No se pudo sincronizar {sidecar}: {exc}')
                self.eur_cinematic_project_path = bundled
            else:
                if self.master_root is None:
                    raise K7Error('No hay un proyecto XLIFF activo para guardar.')
                self._stamp_hash()
                master_path = editable_path('resources', 'master', 'Killer7_SLUS-21154_master_ES_started.xlf')
                master_path.parent.mkdir(parents=True, exist_ok=True)
                master_path.write_bytes(pretty_bytes(self.master_root))
                saved_files.append(master_path)

            self._append_project_change_log(changes, saved_files)
        except Exception as exc:
            messagebox.showerror('Guardar Proyecto', str(exc), parent=self)
            return False

        self.project_saved_snapshot = after
        self.dirty = False
        detail = f'{len(changes)} cambio(s) de texto registrado(s).'
        if not changes:
            detail = 'No había cambios de texto nuevos desde el último guardado.'
        extra = '' if not warnings else '\n\nAvisos:\n' + '\n'.join(warnings)
        messagebox.showinfo(
            'Guardar Proyecto',
            'Proyecto guardado correctamente.\n\n'
            f'{detail}\n'
            f'Log: {self.project_log_path.name}' + extra,
            parent=self,
        )
        return True

    # ---------- XLIFF I/O ----------
    def _ctrl_save(self, _event=None):
        self.save_project()
        return 'break'

    def _stamp_hash(self):
        if not self.project or self.master_root is None:
            return ''
        sha = self.project.image_sha256()
        for f in self.master_root.findall(NS + 'file'):
            notes = f.find(NS + 'notes')
            if notes is None:
                notes = ET.Element(NS + 'notes')
                f.insert(0, notes)
            note = next((n for n in notes.findall(NS + 'note') if n.attrib.get('category') == 'killer7:image_sha256'), None)
            if note is None:
                note = ET.SubElement(notes, NS + 'note', {'category': 'killer7:image_sha256'})
            note.text = sha
        return sha

    def save_block_xlf(self):
        if not self.block or self.master_root is None:
            return False
        if not self.commit():
            return False
        f = find_file(self.master_root, self.block.id)
        if f is None:
            return False
        root = ET.Element(NS + 'xliff', {'version': '2.2', 'srcLang': 'en', 'trgLang': 'es'})
        root.append(deepcopy(f))
        p = filedialog.asksaveasfilename(
            title='Guardar bloque como XLIFF', defaultextension='.xlf',
            initialfile=f'{self.block.id}.xlf',
            filetypes=[('XLIFF', '*.xlf'), ('Todos', '*.*')],
        )
        if not p:
            return False
        Path(p).write_bytes(pretty_bytes(root))
        messagebox.showinfo('XLIFF', f'Guardado:\n{p}', parent=self)
        return True

    def save_master_xlf(self):
        if not self.project or self.master_root is None:
            return False
        if not self.commit():
            return False
        self._stamp_hash()
        p = filedialog.asksaveasfilename(
            title='Guardar proyecto maestro XLIFF', defaultextension='.xlf',
            initialfile=f'Killer7_{self.project.serial.replace(".", "-")}_master.xlf',
            filetypes=[('XLIFF', '*.xlf'), ('Todos', '*.*')],
        )
        if not p:
            return False
        Path(p).write_bytes(pretty_bytes(self.master_root))
        manifest = self.project.manifest(with_hash=True)
        Path(p).with_suffix('.manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
        self.dirty = False
        stats = project_stats(self.master_root)
        messagebox.showinfo(
            'XLIFF maestro',
            f'Guardado:\n{p}\n\n{stats["files"]} bloques · {stats["units"]} unidades · '
            f'{stats["translated"]} traducidas · {stats["pending_source"]} pendientes reales · {stats.get("special_source", 0)} especiales',
            parent=self,
        )
        return True

    def _verify_xlf_identity(self, parsed):
        if not self.project:
            return
        notes = parsed['files'][0].get('notes', {}) if parsed['files'] else {}
        serial = (notes.get('killer7:serial') or [''])[0]
        if serial and serial != 'unknown' and serial != self.project.serial:
            raise ValueError(f'El XLIFF es para {serial}; la ISO cargada es {self.project.serial}.')
        hashes = [x for f in parsed['files'] for x in f.get('notes', {}).get('killer7:image_sha256', []) if x]
        if hashes:
            expected = hashes[0]
            if any(x != expected for x in hashes):
                raise ValueError('El XLIFF contiene huellas SHA-256 inconsistentes entre bloques.')
            actual = self.project.image_sha256()
            if expected != actual:
                raise ValueError('La huella SHA-256 del XLIFF no coincide con la ISO seleccionada.')

    def load_xlf(self):
        if not self.project or self.master_root is None:
            return
        if not self._confirm_discard():
            return
        p = filedialog.askopenfilename(
            title='Cargar traducción XLIFF',
            filetypes=[('XLIFF', '*.xlf *.xliff'), ('XML', '*.xml'), ('Todos', '*.*')],
        )
        if not p:
            return
        try:
            parsed = parse_project_xliff(p)
            self._verify_xlf_identity(parsed)
            if len(parsed['files']) == 1:
                fid = parsed['files'][0]['file_id']
                block = next((b for b in self.project.all_blocks if b.id == fid), None)
                if block is None:
                    raise ValueError(f'El bloque {fid} no existe en esta ISO.')
                issues = validate_xliff(p, block)
                errs = [x for x in issues if x[0] == 'ERR']
                if errs:
                    raise ValueError('\n'.join(f'{u}: {m}' for _s, u, m in errs[:12]))
                self._replace_master_file(parsed['files'][0]['xml_file'])
                self._show_block_in_its_category(block)
                self.block_var.set(block.label)
                self.load_block(force=True)
            else:
                issues = validate_project_xliff(p, self.project.all_blocks)
                errs = [x for x in issues if x[0] == 'ERR']
                if errs:
                    raise ValueError('\n'.join(f'{u}: {m}' for _s, u, m in errs[:12]))
                self.master_root = parsed['root']
                self.load_block(force=True)
            self.dirty = False
            self._reset_project_save_snapshot()
            messagebox.showinfo('XLIFF', f'Cargado correctamente: {len(parsed["files"])} bloque(s).', parent=self)
        except Exception as exc:
            messagebox.showerror('XLIFF', str(exc), parent=self)

    def run_preflight(self):
        if not self.project or self.master_root is None:
            messagebox.showinfo('Preflight', 'Selecciona primero la ISO original.', parent=self)
            return
        if not self.commit():
            return
        issues = validate_project_xliff(self.master_root, self.project.all_blocks)
        errs = [x for x in issues if x[0] == 'ERR']
        if errs:
            text = '\n'.join(f'{u}: {m}' for _s, u, m in errs[:20])
            messagebox.showerror('Preflight', 'Corrige primero el XLIFF:\n\n' + text, parent=self)
            return

        xlf_bytes = self._compile_snapshot_bytes()
        iso_path = str(self.project.iso_path)
        catalog_path = str(self.catalog_path)
        progress = tk.Toplevel(self)
        progress.title('Preflight completo')
        progress.transient(self)
        progress.grab_set()
        progress.resizable(False, False)
        ttk.Label(
            progress,
            text='Compilando en seco todos los bloques traducidos…\nNo se modifica la ISO.',
            justify=tk.LEFT, padding=14,
        ).pack(fill=tk.X)
        bar = ttk.Progressbar(progress, mode='indeterminate', length=440)
        bar.pack(fill=tk.X, padx=14, pady=(0, 14))
        bar.start(10)

        def worker():
            try:
                cat = load_source_catalog(catalog_path)
                proj = Killer7Project(iso_path, cat)
                try:
                    report = preflight_project(proj, xlf_bytes)
                finally:
                    proj.close()
                self.after(0, lambda: finish(report))
            except Exception as exc:
                self.after(0, lambda exc=exc: fail(exc))

        def close_progress():
            try:
                bar.stop(); progress.grab_release(); progress.destroy()
            except Exception:
                pass

        def finish(report):
            close_progress()
            if report['errors']:
                sample = '\n\n'.join(
                    f"{e['file_id']} ({e['kind']}):\n{e['error']}"
                    for e in report['errors'][:18]
                )
                if len(report['errors']) > 18:
                    sample += f"\n\n… y {len(report['errors'])-18} bloques más."
                messagebox.showerror(
                    'Preflight — errores',
                    f"{len(report['errors'])} bloque(s) no compilan. No inyectes todavía.\n\n{sample}",
                    parent=self,
                )
                return
            messagebox.showinfo(
                'Preflight — OK',
                f"Compilación en seco correcta.\n\n"
                f"{report['blocks_checked']} bloques comprobados · "
                f"{report['translated_units']} unidades efectivamente recompiladas · "
                f"0 errores.\n\nLa ISO no se ha modificado.",
                parent=self,
            )

        def fail(exc):
            close_progress()
            messagebox.showerror('Preflight', str(exc), parent=self)

        threading.Thread(target=worker, daemon=True).start()

    def compile_patch(self):
        if not self.project or self.master_root is None:
            return
        if not self.commit():
            return
        issues = validate_project_xliff(self.master_root, self.project.all_blocks)
        errs = [x for x in issues if x[0] == 'ERR']
        if errs:
            text = '\n'.join(f'{u}: {m}' for _s, u, m in errs[:15])
            messagebox.showerror('Compilación', 'Corrige primero los errores XLIFF:\n\n' + text, parent=self)
            return
        try:
            self._stamp_hash()
            p = filedialog.asksaveasfilename(
                title='Guardar parche compilado',
                defaultextension='.zip',
                initialfile=f'Killer7_{self.project.serial.replace(".", "-")}_ES_test.k7patch.zip',
                filetypes=[('Parche Killer7 ZIP', '*.zip'), ('Todos', '*.*')],
            )
            if not p:
                return
            manifest = build_patch_zip(self.project, self.master_root, p)
            messagebox.showinfo(
                'Parche compilado',
                f'Guardado:\n{p}\n\n'
                f'{len(manifest["blocks"])} bloques · {manifest["translated_units"]} unidades traducidas · '
                f'{len(manifest["entries"])} entradas AFS.\n\n'
                'El ZIP no contiene la ISO. El aplicador CLI siempre crea una copia nueva.',
                parent=self,
            )
        except Exception as exc:
            messagebox.showerror('Compilación', str(exc), parent=self)


    def _compile_snapshot_bytes(self) -> bytes:
        """Crea una instantánea XLIFF sin SHA heredado; el parche se vincula luego a la ISO actual."""
        root = deepcopy(self.master_root)
        for f in root.findall(NS + 'file'):
            notes = f.find(NS + 'notes')
            if notes is None:
                continue
            for note in list(notes.findall(NS + 'note')):
                if note.attrib.get('category') == 'killer7:image_sha256':
                    notes.remove(note)
        return pretty_bytes(root)

    def inject_iso(self):
        if not self.project or self.master_root is None:
            messagebox.showinfo('Inyectar traducción', 'Selecciona primero la ISO del juego.', parent=self)
            return
        if not self.commit():
            return
        issues = validate_project_xliff(self.master_root, self.project.all_blocks)
        errors = [x for x in issues if x[0] == 'ERR']
        if errors:
            sample = '\n'.join(f'{u}: {m}' for _s, u, m in errors[:15])
            messagebox.showerror(
                'Inyectar traducción',
                'El XLIFF tiene errores y no se puede inyectar:\n\n' + sample,
                parent=self,
            )
            return
        src = Path(self.project.iso_path)
        suggested = src.with_name(src.stem + ' [ES XLIFF].iso').name
        out = filedialog.asksaveasfilename(
            title='Crear ISO traducida',
            defaultextension='.iso',
            initialdir=str(src.parent),
            initialfile=suggested,
            filetypes=[('ISO de PlayStation 2', '*.iso'), ('Todos', '*.*')],
        )
        if not out:
            return
        outp = Path(out).resolve()
        if outp == src.resolve():
            messagebox.showerror(
                'Inyectar traducción',
                'Por seguridad la ISO de salida debe tener un nombre distinto. La original nunca se sobrescribe.',
                parent=self,
            )
            return
        stats = project_stats(self.master_root)
        if not messagebox.askyesno(
            'Inyectar TODOS los textos en ISO',
            f'Se creará una nueva ISO:\n\n{outp}\n\n'
            f'Traducciones activas: {stats["translated"]}\n'
            f'Pendientes reales: {stats["pending_source"]}\n'
            f'Recursos especiales preservados: {stats.get("special_source", 0)}\n\n'
            'La ISO original no se modificará. ¿Continuar?',
            parent=self,
        ):
            return

        xlf_bytes = self._compile_snapshot_bytes()
        iso_path = str(src)
        out_path = str(outp)
        catalog_path = str(self.catalog_path)

        progress = tk.Toplevel(self)
        progress.title('Inyectando traducción')
        progress.transient(self)
        progress.grab_set()
        progress.resizable(False, False)
        ttk.Label(
            progress,
            text='Validando y recompilando JMB/DIC + subtítulos .da + textos directos…\nDespués se copiará la ISO y se aplicarán los cambios.',
            justify=tk.LEFT,
            padding=14,
        ).pack(fill=tk.X)
        bar = ttk.Progressbar(progress, mode='indeterminate', length=440)
        bar.pack(fill=tk.X, padx=14, pady=(0, 14))
        bar.start(10)
        self.update_idletasks()

        def worker():
            try:
                with tempfile.TemporaryDirectory(prefix='killer7_xliff_') as td:
                    patch_path = Path(td) / 'translation.k7patch.zip'
                    cat = load_source_catalog(catalog_path)
                    proj = Killer7Project(iso_path, cat)
                    try:
                        preflight = preflight_project(proj, xlf_bytes)
                        if preflight['errors']:
                            sample = '\n\n'.join(
                                f"{e['file_id']} ({e['kind']}): {e['error']}"
                                for e in preflight['errors'][:18]
                            )
                            if len(preflight['errors']) > 18:
                                sample += f"\n… y {len(preflight['errors'])-18} bloques más."
                            raise K7Error(
                                f"Preflight fallido: {len(preflight['errors'])} bloque(s) no compilan.\n\n{sample}"
                            )
                        manifest = build_patch_zip(proj, xlf_bytes, patch_path)
                    finally:
                        proj.close()
                    applied = apply_patch_to_iso(iso_path, patch_path, out_path, verify_hash=True)
                self.after(0, lambda: finish_ok(manifest, applied))
            except Exception as exc:
                self.after(0, lambda exc=exc: finish_error(exc))

        def finish_ok(manifest, _applied):
            try:
                bar.stop()
                progress.grab_release()
                progress.destroy()
            except Exception:
                pass
            messagebox.showinfo(
                'ISO traducida creada',
                f'ISO creada correctamente:\n{out_path}\n\n'
                f'{len(manifest["blocks"])} bloques AFS modificados · '
                f'{manifest["translated_units"]} unidades traducidas · '
                f'{len(manifest["entries"])} entradas AFS · '
                f'{len(manifest.get("iso_patches", []))} cadenas del ejecutable.\n\n'
                'La ISO original permanece intacta.',
                parent=self,
            )

        def finish_error(exc):
            try:
                bar.stop()
                progress.grab_release()
                progress.destroy()
            except Exception:
                pass
            try:
                p = Path(out_path)
                if p.exists():
                    p.unlink()
            except Exception:
                pass
            messagebox.showerror('Inyectar traducción', str(exc), parent=self)

        threading.Thread(target=worker, daemon=True).start()

    def patch_eur_translated_images(self):
        """Botón independiente: aplica todas las imágenes rasterizadas ya traducidas."""
        if not self.eur_view_mode or not self.eur_iso_path or not self.eur_iso_path.exists():
            messagebox.showerror(
                'Imagenes Traducidas',
                'Selecciona primero una ISO EUR SLES_533.66.',
                parent=self,
            )
            return
        eurp = self.eur_iso_path.resolve()
        out = filedialog.asksaveasfilename(
            title='Guardar ISO EUR · Imágenes traducidas',
            defaultextension='.iso',
            initialdir=str(eurp.parent),
            initialfile=eurp.stem + '_IMAGENES_TRADUCIDAS_ES.iso',
            filetypes=[('Imagen ISO de PlayStation 2', '*.iso'), ('Todos', '*.*')],
        )
        if not out:
            return
        outp = Path(out).resolve()
        if outp == eurp:
            messagebox.showerror(
                'Imagenes Traducidas',
                'La ISO original nunca se sobrescribe. Elige otro nombre de salida.',
                parent=self,
            )
            return
        if not messagebox.askyesno(
            'Imagenes Traducidas · botón independiente',
            f'Entrada:\n{eurp}\n\nSalida:\n{outp}\n\n'
            'Se traducirán exclusivamente estas imágenes rasterizadas:\n'
            '• AFS #3870 euRGB60_f.dic: confirmación 50/60 Hz en español\n'
            '• AFS #3896 selLang.dic: selector de idioma + textos PAL/NTSC + pregunta 50/60 Hz\n'
            '• AFS #3897 selLangAnser.: copia de la confirmación 50/60 Hz\n'
            '• AFS #3941 titleF.dic: Elige dificultad / Mortal / descripciones ES\n\n'
            'No se tocarán SLES, módulos, subtítulos, selector de escenas ni otros gráficos.\n\n'
            '¿Continuar?',
            parent=self,
        ):
            return

        progress = tk.Toplevel(self)
        progress.title('Imagenes Traducidas · EUR')
        progress.transient(self)
        progress.grab_set()
        progress.resizable(False, False)
        ttk.Label(
            progress,
            text='Copiando la ISO y aplicando las imágenes traducidas…\n'
                 'Se verificará cada recurso antes y después de escribir.',
            justify=tk.LEFT,
            padding=14,
        ).pack(fill=tk.X)
        bar = ttk.Progressbar(progress, mode='indeterminate', length=520)
        bar.pack(fill=tk.X, padx=14, pady=(0, 14))
        bar.start(10)
        self.update_idletasks()

        def worker():
            try:
                report = apply_eur_translated_images_to_iso(str(eurp), str(outp))
                self.after(0, lambda: finish_ok(report))
            except Exception as exc:
                self.after(0, lambda exc=exc: finish_error(exc))

        def finish_ok(report):
            try:
                bar.stop()
                progress.grab_release()
                progress.destroy()
            except Exception:
                pass
            already = '\nTodos los recursos ya estaban traducidos en la ISO de entrada.' if report.get('already_patched_all') else ''
            upgraded = '\nSe actualizó al estilo nuevo al menos un parche anterior.' if report.get('upgraded_previous_patch') else ''
            resources = '\n'.join(
                f"AFS #{row['afs_index']} {row['afs_name']}: {', '.join(row.get('textures', []))}"
                for row in report.get('resources', [])
            )
            messagebox.showinfo(
                'Imagenes Traducidas',
                f'ISO creada correctamente:\n{outp}\n\n'
                f'Recursos aplicados:\n{resources}\n\n'
                'Pantallas iniciales traducidas con estilo rasterizado revisado:\n'
                '• Seleccionar idioma español\n'
                '• Ajustar pantalla a NTSC (60 Hz).\n'
                '• Ajustar pantalla a PAL (50 Hz).\n'
                '• ¿Quieres usar el modo de 60 Hz? / Sí / No\n'
                '• Pantalla ajustada al modo de 50/60 Hz.\n\n'
                'Pantalla de dificultad incluida:\n'
                '• Elige dificultad / Normal / Mortal\n'
                '• Descripciones de Normal y Mortal en español\n\n'
                f'Conservada en dificultad: {", ".join(report.get("preserved_textures", []))}.{already}{upgraded}',
                parent=self,
            )

        def finish_error(exc):
            try:
                bar.stop()
                progress.grab_release()
                progress.destroy()
            except Exception:
                pass
            messagebox.showerror('Imagenes Traducidas', str(exc), parent=self)

        threading.Thread(target=worker, daemon=True).start()

    def inject_texts(self):
        """Ruta EUR-first: aplica los 4.759 textos y cinemáticas editables a una ISO PAL/EUR.

        La ISO europea SLES_533.66 es la única imagen de juego utilizada. El
        idioma francés actúa como slot/base que se sustituye por el proyecto
        español integrado. La ruta estable USA permanece completamente separada.
        """
        if self.eur_view_mode and not self.commit():
            return

        # Si «Seleccionar ISO…» ya dejó una EUR activa, usarla directamente.
        # Sólo abrir un selector aquí cuando el usuario todavía no ha elegido una.
        if self.eur_iso_path and self.eur_iso_path.exists():
            eurp = self.eur_iso_path.resolve()
        else:
            eur = filedialog.askopenfilename(
                title='Seleccionar ISO europea de Killer7 · SLES_533.66',
                filetypes=[('Imagen ISO de PlayStation 2', '*.iso'), ('Todos', '*.*')],
            )
            if not eur:
                return
            eurp = Path(eur).resolve()

        out = filedialog.asksaveasfilename(
            title='Guardar ISO EUR · francés sustituido por español',
            defaultextension='.iso',
            initialdir=str(eurp.parent),
            initialfile=eurp.stem + '_ES.iso',
            filetypes=[('Imagen ISO de PlayStation 2', '*.iso'), ('Todos', '*.*')],
        )
        if not out:
            return
        outp = Path(out).resolve()
        if outp == eurp:
            messagebox.showerror(
                'Inyectar Textos',
                'La ISO europea original nunca se sobrescribe. Elige otro nombre de salida.',
                parent=self,
            )
            return

        if not messagebox.askyesno(
            'Inyectar Textos · ISO EUR',
            f'BASE DE TRABAJO: ISO EUROPEA SLES_533.66\n\n'
            f'Entrada:\n{eurp}\n\nSalida:\n{outp}\n\n'
            'Se aplicarán los 4.759 targets españoles y todas las imágenes traducidas sobre los recursos del idioma FRANCÉS.\n\n'
            '• D_EU/DIR_E.AFS: JMB/DIC franceses, K7P2 (incluido child 2 francés) y gráficos equivalentes\n'
            '• Aviso inicial: contenido para adultos / escenas de violencia explícita\n'
            '• Imágenes iniciales: idioma y confirmaciones PAL/NTSC en español\n'
            '• Dificultad: Elige dificultad / Mortal / descripciones ES\n'
            '• Menú Special: 17 rótulos españoles ajustados a los recuadros UV detectados en SLES_533.66\n'
            '• Índice del tutorial: Info general / combate / sangre / Datos prev.\n'
            '• Selector de escenas: capítulos + fechas + OBJETIVO + Sí/No + confirmación de salida\n'
            '• 230 subtítulos .da: texto español con atlas/glifos franceses EUR\n'
            '• Subtítulos CINEMÁTICAS: targets que escribas en el editor + glifos EUR dinámicos\n'
            '• SLES_533.66: menú principal y pantalla de Opciones en español\n'
            '• STÉRÉO → ESTÉREO usando la É nativa europea\n\n'
            'La ISO se copiará a un archivo temporal. SLES y módulos conservan sus posiciones; '
            'si las cinemáticas hacen crecer DIR_E.AFS, se reubica al final de la ISO actualizando '
            'su registro ISO9660, sin desplazar archivos existentes. La ISO de origen no se modifica.\n\n'
            'No se solicita ni se utiliza ninguna ISO americana. Todas las imágenes traducidas '
            'se integran en esta misma operación.\n\n¿Continuar?',
            parent=self,
        ):
            return

        eur_path = str(eurp)
        out_path = str(outp)

        progress = tk.Toplevel(self)
        progress.title('Inyectar Textos · ISO EUR → ES')
        progress.transient(self)
        progress.grab_set()
        progress.resizable(False, False)
        ttk.Label(
            progress,
            text=(
                'Aplicando textos, subtítulos e imágenes traducidas a la rama francesa de la ISO EUR…\n'
                'Se comprobará SLES_533.66, se reconstruirá DIR_E.AFS y se verificará byte a byte la inserción.'
            ),
            justify=tk.LEFT,
            padding=14,
        ).pack(fill=tk.X)
        bar = ttk.Progressbar(progress, mode='indeterminate', length=520)
        bar.pack(fill=tk.X, padx=14, pady=(0, 14))
        bar.start(10)
        self.update_idletasks()

        def worker():
            try:
                report = apply_current_spanish_to_eur_iso(
                    eur_path, out_path, dict(self.eur_cinematic_targets),
                    dict(self.eur_scene_selector_targets)
                )
                self.after(0, lambda: finish_ok(report))
            except Exception as exc:
                self.after(0, lambda exc=exc: finish_error(exc))

        def finish_ok(report):
            try:
                bar.stop()
                progress.grab_release()
                progress.destroy()
            except Exception:
                pass
            c = report['afs']['counts']
            d = report['direct_strings']
            sf = report.get('sles_french_verified', {})
            extra = ''
            if report.get('report_file'):
                extra = f'\nInforme técnico: {report["report_file"]}\n'
            messagebox.showinfo(
                'ISO EUR española creada',
                f'ISO creada correctamente:\n{out_path}\n\n'
                f'BASE: Killer7 PAL/EUR SLES_533.66 · FRANCÉS sustituido por español\n\n'
                f'• Unidades españolas integradas: {c.get("translated_units", 0)}\n'
                f'• JMB: {c.get("jmb", 0)}\n'
                f'• DIC de texto: {c.get("dic", 0)}\n'
                f'• Espejos DAR JMB/DIC: {c.get("jmb_dar_mirror", 0)}\n'
                f'• Subtítulos .da: {c.get("subtitle_da", 0)}\n'
                f'• .da reconstruidos con glifos franceses EUR: {c.get("subtitle_da_french_style", 0)}\n'
                f'• Cinemáticas FR detectadas: {c.get("cinematic_french_entries", 0)} contenedores / {c.get("cinematic_visible_lines", 0)} líneas\n'
                f'• DIR_E.AFS: {"reubicado al final de la ISO" if report.get("afs_iso_location", {}).get("relocated") else "insertado en su extent original"}\n'
                f'• Shadow AFS runtime: {report.get("afs_runtime_shadow", {}).get("same_size_entries", 0) if report.get("afs_runtime_shadow", {}).get("enabled") else 0} entradas same-size reflejadas en el extent antiguo\n'
                f'• Cinemáticas ES aplicadas: {c.get("cinematic_translated_lines", 0)} líneas · pendientes: {c.get("cinematic_pending_lines", 0)}\n'
                f'• Gráficos del proyecto: {c.get("graphic_dic", 0)}\n'
                f'• Aviso inicial español: {c.get("adult_warning_graphic", 0)} recurso / {c.get("adult_warning_textures", 0)} textura\n'
                f'• Pantallas iniciales traducidas: {c.get("sellang_graphics", 0)} recursos / {c.get("sellang_textures", 0)} texturas\n'
                f'• Pantalla de dificultad traducida: {c.get("difficulty_graphics", 0)} recurso / {c.get("difficulty_textures", 0)} texturas\n'
                f'• Menú · Special: {c.get("special_menu_labels", 0)} rótulos ES ajustados a sus UV / {c.get("special_menu_graphics", 0)} recurso\n'
                f'• Índice del tutorial traducido: {c.get("explan_tutorial_graphic", 0)} recurso / {c.get("explan_tutorial_labels", 0)} etiquetas\n'
                f'• Selector de escenas SceSel_F: {c.get("scene_selector_graphic", 0)} recurso / {c.get("scene_selector_units", 0)} textos\n'
                f'• Tarjetas gráficas de capítulo FR verificadas: {c.get("chapter_graphic_dic_verified", 0)} / 12\n'
                f'• K7P2 primarios: {c.get("k7p2_primary", 0)}\n'
                f'• Espejos K7P2: {c.get("k7p2_mirror", 0)}\n'
                f'• K7P2 francés (DAR child 2): {c.get("k7p2_french_units", 0)} cambios / {c.get("k7p2_french_matched_units", 0)} rótulos emparejados · {c.get("k7p2_french_overflow_units", 0)} conservados por límite de slot\n'
                f'• Entradas AFS sustituidas: {report["afs"]["replacement_entries"]}\n'
                f'• Cambios SLES franceses verificados (slots/punteros): {sf.get("count", 0)}\n\n'
                f'DIRECTO aplicados a francés: {d.get("changed_units", 0)}/{d.get("total_manifest_direct", 0)}.\n'
                f'DIRECTO todavía pendientes: {d.get("pending_units", 0)}.\n'
                f'{extra}\n'
                'Arranca esta ISO EUR y selecciona FRANCÉS: esa rama contiene ahora nuestros textos españoles.',
                parent=self,
            )

        def finish_error(exc):
            try:
                bar.stop()
                progress.grab_release()
                progress.destroy()
            except Exception:
                pass
            messagebox.showerror('Inyectar Textos · ISO EUR', str(exc), parent=self)

        threading.Thread(target=worker, daemon=True).start()

    def validate_master(self):
        if not self.project or self.master_root is None:
            return
        if not self.commit():
            return
        issues = validate_project_xliff(self.master_root, self.project.all_blocks)
        errs = [x for x in issues if x[0] == 'ERR']
        warns = [x for x in issues if x[0] == 'WARN']
        stats = project_stats(self.master_root)
        if not issues:
            messagebox.showinfo(
                'Validación',
                f'Proyecto válido.\n\n{stats["files"]} bloques · {stats["units"]} unidades · '
                f'{stats["translated"]} traducidas · {stats["pending_source"]} pendientes reales · {stats.get("special_source", 0)} especiales.',
                parent=self,
            )
        else:
            text = '\n'.join(f'[{s}] {u}: {m}' for s, u, m in issues[:35])
            if len(issues) > 35:
                text += f'\n… y {len(issues)-35} más.'
            (messagebox.showerror if errs else messagebox.showwarning)(
                'Validación', f'{len(errs)} errores · {len(warns)} avisos\n\n{text}', parent=self
            )


if __name__ == '__main__':
    App().mainloop()
