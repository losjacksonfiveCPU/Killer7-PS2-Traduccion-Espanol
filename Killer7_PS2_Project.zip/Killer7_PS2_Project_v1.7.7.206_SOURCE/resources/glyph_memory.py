from __future__ import annotations
import hashlib
from collections import defaultdict
from core import Killer7Project, TextBlock, TextUnit

UNKNOWN = '□'


def glyph_fingerprint(image) -> str:
    """Huella exacta del recorte de glifo ya deswizzleado.

    Incluye dimensiones: evita confundir formas que casualmente tengan los mismos
    bytes pero distinto avance. No se hace OCR ni se adivinan letras.
    """
    h = hashlib.sha1()
    h.update(image.width.to_bytes(2, 'little'))
    h.update(image.height.to_bytes(2, 'little'))
    h.update(image.tobytes())
    return h.hexdigest()


def _glyph_index(code: int) -> int | None:
    if code in (-4, -3):
        return None
    u = code & 0xffff
    if u >= 0xff00:
        return None
    return (u & 0x0fff) if ((u & 0x7000) or (u & 0x8000)) else code


def _block_assets(project: Killer7Project, block: TextBlock):
    atlas = project.decode_atlas(block)
    params = project.glyph_params(block)
    return atlas, params


def _unit_char_pairs(unit: TextUnit, source: str):
    """Devuelve (glyph_index, char) para un source que encaja con códigos."""
    pos = 0
    out = []
    for code in unit.codes:
        if code in (-4, -3):
            if pos >= len(source) or source[pos] not in (' ', '\u3000'):
                return None
            pos += 1
            continue
        if (code & 0xffff) >= 0xff00:
            continue
        if pos >= len(source):
            return None
        out.append((_glyph_index(code), source[pos]))
        pos += 1
    if pos != len(source):
        return None
    return out


def build_memory(project: Killer7Project):
    votes = defaultdict(lambda: defaultdict(int))
    cache = {}
    seeded_units = 0
    for block in project.all_blocks:
        if block.storage_kind not in ('afs_pair', 'afs_da'):
            continue
        verified = [u for u in block.units if u.source and u.source_state.lower() in {'verified', 'trusted', 'transcribed', 'imported'}]
        if not verified:
            continue
        atlas, params = cache.setdefault((block.storage_kind, block.jmb_index), _block_assets(project, block))
        for unit in verified:
            pairs = _unit_char_pairs(unit, unit.source)
            if pairs is None:
                continue
            seeded_units += 1
            for idx, ch in pairs:
                if idx is None or not (0 <= idx < len(params)):
                    continue
                x, y, w, h = params[idx]
                if x + w > atlas.width or y + h > atlas.height:
                    continue
                fp = glyph_fingerprint(atlas.crop((x, y, x+w, y+h)))
                votes[fp][ch] += 1

    memory = {}
    conflicts = {}
    for fp, chars in votes.items():
        ranked = sorted(chars.items(), key=lambda kv: (-kv[1], kv[0]))
        if len(ranked) > 1:
            # Una huella exacta que se ha verificado como dos caracteres no es segura.
            conflicts[fp] = dict(ranked)
            continue
        memory[fp] = ranked[0][0]
    return memory, conflicts, seeded_units


def decode_unit(project: Killer7Project, block: TextBlock, unit: TextUnit, memory: dict[str, str], assets=None):
    atlas, params = assets or _block_assets(project, block)
    out = []
    known = 0
    regular = 0
    for code in unit.codes:
        if code in (-4, -3):
            out.append(' ')
            continue
        if (code & 0xffff) >= 0xff00:
            # El source XLIFF no contiene el control; build_xliff vuelve a insertarlo
            # leyendo los códigos originales de la ISO.
            continue
        regular += 1
        idx = _glyph_index(code)
        if idx is None or not (0 <= idx < len(params)):
            out.append(UNKNOWN)
            continue
        x, y, w, h = params[idx]
        if x + w > atlas.width or y + h > atlas.height:
            out.append(UNKNOWN)
            continue
        fp = glyph_fingerprint(atlas.crop((x, y, x+w, y+h)))
        ch = memory.get(fp)
        if ch is None:
            out.append(UNKNOWN)
        else:
            out.append(ch)
            known += 1
    confidence = 1.0 if regular == 0 else known / regular
    return ''.join(out), confidence


def propagate_candidates(project: Killer7Project, catalog: dict, min_confidence: float = 0.01):
    """Propaga glifos conocidos a unidades pendientes sin convertirlos en source verificado."""
    memory, conflicts, seeded = build_memory(project)
    cache = {}
    updated = 0
    full = 0
    partial = 0
    for block in project.all_blocks:
        if block.storage_kind not in ('afs_pair', 'afs_da'):
            continue
        assets = cache.setdefault((block.storage_kind, block.jmb_index), _block_assets(project, block))
        for unit in block.units:
            if unit.source and unit.source_state.lower() in {'verified', 'trusted', 'transcribed', 'imported'}:
                continue
            # Las unidades que sólo contienen espacios/controles no aportan glifos
            # y no deben aparecer como candidatos de texto completos.
            regular = sum(1 for c in unit.codes if c not in (-4, -3) and (c & 0xffff) < 0xff00)
            if regular == 0:
                continue
            candidate, confidence = decode_unit(project, block, unit, memory, assets)
            if confidence < min_confidence:
                continue
            current = catalog.get(unit.id, {})
            if isinstance(current, str):
                current = {'text': current, 'state': 'verified'}
            current = dict(current) if isinstance(current, dict) else {}
            old_conf = current.get('confidence')
            try:
                old_conf = float(old_conf) if old_conf is not None else -1.0
            except Exception:
                old_conf = -1.0
            if confidence <= old_conf and current.get('candidate'):
                continue
            current.update({
                'candidate': candidate,
                'state': current.get('state', 'pending'),
                'provenance': 'glyph-memory',
                'confidence': round(confidence, 6),
            })
            catalog[unit.id] = current
            unit.source_candidate = candidate
            unit.source_provenance = 'glyph-memory'
            unit.source_confidence = confidence
            updated += 1
            if UNKNOWN in candidate:
                partial += 1
            else:
                full += 1
    return {
        'seeded_units': seeded,
        'memory_glyphs': len(memory),
        'conflicts': len(conflicts),
        'updated_units': updated,
        'full_candidates': full,
        'partial_candidates': partial,
    }
