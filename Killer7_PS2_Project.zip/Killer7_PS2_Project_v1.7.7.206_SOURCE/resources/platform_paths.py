from __future__ import annotations

import os
import shutil
import sys
from pathlib import Path

APP_DIR_NAME = "Killer7 PS2 Project"


def is_frozen() -> bool:
    return bool(getattr(sys, "frozen", False))


def resource_root() -> Path:
    """Root containing bundled read-only application resources."""
    if is_frozen():
        base = getattr(sys, "_MEIPASS", None)
        if base:
            return Path(base).resolve()
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent.parent


def resource_path(*parts: str | os.PathLike[str]) -> Path:
    return resource_root().joinpath(*map(Path, parts))


def user_data_root() -> Path:
    """Writable per-user data directory for packaged builds.

    Source checkouts intentionally keep the historical behavior and write beside
    the source tree so translation changes remain easy to inspect/version.
    """
    if not is_frozen():
        return resource_root()

    home = Path.home()
    if sys.platform == "win32":
        base = Path(os.environ.get("LOCALAPPDATA") or os.environ.get("APPDATA") or home)
        root = base / APP_DIR_NAME
    elif sys.platform == "darwin":
        root = home / "Library" / "Application Support" / APP_DIR_NAME
    else:
        base = Path(os.environ.get("XDG_DATA_HOME") or (home / ".local" / "share"))
        root = base / APP_DIR_NAME
    root.mkdir(parents=True, exist_ok=True)
    return root


def editable_path(*parts: str | os.PathLike[str]) -> Path:
    """Path for an application file that may be edited at runtime.

    In source mode this is the repository copy. In a frozen build a writable
    per-user copy is created lazily from the bundled resource on first access.
    """
    rel = Path(*parts)
    src = resource_root() / rel
    if not is_frozen():
        return src

    dst = user_data_root() / rel
    if not dst.exists() and src.exists():
        dst.parent.mkdir(parents=True, exist_ok=True)
        if src.is_dir():
            shutil.copytree(src, dst)
        else:
            shutil.copy2(src, dst)
    else:
        dst.parent.mkdir(parents=True, exist_ok=True)
    return dst
