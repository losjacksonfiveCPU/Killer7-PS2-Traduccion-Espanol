from __future__ import annotations

import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
RESOURCES = ROOT / "resources"
if str(RESOURCES) not in sys.path:
    sys.path.insert(0, str(RESOURCES))

from app import App  # noqa: E402


def main() -> None:
    App().mainloop()


if __name__ == "__main__":
    main()
