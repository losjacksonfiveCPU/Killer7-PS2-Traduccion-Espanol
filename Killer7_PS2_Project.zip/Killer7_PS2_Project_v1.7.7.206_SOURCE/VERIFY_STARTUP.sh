#!/usr/bin/env bash
# Source-tree regression guard. Uses the host Python instead of a bundled Linux runtime.
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
PY="${PYTHON:-python3}"

if ! command -v "$PY" >/dev/null 2>&1; then
    echo "ERROR: no se encuentra Python: $PY" >&2
    exit 1
fi

for f in \
    "$ROOT/run.py" \
    "$ROOT/resources/app.py" \
    "$ROOT/resources/compiler.py" \
    "$ROOT/resources/core.py" \
    "$ROOT/resources/xliff_io.py" \
    "$ROOT/resources/glyph_memory.py" \
    "$ROOT/resources/platform_paths.py"; do
    if [ ! -f "$f" ]; then
        echo "ERROR: falta archivo: $f" >&2
        exit 1
    fi
done

if [ -d "$ROOT/resources/runtime" ]; then
    echo "ERROR: el árbol SOURCE no debe incluir resources/runtime" >&2
    exit 1
fi

export PYTHONPATH="$ROOT/resources${PYTHONPATH:+:$PYTHONPATH}"
export PYTHONDONTWRITEBYTECODE=1
export PYTHONPYCACHEPREFIX="${TMPDIR:-/tmp}/killer7_verify_pycache_$$"
trap 'rm -rf "$PYTHONPYCACHEPREFIX"' EXIT

"$PY" -m py_compile \
  "$ROOT/run.py" \
  "$ROOT/resources/app.py" \
  "$ROOT/resources/compiler.py" \
  "$ROOT/resources/core.py" \
  "$ROOT/resources/xliff_io.py" \
  "$ROOT/resources/glyph_memory.py" \
  "$ROOT/resources/platform_paths.py"

"$PY" - <<'PYTEST'
import tkinter
from PIL import Image, ImageTk
import core, compiler, xliff_io, glyph_memory, app, json, tempfile
# v1.7.7.186: todo el francés confirmado del child 1 de explan_f.dat debe
# traducirse in-place con el atlas retail exmes, sin tocar child 2.
import struct as _struct186
_fixture186 = bytearray(0x32380)
_fixture186[:4] = b'DAR\0'
_struct186.pack_into('<I', _fixture186, 8, 3)
_struct186.pack_into('<3I', _fixture186, 0x10, 0x80, 0x18D80, 0x21580)
_struct186.pack_into('<3I', _fixture186, 0x30, 0x18CB8, 0x87A0, 0x10DC0)
_fixture186[0x18D80:0x21520] = b'\xff' * 0x87A0
_offsets186 = [0x18DF8 + 0x1A8 * i for i in range(len(compiler._EUR_EXPLAN_MENU_LABEL_SPECS))]
for (_source186, _target186), _off186 in zip(compiler._EUR_EXPLAN_MENU_LABEL_SPECS, _offsets186):
    _codes186 = compiler._eur_explan_menu_encode(_source186)
    _struct186.pack_into('<' + 'h' * (len(_codes186) + 1), _fixture186, _off186, *(_codes186 + [-2]))
_child2_before186 = bytes(_fixture186[0x21580:0x32340])
_patched186, _info186 = compiler._eur_patch_explan_menu_labels_blob(bytes(_fixture186))
assert len(_patched186) == len(_fixture186) and _info186['patched_count'] == 31
assert bytes(_patched186[0x21580:0x32340]) == _child2_before186
_specs186 = dict(compiler._EUR_EXPLAN_MENU_LABEL_SPECS)
assert _specs186["Chambre d'Harman"] == 'Cuarto de Harman'
assert _specs186['Combat au pistolet'] == 'Combate con pistola'
assert _specs186['Récupération du corps'] == 'Recuperacion del cuerpo'
assert _specs186['Sur les aptitudes spéciales'] == 'Sobre habilidades especiales'
assert _specs186['Kevin (aptitudes spéciales)'] == 'Kevin (habilidades especiales)'
_patched186b, _info186b = compiler._eur_patch_explan_menu_labels_blob(_patched186)
assert _patched186b == _patched186 and all(x['already_patched'] for x in _info186b['patches'])
print('EXPLAN_CHILD1_COMPLETE_ES_GUARD_OK', _info186['patched_count'])
# v1.7.7.190: traducir sólo los textos del child 2 / exlog, conservando
# Jean DePaul y sin modificar child 0/1 ni el tamaño de explan_f.dat.
_fixture190 = bytearray(0x32380)
_fixture190[:4] = b'DAR\0'
_struct186.pack_into('<I', _fixture190, 8, 3)
_struct186.pack_into('<3I', _fixture190, 0x10, 0x80, 0x18D80, 0x21580)
_struct186.pack_into('<3I', _fixture190, 0x30, 0x18CB8, 0x87A0, 0x10DC0)
_fixture190[0x21580:0x32340] = b'\xff' * 0x10DC0
_cursor190 = 0x21580 + 0x100
for _source190, _target190, _count190 in compiler._EUR_EXPLAN_CHILD2_LABEL_SPECS:
    for _ in range(_count190):
        _codes190 = compiler._eur_explan_log_encode(_source190)
        _struct186.pack_into('<' + 'h' * (len(_codes190) + 1), _fixture190, _cursor190, *(_codes190 + [-2]))
        _cursor190 += 0x1A8
_codes190_name = compiler._eur_explan_log_encode('Jean DePaul')
_struct186.pack_into('<' + 'h' * (len(_codes190_name) + 1), _fixture190, _cursor190, *(_codes190_name + [-2]))
_child01_before190 = bytes(_fixture190[:0x21580])
_patched190, _info190 = compiler._eur_patch_explan_child2_labels_blob(bytes(_fixture190))
assert len(_patched190) == len(_fixture190)
assert _info190['patched_unique'] == 42 and _info190['patched_occurrences'] == 53
assert bytes(_patched190[:0x21580]) == _child01_before190
assert _info190['preserved'] and _info190['preserved'][0]['text'] == 'Jean DePaul'
_specs190 = {src: (dst, cnt) for src, dst, cnt in compiler._EUR_EXPLAN_CHILD2_LABEL_SPECS}
assert _specs190['Introduction'] == ('Introduccion', 1)
assert _specs190["L'ennemi"] == ('El enemigo', 1)
assert _specs190['Entrée'] == ('Entrada', 6)
assert _specs190['Église RDC'] == ('Iglesia planta baja', 1)
assert _specs190['Dernier avertissement'] == ('Ultimo aviso', 1)
_patched190b, _info190b = compiler._eur_patch_explan_child2_labels_blob(_patched190)
assert _patched190b == _patched190 and all(x['already_patched'] for x in _info190b['patches'])
print('EXPLAN_CHILD2_ES_GUARD_OK', _info190['patched_occurrences'])
# v1.7.7.184: the two 256x64 difficulty descriptions must use a monotonic
# pure-white GS alpha ramp rather than the non-monotonic retail French CLUT.
_diff_asset = app.Path(compiler.__file__).resolve().parent / 'eur_base' / compiler._EUR_DIFFICULTY_PATCHED_FILE
_diff_clut = compiler._eur_verify_difficulty_white_clut(_diff_asset.read_bytes())
assert len(_diff_clut['textures']) == 2 and _diff_clut['gs_alpha_max'] == 128
print('DIFFICULTY_WHITE_CLUT_GUARD_OK', _diff_clut)
# v1.7.7.189: ambas descripciones deben compartir las mismas métricas de raster.
_m189 = compiler._EUR_DIFFICULTY_DESC_FONT_METRICS
assert _m189['family'] == 'Open Sans Condensed Light'
assert _m189['size'] == 21 and _m189['origin_x'] == 3
assert _m189['line_y'] == [4, 26] and _m189['texture_size'] == [256, 64]
assert compiler.hashlib.sha256(_diff_asset.read_bytes()).hexdigest() == compiler._EUR_DIFFICULTY_PATCHED_SHA256
print('DIFFICULTY_EQUAL_FONT_GUARD_OK', _m189)
codec = compiler._eur_verify_scene_selector_chapter_codec()
sprite = compiler._eur_verify_scene_selector_angel_sprite_constants()
all_sprites = compiler._eur_verify_scene_selector_all_sprite_constants()
map_clut = compiler._eur_verify_map_clut_csm1()
map_es = compiler._eur_verify_map_raster_spanish_assets()
mission_pairs = compiler._eur_verify_mission_pair_alignment()
mission_fonts = compiler._eur_verify_all_mission_font_codecs()
jmb_mirror = compiler._eur_verify_jmb_dar_mirror_helper()
floor_labels = compiler._eur_verify_numeric_floor_label_constants()
st00_line1 = compiler._eur_st00font_encode_spanish('Arrasa la base Heaven Smile')
st00_line2 = compiler._eur_st00font_encode_spanish('y captura vivo al jefe.')
blood_catalog = compiler._eur_verify_blood_room_catalog()
assert hasattr(compiler, '_eur_patch_bloodfontf_spanish')
assert hasattr(compiler, '_eur_patch_st00fontf_mission33')
assert hasattr(compiler, '_eur_patch_remaining_mission_fonts')
assert mission_fonts['phase_count'] == 13 and mission_fonts['pair_aligned']
assert floor_labels['expected_min_units'] == 37
assert floor_labels['targets']['1st Floor'] == 'Planta 1'
assert floor_labels['targets']['5th Floor'] == 'Planta 5'
assert floor_labels['targets']['Top-floor'] == 'Última planta'
assert floor_labels['targets']['Upstairs'] == 'Planta superior'
assert floor_labels['targets']['Downstairs'] == 'Planta inferior'
assert st00_line1 == b'Qrra\xe9a la Da\xe9e Heaven Smile', st00_line1
assert st00_line2 == b'h captura vivG al .efe\'', st00_line2
assert st00_line1.count(b'e') >= 1 and b'e' in st00_line2  # e sigue nativa (0x65)
# v1.7.7.161: muestras representativas de las stXXFont restantes.
assert compiler._eur_direct_target_bytes(('k7-9005-16-00',), 'Elimina al gobernador Toru Fukushima.') == b'E\xfcimina a\xfc goBernador Toru Fukushima. ' 
assert compiler._eur_direct_target_bytes(('k7-9005-20-00',), 'Mata al dibujante de cómics,') == b'Mata al dib\xfcCante de c\xf6micsg'
assert compiler._eur_direct_target_bytes(('k7-9005-28-00',), 'Duelo final.') == b'\xc9uedo fpvcd.'
assert compiler._eur_direct_target_bytes(('k7-9005-30-00',), 'alto cargo del Partido Demócrata.') == b'alto carpo del Partido Demycrata. '
assert core.Killer7Project._direct_string_ok('all you need is Blood')

# v1.7.7.155: cinematic wording guard, including migration of legacy sidecars.
expected_cinema = {
    '399:5': 'He sido ELEGIDO',
    '401:5': 'He sido ELEGIDO',
    '399:6': 'Mierda. Son mas de 14',
    '401:6': 'Mierda. Son mas de 14',
}
bundled = app.Path(app.__file__).resolve().parent.parent / 'Killer7EUR_cinematicas_es.json'
loaded = app.App._read_eur_cinematic_file(None, bundled)
for key, value in expected_cinema.items():
    assert loaded.get(key) == value, (key, loaded.get(key), value)
legacy = {
    'format': 'killer7-eur-cinematic-translations',
    'version': 1,
    'serial': 'SLES_533.66',
    'translations': {
        '399:5': 'Me han elegido.', '401:5': 'Me han elegido.',
        '399:6': 'Joder. Hay más de 14.', '401:6': 'Joder. Hay más de 14.',
        '999:0': 'Personalizado',
    },
}
with tempfile.TemporaryDirectory() as td:
    lp = app.Path(td) / 'legacy.json'
    lp.write_text(json.dumps(legacy, ensure_ascii=False), encoding='utf-8')
    migrated = app.App._read_eur_cinematic_file(None, lp)
    for key, value in expected_cinema.items():
        assert migrated.get(key) == value, (key, migrated.get(key), value)
    assert migrated.get('999:0') == 'Personalizado'

print('SCENE_SELECTOR_CODEC_OK', codec)
print('SCENE_SELECTOR_ANGEL_SPRITE_GUARD_OK', sprite)
print('SCENE_SELECTOR_ALL_CHAPTER_SPRITES_OK', all_sprites)
print('MAP_CLUT_CSM1_OK', map_clut)
print('MAP_RASTER_SPANISH_ASSETS_OK', map_es)
print('MISSION_PAIR_ALIGNMENT_OK', mission_pairs)
print('ALL_MISSION_FONTS_CODEC_OK', mission_fonts)
print('JMB_DAR_MIRROR_HELPER_OK', jmb_mirror)
print('K7P2_FLOOR_LABELS_ES_OK', floor_labels)
print('ST00FONT_HEAVEN_SMILE_CODEC_OK', {
    'line1': st00_line1.hex().upper(), 'line2': st00_line2.hex().upper(),
    'e_native': True,
})
print('BLOOD_ROOM_CATALOG_OK', blood_catalog)
print('BLOODFONTF_SPANISH_CODEC_OK', {'á':'à','í':'î','ó':'ô','¿':'Ç','¡':'È'})
print('CINEMATIC_SUBTITLE_WORDING_OK', expected_cinema)
# v1.7.7.156: Iwazaru punctuation verified against the actual EUR game resource.
from pathlib import Path as _P
import xml.etree.ElementTree as _ET
_src_expected = [
    'Master.', "We're in a tight spot.", 'A real tight spot.',
    "Like, I haven't seen you for ages.", 'It is I, Vincel Dill Boris VII,',
    'Iwazaruscof, at your service.', 'Just call me Iwazaru.',
    'Let me show you along the way.', "To the right, master's room.",
    'Straight ahead, the enemy.', 'Let the bloodbath begin.',
    'In the name of Harman...',
]
_tgt_expected = [
    'Maestro.',
    'Estamos en un aprieto.',
    'Un aprieto de verdad.',
    'Vaya, hace siglos sin verle.',
    'Soy yo, Vincel Dill Boris VII,',
    'Iwazaruscof, a su servicio.',
    'Llámeme Iwazaru.',
    'Déjeme mostrarle el camino.',
    'A su derecha, la habitación del Maestro.',
    'Más adelante, el enemigo.',
    'Que empiece el baño de sangre.',
    'En nombre de Harman...',
]
_xlf = _P(app.__file__).resolve().parent / 'master' / 'Killer7_SLUS-21154_master_ES_started.xlf'
_rt = _ET.parse(_xlf).getroot()
_ns = {'x':'urn:oasis:names:tc:xliff:document:2.0'}
_ff = next(f for f in _rt.findall('.//x:file', _ns) if f.get('id') == 'K7_0765_0071010_da')
_rows=[]
for _u in _ff.findall('x:unit', _ns):
    _seg=_u.find('x:segment', _ns)
    _rows.append((_seg.findtext('x:source', default='', namespaces=_ns), _seg.findtext('x:target', default='', namespaces=_ns)))
assert [a for a,b in _rows] == _src_expected, _rows
assert [b for a,b in _rows] == _tgt_expected, _rows
print('IWAZARU_GAME_PUNCTUATION_OK', len(_rows))
# v1.7.7.206: button/emoticon symbols newly used by revised .da translations
# must come from verified French retail glyph donors, never an external font.
assert compiler._EUR_DA_FRENCH_GLYPH_REFS['□'] == ('0074070F.da', 36)
assert compiler._EUR_DA_FRENCH_GLYPH_REFS['△'] == ('0112030F.da', 52)
assert compiler._EUR_DA_FRENCH_GLYPH_REFS['○'] == ('0121110F.da', 41)
assert compiler._EUR_DA_FRENCH_GLYPH_REFS['¯'] == ('0112030F.da', 40)
print('DA_BUTTON_GLYPHS_FR_RETAIL_GUARD_OK', '□ △ ○ ¯')
# v1.7.7.158: the blood interface block must expose all eight real strings.
_bf = next(f for f in _rt.findall('.//x:file', _ns) if f.get('id') == 'K7_9001_Interfaz___sangre')
_brows=[]
for _u in _bf.findall('x:unit', _ns):
    _seg=_u.find('x:segment', _ns)
    _brows.append((_u.get('id'), _seg.findtext('x:source', default='', namespaces=_ns), _seg.findtext('x:target', default='', namespaces=_ns)))
assert len(_brows) == 8, _brows
assert _brows[-1] == ('k7-9001-07-00', 'all you need is Blood', 'Sangre y nada más'), _brows[-1]
print('BLOOD_ROOM_XLIFF_8_OF_8_OK', _brows[-1])
# v1.7.7.164: category classifier must keep the visual editor families separate.
from types import SimpleNamespace as _SNS
_category_cases = [
    ('objectives', _SNS(id='K7_9005_Misiones', storage_kind='iso_ascii', context='Misiones', name='Misiones')),
    ('jmb', _SNS(id='J', storage_kind='afs_pair', context='Angel', name='J')),
    ('subtitles', _SNS(id='S', storage_kind='afs_da', context='Angel', name='S')),
    ('cinematics', _SNS(id='C', storage_kind='afs_cinematic_da', context='Cinemática / diálogo', name='C')),
    ('map', _SNS(id='M', storage_kind='afs_k7p2_eur', context='Mapa / rutas / localizadores K7P2', name='M')),
    ('interface', _SNS(id='I', storage_kind='elf_strings', context='Interfaz · menú principal', name='I')),
    ('selector', _SNS(id='EUR_SCENE_SELECTOR', storage_kind='eur_scene_selector', context='Selector de escenas', name='SEL')),
    ('direct', _SNS(id='D', storage_kind='iso_ascii', context='Combate', name='D')),
    ('graphics', _SNS(id='G', storage_kind='afs_graphic_ref', context='Título gráfico', name='G')),
]
for _expected, _block in _category_cases:
    assert app.App._text_category_for_block(_block) == _expected, (_expected, app.App._text_category_for_block(_block))
assert [x[0] for x in app.App.__new__(app.App).__dict__.get('text_category_specs', [])] == []  # state is initialized by __init__
print('TEXT_CATEGORY_TABS_CLASSIFIER_OK', len(_category_cases))
# v1.7.7.188: launcher loading indicator must remain above Seleccionar ISO,
# and translation must be protected while the ISO is being prepared.
import inspect as _inspect188
_launcher188 = _inspect188.getsource(app.App._show_launcher)
_loading188 = _inspect188.getsource(app.App._set_launcher_loading)
_openiso188 = _inspect188.getsource(app.App.open_iso)
assert "text='Cargando...'" in _launcher188
assert "self.launcher_translate_button.config(state=tk.DISABLED)" in _launcher188
assert "item_state = 'normal' if loading else 'hidden'" in _loading188
assert "self._set_launcher_loading(True)" in _openiso188
assert "self._set_launcher_loading(False)" in _openiso188
print('LAUNCHER_LOADING_INDICATOR_GUARD_OK')
# v1.7.7.165: UI layout guard without requiring an X display.
import inspect as _inspect
_build_src = _inspect.getsource(app.App._build)
assert "self.inject_texts_button.pack(side=tk.LEFT, padx=(8, 0))" in _build_src
assert "self.image_scan_button.pack" not in _build_src
assert "format_info.pack" not in _build_src
assert "project_actions.pack" not in _build_src
assert "experimental_actions.pack" not in _build_src
assert "textvariable=self.source_state_var" not in _build_src
print('UI_HEADER_CLEANUP_OK')
# v1.7.7.181: launcher gráfico 824x450 con tres accesos directos.
_launcher_src_181 = _inspect.getsource(app.App._show_launcher)
assert "add_button('Seleccionar ISO'" in _launcher_src_181
assert "add_button('Traducir al Español'" in _launcher_src_181
assert "add_button('Editor de Textos'" in _launcher_src_181
assert 'launcher_background.jpg' in _launcher_src_181
_bg181 = _P(app.__file__).resolve().parent / 'launcher_background.jpg'
assert _bg181.exists(), _bg181
from PIL import Image as _Image181
with _Image181.open(_bg181) as _im181:
    assert _im181.size == (824, 450), _im181.size
_editor_src_181 = _inspect.getsource(app.App._show_text_editor)
assert "self.geometry('1280x850')" in _editor_src_181
print('LAUNCHER_IMAGE_MENU_OK', _bg181.name, (824, 450))
# v1.7.7.183: el launcher sólo debe mostrar tres botones y ningún cuarto bloque vacío.
assert _launcher_src_181.count('add_button(') == 4  # definición + 3 llamadas
assert "canvas.create_window(58, 339" not in _launcher_src_181
assert 'textvariable=self.launcher_status_var' not in _launcher_src_181
print('LAUNCHER_BUTTON_CLEANUP_OK')
# v1.7.7.166: unified project save and delta log guard.
_build_src_166 = _inspect.getsource(app.App._build)
_menu_src_166 = _inspect.getsource(app.App._build_menu)
_ctrl_src_166 = _inspect.getsource(app.App._ctrl_save)
assert "text='Guardar Proyecto'" in _build_src_166
assert "Cargar traducción XLIFF…" not in _build_src_166
assert "Guardar bloque…" not in _build_src_166
assert "Guardar proyecto maestro…" not in _build_src_166
assert "label='Guardar Proyecto'" in _menu_src_166
assert "Cargar traducción XLIFF…" not in _menu_src_166
assert 'self.save_project()' in _ctrl_src_166
_before = {'k': {'target':'Antes', 'source':'Original', 'block_id':'B', 'directory':'D', 'unit_id':'U'}}
_after = {'k': {'target':'Después', 'source':'Original', 'block_id':'B', 'directory':'D', 'unit_id':'U'}}
_diff = app.App._project_text_differences(_before, _after)
assert len(_diff) == 1 and _diff[0]['before'] == 'Antes' and _diff[0]['after'] == 'Después', _diff
assert app.App._project_text_differences(_after, _after) == []
with tempfile.TemporaryDirectory() as _td:
    _dummy = app.App.__new__(app.App)
    _dummy.project_log_path = app.Path(_td) / 'CAMBIOS_PROYECTO.log'
    _dummy.eur_view_mode = True
    _dummy.eur_iso_path = app.Path('/tmp/Killer7EUR.iso')
    _dummy.project = None
    _dummy.text_category_specs = [('cinematics','Cinemáticas')]
    _dummy._program_root = lambda: app.Path(_td)
    _dummy._append_project_change_log([{
        'category':'cinematics','block_label':'Prueba','block_id':'B','directory':'D_EU/DIR_E.AFS#1742',
        'unit_id':'U','source':"Balle d'âmes reçue",'before':"Balle d'âmes reçue",'after':'Has obtenido una Soul Shell'
    }], [])
    _log = _dummy.project_log_path.read_text(encoding='utf-8')
    assert 'D_EU/DIR_E.AFS#1742' in _log and 'Has obtenido una Soul Shell' in _log and 'Balle d' in _log
print('SAVE_PROJECT_LOG_GUARD_OK')
# v1.7.7.167: regression guard for the crash shown as KeyError 'unit_ids' when
# «Inyectar Textos» reached the Memory Card verification pass.
_max_mem = max(o for o, _e, _t in compiler._EUR_DIRECT_MEMORY_CARD_SPECS)
_mem_blob = bytearray(_max_mem + 0x400)
for _off, _expected, _target in compiler._EUR_DIRECT_MEMORY_CARD_SPECS:
    _raw = _expected if isinstance(_expected, bytes) else _expected.encode('latin-1')
    _mem_blob[_off:_off+len(_raw)] = _raw
    _mem_blob[_off+len(_raw)] = 0
# El siguiente literal actúa como fin de cada slot; para el último dejamos un
# centinela al final del fixture.
_mem_blob[-1] = 0x7f
_mem_ids = {'k7-9010-00-00'}
_mem_patched, _mem_info = compiler._eur_patch_memory_card_french(bytes(_mem_blob), _mem_ids)
assert _mem_info['verified_contexts'] == len(compiler._EUR_DIRECT_MEMORY_CARD_SPECS)
assert all(row.get('unit_ids') for row in _mem_info['changes'])
print('INJECT_MEMORY_CARD_UNIT_IDS_OK', _mem_info['verified_contexts'])
# v1.7.7.204: 77102 conserva el patrón in-place validado en juego, pero
# ahora traduce también la segunda unidad textual (Coffre ouvert -> Cofre abierto).
assert compiler._EUR_77102_SOUL_TARGET == 'Soul Shell hallada'
_src176 = _inspect.getsource(compiler._eur_patch_77102_inplace_runtime)
assert '1739' in _src176 and '1741' in _src176
assert "targets = ['Soul Shell hallada', 'Cofre abierto']" in _src176
assert "char_num 17 unchanged" in _src176
assert '_eur_rebuild_jmb_dic_mirror_dar' in _src176
_shadow_src_170 = _inspect.getsource(compiler._eur_write_original_extent_shadow)
assert 'same-size' in _shadow_src_170.lower() or 'same_size' in _shadow_src_170.lower()
print('SOUL_SHELL_ALL_UNITS_INPLACE_GUARD_OK')
# v1.7.7.178: el AFS principal debe volver a ser estrictamente secuencial;
# 77102F retail se conserva sólo mediante el runtime shadow del extent antiguo.
_rebuild178 = _inspect.getsource(compiler._eur_rebuild_afs)
_apply178 = _inspect.getsource(compiler.apply_current_spanish_to_eur_iso)
assert "layout': 'sequential-v172'" in _rebuild178
assert "offsets_monotonic': True" in _rebuild178
assert 'pinned_offsets' not in _rebuild178
assert 'write_order = sorted' not in _rebuild178
assert 'relocate_afs' not in _apply178
assert '_iso_append_and_relocate_file(' in _apply178
assert '_eur_write_original_extent_shadow(' in _apply178
assert "with rebuilt_afs.open('rb') as src_afs" not in _apply178

import struct as _struct178
# Fixture AFS realista (1745 entradas) para verificar la regresión que originó v178.
# Un replacement crece antes de 77102: el AFS principal debe desplazarlo de forma
# secuencial, mientras el shadow debe mantener los tres slots retail exactos.
with tempfile.TemporaryDirectory() as _td178:
    _td178 = _P(_td178)
    _src178 = _td178 / 'source.afs'
    _out178 = _td178 / 'rebuilt.afs'
    _count178 = 1745
    _hdr178 = 8 + 8 * _count178 + 8
    _first178 = compiler._eur_align(_hdr178)
    _entries178 = []
    _pos178 = _first178
    for _i178 in range(_count178):
        _entries178.append((_pos178, 1))
        _pos178 = compiler._eur_align(_pos178 + 1)
    _name_off178 = compiler._eur_align(_pos178)
    _names178 = bytearray(_count178 * 48)
    for _i178 in range(_count178):
        _nm178 = ('77102' if _i178 in (1742,1743,1744) else f'{_i178:05d}').encode('ascii')
        _names178[_i178*48:_i178*48+len(_nm178)] = _nm178
    with _src178.open('wb') as _f178:
        _f178.write(b'AFS\0')
        _f178.write(_struct178.pack('<I', _count178))
        for _off178, _sz178 in _entries178:
            _f178.write(_struct178.pack('<II', _off178, _sz178))
        _f178.write(_struct178.pack('<II', _name_off178, len(_names178)))
        if _f178.tell() < _first178:
            _f178.write(b'\0' * (_first178 - _f178.tell()))
        for _i178, (_off178, _sz178) in enumerate(_entries178):
            if _f178.tell() < _off178:
                _f178.write(b'\0' * (_off178 - _f178.tell()))
            _f178.write(bytes([_i178 & 0xff]))
        if _f178.tell() < _name_off178:
            _f178.write(b'\0' * (_name_off178 - _f178.tell()))
        _f178.write(_names178)
    _rep178 = {100: b'X' * 2050, 345:b'A', 361:b'B', 365:b'C', 1742:b'J', 1743:b'D', 1744:b'I'}
    _meta178 = compiler._eur_rebuild_afs(_src178, _out178, _rep178)
    _new178, *_ = compiler._eur_parse_afs(_out178)
    assert _meta178['offsets_monotonic'] and _meta178['pinned_islands'] == []
    assert all(_new178[i][0] < _new178[i+1][0] for i in range(_count178-1))
    assert _new178[1742][0] != _entries178[1742][0]  # creció #100: no hay pinning.
    _iso178 = _td178 / 'shadow.bin'
    _base178 = 4096
    with _iso178.open('wb') as _f178:
        _f178.write(b'Z' * _base178)
        _f178.write(_src178.read_bytes())
    with _iso178.open('r+b') as _f178:
        _shadow178 = compiler._eur_write_original_extent_shadow(_f178, _src178, _base178, _rep178)
    assert _shadow178['enabled']
    with _iso178.open('rb') as _f178:
        for _idx178 in (1742,1743,1744):
            _f178.seek(_base178 + _entries178[_idx178][0])
            assert _f178.read(1) == _rep178[_idx178]
print('SEQUENTIAL_AFS_RUNTIME_SHADOW_GUARD_OK')
# v1.7.7.179: barrido exacto global de espejos 77102, incluidos hijos anidados.
with tempfile.TemporaryDirectory() as _td179:
    _td179 = _P(_td179)
    _img179 = _td179 / 'iso.bin'
    _oldj179, _newj179 = b'JMB-OLD', b'JMB-ESP'
    _oldd179, _newd179 = b'DIC-OLD', b'DIC-ESP'
    _olddar179 = b'DAR<' + _oldj179 + b'|' + _oldd179 + b'>'
    _newdar179 = b'DAR<' + _newj179 + b'|' + _newd179 + b'>'
    _img179.write_bytes(b'AA' + _oldj179 + b'BB' + _olddar179 + b'CC' + _oldd179 + b'ZZ')
    _orig179 = {1742:_oldj179, 1743:_olddar179, 1744:_oldd179}
    _new179 = {1742:_newj179, 1743:_newdar179, 1744:_newd179}
    _pos179 = compiler._eur_scan_exact_payload_positions(_img179, _orig179, chunk_size=11)
    assert len(_pos179[1742]) == 2 and len(_pos179[1743]) == 1 and len(_pos179[1744]) == 2, _pos179
    with _img179.open('r+b') as _fh179:
        _rep179 = compiler._eur_patch_exact_payload_positions(_fh179, _pos179, _orig179, _new179)
    _final179 = _img179.read_bytes()
    assert _oldj179 not in _final179 and _oldd179 not in _final179 and _olddar179 not in _final179
    assert _rep179['match_counts'] == {'1743': 1, '1742': 2, '1744': 2}, _rep179
print('GLOBAL_77102_EXACT_MIRRORS_GUARD_OK')
# v1.7.7.180: el mensaje visible de Soul Shell vive en el JMB global de mes_f.dat,
# no en 77102F. Fixture sintético con la misma geometría retail observada en s(9).
import struct as _struct180
_child0_180 = bytearray(0x80)
_child0_180[:8] = b'STRIMAGS'
_struct180.pack_into('<I', _child0_180, 0x18, 107)
_child1_180 = bytearray(0x80)
_child1_180[:4] = b'MEP\0'
_jmb180 = bytearray(151264)
_struct180.pack_into('<hhIII', _jmb180, 0, 22, 29, 104, 151024, 151264)
_soul_off180 = 104 + 7 * compiler.JMB_SCENE_SIZE + 76 + 8
_neigh_off180 = 104 + 8 * compiler.JMB_SCENE_SIZE + 76 + 8
_src_slots180 = list(compiler._EUR_MES_F_SOUL_SOURCE_CODES) + [-2] + [-1] * (compiler.JMB_CODE_SLOTS - len(compiler._EUR_MES_F_SOUL_SOURCE_CODES) - 1)
_ngh_slots180 = list(compiler._EUR_MES_F_SCENE8_CODES) + [-2] + [-1] * (compiler.JMB_CODE_SLOTS - len(compiler._EUR_MES_F_SCENE8_CODES) - 1)
_struct180.pack_into(f'<{compiler.JMB_CODE_SLOTS}h', _jmb180, _soul_off180, *_src_slots180)
_struct180.pack_into(f'<{compiler.JMB_CODE_SLOTS}h', _jmb180, _neigh_off180, *_ngh_slots180)
_off0_180, _off1_180, _off2_180 = 0x80, 0x100, 0x180
_size0_180, _size1_180, _size2_180 = len(_child0_180), len(_child1_180), len(_jmb180)
_mes180 = bytearray(_off2_180 + _size2_180)
_mes180[:4] = b'DAR\0'
_struct180.pack_into('<I', _mes180, 8, 3)
_struct180.pack_into('<III', _mes180, 0x10, _off0_180, _off1_180, _off2_180)
_struct180.pack_into('<III', _mes180, 0x30, _size0_180, _size1_180, _size2_180)
_mes180[_off0_180:_off0_180+_size0_180] = _child0_180
_mes180[_off1_180:_off1_180+_size1_180] = _child1_180
_mes180[_off2_180:_off2_180+_size2_180] = _jmb180
_mes180_before = bytes(_mes180)
_mes180_after, _info180 = compiler._eur_patch_mes_f_soul_shell(_mes180_before)
assert len(_mes180_after) == len(_mes180_before)
assert _info180['source'] == "Balle d'âmes reçue"
assert _info180['target'] == 'Soul Shell hallada'
_abs180 = _off2_180 + _soul_off180
_vals180 = list(_struct180.unpack_from(f'<{compiler.JMB_CODE_SLOTS}h', _mes180_after, _abs180))
_target180 = [-4 if ch == ' ' else compiler._EUR_MES_F_SOUL_CHAR_CODES[ch] for ch in compiler._EUR_MES_F_SOUL_TARGET]
assert _vals180[:_vals180.index(-2)] == _target180
assert _mes180_before[:_abs180] == _mes180_after[:_abs180]
assert _mes180_before[_abs180+64:] == _mes180_after[_abs180+64:]
print('MES_F_SOUL_SHELL_GUARD_OK', _info180['jmb_char_data_offset'])

# v1.7.7.182: generalización del mismo JMB global de mes_f.dat.
# Se verifican los 12 avisos confirmados, todos same-size y sólo en char_data.
_child0_182 = bytearray(0x80)
_child0_182[:8] = b'STRIMAGS'
_struct180.pack_into('<I', _child0_182, 0x18, 107)
_child1_182 = bytearray(0x80)
_child1_182[:4] = b'MEP\0'
_jmb182 = bytearray(151264)
_struct180.pack_into('<hhIII', _jmb182, 0, 22, 29, 104, 151024, 151264)
for _scene182, _source182, _target182 in compiler._EUR_MES_F_GLOBAL_MESSAGE_SPECS:
    _off182 = 104 + _scene182 * compiler.JMB_SCENE_SIZE + 76 + 8
    _codes182 = compiler._eur_mes_f_encode_global_text(_source182)
    _slots182 = _codes182 + [-2] + [-1] * (compiler.JMB_CODE_SLOTS - len(_codes182) - 1)
    _struct180.pack_into(f'<{compiler.JMB_CODE_SLOTS}h', _jmb182, _off182, *_slots182)
    _ring182 = compiler._EUR_MES_F_RING_BY_SCENE.get(_scene182)
    if _ring182 is not None:
        _struct180.pack_into('<II', _jmb182, _off182 - 8, int(_ring182['item_id']) * 4800, 4800)
# Placeholders retail no traducibles: una sola ``a``.
for _scene182 in (0,1,3,4,6,9,10,12,13,14):
    _off182 = 104 + _scene182 * compiler.JMB_SCENE_SIZE + 76 + 8
    _slots182 = [compiler._EUR_MES_F_GLOBAL_CHAR_CODES['a'], -2] + [-1] * (compiler.JMB_CODE_SLOTS - 2)
    _struct180.pack_into(f'<{compiler.JMB_CODE_SLOTS}h', _jmb182, _off182, *_slots182)
_off0_182, _off1_182, _off2_182 = 0x80, 0x100, 0x180
_mes182 = bytearray(_off2_182 + len(_jmb182))
_mes182[:4] = b'DAR\0'
_struct180.pack_into('<I', _mes182, 8, 3)
_struct180.pack_into('<III', _mes182, 0x10, _off0_182, _off1_182, _off2_182)
_struct180.pack_into('<III', _mes182, 0x30, len(_child0_182), len(_child1_182), len(_jmb182))
_mes182[_off0_182:_off0_182+len(_child0_182)] = _child0_182
_mes182[_off1_182:_off1_182+len(_child1_182)] = _child1_182
_mes182[_off2_182:_off2_182+len(_jmb182)] = _jmb182
_before182 = bytes(_mes182)
_after182, _info182 = compiler._eur_patch_mes_f_global_messages(_before182)
assert len(_after182) == len(_before182)
assert _info182['patched_count'] == 12, _info182
assert _info182['patched_scenes'] == [2,5,7,8,11,15,16,17,18,19,20,21]
_ring_specs194 = {scene: (item_id, ring, target) for scene, item_id, ring, target in compiler._EUR_MES_F_RING_SCENE_SPECS}
assert _ring_specs194 == {
    16: (48, 'Time Ring selector', 'muestras de color obtenidas'),
    17: (47, 'Wind Ring selector', 'muestras de color obtenidas'),
    18: (46, 'Stamina Ring selector', 'muestras de color obtenidas'),
    19: (50, 'Fire Ring selector', 'muestras de color obtenidas'),
    20: (49, 'Water Ring selector', 'muestras de color obtenidas'),
    21: (45, 'Power Ring selector', 'muestras de color obtenidas'),
}
assert len(_info182['ring_scenes']) == 6
assert {x['scene']: x['item_id'] for x in _info182['ring_scenes']} == {16:48,17:47,18:46,19:50,20:49,21:45}
assert next(x for x in _info182['ring_scenes'] if x['scene'] == 19)['target'] == 'muestras de color obtenidas'
for _scene194, (_item194, _ring194, _target194) in _ring_specs194.items():
    _codes194 = compiler._eur_mes_f_encode_global_text(_target194, ring=True)
    assert len(_codes194) <= compiler.JMB_MAX_CODES
    # Todos los caracteres deben existir ya en el SystemF retail.
    assert all(ch == ' ' or ch in compiler._EUR_MES_F_GLOBAL_CHAR_CODES for ch in _target194)
for _patch182 in _info182['patches']:
    _vals182 = list(_struct180.unpack_from(
        f'<{compiler.JMB_CODE_SLOTS}h', _after182, _patch182['jmb_char_data_offset']
    ))
    assert _vals182[:_vals182.index(-2)] == _patch182['target_codes']
# Los placeholders no se tocan.
for _scene182 in (0,1,3,4,6,9,10,12,13,14):
    _rel182 = 104 + _scene182 * compiler.JMB_SCENE_SIZE + 76 + 8
    _abs182 = _off2_182 + _rel182
    assert _before182[_abs182:_abs182+64] == _after182[_abs182:_abs182+64]
print('MES_F_GLOBAL_MESSAGES_ES_GUARD_OK', _info182['patched_count'])
print('MES_F_COLOR_SAMPLES_SELECTOR_GUARD_OK', len(_info182['ring_scenes']))
# v1.7.7.201: las variantes Échantillons couleur no modifican SystemF.
_src194 = open(compiler.__file__, 'r', encoding='utf-8').read()
_build194 = _src194.split('def _eur_build_replacements', 1)[1].split('def ', 1)[0]
assert '_eur_patch_mes_systemf_ring_glyphs' not in _build194
assert 'ring_font_strategy' in _src194
assert _info182['ring_systemf_extra_codes'] == {}
assert _info182['ring_font_strategy'] == 'retail-SystemF-unchanged'
print('MES_F_COLOR_SAMPLES_RETAIL_SYSTEMF_GUARD_OK')
# v1.7.7.199 TEST: el mensaje real «Anneau de feu récupéré» se parchea en
# K7_0750_7730 -> EUR 77304 (#1793-1795), no mediante SystemF.
from pathlib import Path as _Path199
import struct as _struct199
_res199 = _Path199(compiler.__file__).resolve().parent
_xlf199 = (_res199 / 'master' / 'Killer7_SLUS-21154_master_ES_started.xlf').read_text(encoding='utf-8')
assert '<ns0:target>Anillo de llama obtenido</ns0:target>' in _xlf199
_mpath199 = _res199 / 'eur_base' / 'compiled_es_4759' / 'manifest.json'
_manifest199 = json.loads(_mpath199.read_text(encoding='utf-8'))
_block199 = next(b for b in _manifest199['blocks'] if b.get('file_id') == 'K7_0750_7730')
assert int(_block199.get('added_glyphs', {}).get('m', -1)) == 36, _block199
_entries199 = {(int(r['index']), r['kind']): r for r in _manifest199['entries']}
_jrec199 = _entries199[(750, 'jmb')]
_jmb199 = (_mpath199.parent / _jrec199['file']).read_bytes()
_sn199, _cn199, _so199, _co199, _to199 = _struct199.unpack_from('<hhIII', _jmb199, 0)
assert (_sn199, _cn199, _co199, _to199) == (4, 37, 27472, 27776)
_off199 = _so199 + 76 + 8
_vals199 = list(_struct199.unpack_from(f'<{compiler.JMB_CODE_SLOTS}h', _jmb199, _off199))
_vals199 = _vals199[:_vals199.index(-2)]
assert _vals199 == [33,5,1,27,27,28,-4,9,3,-4,27,27,12,36,12,-4,28,11,7,3,5,1,9,28]
print('JMB_77304_FIRE_RING_TEST_GUARD_OK', _cn199, _block199['added_glyphs']['m'])
# v1.7.7.202: 77304 ya no usa ese JMB recompilado en runtime; se sobreescribe
# con un parche same-size sobre la terna francesa retail, como 77102.
assert compiler._EUR_77304_FIRE_RING_SOURCE == 'Anneau de feu récupéré'
assert compiler._EUR_77304_FIRE_RING_TARGET == 'Anillo de llama obtenido'
assert compiler._EUR_77304_M_SLOT == 6
assert compiler._EUR_77304_M_DST == (0, 72, 25, 36)
assert compiler._EUR_77304_M_DONOR_JMB == 1524
assert compiler._EUR_77304_M_DONOR_DIC == 1526
assert compiler._EUR_77304_M_DONOR_SLOT == 20
assert '_eur_patch_77304_inplace_runtime' in dir(compiler)
print('JMB_77304_FRENCH_INPLACE_GUARD_OK', compiler._EUR_77304_M_SLOT, compiler._EUR_77304_M_DST)
# v1.7.7.201: remapeo por frase/escena francesa real.
assert compiler._EUR_FR_ABSENT_PAIR_TRANSLATIONS == frozenset({'K7_0669_5540','K7_0684_5540'})
assert compiler._EUR_FR_SCENE_REMAPS['K7_0319_h_010'] == (
    (0,0),(1,1),(2,2),(3,3),(5,4),(6,5),(7,6),(8,7),(9,8),(10,9),(11,10)
)
_remap201 = compiler._eur_remap_compiled_jmb_scenes_to_french('K7_0319_h_010', _jmb199[:0]) if False else None
# Usa el payload real de h_010 para comprobar que desaparece sólo la escena EN 4.
_block201 = next(b for b in _manifest199['blocks'] if b.get('file_id') == 'K7_0319_h_010')
_jrec201 = _entries199[(int(_block201['jmb_index']), 'jmb')]
_jmb201_src = (_mpath199.parent / _jrec201['file']).read_bytes()
_jmb201, _info201 = compiler._eur_remap_compiled_jmb_scenes_to_french('K7_0319_h_010', _jmb201_src)
assert _info201['source_scene_count'] == 12
assert _info201['french_scene_count'] == 11
assert _info201['omitted_source_scenes'] == [4]
assert _struct199.unpack_from('<h', _jmb201, 0)[0] == 11
# Cada escena destino debe ser byte por byte la escena española fuente indicada.
_osn201, _ocn201, _oso201, _oco201, _oto201 = _struct199.unpack_from('<hhIII', _jmb201_src, 0)
_nsn201, _ncn201, _nso201, _nco201, _nto201 = _struct199.unpack_from('<hhIII', _jmb201, 0)
for _src201, _dst201 in compiler._EUR_FR_SCENE_REMAPS['K7_0319_h_010']:
    _a201 = _jmb201_src[_oso201 + _src201*compiler.JMB_SCENE_SIZE:_oso201 + (_src201+1)*compiler.JMB_SCENE_SIZE]
    _b201 = _jmb201[_nso201 + _dst201*compiler.JMB_SCENE_SIZE:_nso201 + (_dst201+1)*compiler.JMB_SCENE_SIZE]
    assert _a201 == _b201
print('EUR_FR_PHRASE_SCENE_REMAP_GUARD_OK', _info201)
# v1.7.7.171: map floor labels have a second, precompiled STRIMAGS layer.
import struct as _struct171
_codes171 = [ord('1'),ord('e'),ord('r'),ord('é'),ord('t'),ord('a'),ord('g'),ord('2'),ord('3'),ord('4'),ord('5'),ord('6'),ord(' ')]
_rows171 = [[c,0,0,1,1,0,0,1,1,c] for c in _codes171]
_by171 = {c:i for i,c in enumerate(_codes171)}
_ihe171 = bytearray(0x2000)
_cursor171 = 0x200
for _floor171 in range(1,7):
    _oldchars171 = '1er étage' if _floor171 == 1 else f'{_floor171}e étage'
    _oldseq171 = [_by171[ord(ch)] for ch in _oldchars171]
    _pat171 = b''.join(_struct171.pack('<H', n) for n in _oldseq171) + b'\xff\xff'
    _ihe171[_cursor171:_cursor171+len(_pat171)] = _pat171
    _cursor171 += 0x102
_rep171 = compiler._eur_map_floor_patch_sequence_table(_ihe171, _rows171, 'cel')
assert _rep171['sequence_count'] == 6, _rep171
_newseq171 = [_by171[ord(c)] for c in 'graeta 1']
_newpat171 = b''.join(_struct171.pack('<H', n) for n in _newseq171) + b'\xff\xff'
assert _newpat171 in bytes(_ihe171)
_src171 = _inspect.getsource(compiler.apply_current_spanish_to_eur_iso)
assert '_eur_force_77102_final_afs(rebuilt_afs, replacements)' in _src171
assert 'final_exact_indices = (1742, 1743, 1744, 345, 361, 365)' in _src171
assert compiler._EUR_MAP_FLOOR_SLOT_MAP == {'P':'g','l':'r','n':'e'}
print('MAP_FLOOR_STRIMAGS_SOUL_FINAL_GUARD_OK', _rep171['sequence_count'])
# v1.7.7.200: catálogo de los JMB/DIC franceses retail reales empaquetado.
import hashlib as _hashlib200, json as _json200
_cat200 = compiler._eur_fr_jmb_retail_catalog()
assert len(_cat200) == 118, len(_cat200)
_dar200 = 0
for _fid200, _rec200 in _cat200.items():
    for _kind200 in ('jmb', 'dic'):
        _fp200 = compiler._EUR_FR_JMB_RETAIL_DIR / _rec200[f'{_kind200}_file']
        _raw200 = _fp200.read_bytes()
        assert len(_raw200) == int(_rec200[f'{_kind200}_size'])
        assert _hashlib200.sha256(_raw200).hexdigest() == _rec200[f'{_kind200}_sha256']
    if _rec200.get('dar_index') is not None:
        _dar200 += 1
        _fp200 = compiler._EUR_FR_JMB_RETAIL_DIR / _rec200['dar_file']
        _raw200 = _fp200.read_bytes()
        assert len(_raw200) == int(_rec200['dar_size'])
        assert _hashlib200.sha256(_raw200).hexdigest() == _rec200['dar_sha256']
assert _dar200 == 89, _dar200
assert _cat200['K7_0750_7730']['jmb_index'] == 1793
assert _cat200['K7_0750_7730']['dic_index'] == 1795
assert _cat200['K7_0750_7730']['dar_index'] == 1794
assert _cat200['K7_0373_Select_j']['jmb_index'] == 767
assert _cat200['K7_0373_Select_j']['dic_index'] == 768
# v1.7.7.205: nueve familias PAL usan DIC -> JMB. La 204 emparejaba el
# JMB francés con el DIC alemán siguiente y producía texto corrupto en juego.
_expected205 = {
    'K7_0286_Handso': (307, 306), 'K7_0315_h_007': (528, 527),
    'K7_0317_h_007': (534, 533), 'K7_0319_h_010': (540, 539),
    'K7_0321_h_010': (546, 545), 'K7_0323_h_010': (552, 551),
    'K7_0325_h_020': (558, 557), 'K7_0327_h_035': (564, 563),
    'K7_0329_h_055': (570, 569),
}
assert compiler._EUR_FR_DIC_BEFORE_JMB_EXPECTED == _expected205
for _fid205, (_j205, _d205) in _expected205.items():
    _r205 = _cat200[_fid205]
    assert (int(_r205['jmb_index']), int(_r205['dic_index'])) == (_j205, _d205)
    _ret_dic205 = (compiler._EUR_FR_JMB_RETAIL_DIR / _r205['dic_file']).read_bytes()
    _esr205 = compiler._eur_fr_es_jmb_catalog()[_fid205]
    _es_dic205 = (compiler._EUR_FR_ES_JMB_DIR / _esr205['dic_file']).read_bytes()
    _ri205 = core.Killer7Project._dic_texture_info(_ret_dic205)
    _ei205 = core.Killer7Project._dic_texture_info(_es_dic205)
    assert _ri205 and _ei205 and (_ri205['width'],_ri205['height'],_ri205['bpp']) == (_ei205['width'],_ei205['height'],_ei205['bpp'])
    _po205, _ps205 = int(_ri205['pixel_offset']), int(_ri205['payload_size'])
    assert _ret_dic205[:_po205] == _es_dic205[:_po205]
    assert _ret_dic205[_po205+_ps205:] == _es_dic205[_po205+_ps205:]
print('EUR_DIC_BEFORE_JMB_205_GUARD_OK', len(_expected205))
_src200 = _inspect.getsource(compiler._eur_build_replacements)
assert 'retail_map = _eur_fr_jmb_retail_catalog()' in _src200
assert "stats['jmb_fr_retail_exact'] += 1" in _src200
print('EUR_FR_JMB_RETAIL_CATALOG_GUARD_OK', len(_cat200), _dar200)
# v1.7.7.204: todos los JMB de texto EUR deben compilarse sobre la estructura
# francesa retail. 114 bloques viajan precompilados; 77102/77304 usan sus rutas
# in-place verificadas y 55401/55403 se preservan porque la frase USA no existe FR.
import json as _json204, hashlib as _hashlib204
_cat204 = compiler._eur_fr_es_jmb_catalog()
assert len(_cat204) == 114, len(_cat204)
_doc204 = _json204.loads(compiler._EUR_FR_ES_JMB_MANIFEST.read_text(encoding='utf-8'))
assert set(_doc204.get('excluded') or []) == {
    'K7_0669_5540','K7_0684_5540','K7_0729_7710','K7_0750_7730'
}
_same204 = _ext204 = 0
for _fid204, _rec204 in _cat204.items():
    _ret204 = _cat200[_fid204]
    assert int(_rec204['jmb_index']) == int(_ret204['jmb_index'])
    assert int(_rec204['dic_index']) == int(_ret204['dic_index'])
    for _kind204 in ('jmb','dic'):
        _fp204 = compiler._EUR_FR_ES_JMB_DIR / _rec204[f'{_kind204}_file']
        _raw204 = _fp204.read_bytes()
        assert _hashlib204.sha256(_raw204).hexdigest() == _rec204[f'{_kind204}_sha256']
    _j204 = (compiler._EUR_FR_ES_JMB_DIR / _rec204['jmb_file']).read_bytes()
    _sn204, _cn204, _so204, _co204, _to204 = _struct199.unpack_from('<hhIII', _j204, 0)
    assert 0 < _sn204 < 100 and 0 < _cn204 < 500
    assert _so204 == 16 + 4 * _sn204
    assert _co204 - _so204 == compiler.JMB_SCENE_SIZE * _sn204
    assert _co204 + _cn204 * 8 <= _to204 <= len(_j204)
    if int(_rec204['original_jmb_size']) == int(_rec204['new_jmb_size']): _same204 += 1
    else: _ext204 += 1
assert (_same204, _ext204) == (74, 40), (_same204, _ext204)
_src204 = _inspect.getsource(compiler._eur_build_replacements)
assert 'precompiled_fr_es = _eur_fr_es_jmb_catalog().get(file_id)' in _src204
assert "stats['jmb_fr_es_precompiled'] += 1" in _src204
_src77102_204 = _inspect.getsource(compiler._eur_patch_77102_inplace_runtime)
_src77304_204 = _inspect.getsource(compiler._eur_patch_77304_inplace_runtime)
assert 'Cofre abierto' in _src77102_204
assert 'Grabado raro obtenido' in _src77304_204 and 'Cerrado con candado' in _src77304_204
print('EUR_ALL_FR_JMB_SPANISH_PRECOMPILED_GUARD_OK', len(_cat204), _same204, _ext204)
print('STARTUP_IMPORTS_OK')
PYTEST

# v1.7.7.203: la guía JMB francesa debe viajar dentro de la aplicación y ser visible desde la UI.
test -f resources/NOTA_JMB_FR_RETAIL.md
grep -q "77304 — Fire Ring" resources/NOTA_JMB_FR_RETAIL.md
grep -q "77102 — \"Soul Shell hallada\"" resources/NOTA_JMB_FR_RETAIL.md
grep -q "notebook.add(eur_jmb_frame, text='JMB EUR')" resources/app.py
grep -q "Nota técnica JMB francés" resources/app.py
echo "EUR_JMB_TECHNICAL_NOTE_GUARD_OK"

# v1.7.7.204: los JMB EUR traducibles se compilan sobre la estructura francesa retail.
"$PY" - <<'PY204'
import hashlib, inspect, json, pathlib, sys
root = pathlib.Path('.').resolve()
sys.path.insert(0, str(root / 'resources'))
import compiler
cat = compiler._eur_fr_es_jmb_catalog()
assert len(cat) == 114, len(cat)
manifest_path = root / 'resources' / 'eur_base' / 'jmb_fr_es_all' / 'manifest.json'
manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
assert manifest['format'] == 'killer7-eur-french-retail-spanish-precompiled'
assert manifest['excluded'] == [
    'K7_0669_5540', 'K7_0684_5540', 'K7_0729_7710', 'K7_0750_7730'
]
assert len(manifest['blocks']) == 114
extended = 0
dar_count = 0
for fid, rec in cat.items():
    assert fid not in manifest['excluded']
    for kind in ('jmb','dic'):
        fp = compiler._EUR_FR_ES_JMB_DIR / rec[f'{kind}_file']
        raw = fp.read_bytes()
        assert hashlib.sha256(raw).hexdigest() == rec[f'{kind}_sha256']
    extended += bool(rec.get('extended'))
    dar_count += rec.get('dar_index') is not None
assert extended == 40, extended
assert dar_count == 85, dar_count
src = inspect.getsource(compiler._eur_build_replacements)
assert '_eur_fr_es_jmb_catalog()' in src
assert "stats['jmb_fr_es_precompiled']" in src
src77102 = inspect.getsource(compiler._eur_patch_77102_inplace_runtime)
assert 'Soul Shell hallada' in src77102 and 'Cofre abierto' in src77102
src77304 = inspect.getsource(compiler._eur_patch_77304_inplace_runtime)
for text in ('Anillo de llama obtenido','Grabado raro obtenido','Cerrado con candado'):
    assert text in src77304
print('EUR_FR_ES_ALL_JMB_GUARD_OK', len(cat), extended, dar_count)
PY204

echo "STARTUP_RELEASE_CHECK_OK"
