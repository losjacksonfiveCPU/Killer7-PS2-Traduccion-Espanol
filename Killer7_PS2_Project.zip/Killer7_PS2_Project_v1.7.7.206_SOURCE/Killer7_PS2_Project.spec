# -*- mode: python ; coding: utf-8 -*-
from pathlib import Path
import sys

ROOT = Path(SPECPATH).resolve()
RES = ROOT / "resources"

datas = [
    (str(RES / "eur_base"), "resources/eur_base"),
    (str(RES / "master"), "resources/master"),
    (str(RES / "launcher_background.jpg"), "resources"),
    (str(RES / "source_catalog.json"), "resources"),
    (str(RES / "NOTA_JMB_FR_RETAIL.md"), "resources"),
    (str(ROOT / "Killer7EUR_GRAFICOS_FR.json"), "."),
    (str(ROOT / "Killer7EUR_K7P2_ES.json"), "."),
    (str(ROOT / "Killer7EUR_cinematicas_es.json"), "."),
    (str(ROOT / "THIRD_PARTY_NOTICES.md"), "."),
]

a = Analysis(
    [str(ROOT / "run.py")],
    pathex=[str(ROOT), str(RES)],
    binaries=[],
    datas=datas,
    hiddenimports=["PIL._tkinter_finder"],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=[],
    noarchive=False,
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    [],
    exclude_binaries=True,
    name="Killer7 PS2 Project",
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=False,
    console=False,
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
)

coll = COLLECT(
    exe,
    a.binaries,
    a.datas,
    strip=False,
    upx=False,
    name="Killer7 PS2 Project",
)

if sys.platform == "darwin":
    app = BUNDLE(
        coll,
        name="Killer7 PS2 Project.app",
        icon=None,
        bundle_identifier="org.killer7ps2.project",
        info_plist={
            "NSHighResolutionCapable": True,
            "CFBundleShortVersionString": "1.7.7.206",
        },
    )
