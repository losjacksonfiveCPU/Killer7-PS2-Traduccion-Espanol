# Killer7 PS2 Project

Herramienta Linux para traducir al español la edición PAL/EUR de **killer7** para PS2 y editar los textos del proyecto.

## Uso rápido

1. Ejecuta **Killer7 PS2 Project** o el acceso `.desktop`.
2. Pulsa **Seleccionar ISO** y elige tu ISO PAL/EUR compatible.
3. Pulsa **Traducir al Español** para generar una ISO traducida.
4. **Editor de Textos** abre la interfaz completa del proyecto.

La ISO original no se sobrescribe. El programa utiliza los recursos integrados en `resources/` y los catálogos JSON de la raíz.

## Estado integrado

Esta distribución conserva todas las correcciones acumuladas hasta v1.7.7.206, incluidas las traducciones del child 1 de `explan_f.dat`, los mensajes globales de `mes_f.dat`, las correcciones gráficas de dificultad y el menú inicial gráfico.

Al seleccionar una ISO desde la portada aparece un indicador **Cargando...** mientras se preparan sus recursos. **Traducir al Español** sólo se habilita al finalizar correctamente esa carga.

Las dos descripciones de dificultad (`text_a01F` y `text_b01F`) se prerasterizan ahora con exactamente la misma tipografía, tamaño 21, origen e interlineado, manteniendo 256×64 y la CLUT blanca monotónica.

## Archivos de soporte

- `VERIFY_STARTUP.sh`: comprobación de integridad/importación del paquete.
- `THIRD_PARTY_NOTICES.md`: avisos de componentes de terceros.

Los historiales `HOTFIX_*`, informes `INTERNAL_*` y artefactos `VALIDACION_*` se han retirado de esta distribución porque no intervienen en la ejecución.

## v1.7.7.190 — child 2 de explan_f.dat

Se traducen también los 53 rótulos franceses confirmados del child 2 de `explan_f.dat` usando el atlas retail `exlog`. `Jean DePaul` se conserva como nombre propio. El parche es in-place: no cambia atlas, offsets DAR ni tamaño del recurso.


## v1.7.7.191 — aviso de muestras de color

El savestate `s(20261001-200210)` mostró que el aviso de muestras de color podía convertirse en rectángulos blancos. Las escenas 16–21 de `mes_f.dat` usan una variante local del atlas de glifos, por lo que ya no se reutilizan caracteres tomados de otros avisos. Las seis escenas muestran ahora **se obtiene color**, construido únicamente con glifos presentes en el francés retail de esas mismas escenas. El cambio sigue siendo in-place y no modifica tamaños, fParams ni texturas.



## v1.7.7.206 — nuevas traducciones de subtítulos y cinemáticas

Se incorporan las revisiones entregadas en `Killer7_subtitulos_EN_ES_editables_por_bloque(1).zip`: **488 líneas de subtítulos `.da`** y **46 líneas de cinemáticas**, conservando IDs, tiempos y metadatos. Los `.da` se leen desde el XLIFF maestro integrado y se recompilan en la rama EUR sobre los glifos franceses; las cinemáticas se cargan desde `Killer7EUR_cinematicas_es.json`. Se añaden además donantes retail franceses para los símbolos `□`, `△`, `○` y `¯`, de modo que las nuevas referencias a botones se renderizan con glifos originales del juego y no con una fuente externa.

## v1.7.7.205 — corrección DIC-before-JMB en 9 bloques PAL

Se corrige una asociación de idioma descubierta al comparar `DIR_E.AFS` retail con el comportamiento real del ejecutable. En nueve bloques PAL el orden es `DIC -> JMB` por idioma; la v1.7.7.204 asociaba el JMB francés con el DIC alemán siguiente. El JMB español era correcto, pero sus índices de glifo se resolvían contra el atlas equivocado y aparecían caracteres aparentemente corruptos.

Bloques corregidos: `K7_0286_Handso` (#307→DIC #306), `K7_0315_h_007` (#528→#527), `K7_0317_h_007` (#534→#533), `K7_0319_h_010` (#540→#539), `K7_0321_h_010` (#546→#545), `K7_0323_h_010` (#552→#551), `K7_0325_h_020` (#558→#557), `K7_0327_h_035` (#564→#563) y `K7_0329_h_055` (#570→#569).

Los DIC españoles de esos nueve bloques se han reconstruido sobre el **contenedor francés correcto**, conservando cabecera, CLUT, metadatos y todos los bytes ajenos al payload gráfico. El atlas español recompilado hace round-trip 1:1. Se añade además un guard de regresión en `VERIFY_STARTUP.sh` y en el cargador del catálogo retail para impedir que esos File ID vuelvan a apuntar al DIC posterior.




## v1.7.7.204 — todos los JMB PAL franceses recompilados sobre retail

La rama EUR ya no trasplanta los JMB/DIC de la edición USA para los textos normales. 114 bloques se entregan precompilados directamente sobre sus JMB/DIC franceses retail; 77102 y 77304 usan rutas in-place dedicadas y traducen todas sus unidades textuales. Los dos recursos 55401/55403 cuya frase USA `Received tape` no existe en PAL se mantienen retail.

Cobertura validada: 116/118 bloques JMB con texto español, 2/118 preservados por ausencia de frase francesa equivalente. De los 114 payloads precompilados, 76 conservan también el tamaño JMB y 40 amplían únicamente la tabla fParams/tex_offset manteniendo la estructura de escenas PAL y el DIC francés con el mismo tamaño y metadatos.

Validación contra el `DIR_E.AFS` retail de referencia: 114/114 anclas JMB/DIC coinciden por SHA-256; 85 DAR espejo se reconstruyen correctamente (15 crecen por la ampliación controlada del JMB). El informe queda en `JMB_FR_ALL_VALIDATION.json`.

Casos verificados in-place:
- `77102`: `Soul Shell hallada` y `Cofre abierto`.
- `77304`: `Anillo de llama obtenido`, `Grabado raro obtenido` y `Cerrado con candado`; la escena especial 2 permanece intacta.

## v1.7.7.203 — Nota técnica JMB francés dentro del programa

Se añade una pestaña **JMB EUR** y el menú **Ayuda → Nota técnica JMB francés**. La guía documenta el procedimiento comprobado para textos JMB franceses: localizar la frase retail real, parchear sobre JMB/DIC francés in-place, conservar tamaños/layout cuando sea posible, validar donors y reconstruir DAR espejo. Incluye los casos verificados 77102 (Soul Shell) y 77304 ("Anneau de feu récupéré" → "Anillo de llama obtenido"), además de las rutas descartadas que producían bloques blancos. La misma nota queda en `resources/NOTA_JMB_FR_RETAIL.md`.

## v1.7.7.202 — 77304 in-place como Soul Shell

El mensaje retail francés `Anneau de feu récupéré` se parchea ahora directamente sobre la terna francesa `77304` (#1793/#1794/#1795), con la misma estrategia same-size que el caso `77102`/Soul Shell que ya se muestra correctamente en juego. Se conserva `char_num=37`; el slot 6 (`f`, exclusivo de la escena del anillo) se redirige a una zona vacía del atlas y allí se copia un `m` oficial de la misma fuente francesa desde `55101` (#1524/#1526, slot 20). No se trasplanta el JMB/DIC USA para este recurso.

## v1.7.7.201 — traducciones ubicadas por la variante francesa real

Se han comparado los 118 JMB traducidos con los JMB franceses retail y con su variante inglesa PAL contigua. De las 743 unidades traducidas, 663 conservan exactamente la misma posición francesa; 47 pertenecen a la misma escena pero el francés usa un corte de líneas distinto; 29 se remapean por escena; y 4 unidades USA no tienen frase equivalente en francés.

La diferencia semántica importante está en `K7_0319_h_010`: el francés tiene 11 escenas y omite la escena inglesa **“But I decided to put my life first.”**. El inyector elimina esa escena de la carga española y desplaza las escenas posteriores según el JMB francés, en vez de imponer la estructura USA de 12 escenas.

`K7_0669_5540` y `K7_0684_5540` contienen en francés únicamente el recurso gráfico `M2B`; la unidad USA **“Received tape”** no existe en esos JMB PAL. Por eso esos dos pares JMB/DIC/DAR se dejan retail y ya no reciben una traducción asociada a una frase inexistente.

También se corrige `mes_f.dat`: las escenas 16–21 dicen literalmente **“Échantillons couleur obtenus”**. Los IDs 45–50 son selectores de objeto, pero no convierten ese texto en seis nombres de anillos. Esas seis escenas se traducen ahora como **“muestras de color obtenidas”**. El aviso real del Fire Ring permanece en `77304` (#1793–1795), donde **“Anneau de feu récupéré”** se traduce como **“Anillo de llama obtenido”**. `SystemF` permanece byte por byte intacto.

Los archivos `JMB_FR_TRANSLATION_BLOCK_MAP.csv` y `JMB_FR_TRANSLATION_UNIT_MAP.csv` documentan el destino francés de cada bloque y cada unidad traducida.

## v1.7.7.200 — catálogo JMB francés retail real

La rama EUR ya no decide los 118 JMB principales mediante la heurística histórica `3*k+1` durante la inyección. Esta distribución incluye en `resources/eur_base/jmb_fr_retail/` las copias reales extraídas de `DIR_E.AFS` PAL: 118 JMB, 118 DIC y 89 DAR espejo, junto con un `manifest.json` que fija índice AFS, nombre, tamaño y SHA-256 para cada `File ID`.

Antes de sustituir un texto, el inyector compara el JMB/DIC/DAR de la ISO con la copia francesa retail empaquetada. Si no coincide byte por byte, aborta. Esto evita escribir por error sobre la variante inglesa, alemana o una subvariante numérica distinta. El caso Fire Ring queda anclado a `K7_0750_7730 -> 77304 #1793/#1794/#1795`.

## v1.7.7.199 — preservación de SystemF (nota histórica)

Esta revisión estableció que `SystemF` debía conservarse byte por byte para evitar los bloques blancos observados en GS. La asociación provisional de `mes_f.dat` 16–21 con nombres de anillos quedó **corregida en v1.7.7.201** después de comparar los JMB franceses reales. La regla que permanece vigente es únicamente la preservación total de `SystemF`.


## TEST v1.7.7.199 — Fire Ring / 77304
Prueba focalizada sobre K7_0750_7730, que la edición EUR mapea a DIR_E.AFS #1793-1795 (77304). La escena 0 se compila como `Anillo de llama obtenido` y se añade un único glifo `m` al atlas JMB/DIC compilado. No se modifica SystemF ni el SLES para este cambio.
