# Killer7 PS2 Project — código fuente v1.7.7.206

Esta edición contiene el **código fuente portable** del proyecto, sin el ejecutable ELF ni el runtime Linux que llevaba la distribución anterior. El mismo árbol está preparado para ejecutarse con Python y para generar builds nativas de Windows, Linux y macOS mediante PyInstaller.

## Requisitos

- Python **3.10–3.13**.
- Tkinter/Tk disponible en la instalación de Python.
- Pillow (se instala desde `requirements.txt`).
- Para crear ejecutables: PyInstaller (incluido en `requirements-dev.txt`).

En Windows y macOS, las distribuciones oficiales de Python suelen incluir Tk. En Debian/Ubuntu puede ser necesario instalar `python3-tk` con el gestor de paquetes del sistema.

## Ejecutar desde código fuente

```bash
python -m pip install -r requirements.txt
python run.py
```

El punto de entrada es `run.py`; el código principal está en `resources/`. En modo fuente, los proyectos editables continúan guardándose dentro de este mismo árbol para facilitar su revisión y versionado.

## Verificar el código

Comprobación portable:

```bash
python scripts/verify_source.py
```

En Linux/macOS también se conserva la batería histórica ampliada, adaptada para usar el Python del sistema:

```bash
./VERIFY_STARTUP.sh
```

## Preparar el entorno de build

```bash
python -m venv .venv
```

Windows:

```bat
.venv\Scripts\activate
python -m pip install -U pip
python -m pip install -r requirements-dev.txt
scripts\build_windows.bat
```

Linux/macOS:

```bash
source .venv/bin/activate
python -m pip install -U pip
python -m pip install -r requirements-dev.txt
./scripts/build_linux.sh      # Linux
./scripts/build_macos.sh      # macOS
```

Los resultados aparecen en `dist/`. La configuración usa **onedir** en Windows/Linux y genera además una `.app` en macOS. Se ha elegido onedir porque el proyecto incluye decenas de MB de recursos; un único ejecutable tendría que extraerlos temporalmente en cada arranque.

### Importante sobre las plataformas

PyInstaller no hace cross-compilation real entre estos sistemas. Para obtener una build fiable:

- el `.exe` se genera en Windows;
- el binario Linux se genera en Linux;
- la `.app` se genera en macOS.

En macOS, la arquitectura de la aplicación depende del Python usado para construirla (Apple Silicon o Intel). Para una aplicación universal2 hay que usar un Python universal2 y comprobar que todas las dependencias incluidas también lo sean.

## Recursos y datos editables

`resources/platform_paths.py` centraliza las rutas.

- **Código fuente:** mantiene el comportamiento histórico y lee/escribe en el checkout.
- **Build empaquetada:** los recursos originales se leen desde el bundle; los archivos que deben poder modificarse se copian automáticamente, en su primer uso, a una carpeta escribible del usuario.

Ubicación de datos de una build empaquetada:

- Windows: `%LOCALAPPDATA%\Killer7 PS2 Project` (o `%APPDATA%` como fallback).
- macOS: `~/Library/Application Support/Killer7 PS2 Project`.
- Linux: `$XDG_DATA_HOME/Killer7 PS2 Project` o `~/.local/share/Killer7 PS2 Project`.

Ahí se guardan, entre otros, `CAMBIOS_PROYECTO.log`, el XLIFF maestro editable, `source_catalog.json` y `Killer7EUR_cinematicas_es.json`.

## Estructura relevante

```text
run.py                         punto de entrada portable
resources/app.py               interfaz Tk
resources/compiler.py          compilador/parcheador
resources/core.py              ISO/AFS/JMB/DIC y modelos
resources/xliff_io.py          XLIFF
resources/glyph_memory.py      glifos
resources/platform_paths.py    rutas source/frozen multiplataforma
resources/eur_base/            recursos PAL/EUR integrados
resources/master/              XLIFF maestro
scripts/verify_source.py       verificación portable
scripts/build.py               build PyInstaller
Killer7_PS2_Project.spec       configuración común de empaquetado
```

## Qué se ha eliminado respecto a la distribución Linux

No forman parte del paquete SOURCE:

- `resources/runtime/` (Python/Tcl/Tk/Pillow Linux embebidos);
- el ELF `Killer7 PS2 Project`;
- el acceso `.desktop`;
- el lanzador Linux `Killer7_XLIFF.sh`;
- cachés `__pycache__`/`.pyc`.

Esto evita mezclar binarios de una plataforma concreta con el código que después se empaquetará para otros sistemas.

## Historial funcional

La lógica y los recursos corresponden a **v1.7.7.206**, incluidas las nuevas traducciones y la corrección de los 9 pares DIC-before-JMB. El README completo de la distribución anterior se conserva en `docs/README_RELEASE_HISTORY.md`.

## Nota sobre ISO y recursos del juego

El proyecto no debe sobrescribir la ISO original. Las builds siguen usando las verificaciones de serial, estructura, tamaños y hashes existentes antes de reemplazar recursos.
