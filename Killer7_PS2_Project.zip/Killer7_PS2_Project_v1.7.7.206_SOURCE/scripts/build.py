from __future__ import annotations

import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SPEC = ROOT / "Killer7_PS2_Project.spec"


def main() -> int:
    if sys.version_info < (3, 10):
        raise SystemExit("Se requiere Python 3.10 o posterior.")
    cmd = [sys.executable, "-m", "PyInstaller", "--clean", "--noconfirm", str(SPEC)]
    print("Sistema:", sys.platform)
    print("Python:", sys.version.split()[0])
    print("Build:", " ".join(cmd))
    subprocess.run(cmd, cwd=ROOT, check=True)
    print("\nBuild terminada en:", ROOT / "dist")
    if sys.platform == "darwin":
        print("macOS: la arquitectura de la .app es la arquitectura del Python usado para compilar.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
