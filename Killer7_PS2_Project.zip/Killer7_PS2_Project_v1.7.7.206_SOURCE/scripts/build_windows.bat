@echo off
setlocal
cd /d "%~dp0\.."
py -3 scripts\verify_source.py || exit /b 1
py -3 scripts\build.py
