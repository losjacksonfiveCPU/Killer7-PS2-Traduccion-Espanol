from __future__ import annotations

import compileall
import importlib
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
RES = ROOT / "resources"
sys.path.insert(0, str(RES))

REQUIRED = [
    ROOT / "run.py",
    RES / "app.py",
    RES / "compiler.py",
    RES / "core.py",
    RES / "xliff_io.py",
    RES / "glyph_memory.py",
    RES / "platform_paths.py",
    RES / "launcher_background.jpg",
    RES / "source_catalog.json",
    RES / "master" / "Killer7_SLUS-21154_master_ES_started.xlf",
    RES / "eur_base" / "compiled_es_4759" / "manifest.json",
    ROOT / "Killer7EUR_GRAFICOS_FR.json",
    ROOT / "Killer7EUR_K7P2_ES.json",
    ROOT / "Killer7EUR_cinematicas_es.json",
]


def main() -> int:
    missing = [str(p.relative_to(ROOT)) for p in REQUIRED if not p.exists()]
    if missing:
        raise SystemExit("Faltan recursos requeridos:\n- " + "\n- ".join(missing))
    if (RES / "runtime").exists():
        raise SystemExit("El árbol SOURCE no debe incluir resources/runtime.")

    ok = compileall.compile_dir(RES, quiet=1, force=True)
    if not ok:
        raise SystemExit("Falló compileall.")

    import tkinter  # noqa: F401
    import PIL
    for name in ("platform_paths", "core", "xliff_io", "glyph_memory", "compiler", "app"):
        importlib.import_module(name)

    from platform_paths import resource_root, resource_path
    assert resource_root() == ROOT
    assert resource_path("resources", "eur_base").is_dir()

    print("SOURCE_VERIFY_OK")
    print("Python", sys.version.split()[0])
    print("Pillow", PIL.__version__)
    print("Tk", tkinter.TkVersion)
    print("Root", ROOT)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
